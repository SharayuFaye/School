<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-28 10:26:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 10:26:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 10:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 10:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 10:27:06 --> Total execution time: 7.9319
ERROR - 2019-11-28 10:27:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 10:49:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 10:49:18 --> No URI present. Default controller set.
DEBUG - 2019-11-28 10:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 10:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 10:49:19 --> mmd :: Mmd@1234
DEBUG - 2019-11-28 10:49:19 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-28 10:49:20 --> Total execution time: 1.2921
ERROR - 2019-11-28 10:49:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 10:52:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 10:52:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 10:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 10:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 10:52:02 --> Total execution time: 0.0264
ERROR - 2019-11-28 10:52:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 10:52:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 10:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 10:52:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 10:52:03 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-28 10:52:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:05:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:05:38 --> Total execution time: 0.0031
ERROR - 2019-11-28 12:08:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:07 --> No URI present. Default controller set.
DEBUG - 2019-11-28 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:08:07 --> admin :: admin
DEBUG - 2019-11-28 12:08:07 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-28 12:08:07 --> Total execution time: 0.0244
ERROR - 2019-11-28 12:08:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:08:28 --> Total execution time: 0.0569
ERROR - 2019-11-28 12:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:08:28 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-28 12:08:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-28 12:08:35 --> Query error: Table 'db_school.user' doesn't exist - Invalid query: DELETE FROM `user`
WHERE `school_id` = '28'
DEBUG - 2019-11-28 12:08:35 --> Total execution time: 0.0981
ERROR - 2019-11-28 12:08:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:08:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:08:35 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-28 12:08:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:08:38 --> Total execution time: 0.0282
ERROR - 2019-11-28 12:08:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:08:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:08:44 --> Total execution time: 0.0088
ERROR - 2019-11-28 12:08:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:08:44 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-28 12:08:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:08:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:08:58 --> Total execution time: 0.2437
ERROR - 2019-11-28 12:08:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:08:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:08:58 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-28 12:09:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:09:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:09:00 --> Total execution time: 0.0082
ERROR - 2019-11-28 12:09:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:09:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:09:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:09:51 --> Total execution time: 0.0050
ERROR - 2019-11-28 12:10:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:10:13 --> Total execution time: 0.1032
ERROR - 2019-11-28 12:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:10:15 --> Total execution time: 0.0052
ERROR - 2019-11-28 12:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:10:15 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-28 12:11:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:11:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:11:45 --> Total execution time: 0.0034
ERROR - 2019-11-28 12:11:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:11:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:11:51 --> No URI present. Default controller set.
DEBUG - 2019-11-28 12:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:11:51 --> mmd :: Mmd@123
DEBUG - 2019-11-28 12:11:51 --> mmd :: 451e5aab7012b98a36d7847beb40ddc3
DEBUG - 2019-11-28 12:11:51 --> Total execution time: 0.0034
ERROR - 2019-11-28 12:11:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:11:58 --> No URI present. Default controller set.
DEBUG - 2019-11-28 12:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:11:58 --> mmd :: Mmd@1234
DEBUG - 2019-11-28 12:11:58 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-28 12:11:58 --> Total execution time: 0.0653
ERROR - 2019-11-28 12:12:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:12:02 --> Total execution time: 0.0434
ERROR - 2019-11-28 12:13:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:13:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:13:02 --> Total execution time: 0.0237
ERROR - 2019-11-28 12:13:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:13:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:13:07 --> Total execution time: 0.0059
ERROR - 2019-11-28 12:15:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:15:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:15:26 --> Total execution time: 0.0021
ERROR - 2019-11-28 12:15:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:15:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:15:30 --> No URI present. Default controller set.
DEBUG - 2019-11-28 12:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:15:30 --> admin :: admin
DEBUG - 2019-11-28 12:15:30 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-28 12:15:30 --> Total execution time: 0.0229
ERROR - 2019-11-28 12:15:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:15:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:15:35 --> Total execution time: 0.0083
ERROR - 2019-11-28 12:15:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:15:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:15:38 --> Total execution time: 0.0099
ERROR - 2019-11-28 12:15:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:15:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:15:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:15:38 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-28 12:19:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:19:10 --> Total execution time: 0.0113
ERROR - 2019-11-28 12:19:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:19:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:19:10 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-28 12:19:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-28 12:19:14 --> Query error: Table 'db_school.user' doesn't exist - Invalid query: DELETE FROM `user`
WHERE `school_id` = '29'
ERROR - 2019-11-28 12:19:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-28 12:19:54 --> Query error: Table 'db_school.user' doesn't exist - Invalid query: DELETE FROM `user`
WHERE `school_id` = '29'
DEBUG - 2019-11-28 12:19:54 --> Total execution time: 0.0112
ERROR - 2019-11-28 12:19:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:19:54 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-28 12:19:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:19:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:19:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:19:57 --> Total execution time: 0.0049
ERROR - 2019-11-28 12:20:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:20:45 --> Total execution time: 0.0137
ERROR - 2019-11-28 12:20:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:20:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:20:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:20:48 --> Total execution time: 0.0075
ERROR - 2019-11-28 12:20:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:20:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:20:48 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-28 12:21:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:21:05 --> Total execution time: 0.2044
ERROR - 2019-11-28 12:21:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:21:05 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-28 12:21:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:21:07 --> Total execution time: 0.0038
ERROR - 2019-11-28 12:21:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:21:31 --> Total execution time: 0.0916
ERROR - 2019-11-28 12:21:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:21:33 --> Total execution time: 0.0046
ERROR - 2019-11-28 12:21:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:21:33 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-28 12:21:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:21:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:21:37 --> Total execution time: 0.1516
ERROR - 2019-11-28 12:21:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 12:21:37 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-28 12:21:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:21:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:21:39 --> Total execution time: 0.0052
ERROR - 2019-11-28 12:24:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:24:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:24:20 --> Total execution time: 0.0037
ERROR - 2019-11-28 12:24:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:24:27 --> No URI present. Default controller set.
DEBUG - 2019-11-28 12:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:24:27 --> mmd :: Mmd@1234
DEBUG - 2019-11-28 12:24:27 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-28 12:24:28 --> Total execution time: 0.0896
ERROR - 2019-11-28 12:24:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:24:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:24:34 --> Total execution time: 0.0076
ERROR - 2019-11-28 12:29:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:29:15 --> Total execution time: 0.0069
ERROR - 2019-11-28 12:30:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:30:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:30:02 --> Total execution time: 0.0041
ERROR - 2019-11-28 12:30:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:30:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:30:39 --> Total execution time: 0.0042
ERROR - 2019-11-28 12:31:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:31:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:31:23 --> Total execution time: 0.0067
ERROR - 2019-11-28 12:31:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:31:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:31:24 --> Total execution time: 0.0068
ERROR - 2019-11-28 12:31:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:31:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:31:24 --> Total execution time: 0.0037
ERROR - 2019-11-28 12:31:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:31:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:31:50 --> Total execution time: 0.0074
ERROR - 2019-11-28 12:34:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:34:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:34:46 --> Total execution time: 0.0062
ERROR - 2019-11-28 12:34:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:34:47 --> Total execution time: 0.0040
ERROR - 2019-11-28 12:34:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:34:47 --> Total execution time: 0.0054
ERROR - 2019-11-28 12:34:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:34:47 --> Total execution time: 0.0039
ERROR - 2019-11-28 12:34:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:34:48 --> Total execution time: 0.0045
ERROR - 2019-11-28 12:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:36:42 --> Total execution time: 0.0070
ERROR - 2019-11-28 12:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:36:43 --> Total execution time: 0.0057
ERROR - 2019-11-28 12:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:36:43 --> Total execution time: 0.0040
ERROR - 2019-11-28 12:36:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:36:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:36:44 --> Total execution time: 0.0056
ERROR - 2019-11-28 12:38:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:38:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:38:41 --> Total execution time: 0.0059
ERROR - 2019-11-28 12:38:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:38:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:38:42 --> Total execution time: 0.0095
ERROR - 2019-11-28 12:39:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:39:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:39:27 --> Total execution time: 0.0063
ERROR - 2019-11-28 12:39:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:39:28 --> Total execution time: 0.0039
ERROR - 2019-11-28 12:40:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:40:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:40:08 --> Total execution time: 0.0094
ERROR - 2019-11-28 12:40:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:40:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:40:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:40:09 --> Total execution time: 0.0033
ERROR - 2019-11-28 12:40:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:40:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:40:09 --> Total execution time: 0.0027
ERROR - 2019-11-28 12:40:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:40:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:40:09 --> Total execution time: 0.0044
ERROR - 2019-11-28 12:40:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:40:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:40:35 --> Total execution time: 0.0089
ERROR - 2019-11-28 12:42:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:42:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:42:34 --> Total execution time: 0.0064
ERROR - 2019-11-28 12:42:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:42:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:42:35 --> Total execution time: 0.0053
ERROR - 2019-11-28 12:42:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:42:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:42:35 --> Total execution time: 0.0034
ERROR - 2019-11-28 12:42:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:42:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:42:35 --> Total execution time: 0.0045
ERROR - 2019-11-28 12:47:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:47:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:47:17 --> Total execution time: 0.0050
ERROR - 2019-11-28 12:47:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:47:18 --> Total execution time: 0.0044
ERROR - 2019-11-28 12:47:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:47:18 --> Total execution time: 0.0037
ERROR - 2019-11-28 12:47:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:47:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:47:59 --> Total execution time: 0.0045
ERROR - 2019-11-28 12:47:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:47:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:47:59 --> Total execution time: 0.0072
ERROR - 2019-11-28 12:49:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:49:48 --> Total execution time: 0.0047
ERROR - 2019-11-28 12:49:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:49:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:49:49 --> Total execution time: 0.0036
ERROR - 2019-11-28 12:52:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:52:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:52:40 --> Total execution time: 0.0065
ERROR - 2019-11-28 12:52:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:52:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:52:41 --> Total execution time: 0.0087
ERROR - 2019-11-28 12:53:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:53:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:53:00 --> Total execution time: 0.0373
ERROR - 2019-11-28 12:55:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:55:05 --> Total execution time: 0.0043
ERROR - 2019-11-28 12:55:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:55:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:55:06 --> Total execution time: 0.0041
ERROR - 2019-11-28 12:55:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:55:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:55:06 --> Total execution time: 0.0047
ERROR - 2019-11-28 12:55:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:55:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:55:06 --> Total execution time: 0.0035
ERROR - 2019-11-28 12:55:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:55:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:55:27 --> Total execution time: 0.0039
ERROR - 2019-11-28 12:55:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:55:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:55:28 --> Total execution time: 0.0081
ERROR - 2019-11-28 12:55:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:55:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:55:46 --> Total execution time: 0.0031
ERROR - 2019-11-28 12:55:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:55:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:55:46 --> Total execution time: 0.0041
ERROR - 2019-11-28 12:56:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:19 --> Total execution time: 0.0058
ERROR - 2019-11-28 12:56:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:20 --> Total execution time: 0.0067
ERROR - 2019-11-28 12:56:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:20 --> Total execution time: 0.0037
ERROR - 2019-11-28 12:56:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:21 --> Total execution time: 0.0040
ERROR - 2019-11-28 12:56:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:21 --> Total execution time: 0.0073
ERROR - 2019-11-28 12:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:54 --> Total execution time: 0.0066
ERROR - 2019-11-28 12:56:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:55 --> Total execution time: 0.0044
ERROR - 2019-11-28 12:56:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:55 --> Total execution time: 0.0039
ERROR - 2019-11-28 12:56:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:55 --> Total execution time: 0.0040
ERROR - 2019-11-28 12:56:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:56 --> Total execution time: 0.0041
ERROR - 2019-11-28 12:56:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:57 --> Total execution time: 0.0042
ERROR - 2019-11-28 12:56:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:58 --> Total execution time: 0.0038
ERROR - 2019-11-28 12:56:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:58 --> Total execution time: 0.0023
ERROR - 2019-11-28 12:56:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:58 --> Total execution time: 0.0036
ERROR - 2019-11-28 12:56:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:56:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:56:58 --> Total execution time: 0.0038
ERROR - 2019-11-28 12:57:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:51 --> Total execution time: 0.0044
ERROR - 2019-11-28 12:57:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:51 --> Total execution time: 0.0059
ERROR - 2019-11-28 12:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:52 --> Total execution time: 0.0031
ERROR - 2019-11-28 12:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:52 --> Total execution time: 0.0036
ERROR - 2019-11-28 12:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:52 --> Total execution time: 0.0039
ERROR - 2019-11-28 12:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:52 --> Total execution time: 0.0052
ERROR - 2019-11-28 12:57:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:52 --> Total execution time: 0.0042
ERROR - 2019-11-28 12:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:53 --> Total execution time: 0.0035
ERROR - 2019-11-28 12:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:53 --> Total execution time: 0.0044
ERROR - 2019-11-28 12:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:57:53 --> Total execution time: 0.0033
ERROR - 2019-11-28 12:58:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:23 --> Total execution time: 0.0064
ERROR - 2019-11-28 12:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:24 --> Total execution time: 0.0039
ERROR - 2019-11-28 12:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:24 --> Total execution time: 0.0046
ERROR - 2019-11-28 12:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:24 --> Total execution time: 0.0048
ERROR - 2019-11-28 12:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:24 --> Total execution time: 0.0039
ERROR - 2019-11-28 12:58:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:25 --> Total execution time: 0.0043
ERROR - 2019-11-28 12:58:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:25 --> Total execution time: 0.0058
ERROR - 2019-11-28 12:58:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:25 --> Total execution time: 0.0035
ERROR - 2019-11-28 12:58:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:25 --> Total execution time: 0.0232
ERROR - 2019-11-28 12:58:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:43 --> Total execution time: 0.0082
ERROR - 2019-11-28 12:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:44 --> Total execution time: 0.0036
ERROR - 2019-11-28 12:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:44 --> Total execution time: 0.0037
ERROR - 2019-11-28 12:58:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:45 --> Total execution time: 0.0045
ERROR - 2019-11-28 12:58:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:45 --> Total execution time: 0.0049
ERROR - 2019-11-28 12:58:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:45 --> Total execution time: 0.0034
ERROR - 2019-11-28 12:58:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:45 --> Total execution time: 0.0037
ERROR - 2019-11-28 12:58:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:51 --> Total execution time: 0.0051
ERROR - 2019-11-28 12:58:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:58:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:52 --> Total execution time: 0.0047
ERROR - 2019-11-28 12:58:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:58:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:58:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:58:52 --> Total execution time: 0.0052
ERROR - 2019-11-28 12:58:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:59:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:40 --> Total execution time: 0.0059
ERROR - 2019-11-28 12:59:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:41 --> Total execution time: 0.0058
ERROR - 2019-11-28 12:59:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:41 --> Total execution time: 0.0066
ERROR - 2019-11-28 12:59:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:41 --> Total execution time: 0.0065
ERROR - 2019-11-28 12:59:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:41 --> Total execution time: 0.0040
ERROR - 2019-11-28 12:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:42 --> Total execution time: 0.0058
ERROR - 2019-11-28 12:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:42 --> Total execution time: 0.0034
ERROR - 2019-11-28 12:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:42 --> Total execution time: 0.0029
ERROR - 2019-11-28 12:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:42 --> Total execution time: 0.0047
ERROR - 2019-11-28 12:59:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 12:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:42 --> Total execution time: 0.0037
ERROR - 2019-11-28 12:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:42 --> Total execution time: 0.0056
ERROR - 2019-11-28 12:59:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 12:59:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 12:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 12:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 12:59:43 --> Total execution time: 0.0050
ERROR - 2019-11-28 13:00:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:00:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:00:43 --> Total execution time: 0.0081
ERROR - 2019-11-28 13:00:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:00:44 --> Total execution time: 0.0066
ERROR - 2019-11-28 13:00:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:00:44 --> Total execution time: 0.0039
ERROR - 2019-11-28 13:00:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:00:44 --> Total execution time: 0.0032
ERROR - 2019-11-28 13:00:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:00:44 --> Total execution time: 0.0036
ERROR - 2019-11-28 13:00:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:00:44 --> Total execution time: 0.0037
ERROR - 2019-11-28 13:00:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:00:44 --> Total execution time: 0.0047
ERROR - 2019-11-28 13:02:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:02:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:02:11 --> Total execution time: 0.0054
ERROR - 2019-11-28 13:02:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:02:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:02:12 --> Total execution time: 0.0033
ERROR - 2019-11-28 13:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:02:13 --> Total execution time: 0.0038
ERROR - 2019-11-28 13:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:02:13 --> Total execution time: 0.0044
ERROR - 2019-11-28 13:02:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:02:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:02:14 --> Total execution time: 0.0040
ERROR - 2019-11-28 13:02:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:02:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:02:36 --> Total execution time: 0.0970
ERROR - 2019-11-28 13:02:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:02:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:02:42 --> Total execution time: 0.0029
ERROR - 2019-11-28 13:03:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:03:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:03:21 --> Total execution time: 0.0092
ERROR - 2019-11-28 13:03:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:03:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:03:21 --> Total execution time: 0.0104
ERROR - 2019-11-28 13:03:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 13:03:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:03:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:03:34 --> Total execution time: 0.1694
ERROR - 2019-11-28 13:03:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:03:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:03:39 --> Total execution time: 0.0028
ERROR - 2019-11-28 13:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:04:56 --> Total execution time: 0.0047
ERROR - 2019-11-28 13:04:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:04:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:04:59 --> Total execution time: 0.0281
ERROR - 2019-11-28 13:04:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:04:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 13:04:59 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-28 13:05:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:05:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:05:06 --> Total execution time: 0.0029
ERROR - 2019-11-28 13:05:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:05:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:05:13 --> Total execution time: 0.0034
ERROR - 2019-11-28 13:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:00 --> Total execution time: 0.0057
ERROR - 2019-11-28 13:07:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 13:07:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:01 --> Total execution time: 0.0044
ERROR - 2019-11-28 13:07:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:01 --> Total execution time: 0.0052
ERROR - 2019-11-28 13:07:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:06 --> Total execution time: 0.0036
ERROR - 2019-11-28 13:07:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:07 --> Total execution time: 0.0038
ERROR - 2019-11-28 13:07:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:08 --> Total execution time: 0.0062
ERROR - 2019-11-28 13:07:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:08 --> Total execution time: 0.0093
ERROR - 2019-11-28 13:07:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:08 --> Total execution time: 0.0039
ERROR - 2019-11-28 13:07:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:21 --> Total execution time: 0.0661
ERROR - 2019-11-28 13:07:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:07:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:07:25 --> Total execution time: 0.0026
ERROR - 2019-11-28 13:09:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:19 --> Total execution time: 0.0057
ERROR - 2019-11-28 13:09:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:20 --> Total execution time: 0.0030
ERROR - 2019-11-28 13:09:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:20 --> Total execution time: 0.0028
ERROR - 2019-11-28 13:09:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:21 --> Total execution time: 0.0032
ERROR - 2019-11-28 13:09:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:21 --> Total execution time: 0.0085
ERROR - 2019-11-28 13:09:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 13:09:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:21 --> Total execution time: 0.0044
ERROR - 2019-11-28 13:09:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:23 --> Total execution time: 0.0026
ERROR - 2019-11-28 13:09:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:25 --> Total execution time: 0.0042
ERROR - 2019-11-28 13:09:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:26 --> Total execution time: 0.0026
ERROR - 2019-11-28 13:09:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:34 --> Total execution time: 0.0055
ERROR - 2019-11-28 13:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:09:37 --> Total execution time: 0.0039
ERROR - 2019-11-28 13:10:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:10:06 --> Total execution time: 0.0053
ERROR - 2019-11-28 13:10:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:10:06 --> Total execution time: 0.0042
ERROR - 2019-11-28 13:10:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:10:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:10:07 --> Total execution time: 0.0083
ERROR - 2019-11-28 13:10:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 13:10:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:10:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:10:11 --> Total execution time: 0.0033
ERROR - 2019-11-28 13:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:10:47 --> Total execution time: 0.0081
ERROR - 2019-11-28 13:10:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 13:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:10:47 --> Total execution time: 0.0061
ERROR - 2019-11-28 13:10:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:10:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:10:48 --> Total execution time: 0.0043
ERROR - 2019-11-28 13:10:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:10:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:10:51 --> Total execution time: 0.0033
ERROR - 2019-11-28 13:11:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:11:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:11:18 --> Total execution time: 0.0045
ERROR - 2019-11-28 13:11:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:11:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:11:18 --> Total execution time: 0.0064
ERROR - 2019-11-28 13:11:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:11:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:11:19 --> Total execution time: 0.0040
ERROR - 2019-11-28 13:11:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:11:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:11:21 --> Total execution time: 0.0027
ERROR - 2019-11-28 13:12:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:12:16 --> Total execution time: 0.0045
ERROR - 2019-11-28 13:12:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:12:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:12:17 --> Total execution time: 0.0060
ERROR - 2019-11-28 13:12:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:12:20 --> Total execution time: 0.0031
ERROR - 2019-11-28 13:12:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:12:29 --> Total execution time: 0.1307
ERROR - 2019-11-28 13:12:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:12:59 --> Total execution time: 0.0552
ERROR - 2019-11-28 13:13:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:13:06 --> Total execution time: 0.0021
ERROR - 2019-11-28 13:13:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 13:13:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 13:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 13:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 13:13:11 --> Total execution time: 0.0601
ERROR - 2019-11-28 15:02:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:02:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 15:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 15:02:57 --> Total execution time: 0.0843
ERROR - 2019-11-28 15:02:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-28 15:02:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:02:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 15:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 15:02:59 --> Total execution time: 0.0044
ERROR - 2019-11-28 15:03:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:03:04 --> No URI present. Default controller set.
DEBUG - 2019-11-28 15:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 15:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 15:03:04 --> admin :: admin
DEBUG - 2019-11-28 15:03:04 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-28 15:03:04 --> Total execution time: 0.0175
ERROR - 2019-11-28 15:03:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:03:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 15:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 15:03:08 --> Total execution time: 0.0085
ERROR - 2019-11-28 15:03:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:03:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:03:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-28 15:03:09 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-28 15:03:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:03:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 15:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 15:03:21 --> Total execution time: 0.0056
ERROR - 2019-11-28 15:34:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:34:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 15:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 15:34:09 --> Total execution time: 0.0050
ERROR - 2019-11-28 15:34:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:34:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:34:14 --> No URI present. Default controller set.
DEBUG - 2019-11-28 15:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 15:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 15:34:14 --> mmd :: Mmd@1234
DEBUG - 2019-11-28 15:34:14 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-28 15:34:14 --> Total execution time: 0.0776
ERROR - 2019-11-28 15:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-28 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-28 15:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-28 15:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-28 15:34:18 --> Total execution time: 0.0052
