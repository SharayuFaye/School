<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-18 04:52:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 04:52:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 04:52:58 --> No URI present. Default controller set.
DEBUG - 2019-09-18 04:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 04:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 04:52:58 --> Total execution time: 0.0245
ERROR - 2019-09-18 04:53:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 04:53:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 04:53:27 --> No URI present. Default controller set.
DEBUG - 2019-09-18 04:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 04:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 04:53:27 --> Total execution time: 0.0077
ERROR - 2019-09-18 05:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:16:52 --> Total execution time: 0.0044
ERROR - 2019-09-18 05:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:16:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:16:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:16:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:16:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:16:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:16:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:18:04 --> Total execution time: 0.0065
ERROR - 2019-09-18 05:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:18:10 --> Total execution time: 0.0021
ERROR - 2019-09-18 05:18:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:18:12 --> Total execution time: 0.0054
ERROR - 2019-09-18 05:18:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:18:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:18:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:18:26 --> Total execution time: 0.0055
ERROR - 2019-09-18 05:18:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:18:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:18:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:18:28 --> Total execution time: 0.0039
ERROR - 2019-09-18 05:18:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:18:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:18:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:18:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:18:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:25:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:25:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:25:35 --> No URI present. Default controller set.
DEBUG - 2019-09-18 05:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:25:35 --> Total execution time: 0.0019
ERROR - 2019-09-18 05:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:25:44 --> No URI present. Default controller set.
DEBUG - 2019-09-18 05:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:25:44 --> Total execution time: 0.0046
ERROR - 2019-09-18 05:26:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:26:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:26:07 --> Total execution time: 0.0050
ERROR - 2019-09-18 05:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:26:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:26:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:26:08 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-09-18 05:26:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:26:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:26:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:30:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:30:11 --> Total execution time: 0.0019
ERROR - 2019-09-18 05:30:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:30:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:30:18 --> No URI present. Default controller set.
DEBUG - 2019-09-18 05:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:30:18 --> Total execution time: 0.0045
ERROR - 2019-09-18 05:30:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:30:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:30:32 --> Total execution time: 0.0041
ERROR - 2019-09-18 05:30:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:30:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:30:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:30:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:30:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:30:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:30:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:30:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:30:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:30:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:30:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:30:58 --> Total execution time: 0.0020
ERROR - 2019-09-18 05:31:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:31:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:31:12 --> ROLE ::::: section
DEBUG - 2019-09-18 05:31:12 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`sections_id` = '*'
AND `b`.`class_id` = '4'
DEBUG - 2019-09-18 05:31:12 --> Array
(
)

DEBUG - 2019-09-18 05:31:12 --> Array
(
)

DEBUG - 2019-09-18 05:31:12 --> HELLO
DEBUG - 2019-09-18 05:31:12 --> "registration_ids" field cannot be empty

DEBUG - 2019-09-18 05:31:12 --> Total execution time: 0.0569
ERROR - 2019-09-18 05:31:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:31:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:31:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:31:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:31:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:31:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:31:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:31:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:31:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:31:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:31:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:32:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:32:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-18 05:32:20 --> Query error: Duplicate entry '2147483647' for key 'school_mobile2' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('nbb', 'nagpur', '4578456595', '7848459565', 'index7.jpeg', 'nb@gmail.com', '2019-05-15', '2019-09-18', '1')
DEBUG - 2019-09-18 05:32:20 --> Total execution time: 0.0214
ERROR - 2019-09-18 05:32:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:32:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:32:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:32:20 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:32:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:32:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:32:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:32:20 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:32:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:32:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:32:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:32:20 --> 404 Page Not Found: Welcome/img
ERROR - 2019-09-18 05:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:33:34 --> Total execution time: 0.0016
ERROR - 2019-09-18 05:34:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:34:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:34:03 --> No URI present. Default controller set.
DEBUG - 2019-09-18 05:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:34:03 --> Total execution time: 0.0047
ERROR - 2019-09-18 05:34:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:34:17 --> Total execution time: 0.0042
ERROR - 2019-09-18 05:34:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:34:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:34:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:34:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:38:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:38:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:38:22 --> ROLE ::::: section
ERROR - 2019-09-18 05:38:22 --> Severity: Notice --> Undefined variable: section_id /var/www/html/school/application/models/M_students.php 343
ERROR - 2019-09-18 05:38:22 --> Severity: Notice --> Array to string conversion /var/www/html/school/system/database/DB_query_builder.php 2442
ERROR - 2019-09-18 05:38:22 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE 0 = Array
DEBUG - 2019-09-18 05:38:22 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE 0 = Array
ERROR - 2019-09-18 05:38:22 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_students.php 351
ERROR - 2019-09-18 05:38:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:38:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:38:58 --> ROLE ::::: section
ERROR - 2019-09-18 05:38:58 --> Severity: Notice --> Array to string conversion /var/www/html/school/system/database/DB_query_builder.php 2442
ERROR - 2019-09-18 05:38:58 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE 0 = Array
DEBUG - 2019-09-18 05:38:58 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE 0 = Array
ERROR - 2019-09-18 05:38:58 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_students.php 351
ERROR - 2019-09-18 05:40:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:40:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:40:22 --> ROLE ::::: section
DEBUG - 2019-09-18 05:40:22 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`class_id` = '4'
DEBUG - 2019-09-18 05:40:22 --> Array
(
)

DEBUG - 2019-09-18 05:40:22 --> Array
(
)

DEBUG - 2019-09-18 05:40:23 --> HELLO
DEBUG - 2019-09-18 05:40:23 --> "registration_ids" field cannot be empty

DEBUG - 2019-09-18 05:40:23 --> Total execution time: 0.0511
ERROR - 2019-09-18 05:40:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:40:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:40:24 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:40:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:40:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:40:24 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:41:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:41:03 --> Total execution time: 0.0034
ERROR - 2019-09-18 05:41:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:41:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:41:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:41:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:41:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 05:41:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 05:41:12 --> Total execution time: 0.0054
ERROR - 2019-09-18 05:41:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 05:41:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 05:41:36 --> Total execution time: 0.0047
ERROR - 2019-09-18 05:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 05:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 05:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 05:41:37 --> Total execution time: 0.0048
ERROR - 2019-09-18 05:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:41:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 05:41:37 --> Total execution time: 0.0045
ERROR - 2019-09-18 05:42:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:42:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:42:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 05:42:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:42:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:42:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 05:42:38 --> Total execution time: 0.0047
ERROR - 2019-09-18 05:47:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:47:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:47:11 --> Total execution time: 0.0020
ERROR - 2019-09-18 05:48:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:48:18 --> ROLE ::::: section
DEBUG - 2019-09-18 05:48:18 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`class_id` = '1'
AND `b`.`sections_id` = '40'
DEBUG - 2019-09-18 05:48:18 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-18 05:48:18 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-18 05:48:18 --> HELLO
DEBUG - 2019-09-18 05:48:18 --> {"multicast_id":7099911021702157891,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568785698671205%ec14b888ec14b888"},{"message_id":"0:1568785698676483%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 05:48:18 --> Total execution time: 0.0900
ERROR - 2019-09-18 05:48:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:48:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:48:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:48:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:48:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:48:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:48:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:48:51 --> Total execution time: 0.0140
ERROR - 2019-09-18 05:48:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:48:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:48:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:48:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:48:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:48:58 --> Total execution time: 0.0036
ERROR - 2019-09-18 05:48:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:48:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:48:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:48:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:48:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:50:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:50:11 --> Total execution time: 0.0172
ERROR - 2019-09-18 05:50:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:50:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:50:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:50:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:50:16 --> Total execution time: 0.0027
ERROR - 2019-09-18 05:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:50:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:50:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:52:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:52:03 --> Total execution time: 0.0045
ERROR - 2019-09-18 05:52:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:52:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:52:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:52:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:52:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:52:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:52:10 --> Total execution time: 0.0032
ERROR - 2019-09-18 05:52:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:52:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:52:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:52:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:52:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:53:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:53:19 --> Total execution time: 0.0047
ERROR - 2019-09-18 05:53:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:53:20 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:53:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:53:20 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:53:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:53:41 --> Total execution time: 0.0036
ERROR - 2019-09-18 05:53:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:53:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:53:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:53:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:53:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:53:56 --> Total execution time: 0.0027
ERROR - 2019-09-18 05:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:53:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:53:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:54:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:54:05 --> Total execution time: 0.0031
ERROR - 2019-09-18 05:54:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:54:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:54:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:54:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:54:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:54:47 --> Total execution time: 0.0056
ERROR - 2019-09-18 05:54:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:54:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:54:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:54:48 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:54:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:54:55 --> Total execution time: 0.0032
ERROR - 2019-09-18 05:54:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:54:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:54:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:54:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:54:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:57:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:57:03 --> Total execution time: 0.0243
ERROR - 2019-09-18 05:57:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:57:03 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 05:57:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:57:03 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 05:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:57:10 --> Total execution time: 0.0053
ERROR - 2019-09-18 05:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:57:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 05:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:57:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 05:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 05:57:10 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-18 05:57:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:57:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:57:37 --> Total execution time: 0.0021
ERROR - 2019-09-18 05:59:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:59:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:59:27 --> Total execution time: 0.0021
ERROR - 2019-09-18 05:59:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 05:59:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 05:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 05:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 05:59:32 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:03:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:03:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:03:36 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:05:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:05:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:05:51 --> ROLE ::::: section
DEBUG - 2019-09-18 06:05:51 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`class_id` = '1'
AND `b`.`sections_id` = '40'
DEBUG - 2019-09-18 06:05:51 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-18 06:05:51 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-18 06:05:51 --> HELLO
DEBUG - 2019-09-18 06:05:51 --> {"multicast_id":7113207166740693162,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568786751784972%ec14b888ec14b888"},{"message_id":"0:1568786751784974%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 06:05:51 --> Total execution time: 0.0731
ERROR - 2019-09-18 06:05:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:05:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:05:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:05:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:05:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:05:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:13:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:13:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:13:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:13:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:13:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:13:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:13:11 --> Total execution time: 0.0187
ERROR - 2019-09-18 06:13:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:13:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:13:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:13:11 --> Total execution time: 0.0041
ERROR - 2019-09-18 06:13:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:13:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:13:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:13:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:13:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:13:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:13:20 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:14:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:14:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:14:00 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:14:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:14:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:14:01 --> Total execution time: 0.0186
ERROR - 2019-09-18 06:16:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:16:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:16:22 --> Total execution time: 0.0197
ERROR - 2019-09-18 06:16:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:16:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:16:59 --> Total execution time: 0.0395
ERROR - 2019-09-18 06:17:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:17:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:17:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:17:00 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:17:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:17:00 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-18 06:17:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:17:12 --> Total execution time: 0.0040
ERROR - 2019-09-18 06:17:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:17:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:17:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:17:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:17:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:17:45 --> Total execution time: 0.0050
ERROR - 2019-09-18 06:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:17:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:17:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:21:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:21:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:11 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:21:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:21:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:21:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:12 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:21:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:13 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:21:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:16 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:21:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:21:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:27 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:21:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:21:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:29 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:21:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:33 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:48 --> Total execution time: 0.0055
ERROR - 2019-09-18 06:21:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:53 --> Total execution time: 0.0030
ERROR - 2019-09-18 06:21:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:21:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:21:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:21:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:21:56 --> Total execution time: 0.0030
ERROR - 2019-09-18 06:23:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:23:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:23:33 --> Total execution time: 0.0056
ERROR - 2019-09-18 06:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:23:34 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:23:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:23:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:23:51 --> Total execution time: 0.0040
ERROR - 2019-09-18 06:23:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:23:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:23:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:23:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:23:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:23:51 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:24:06 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:24:09 --> Total execution time: 0.0039
ERROR - 2019-09-18 06:24:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:24:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:24:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:24:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:24:19 --> Total execution time: 0.0040
ERROR - 2019-09-18 06:24:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:24:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:24:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:24:37 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:24:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:24:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:24:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:24:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:25:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:25:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:25:02 --> Total execution time: 0.0038
ERROR - 2019-09-18 06:25:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:25:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:25:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:25:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:25:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:25:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:25:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:25:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:25:17 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:25:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:25:19 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:25:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:25:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:25:28 --> Total execution time: 0.0023
ERROR - 2019-09-18 06:27:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:27:11 --> Total execution time: 0.0050
ERROR - 2019-09-18 06:27:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:27:28 --> Total execution time: 0.0038
ERROR - 2019-09-18 06:27:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:27:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:27:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:27:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:27:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:27:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:27:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:27:36 --> Total execution time: 0.0061
ERROR - 2019-09-18 06:27:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:36 --> UTF-8 Support Enabled
ERROR - 2019-09-18 06:27:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:27:36 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-18 06:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:27:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:27:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:27:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:27:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:27:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:27:59 --> Total execution time: 0.0021
ERROR - 2019-09-18 06:28:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:28:01 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:28:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:17 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:28:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:19 --> Total execution time: 0.0024
ERROR - 2019-09-18 06:28:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:21 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:28:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:22 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:28:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:23 --> Total execution time: 0.0027
ERROR - 2019-09-18 06:28:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:30 --> Total execution time: 0.0026
ERROR - 2019-09-18 06:28:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:33 --> Total execution time: 0.0025
ERROR - 2019-09-18 06:28:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-18 06:28:37 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1241
ERROR - 2019-09-18 06:28:37 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1242
DEBUG - 2019-09-18 06:28:37 --> Total execution time: 0.0031
ERROR - 2019-09-18 06:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:40 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:28:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:28:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:28:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:28:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:28:59 --> Total execution time: 0.0049
ERROR - 2019-09-18 06:29:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:29:05 --> Total execution time: 0.0138
ERROR - 2019-09-18 06:29:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:29:15 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:29:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:29:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:29:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:29:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:29:25 --> Total execution time: 0.0057
ERROR - 2019-09-18 06:29:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:29:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:29:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:29:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:29:26 --> Total execution time: 0.0026
ERROR - 2019-09-18 06:29:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:29:40 --> Total execution time: 0.0023
ERROR - 2019-09-18 06:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:29:48 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:29:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:29:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:29:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:29:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:29:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:29:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:29:52 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:29:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:29:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:29:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:29:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:29:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:29:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:29:55 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:30:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:30:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:00 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:30:00 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:30:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:30:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:30:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:02 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:30:02 --> Total execution time: 0.0092
ERROR - 2019-09-18 06:30:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:30:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:30:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:30:05 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:30:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:30:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:30:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:30:06 --> Total execution time: 0.0046
ERROR - 2019-09-18 06:30:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:30:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:30:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:30:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:30:07 --> Total execution time: 0.0046
ERROR - 2019-09-18 06:30:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:30:15 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:30:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:30:22 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:30:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:30:26 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:30:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:30:29 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:30:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:30:39 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:30:43 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:30:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:30:46 --> Total execution time: 0.0034
ERROR - 2019-09-18 06:30:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:30:46 --> Total execution time: 0.0063
ERROR - 2019-09-18 06:30:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:30:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:30:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:30:47 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:30:52 --> Total execution time: 0.0056
ERROR - 2019-09-18 06:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:30:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:30:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:30:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:30:52 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:31:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:31:05 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:31:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:31:09 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:31:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:31:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:31:31 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:31:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:31:31 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:31:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:31:32 --> Total execution time: 0.0146
ERROR - 2019-09-18 06:31:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:31:38 --> Total execution time: 0.0036
ERROR - 2019-09-18 06:31:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:31:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:31:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:31:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:31:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:31:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:31:41 --> Total execution time: 0.0046
ERROR - 2019-09-18 06:31:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:31:45 --> Total execution time: 0.0067
ERROR - 2019-09-18 06:31:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:31:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:31:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:31:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:31:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:31:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:31:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:31:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:31:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:31:51 --> Total execution time: 0.0029
ERROR - 2019-09-18 06:32:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:32:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:32:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:32:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:32:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:32:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:32:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:32:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:32:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:32:33 --> Total execution time: 0.0050
ERROR - 2019-09-18 06:33:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:33:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:33:49 --> ROLE ::::: teacher
DEBUG - 2019-09-18 06:33:49 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 06:33:49 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 06:33:49 --> HELLO
DEBUG - 2019-09-18 06:33:49 --> {"multicast_id":8214407731255832374,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568788429361799%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 06:33:49 --> Total execution time: 0.0662
ERROR - 2019-09-18 06:33:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:33:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:33:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:33:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:33:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:33:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:33:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:33:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:33:56 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:33:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:33:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:33:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:33:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:33:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:33:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:34:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:34:17 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:34:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:34:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:34:18 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-18 06:34:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:34:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:34:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:34:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:34:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:34:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:34:45 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:34:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:34:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:34:51 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:34:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:34:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:34:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:34:53 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:34:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:34:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:34:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:34:54 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:35:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:35:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:35:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:35:31 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:35:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:35:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:35:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:35:32 --> Total execution time: 0.0049
ERROR - 2019-09-18 06:35:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:35:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:35:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:35:32 --> Total execution time: 0.0046
ERROR - 2019-09-18 06:35:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:35:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:35:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:35:32 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:35:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:35:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:35:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:35:40 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:35:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:35:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:40 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:35:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:35:40 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:35:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:35:55 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:35:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:35:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:35:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:35:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:35:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:35:57 --> Total execution time: 0.0040
ERROR - 2019-09-18 06:35:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:35:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:35:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:35:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:35:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:36:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:36:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:36:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:36:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:36:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:36:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:36:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:36:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:36:11 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:36:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:36:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:36:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:36:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:36:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:36:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:36:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:36:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:36:52 --> Total execution time: 0.0046
ERROR - 2019-09-18 06:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:36:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:36:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:36:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:36:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:36:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:36:52 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:37:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:37:04 --> Total execution time: 0.0021
ERROR - 2019-09-18 06:37:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:37:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:37:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:37:46 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:37:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:37:47 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:37:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:37:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:37:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:37:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:37:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:37:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:37:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:37:47 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:37:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:37:47 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 119
DEBUG - 2019-09-18 06:37:47 --> Total execution time: 0.0015
ERROR - 2019-09-18 06:37:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:37:51 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:37:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:37:51 --> Total execution time: 0.0041
ERROR - 2019-09-18 06:37:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:37:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:37:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:37:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:37:58 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:38:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:38:19 --> Total execution time: 0.0082
ERROR - 2019-09-18 06:38:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:38:20 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:38:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:38:20 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:38:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:38:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:38:31 --> Total execution time: 0.0046
ERROR - 2019-09-18 06:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:38:38 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:38:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:38:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:38:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:38:58 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:38:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:38:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:38:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:38:58 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:39:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:39:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:39:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:39:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:39:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:39:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:39:23 --> Total execution time: 0.0060
ERROR - 2019-09-18 06:39:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:39:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:39:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:39:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:39:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:39:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:39:24 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:39:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:39:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:39:24 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:39:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:39:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:39:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:39:27 --> Total execution time: 0.0047
ERROR - 2019-09-18 06:40:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:40:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:40:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:40:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:40:01 --> Total execution time: 0.0031
ERROR - 2019-09-18 06:40:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:40:20 --> Total execution time: 0.0037
ERROR - 2019-09-18 06:40:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:40:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:40:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:40:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:40:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:40:30 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:40:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:40:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:40:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:40:36 --> Total execution time: 0.0035
ERROR - 2019-09-18 06:40:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:40:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:40:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:40:36 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-18 06:40:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:40:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:40:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:40:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:40:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:40:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:41:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:41:01 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:41:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:41:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:41:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:41:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:41:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:41:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:41:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:41:08 --> Total execution time: 0.0040
ERROR - 2019-09-18 06:41:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:41:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:41:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:41:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:41:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:41:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:41:14 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:41:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:41:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:41:18 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:41:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:41:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:41:30 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:41:37 --> Total execution time: 0.0032
ERROR - 2019-09-18 06:41:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:41:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:41:42 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:41:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:41:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:41:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:41:42 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:42:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:42:11 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:42:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:42:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:42:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:42:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:42:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:42:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:42:25 --> Total execution time: 0.0041
ERROR - 2019-09-18 06:42:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:42:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:42:38 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:42:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:42:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:42:42 --> Total execution time: 0.0039
ERROR - 2019-09-18 06:42:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:42:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:42:47 --> Total execution time: 0.0041
ERROR - 2019-09-18 06:42:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:42:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:42:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:42:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:42:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:42:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:42:50 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:42:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:42:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:42:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:42:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:42:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:42:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:42:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:42:51 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:43:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:43:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:43:01 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:43:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:43:37 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:43:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:43:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:43:51 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:43:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:43:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:43:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:43:54 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:43:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:43:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:43:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:43:54 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:44:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:44:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:44:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:44:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:44:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:44:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:44:11 --> Total execution time: 0.0029
ERROR - 2019-09-18 06:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:44:52 --> ROLE ::::: teacher
DEBUG - 2019-09-18 06:44:52 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 06:44:52 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 06:44:52 --> HELLO
DEBUG - 2019-09-18 06:44:52 --> {"multicast_id":4986278899586795176,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568789092545284%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 06:44:52 --> Total execution time: 0.0703
ERROR - 2019-09-18 06:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:44:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:44:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:45:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:45:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:45:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:45:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:45:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:45:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:45:03 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:45:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:45:03 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:45:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:45:03 --> Total execution time: 0.0036
ERROR - 2019-09-18 06:45:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:45:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:45:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:45:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:45:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:45:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:45:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:45:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:45:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:45:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:45:19 --> Total execution time: 0.0035
ERROR - 2019-09-18 06:46:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:46:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:46:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:46:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:46:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:46:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:46:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:46:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:46:07 --> Total execution time: 0.0036
ERROR - 2019-09-18 06:46:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:46:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:46:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:46:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:46:23 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:46:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:46:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:46:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:46:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:46:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:46:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:46:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:46:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:46:25 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:46:53 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:46:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:46:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:47:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:47:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:47:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:47:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:47:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:47:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:47:02 --> Total execution time: 0.0032
ERROR - 2019-09-18 06:47:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:47:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:47:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:47:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:47:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:47:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:47:15 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:47:28 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:48:23 --> Total execution time: 0.0070
ERROR - 2019-09-18 06:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:48:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:48:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:48:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:48:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:48:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:48:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:48:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:48:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:48:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:48:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:48:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:48:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:48:31 --> Total execution time: 0.0035
ERROR - 2019-09-18 06:48:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:48:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:48:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:48:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:48:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:48:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:48:38 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:48:38 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:48:38 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:48:38 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:48:38 --> Total execution time: 0.0034
ERROR - 2019-09-18 06:49:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:49:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:49:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:49:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:49:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:49:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:49:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:49:21 --> Total execution time: 0.0036
ERROR - 2019-09-18 06:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:49:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:49:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:49:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:49:31 --> Total execution time: 0.0034
ERROR - 2019-09-18 06:49:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:49:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:49:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:49:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:49:43 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:43 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:49:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:49:43 --> Total execution time: 0.0034
ERROR - 2019-09-18 06:50:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:50:36 --> Total execution time: 0.0041
ERROR - 2019-09-18 06:50:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:50:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:50:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:50:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:50:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:50:40 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:50:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:50:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:50:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:50:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:50:54 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:50:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:50:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:50:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:50:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:50:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:50:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:51:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:51:17 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:51:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:51:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:51:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:51:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 06:51:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:51:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:51:26 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:51:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:51:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:51:29 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:51:29 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:51:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:51:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:51:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:51:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:51:39 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:52:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:52:19 --> ROLE ::::: student
DEBUG - 2019-09-18 06:52:19 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 06:52:19 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 06:52:19 --> HELLO
DEBUG - 2019-09-18 06:52:19 --> {"multicast_id":8497788486472383600,"success":5,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568789539096638%ec14b888ec14b888"},{"message_id":"0:1568789539107873%ec14b888ec14b888"},{"message_id":"0:1568789539107872%ec14b888ec14b888"},{"message_id":"0:1568789539098867%ec14b888ec14b888"},{"message_id":"0:1568789539107870%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 06:52:19 --> Total execution time: 0.1320
ERROR - 2019-09-18 06:52:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:52:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 06:52:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:52:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 06:52:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:52:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:52:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:52:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:52:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:52:31 --> Total execution time: 0.0036
ERROR - 2019-09-18 06:52:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:52:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:52:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:34 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:34 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:52:34 --> Total execution time: 0.0037
ERROR - 2019-09-18 06:52:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:52:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:52:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:52:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:52:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:52:48 --> Total execution time: 0.0035
ERROR - 2019-09-18 06:52:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:52:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:52:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:52:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:52:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:52:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:52:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:52:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:52:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:52:55 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:53:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:53:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:53:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:53:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:53:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:53:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:53:07 --> Total execution time: 0.0048
ERROR - 2019-09-18 06:53:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 06:53:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 06:53:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:53:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 06:53:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 06:53:07 --> Total execution time: 0.0043
ERROR - 2019-09-18 06:53:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:53:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:53:13 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:53:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:53:13 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:53:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:53:13 --> Total execution time: 0.0034
ERROR - 2019-09-18 06:53:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:53:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:53:20 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:53:20 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:53:20 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 06:53:20 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 06:53:20 --> Total execution time: 0.0035
ERROR - 2019-09-18 06:53:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:53:33 --> Total execution time: 0.0021
ERROR - 2019-09-18 06:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:54:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:54:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:54:00 --> Total execution time: 0.0020
ERROR - 2019-09-18 06:54:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:54:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:54:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:54:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:54:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:54:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:54:04 --> Total execution time: 0.0044
ERROR - 2019-09-18 06:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:54:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:54:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:54:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:54:13 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:54:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:54:13 --> Total execution time: 0.0032
ERROR - 2019-09-18 06:55:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:55:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:55:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:55:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:55:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:55:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:55:31 --> Total execution time: 0.0024
ERROR - 2019-09-18 06:56:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:56:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:56:23 --> Total execution time: 0.0042
ERROR - 2019-09-18 06:56:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:56:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:56:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:56:27 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:56:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:56:27 --> Total execution time: 0.0045
ERROR - 2019-09-18 06:56:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:56:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:56:32 --> Total execution time: 0.0033
ERROR - 2019-09-18 06:56:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 06:56:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:56:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:56:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 06:56:43 --> Total execution time: 0.0032
ERROR - 2019-09-18 06:57:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:57:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 06:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 06:57:46 --> Total execution time: 0.0034
ERROR - 2019-09-18 06:57:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:57:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:57:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 06:57:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 06:57:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 06:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 06:57:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:00:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:00:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:00:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:00:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:00:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:00:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:00:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:00:11 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:00:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:00:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:00:11 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:01:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:01:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:01:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:01:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:01:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:01:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:01:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:01:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:01:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:01:51 --> Total execution time: 0.0051
ERROR - 2019-09-18 07:01:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:01:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:01:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:01:51 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:05:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:05:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:05:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:05:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:05:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:05:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:05:20 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:05:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:05:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:05:20 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:05:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:05:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:05:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:05:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:05:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:05:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:05:32 --> Total execution time: 0.0029
ERROR - 2019-09-18 07:11:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:11:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:11:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:11:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:11:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:11:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:11:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:11:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:11:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:11:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 07:11:51 --> Total execution time: 0.0036
ERROR - 2019-09-18 07:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:12:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:12:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:12:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 374
DEBUG - 2019-09-18 07:12:18 --> Total execution time: 0.0029
ERROR - 2019-09-18 07:13:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:13:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:13:36 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:13:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:13:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:13:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:13:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:13:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:13:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:13:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:13:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:13:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:13:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:13:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:13:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:13:56 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-18 07:13:56 --> Total execution time: 0.0045
ERROR - 2019-09-18 07:14:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:05 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-18 07:14:05 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:14:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:14:32 --> ROLE ::::: teacher
DEBUG - 2019-09-18 07:14:32 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 07:14:32 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 07:14:32 --> HELLO
DEBUG - 2019-09-18 07:14:32 --> {"multicast_id":5072159788305625222,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568790872904410%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 07:14:32 --> Total execution time: 0.0752
ERROR - 2019-09-18 07:14:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:14:33 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 07:14:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:14:33 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 07:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 07:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 07:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:14:50 --> Total execution time: 0.0046
ERROR - 2019-09-18 07:14:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 07:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 07:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:14:50 --> Total execution time: 0.0047
ERROR - 2019-09-18 07:14:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 07:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 07:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:14:50 --> Total execution time: 0.0048
ERROR - 2019-09-18 07:14:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 07:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 07:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:14:50 --> Total execution time: 0.0046
ERROR - 2019-09-18 07:14:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 07:14:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 07:14:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:14:57 --> Total execution time: 0.0047
ERROR - 2019-09-18 07:14:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:14:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:14:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 07:14:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 07:14:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:14:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:14:57 --> Total execution time: 0.0046
ERROR - 2019-09-18 07:15:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:15:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:15:04 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:15:04 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:15:04 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:15:04 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 07:15:04 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:15:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:15:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:15:45 --> Total execution time: 0.0046
ERROR - 2019-09-18 07:15:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:15:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:15:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:15:46 --> Total execution time: 0.0042
ERROR - 2019-09-18 07:15:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:15:46 --> Total execution time: 0.0045
ERROR - 2019-09-18 07:15:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:15:49 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:15:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:15:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:15:51 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:15:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:15:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:15:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:15:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:15:59 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:16:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:16:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:16:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:16:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:16:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:16:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:16:50 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:17:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:17:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:17:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:17:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:17:24 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:17:39 --> Total execution time: 0.0026
ERROR - 2019-09-18 07:17:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:17:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:17:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:17:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:17:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:17:47 --> Total execution time: 0.0050
ERROR - 2019-09-18 07:17:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:17:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:17:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:17:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:17:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:17:48 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-18 07:17:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:17:53 --> Total execution time: 0.0021
ERROR - 2019-09-18 07:17:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:17:53 --> Total execution time: 0.0020
ERROR - 2019-09-18 07:17:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:17:57 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:17:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:17:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:17:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:17:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:17:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:17:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:17:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:18:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:18:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:18:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:18:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:18:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:18:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:18:39 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:18:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:18:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:18:39 --> Total execution time: 0.0039
ERROR - 2019-09-18 07:19:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:19:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:19:06 --> Total execution time: 0.0047
ERROR - 2019-09-18 07:19:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:19:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:19:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:19:26 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:19:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:19:26 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:19:35 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:19:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:19:35 --> Total execution time: 0.0041
ERROR - 2019-09-18 07:21:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:21:54 --> ROLE ::::: student
DEBUG - 2019-09-18 07:21:54 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 07:21:54 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 07:21:54 --> HELLO
DEBUG - 2019-09-18 07:21:54 --> {"multicast_id":5662771338220079570,"success":5,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568791314799818%ec14b888ec14b888"},{"message_id":"0:1568791314798750%ec14b888ec14b888"},{"message_id":"0:1568791314798752%ec14b888ec14b888"},{"message_id":"0:1568791314799819%ec14b888ec14b888"},{"message_id":"0:1568791314798892%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 07:21:54 --> Total execution time: 0.0742
ERROR - 2019-09-18 07:21:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:21:55 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 07:21:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:21:55 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 07:22:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:22:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:22:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:22:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:22:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:22:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:22:48 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:22:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:22:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:22:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:22:52 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:23:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:23:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:23:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:23:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:23:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:23:02 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:23:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:23:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:23:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:23:05 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:23:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:23:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:23:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:23:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:23:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:23:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:23:13 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:23:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:23:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:23:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:23:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:23:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:23:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:23:19 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:23:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:23:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:23:42 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:24:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:24:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:24:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:24:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:24:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:24:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 248
ERROR - 2019-09-18 07:24:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 248
DEBUG - 2019-09-18 07:24:11 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:24:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:24:12 --> Total execution time: 0.0071
ERROR - 2019-09-18 07:24:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:24:13 --> Total execution time: 0.0040
ERROR - 2019-09-18 07:24:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:24:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:24:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:24:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:24:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:24:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 07:24:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 07:24:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:24:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:24:31 --> Total execution time: 0.0046
ERROR - 2019-09-18 07:24:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-18 07:24:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-18 07:24:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:24:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-18 07:24:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:24:31 --> Total execution time: 0.0042
ERROR - 2019-09-18 07:24:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:24:35 --> Total execution time: 0.0024
ERROR - 2019-09-18 07:24:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:24:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:24:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:24:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:24:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:24:41 --> Total execution time: 0.0021
ERROR - 2019-09-18 07:24:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:24:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:24:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:24:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:24:44 --> Total execution time: 0.0020
ERROR - 2019-09-18 07:24:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:24:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:24:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:24:54 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:24:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:24:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:24:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:24:59 --> Total execution time: 0.0046
ERROR - 2019-09-18 07:25:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:05 --> Total execution time: 0.0024
ERROR - 2019-09-18 07:25:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:19 --> No URI present. Default controller set.
DEBUG - 2019-09-18 07:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:19 --> Total execution time: 0.0018
ERROR - 2019-09-18 07:25:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:19 --> No URI present. Default controller set.
DEBUG - 2019-09-18 07:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:19 --> Total execution time: 0.0017
ERROR - 2019-09-18 07:25:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:22 --> No URI present. Default controller set.
DEBUG - 2019-09-18 07:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:22 --> Total execution time: 0.0047
ERROR - 2019-09-18 07:25:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:25 --> Total execution time: 0.0042
ERROR - 2019-09-18 07:25:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:25:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:25:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:25 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-18 07:25:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:25:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:28 --> No URI present. Default controller set.
DEBUG - 2019-09-18 07:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:28 --> Total execution time: 0.0021
ERROR - 2019-09-18 07:25:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:31 --> Total execution time: 0.0024
ERROR - 2019-09-18 07:25:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:25:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:25:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:41 --> Total execution time: 0.0040
ERROR - 2019-09-18 07:25:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:25:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:25:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:25:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:25:50 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:25:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:25:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:25:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:25:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:25:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:25:51 --> Total execution time: 0.0029
ERROR - 2019-09-18 07:25:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:25:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:25:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:25:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:25:57 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:26:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:02 --> No URI present. Default controller set.
DEBUG - 2019-09-18 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:26:02 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:26:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:26:05 --> Total execution time: 0.0022
ERROR - 2019-09-18 07:26:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:26:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:26:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:26:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:26:06 --> Total execution time: 0.0029
ERROR - 2019-09-18 07:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:26:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:26:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:26:13 --> Total execution time: 0.0029
ERROR - 2019-09-18 07:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:26:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:26:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:26:13 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:26:13 --> Total execution time: 0.0045
ERROR - 2019-09-18 07:26:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:26:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:26:28 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:26:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:26:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:26:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:26:47 --> Total execution time: 0.0031
ERROR - 2019-09-18 07:27:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:27:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:27:27 --> Total execution time: 0.0041
ERROR - 2019-09-18 07:27:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:27:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:27:40 --> Total execution time: 0.0016
ERROR - 2019-09-18 07:28:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:28:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:28:03 --> No URI present. Default controller set.
DEBUG - 2019-09-18 07:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:28:03 --> Total execution time: 0.0046
ERROR - 2019-09-18 07:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:28:16 --> Total execution time: 0.0041
ERROR - 2019-09-18 07:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:28:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:28:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:28:16 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-18 07:28:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:28:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:28:21 --> Total execution time: 0.0020
ERROR - 2019-09-18 07:28:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:28:22 --> Total execution time: 0.0020
ERROR - 2019-09-18 07:32:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:32:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:32:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:32:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:32:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:32:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:32:01 --> Total execution time: 0.0040
ERROR - 2019-09-18 07:32:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:32:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:32:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:32:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:32:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:32:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:32:48 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:32:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:32:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:32:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:32:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:32:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:32:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:32:50 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:32:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:32:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:32:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:32:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:32:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:32:55 --> Total execution time: 0.0041
ERROR - 2019-09-18 07:33:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:33:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:33:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:33:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:33:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:33:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:33:10 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:33:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:33:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:33:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:33:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:33:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:33:11 --> Total execution time: 0.0025
ERROR - 2019-09-18 07:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:34:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:34:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:34:13 --> Total execution time: 0.0040
ERROR - 2019-09-18 07:34:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:34:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:34:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:34:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:34:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:34:35 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:34:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:34:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:34:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:34:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:34:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:34:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:34:36 --> Total execution time: 0.0025
ERROR - 2019-09-18 07:34:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:34:56 --> Total execution time: 0.0020
ERROR - 2019-09-18 07:35:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:35:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:35:21 --> Total execution time: 0.0174
ERROR - 2019-09-18 07:35:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:35:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:35:21 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 07:35:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:35:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 07:35:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:35:22 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-18 07:35:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:35:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:35:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:35:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:35:51 --> Total execution time: 0.0019
ERROR - 2019-09-18 07:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:36:21 --> Total execution time: 0.0042
ERROR - 2019-09-18 07:36:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:36:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:36:23 --> Total execution time: 0.0039
ERROR - 2019-09-18 07:36:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:36:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:36:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 192
ERROR - 2019-09-18 07:36:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 192
ERROR - 2019-09-18 07:36:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 192
ERROR - 2019-09-18 07:36:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 192
ERROR - 2019-09-18 07:36:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 200
ERROR - 2019-09-18 07:36:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 200
ERROR - 2019-09-18 07:36:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-18 07:36:33 --> Total execution time: 0.0053
ERROR - 2019-09-18 07:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:36:42 --> Total execution time: 0.0041
ERROR - 2019-09-18 07:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:36:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:36:43 --> Total execution time: 0.0042
ERROR - 2019-09-18 07:37:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:37:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:37:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:37:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:37:20 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:37:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:37:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:37:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:37:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:37:32 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:37:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:37:49 --> Total execution time: 0.0020
ERROR - 2019-09-18 07:37:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:37:49 --> Total execution time: 0.0020
ERROR - 2019-09-18 07:37:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:37:52 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:37:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:37:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:37:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:37:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:37:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:38:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:38:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:38:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:38:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:38:53 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:38:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:38:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:38:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:38:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:38:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:38:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:38:59 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:39:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:39:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:39:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:39:03 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:39:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:39:03 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:39:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:39:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:39:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:39:33 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:39:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:39:33 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:39:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:39:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:39:44 --> Total execution time: 0.0030
ERROR - 2019-09-18 07:39:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:39:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:39:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:39:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:39:47 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:40:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:40:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:40:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:40:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:40:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:40:52 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:42:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:42:00 --> ROLE ::::: student
DEBUG - 2019-09-18 07:42:00 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 07:42:00 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 07:42:01 --> HELLO
DEBUG - 2019-09-18 07:42:01 --> {"multicast_id":5388857403652516966,"success":6,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568792521126911%ec14b888ec14b888"},{"message_id":"0:1568792521125622%ec14b888ec14b888"},{"message_id":"0:1568792521125623%ec14b888ec14b888"},{"message_id":"0:1568792521125575%ec14b888ec14b888"},{"message_id":"0:1568792521134478%ec14b888ec14b888"},{"message_id":"0:1568792521126725%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 07:42:01 --> Total execution time: 1.0880
ERROR - 2019-09-18 07:42:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:42:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 07:42:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:42:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 07:42:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:42:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:42:08 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:42:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:42:13 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:42:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:42:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:42:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:42:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:42:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:42:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:42:31 --> Total execution time: 0.0050
DEBUG - 2019-09-18 07:42:31 --> Total execution time: 0.0152
ERROR - 2019-09-18 07:42:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:42:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:42:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:42:32 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:42:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:42:32 --> Total execution time: 0.0024
ERROR - 2019-09-18 07:42:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:42:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:42:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:42:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:42:42 --> Total execution time: 0.0030
ERROR - 2019-09-18 07:44:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:44:01 --> ROLE ::::: teacher
DEBUG - 2019-09-18 07:44:01 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-18 07:44:01 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-18 07:44:01 --> HELLO
DEBUG - 2019-09-18 07:44:01 --> {"multicast_id":7606267897166491063,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568792641363730%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 07:44:01 --> Total execution time: 0.0757
ERROR - 2019-09-18 07:44:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:44:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:44:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 07:44:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:44:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:44:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 07:44:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:44:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:44:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:44:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:44:13 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:44:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:44:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:44:27 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:44:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:44:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:44:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:44:30 --> Total execution time: 0.0035
ERROR - 2019-09-18 07:45:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:45:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:08 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:45:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:12 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:45:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:45:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:15 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:45:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:45:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:21 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:22 --> Total execution time: 0.0025
ERROR - 2019-09-18 07:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:31 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:31 --> Total execution time: 0.0041
ERROR - 2019-09-18 07:45:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:45:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:45 --> Total execution time: 0.0049
ERROR - 2019-09-18 07:45:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:45:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:45:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:45:48 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:46:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:46:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:46:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:46:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:46:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:46:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:46:18 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:46:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:46:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:46:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:46:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:46:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:46:42 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:46:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:46:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:46:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:46:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:46:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:46:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:46:49 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:46:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:46:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:46:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:46:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:46:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:46:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:46:50 --> Total execution time: 0.0025
ERROR - 2019-09-18 07:47:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:47:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:47:24 --> Total execution time: 0.0028
ERROR - 2019-09-18 07:47:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:47:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:47:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:47:24 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:47:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:47:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:47:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:47:24 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:48:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:48:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:48:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:48:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:48:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:48:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:48:57 --> Total execution time: 0.0045
ERROR - 2019-09-18 07:48:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:48:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:48:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:48:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:48:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:48:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:49:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:49:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:49:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:49:00 --> Total execution time: 0.0045
ERROR - 2019-09-18 07:49:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:49:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:49:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:49:01 --> Total execution time: 0.0045
ERROR - 2019-09-18 07:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:49:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:49:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:49:07 --> Total execution time: 0.0030
ERROR - 2019-09-18 07:49:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:49:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:49:53 --> Total execution time: 0.0154
ERROR - 2019-09-18 07:49:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:49:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:49:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 07:49:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:49:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:49:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 07:50:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:50:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:50:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:50:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:50:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:50:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:50:10 --> Total execution time: 0.0038
ERROR - 2019-09-18 07:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:50:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:50:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:50:30 --> Total execution time: 0.0022
ERROR - 2019-09-18 07:50:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:50:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:50:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:50:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:50:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:50:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:50:43 --> Total execution time: 0.0030
ERROR - 2019-09-18 07:51:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:51:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:51:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:51:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:51:18 --> Total execution time: 0.0024
ERROR - 2019-09-18 07:52:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:52:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:52:01 --> Total execution time: 0.0022
ERROR - 2019-09-18 07:52:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:52:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:52:42 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:52:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:52:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:52:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:52:44 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:52:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:52:44 --> Total execution time: 0.0042
ERROR - 2019-09-18 07:52:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:52:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:52:51 --> Total execution time: 0.0047
ERROR - 2019-09-18 07:52:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:52:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:52:52 --> Total execution time: 0.0046
ERROR - 2019-09-18 07:52:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:52:55 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:52:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:52:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:52:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:52:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:52:58 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:53:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:53:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:53:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:53:02 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:53:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:53:19 --> Total execution time: 0.0044
ERROR - 2019-09-18 07:53:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:53:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 07:53:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:53:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 07:54:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:54:14 --> Total execution time: 0.0021
ERROR - 2019-09-18 07:55:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:55:03 --> ROLE ::::: section
DEBUG - 2019-09-18 07:55:03 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`class_id` = '2'
AND `b`.`sections_id` = '41'
DEBUG - 2019-09-18 07:55:03 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 07:55:03 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 07:55:03 --> HELLO
DEBUG - 2019-09-18 07:55:03 --> {"multicast_id":4714397221859699678,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568793303073394%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 07:55:03 --> Total execution time: 0.0853
ERROR - 2019-09-18 07:55:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:55:05 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 07:55:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:55:05 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 07:55:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:55:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:14 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:55:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:55:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:20 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:55:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:55:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:29 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:55:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:55:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:32 --> Total execution time: 0.0030
ERROR - 2019-09-18 07:55:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:33 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:55:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:55:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:40 --> Total execution time: 0.0043
ERROR - 2019-09-18 07:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:40 --> Total execution time: 0.0045
ERROR - 2019-09-18 07:55:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:55:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:46 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:55:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:55:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:55:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:55:51 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:56:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:56:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:56:10 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:56:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:56:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:56:21 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:56:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:56:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:56:38 --> Total execution time: 0.0038
ERROR - 2019-09-18 07:56:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:56:40 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:56:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:56:49 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:57:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:57:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:57:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:57:05 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:57:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:57:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:57:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:57:08 --> Total execution time: 0.0034
ERROR - 2019-09-18 07:58:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:58:04 --> Total execution time: 0.0020
ERROR - 2019-09-18 07:58:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:58:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:58:14 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:58:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:58:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:58:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:58:15 --> Total execution time: 0.0042
ERROR - 2019-09-18 07:58:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:58:16 --> Total execution time: 0.0050
ERROR - 2019-09-18 07:58:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:58:23 --> Total execution time: 0.0021
ERROR - 2019-09-18 07:58:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 07:58:54 --> ROLE ::::: section
DEBUG - 2019-09-18 07:58:54 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`class_id` = '2'
AND `b`.`sections_id` = '41'
DEBUG - 2019-09-18 07:58:54 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 07:58:54 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 07:58:54 --> HELLO
DEBUG - 2019-09-18 07:58:54 --> {"multicast_id":5681386235469348975,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568793534706783%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 07:58:54 --> Total execution time: 0.0631
ERROR - 2019-09-18 07:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:58:55 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 07:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 07:58:55 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 07:59:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:59:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:59:07 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:59:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:59:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:59:19 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:59:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:59:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:59:27 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:59:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:59:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:59:39 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:59:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:59:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 07:59:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:59:48 --> Total execution time: 0.0031
ERROR - 2019-09-18 07:59:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:59:48 --> Total execution time: 0.0033
ERROR - 2019-09-18 07:59:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:59:49 --> Total execution time: 0.0032
ERROR - 2019-09-18 07:59:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 07:59:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 07:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 07:59:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 07:59:55 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:00:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:00:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:00:08 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:00:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:00:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:00:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:00:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:00:10 --> Total execution time: 0.0043
ERROR - 2019-09-18 08:00:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:00:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:00:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:00:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:00:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:00:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:00:15 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:26:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:26:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:26:15 --> Total execution time: 0.0044
ERROR - 2019-09-18 08:26:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:26:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:26:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:26:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:26:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:26:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:26:23 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:29:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:29:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:29:09 --> Total execution time: 0.0031
ERROR - 2019-09-18 08:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:29:26 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:29:33 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:29:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:29:37 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:29:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:29:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:29:49 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:31:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:31:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:31:29 --> Total execution time: 0.0044
ERROR - 2019-09-18 08:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:31:29 --> Total execution time: 0.0043
ERROR - 2019-09-18 08:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:31:29 --> Total execution time: 0.0044
ERROR - 2019-09-18 08:31:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:31:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:31:35 --> Total execution time: 0.0032
ERROR - 2019-09-18 08:31:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:31:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:31:39 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:31:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:31:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:31:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:31:39 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:34:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:34:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:34:38 --> ROLE ::::: parent
DEBUG - 2019-09-18 08:34:38 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 08:34:38 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 08:34:39 --> HELLO
DEBUG - 2019-09-18 08:34:39 --> {"multicast_id":5857708044401807046,"success":6,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568795679109219%ec14b888ec14b888"},{"message_id":"0:1568795679110474%ec14b888ec14b888"},{"message_id":"0:1568795679110993%ec14b888ec14b888"},{"message_id":"0:1568795679110472%ec14b888ec14b888"},{"message_id":"0:1568795679110994%ec14b888ec14b888"},{"message_id":"0:1568795679109550%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 08:34:39 --> Total execution time: 1.0828
ERROR - 2019-09-18 08:34:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:34:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:34:39 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 08:34:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:34:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:34:39 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 08:35:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:35:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:35:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:35:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:35:01 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:35:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:35:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:35:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:35:08 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:35:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:35:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:35:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:35:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:35:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:35:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:35:30 --> Total execution time: 0.0032
ERROR - 2019-09-18 08:35:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:35:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:35:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:35:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:35:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:35:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:35:36 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:35:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:35:40 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:38:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:38:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:38:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:38:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:38:26 --> Total execution time: 0.0037
ERROR - 2019-09-18 08:39:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:39:01 --> Total execution time: 0.0164
ERROR - 2019-09-18 08:40:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:40:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:40:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:40:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:40:13 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:41:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:41:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:41:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:41:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:41:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:41:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:41:59 --> Total execution time: 0.0032
ERROR - 2019-09-18 08:42:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:42:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:42:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:42:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:42:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:42:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:42:17 --> Total execution time: 0.0044
ERROR - 2019-09-18 08:42:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:42:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:42:17 --> Total execution time: 0.0045
ERROR - 2019-09-18 08:45:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:45:12 --> ROLE ::::: section
DEBUG - 2019-09-18 08:45:12 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`class_id` = '2'
AND `b`.`sections_id` = '41'
DEBUG - 2019-09-18 08:45:12 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 08:45:12 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-18 08:45:12 --> HELLO
DEBUG - 2019-09-18 08:45:12 --> {"multicast_id":8959071297575189299,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568796312062283%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 08:45:12 --> Total execution time: 0.0810
ERROR - 2019-09-18 08:45:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:45:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 08:45:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:45:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 08:45:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:45:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 08:45:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:45:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:45:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:45:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:45:52 --> Total execution time: 0.0044
ERROR - 2019-09-18 08:45:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:45:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:45:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:45:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:45:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:45:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:45:56 --> Total execution time: 0.0046
ERROR - 2019-09-18 08:45:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:45:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:45:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:45:56 --> Total execution time: 0.0045
ERROR - 2019-09-18 08:46:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:46:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:46:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:46:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:46:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:46:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:46:03 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:47:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:47:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:47:17 --> ROLE ::::: teacher
DEBUG - 2019-09-18 08:47:17 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-18 08:47:17 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-18 08:47:17 --> HELLO
DEBUG - 2019-09-18 08:47:17 --> {"multicast_id":6554291850110391202,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568796437586789%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 08:47:17 --> Total execution time: 0.1620
ERROR - 2019-09-18 08:47:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:47:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:47:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 08:47:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:47:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:47:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 08:48:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:48:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:48:11 --> Total execution time: 0.0021
ERROR - 2019-09-18 08:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:48:23 --> Total execution time: 0.0071
ERROR - 2019-09-18 08:48:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:48:24 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 08:48:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:48:24 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 08:48:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:48:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:48:45 --> Total execution time: 0.0045
ERROR - 2019-09-18 08:50:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:50:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:50:04 --> ROLE ::::: teacher
DEBUG - 2019-09-18 08:50:04 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-18 08:50:04 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-18 08:50:04 --> HELLO
DEBUG - 2019-09-18 08:50:04 --> {"multicast_id":7495730032277705620,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568796604884708%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 08:50:04 --> Total execution time: 0.0771
ERROR - 2019-09-18 08:50:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:50:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:50:05 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 08:50:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:50:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:50:05 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 08:51:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:51:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:51:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:51:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:51:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:51:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:51:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:51:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:51:46 --> Total execution time: 0.0043
ERROR - 2019-09-18 08:51:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:51:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:51:46 --> Total execution time: 0.0040
ERROR - 2019-09-18 08:51:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:51:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:51:46 --> Total execution time: 0.0042
ERROR - 2019-09-18 08:52:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:52:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:52:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:52:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:52:03 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:52:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:52:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:52:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:52:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:52:09 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:52:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:52:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:52:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:52:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:52:30 --> Total execution time: 0.0034
ERROR - 2019-09-18 08:52:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:52:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:52:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:52:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:52:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:52:53 --> Total execution time: 0.0040
ERROR - 2019-09-18 08:53:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:53:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 08:53:24 --> ROLE ::::: driver
ERROR - 2019-09-18 08:53:24 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 2
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4746731  Threads: 1  Questions: 179931  Slow queries: 0  Opens: 6927  Flush tables: 1  Open tables: 803  Queries per second avg: 0.037
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 37358
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 2
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 08:53:24 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 08:53:24 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-18 08:53:24 --> HELLO
DEBUG - 2019-09-18 08:53:24 --> {"multicast_id":6786851557082949377,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568796804919899%ec14b888ec14b888"}]}
DEBUG - 2019-09-18 08:53:24 --> Total execution time: 0.0915
ERROR - 2019-09-18 08:53:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:53:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:53:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 08:53:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:53:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 08:53:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 08:54:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:54:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:54:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:54:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:54:16 --> Total execution time: 0.0035
ERROR - 2019-09-18 08:55:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:55:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:55:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:55:24 --> Total execution time: 0.0039
ERROR - 2019-09-18 08:55:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:55:24 --> Total execution time: 0.0040
ERROR - 2019-09-18 08:55:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:55:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:55:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:55:28 --> Total execution time: 0.0046
ERROR - 2019-09-18 08:55:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:55:28 --> Total execution time: 0.0045
ERROR - 2019-09-18 08:55:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:55:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:55:29 --> Total execution time: 0.0041
ERROR - 2019-09-18 08:55:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:55:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:55:36 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:56:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:56:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:56:06 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:58:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:58:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:58:48 --> Total execution time: 0.0043
ERROR - 2019-09-18 08:58:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:58:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:58:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:58:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:58:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:58:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:58:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:58:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:58:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:58:52 --> Total execution time: 0.0045
ERROR - 2019-09-18 08:58:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:58:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:58:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:58:52 --> Total execution time: 0.0045
ERROR - 2019-09-18 08:58:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:58:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:58:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 08:58:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:58:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:58:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:58:58 --> Total execution time: 0.0033
ERROR - 2019-09-18 08:59:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 08:59:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 08:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 08:59:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 08:59:05 --> Total execution time: 0.0034
ERROR - 2019-09-18 09:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:01:28 --> Total execution time: 0.0020
ERROR - 2019-09-18 09:01:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:01:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:01:42 --> Total execution time: 0.0043
ERROR - 2019-09-18 09:01:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:01:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:01:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:01:45 --> Total execution time: 0.0044
ERROR - 2019-09-18 09:01:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:01:45 --> Total execution time: 0.0043
ERROR - 2019-09-18 09:01:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:01:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:01:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:01:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:01:50 --> Total execution time: 0.0032
ERROR - 2019-09-18 09:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:02:13 --> Total execution time: 0.0076
ERROR - 2019-09-18 09:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:02:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 09:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:02:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 09:03:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:03:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:03:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:03:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:03:19 --> Total execution time: 0.0031
ERROR - 2019-09-18 09:03:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:03:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:03:31 --> Total execution time: 0.0041
ERROR - 2019-09-18 09:03:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:03:32 --> UTF-8 Support Enabled
ERROR - 2019-09-18 09:03:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:03:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:03:32 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-18 09:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:03:32 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 09:03:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:03:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:03:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:03:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:03:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:03:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:03:53 --> Total execution time: 0.0029
ERROR - 2019-09-18 09:04:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:04:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:04:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:04:12 --> Total execution time: 0.0044
ERROR - 2019-09-18 09:04:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:04:13 --> Total execution time: 0.0022
ERROR - 2019-09-18 09:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:04:21 --> Total execution time: 0.0033
ERROR - 2019-09-18 09:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:04:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:04:31 --> Total execution time: 0.0051
ERROR - 2019-09-18 09:04:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:04:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:04:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:04:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:04:58 --> Total execution time: 0.0048
ERROR - 2019-09-18 09:05:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:05:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:05:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:05:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:05:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:05:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:05:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:05:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:05:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:05:01 --> Total execution time: 0.0047
ERROR - 2019-09-18 09:05:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:05:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:05:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:05:02 --> Total execution time: 0.0047
ERROR - 2019-09-18 09:05:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:05:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:05:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:05:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:05:15 --> Total execution time: 0.0036
ERROR - 2019-09-18 09:06:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:06:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:06:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:06:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:06:06 --> Total execution time: 0.0036
ERROR - 2019-09-18 09:06:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:06:09 --> Total execution time: 0.0040
ERROR - 2019-09-18 09:06:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:06:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 09:06:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:06:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:06:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:06:40 --> Total execution time: 0.0045
ERROR - 2019-09-18 09:06:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:06:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:06:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:06:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 09:06:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:06:51 --> Total execution time: 0.0040
ERROR - 2019-09-18 09:06:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:06:51 --> Total execution time: 0.0034
ERROR - 2019-09-18 09:06:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:06:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:06:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:06:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 09:06:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:06:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:06:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:08:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:08:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:08:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:08:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:08:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:08:23 --> Total execution time: 0.0039
ERROR - 2019-09-18 09:08:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:08:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:08:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:08:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:08:40 --> Total execution time: 0.0044
ERROR - 2019-09-18 09:08:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:08:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:08:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:08:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:08:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:08:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:08:42 --> Total execution time: 0.0028
ERROR - 2019-09-18 09:08:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:08:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:08:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:08:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:08:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:08:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:08:49 --> Total execution time: 0.0030
ERROR - 2019-09-18 09:11:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:11:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:11:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:11:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:11:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:11:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:11:22 --> Total execution time: 0.0043
ERROR - 2019-09-18 09:11:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:11:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:11:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:11:22 --> Total execution time: 0.0023
ERROR - 2019-09-18 09:11:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:11:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:11:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:11:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:11:32 --> Total execution time: 0.0047
ERROR - 2019-09-18 09:11:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:11:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:11:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:12:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:12:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:12:02 --> Total execution time: 0.0051
ERROR - 2019-09-18 09:12:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:12:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:12:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:12:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:12:18 --> Total execution time: 0.0046
ERROR - 2019-09-18 09:13:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:13:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:13:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:13:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:13:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:13:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:13:57 --> Total execution time: 0.0044
ERROR - 2019-09-18 09:14:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:14:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:14:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:14:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:14:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:14:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:14:03 --> Total execution time: 0.0044
ERROR - 2019-09-18 09:14:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:14:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:14:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:14:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:14:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:14:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:14:55 --> Total execution time: 0.0045
ERROR - 2019-09-18 09:14:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:14:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:14:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:14:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:14:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:14:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:14:57 --> Total execution time: 0.0027
ERROR - 2019-09-18 09:15:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:15:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:15:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:15:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:15:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:15:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:15:01 --> Total execution time: 0.0030
ERROR - 2019-09-18 09:15:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:15:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:15:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:15:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:15:06 --> Total execution time: 0.0028
ERROR - 2019-09-18 09:15:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:15:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:15:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:15:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:15:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:15:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:15:21 --> Total execution time: 0.0027
ERROR - 2019-09-18 09:15:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:15:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:15:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:15:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:15:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-18 09:15:29 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1241
ERROR - 2019-09-18 09:15:29 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1242
DEBUG - 2019-09-18 09:15:29 --> Total execution time: 0.0028
ERROR - 2019-09-18 09:18:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:18:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:18:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:18:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:18:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:18:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:18:41 --> Total execution time: 0.0035
ERROR - 2019-09-18 09:18:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:18:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:18:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:18:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:18:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:18:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:18:54 --> Total execution time: 0.0036
ERROR - 2019-09-18 09:19:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:19:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:19:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:19:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:19:14 --> Total execution time: 0.0033
ERROR - 2019-09-18 09:19:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:19:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:19:46 --> Total execution time: 0.0048
ERROR - 2019-09-18 09:19:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:19:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:19:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 09:19:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:19:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:19:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:20:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:20:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:20:04 --> Total execution time: 0.0043
ERROR - 2019-09-18 09:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:20:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:20:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 09:20:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:20:19 --> Total execution time: 0.0023
ERROR - 2019-09-18 09:20:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:20:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:20:21 --> Total execution time: 0.0022
ERROR - 2019-09-18 09:24:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:24:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:24:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:24:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:24:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:24:20 --> Total execution time: 0.0045
ERROR - 2019-09-18 09:24:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:24:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:24:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:24:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:24:21 --> Driver Token : 36695_2019/09/18-09:09:20
DEBUG - 2019-09-18 09:24:21 --> Date : 2019/09/18-09:09:20 End Day : 86400
DEBUG - 2019-09-18 09:24:21 --> Total execution time: 0.0029
ERROR - 2019-09-18 09:28:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:28:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:28:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:28:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:28:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:28:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:28:47 --> Total execution time: 0.0045
ERROR - 2019-09-18 09:28:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:28:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:28:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:28:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:28:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:28:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:28:48 --> Driver Token : 60642_2019/09/18-09:09:47
DEBUG - 2019-09-18 09:28:48 --> Date : 2019/09/18-09:09:47 End Day : 86400
DEBUG - 2019-09-18 09:28:48 --> Total execution time: 0.0030
ERROR - 2019-09-18 09:45:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:45:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:45:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:45:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:45:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:45:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:45:25 --> Total execution time: 0.0040
ERROR - 2019-09-18 09:45:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:45:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:45:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:45:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:45:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:45:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:45:51 --> Total execution time: 0.0050
ERROR - 2019-09-18 09:45:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:45:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:45:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:45:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:45:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:45:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:45:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:45:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:45:54 --> Total execution time: 0.0047
ERROR - 2019-09-18 09:45:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:45:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:45:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:45:54 --> Total execution time: 0.0046
ERROR - 2019-09-18 09:46:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:46:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:46:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:46:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:46:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:46:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:46:21 --> Total execution time: 0.0033
ERROR - 2019-09-18 09:46:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:46:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:46:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:46:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:46:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:46:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:46:58 --> Total execution time: 0.0033
ERROR - 2019-09-18 09:48:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:48:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:48:10 --> Total execution time: 0.0068
ERROR - 2019-09-18 09:48:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:48:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:48:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:48:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 09:48:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:48:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:48:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:48:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 09:48:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:48:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:48:36 --> Total execution time: 0.0032
ERROR - 2019-09-18 09:48:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:48:36 --> UTF-8 Support Enabled
ERROR - 2019-09-18 09:48:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:48:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:48:36 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-18 09:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:48:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 09:48:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:48:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:48:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:49:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:49:51 --> Total execution time: 0.0023
ERROR - 2019-09-18 09:49:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:49:54 --> Total execution time: 0.0023
ERROR - 2019-09-18 09:50:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:50:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:50:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:50:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:50:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:50:50 --> Total execution time: 0.0033
ERROR - 2019-09-18 09:50:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:50:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:50:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:50:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:50:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:50:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:50:54 --> Total execution time: 0.0028
ERROR - 2019-09-18 09:52:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:52:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:52:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:52:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:52:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:52:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:52:55 --> Total execution time: 0.0044
ERROR - 2019-09-18 09:52:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:52:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:52:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:52:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:52:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:52:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:52:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:52:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:52:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:52:59 --> Total execution time: 0.0045
ERROR - 2019-09-18 09:52:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:52:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:52:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:52:59 --> Total execution time: 0.0043
ERROR - 2019-09-18 09:53:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:53:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:53:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:53:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:53:08 --> Total execution time: 0.0030
ERROR - 2019-09-18 09:53:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:53:17 --> Total execution time: 0.0057
ERROR - 2019-09-18 09:53:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:53:18 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 09:53:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:53:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 09:53:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:53:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:53:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:53:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:53:23 --> Total execution time: 0.0024
ERROR - 2019-09-18 09:53:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:53:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:53:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:53:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:53:37 --> Total execution time: 0.0030
ERROR - 2019-09-18 09:54:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:54:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:54:07 --> Total execution time: 0.0034
ERROR - 2019-09-18 09:54:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:54:08 --> Total execution time: 0.0044
ERROR - 2019-09-18 09:54:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:54:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:54:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:54:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 09:54:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 09:54:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 09:54:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:54:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:54:47 --> Total execution time: 0.0026
ERROR - 2019-09-18 09:54:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:54:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:54:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:54:51 --> Total execution time: 0.0027
ERROR - 2019-09-18 09:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:54:52 --> Total execution time: 0.0027
ERROR - 2019-09-18 09:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:54:52 --> Total execution time: 0.0026
ERROR - 2019-09-18 09:54:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:54:53 --> Total execution time: 0.0027
ERROR - 2019-09-18 09:54:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:54:54 --> Total execution time: 0.0028
ERROR - 2019-09-18 09:54:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:54:55 --> Total execution time: 0.0025
ERROR - 2019-09-18 09:54:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:54:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:55:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:55:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:55:00 --> Total execution time: 0.0025
ERROR - 2019-09-18 09:55:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:55:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:55:00 --> Total execution time: 0.0024
ERROR - 2019-09-18 09:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:55:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:55:02 --> Total execution time: 0.0027
ERROR - 2019-09-18 09:55:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:55:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:55:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:55:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:55:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:55:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:55:05 --> Total execution time: 0.0025
ERROR - 2019-09-18 09:55:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:55:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:55:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:55:06 --> Total execution time: 0.0026
ERROR - 2019-09-18 09:56:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:56:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:56:03 --> Total execution time: 0.0029
ERROR - 2019-09-18 09:56:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:56:33 --> Total execution time: 0.0021
ERROR - 2019-09-18 09:56:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:56:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:56:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:56:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:56:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:56:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:56:46 --> Total execution time: 0.0046
ERROR - 2019-09-18 09:56:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:56:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:56:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:56:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:56:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:56:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:56:47 --> Driver Token : 91827_2019/09/18-09:09:46
DEBUG - 2019-09-18 09:56:47 --> Date : 2019/09/18-09:09:46 End Day : 86400
DEBUG - 2019-09-18 09:56:47 --> Total execution time: 0.0024
ERROR - 2019-09-18 09:58:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 09:58:40 --> Total execution time: 0.0046
ERROR - 2019-09-18 09:58:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:58:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:58:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 09:58:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 09:58:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 09:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 09:58:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 09:58:51 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:00:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:00:02 --> Total execution time: 0.0042
ERROR - 2019-09-18 10:00:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:00:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:00:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:00:17 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:00:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:00:17 --> Total execution time: 0.0032
ERROR - 2019-09-18 10:00:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:00:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:00:26 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:00:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:00:28 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:00:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:00:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:00:45 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:00:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:00:46 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:00:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:00:49 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:00:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:00:59 --> Total execution time: 0.0034
ERROR - 2019-09-18 10:00:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:00:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:00:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:00:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:00:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:00:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:00:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:01:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:01:13 --> Total execution time: 0.0054
ERROR - 2019-09-18 10:01:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:01:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:01:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:01:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:01:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:01:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:01:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:01:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:01:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:01:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:01:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:01:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:01:40 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:02:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:02:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:02:11 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:02:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:02:15 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:02:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:02:15 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:02:16 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:02:16 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:02:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:02:16 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:04:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:04:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:04:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:04:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:04:28 --> Total execution time: 0.0028
ERROR - 2019-09-18 10:04:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:04:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:04:57 --> Total execution time: 0.0022
ERROR - 2019-09-18 10:07:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:07:15 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:07:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:07:21 --> Total execution time: 0.0035
ERROR - 2019-09-18 10:07:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:07:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:07:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:07:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:07:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:07:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:07:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:07:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:07:27 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:07:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:07:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:07:31 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:07:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:07:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:07:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:07:50 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:08:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:08:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:08:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:08:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:08:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:23 --> Total execution time: 0.0023
ERROR - 2019-09-18 10:08:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:23 --> Total execution time: 0.0021
ERROR - 2019-09-18 10:08:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:23 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:08:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:23 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:08:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:08:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:08:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:41 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:08:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:41 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:08:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:45 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:08:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:08:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:08:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:49 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:08:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:49 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:08:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:50 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:08:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:50 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:08:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:50 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:08:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:51 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:08:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:51 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:08:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:52 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:08:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:08:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:08:53 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:09:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:09:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:29 --> Total execution time: 0.0029
ERROR - 2019-09-18 10:09:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:09:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:09:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:09:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:39 --> Total execution time: 0.0032
ERROR - 2019-09-18 10:09:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:39 --> Total execution time: 0.0021
ERROR - 2019-09-18 10:09:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:39 --> Total execution time: 0.0022
ERROR - 2019-09-18 10:09:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:39 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:09:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:39 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:09:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:39 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:09:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:39 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:09:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:09:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:46 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:09:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:46 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:09:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:47 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:09:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:09:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:09:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:52 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:09:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:09:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:09:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:09:52 --> Total execution time: 0.0020
ERROR - 2019-09-18 10:11:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:11:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:11:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:11:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:11:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:11:27 --> Total execution time: 0.0049
ERROR - 2019-09-18 10:11:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:11:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:11:40 --> Total execution time: 0.0043
ERROR - 2019-09-18 10:11:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:11:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:11:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:11:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:11:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:11:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-18 10:12:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:12:00 --> Total execution time: 0.0020
ERROR - 2019-09-18 10:12:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:12:00 --> Total execution time: 0.0019
ERROR - 2019-09-18 10:12:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:12:09 --> Total execution time: 0.0032
ERROR - 2019-09-18 10:12:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:12:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:12:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:12:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:12:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:36 --> Total execution time: 0.0029
ERROR - 2019-09-18 10:12:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:36 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:12:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:36 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:12:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:38 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:12:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:42 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:12:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:42 --> Total execution time: 0.0024
ERROR - 2019-09-18 10:12:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:42 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:12:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:12:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:12:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:42 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:12:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:12:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:12:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:12:43 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:14:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:14:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:17 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:14:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:22 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:14:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:14:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:14:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:26 --> Total execution time: 0.0028
ERROR - 2019-09-18 10:14:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:26 --> Total execution time: 0.0023
ERROR - 2019-09-18 10:14:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:26 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:14:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:30 --> Total execution time: 0.0028
ERROR - 2019-09-18 10:14:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:30 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:14:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:14:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:14:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:14:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:33 --> Total execution time: 0.0024
ERROR - 2019-09-18 10:14:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:34 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:14:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:34 --> Total execution time: 0.0023
ERROR - 2019-09-18 10:14:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:35 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:14:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:35 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:14:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:36 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:14:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:14:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:36 --> Total execution time: 0.0024
ERROR - 2019-09-18 10:14:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:41 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:14:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:14:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:45 --> Total execution time: 0.0027
ERROR - 2019-09-18 10:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:14:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:14:47 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:16:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:16:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:16:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:16:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:16:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:16:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:16:04 --> Total execution time: 0.0045
ERROR - 2019-09-18 10:16:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:16:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:16:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:16:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:16:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:16:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:16:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:16:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:16:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:16:08 --> Total execution time: 0.0046
ERROR - 2019-09-18 10:16:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:16:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:16:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:16:08 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:16:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:16:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:16:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:16:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:16:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:16:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:16:17 --> Total execution time: 0.0034
ERROR - 2019-09-18 10:19:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:19:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:19:34 --> Total execution time: 0.0040
ERROR - 2019-09-18 10:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:19:35 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:19:35 --> Total execution time: 0.0043
ERROR - 2019-09-18 10:19:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:19:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:19:41 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:19:42 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:19:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:19:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:19:46 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:19:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:19:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:19:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:19:53 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:04 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:04 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:10 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:14 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:14 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:20:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:14 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:15 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:15 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:15 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:16 --> Total execution time: 0.0022
ERROR - 2019-09-18 10:20:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:16 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:16 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:17 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:17 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:17 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:17 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:20:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:18 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:39 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:20:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:42 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:42 --> Total execution time: 0.0026
ERROR - 2019-09-18 10:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:42 --> Total execution time: 0.0025
ERROR - 2019-09-18 10:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:42 --> Total execution time: 0.0021
ERROR - 2019-09-18 10:20:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:43 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:20:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:43 --> Total execution time: 0.0046
ERROR - 2019-09-18 10:20:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:20:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:20:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:20:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:20:50 --> Total execution time: 0.0034
ERROR - 2019-09-18 10:24:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:24:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:24:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:24:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:24:12 --> Total execution time: 0.0030
ERROR - 2019-09-18 10:24:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:24:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:24:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:24:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:24:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:24:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:24:13 --> Total execution time: 0.0016
ERROR - 2019-09-18 10:26:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:26:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:26:55 --> Total execution time: 0.0034
ERROR - 2019-09-18 10:26:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:26:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:26:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:26:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:26:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:26:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:27:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:27:14 --> Total execution time: 0.0037
ERROR - 2019-09-18 10:27:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:27:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:27:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:27:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:27:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:27:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:27:26 --> Total execution time: 0.0022
ERROR - 2019-09-18 10:27:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:27:31 --> Total execution time: 0.0042
ERROR - 2019-09-18 10:27:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:27:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:27:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:27:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:33:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:33:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:33:42 --> Total execution time: 0.0034
ERROR - 2019-09-18 10:33:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:33:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:33:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:33:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:33:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:33:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:34:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:34:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:34:06 --> Total execution time: 0.0046
ERROR - 2019-09-18 10:34:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:34:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:34:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:34:11 --> Total execution time: 0.0045
ERROR - 2019-09-18 10:34:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:34:11 --> Total execution time: 0.0043
ERROR - 2019-09-18 10:34:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:34:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:34:24 --> Total execution time: 0.0035
ERROR - 2019-09-18 10:34:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:34:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:34:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:34:31 --> Total execution time: 0.0029
ERROR - 2019-09-18 10:35:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:35:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:35:03 --> Total execution time: 0.0021
ERROR - 2019-09-18 10:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:36:39 --> Total execution time: 0.0041
ERROR - 2019-09-18 10:36:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:36:50 --> Total execution time: 0.0031
ERROR - 2019-09-18 10:36:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:36:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:36:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:36:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:36:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:36:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:37:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:37:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:37:19 --> Total execution time: 0.0036
ERROR - 2019-09-18 10:37:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:37:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:37:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:37:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:37:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:37:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:37:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:37:54 --> Total execution time: 0.0022
ERROR - 2019-09-18 10:38:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:38:09 --> Total execution time: 0.0042
ERROR - 2019-09-18 10:38:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:38:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:38:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:38:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:38:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:38:23 --> Total execution time: 0.0040
ERROR - 2019-09-18 10:38:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:38:25 --> Total execution time: 0.0041
ERROR - 2019-09-18 10:38:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:38:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:38:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:38:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:38:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:38:32 --> Total execution time: 0.0042
ERROR - 2019-09-18 10:38:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:38:32 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:38:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:38:32 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:38:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:38:42 --> Total execution time: 0.0041
ERROR - 2019-09-18 10:38:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:38:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:38:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:38:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:39:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:39:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:39:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:39:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:39:19 --> Total execution time: 0.0032
ERROR - 2019-09-18 10:39:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:39:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:39:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:39:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:39:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:39:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:39:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:39:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:39:30 --> Total execution time: 0.0020
ERROR - 2019-09-18 10:39:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:39:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:39:34 --> Total execution time: 0.0020
ERROR - 2019-09-18 10:40:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:40:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:40:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:40:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:40:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:40:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:40:15 --> Total execution time: 0.0041
ERROR - 2019-09-18 10:40:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:40:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:40:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:40:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:40:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:40:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:40:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:40:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:40:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:40:18 --> Total execution time: 0.0046
ERROR - 2019-09-18 10:40:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:40:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:40:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:40:19 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:40:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:40:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:40:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:40:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:40:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:40:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:40:39 --> Total execution time: 0.0031
ERROR - 2019-09-18 10:44:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:44:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:44:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:44:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:44:29 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:44:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:44:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:44:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:44:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:44:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:44:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:44:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:44:33 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:44:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:44:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:44:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:44:33 --> Total execution time: 0.0043
ERROR - 2019-09-18 10:44:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:44:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:44:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:44:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:44:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:44:59 --> Total execution time: 0.0031
ERROR - 2019-09-18 10:45:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:45:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:45:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:45:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:45:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:45:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:45:46 --> Total execution time: 0.0043
ERROR - 2019-09-18 10:45:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:45:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:45:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:45:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:45:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:45:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:45:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:45:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:45:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:45:48 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:45:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:45:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:45:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:45:48 --> Total execution time: 0.0045
ERROR - 2019-09-18 10:46:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:46:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:46:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:46:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:46:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:46:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:46:00 --> Total execution time: 0.0031
ERROR - 2019-09-18 10:46:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:46:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:46:23 --> Total execution time: 0.0022
ERROR - 2019-09-18 10:46:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:46:27 --> Total execution time: 0.0020
ERROR - 2019-09-18 10:46:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:46:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:46:30 --> Total execution time: 0.0021
ERROR - 2019-09-18 10:51:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:51:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:51:17 --> Total execution time: 0.0047
ERROR - 2019-09-18 10:51:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:51:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:51:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:51:20 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:51:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:51:21 --> Total execution time: 0.0043
ERROR - 2019-09-18 10:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:51:30 --> Total execution time: 0.0031
ERROR - 2019-09-18 10:51:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:51:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:51:33 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:51:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:51:55 --> Total execution time: 0.0043
ERROR - 2019-09-18 10:51:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:51:56 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:51:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:51:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:51:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:51:56 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 10:52:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:52:04 --> Total execution time: 0.0030
ERROR - 2019-09-18 10:52:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:52:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 10:52:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:52:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:52:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 10:52:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:52:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:52:22 --> Total execution time: 0.0021
ERROR - 2019-09-18 10:52:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:52:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:52:29 --> Total execution time: 0.0020
ERROR - 2019-09-18 10:55:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:55:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:55:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:55:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:55:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:55:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:55:20 --> Total execution time: 0.0040
ERROR - 2019-09-18 10:55:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:55:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:55:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:55:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:55:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:55:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:55:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:55:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:55:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:55:23 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:55:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:55:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:55:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:55:23 --> Total execution time: 0.0044
ERROR - 2019-09-18 10:55:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:55:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:55:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 10:55:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:55:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:55:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 10:55:35 --> Total execution time: 0.0031
ERROR - 2019-09-18 10:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 10:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 10:58:20 --> Total execution time: 0.0047
ERROR - 2019-09-18 10:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:58:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:58:20 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 10:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 10:58:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 10:58:20 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 11:02:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:02:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:02:26 --> Total execution time: 0.0033
ERROR - 2019-09-18 11:02:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:02:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:02:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:02:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 11:02:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:02:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:02:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:02:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:03:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:03:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:03:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:03:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:03:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 950
DEBUG - 2019-09-18 11:03:16 --> Total execution time: 0.0024
ERROR - 2019-09-18 11:03:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:03:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:03:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:03:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:03:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 950
DEBUG - 2019-09-18 11:03:23 --> Total execution time: 0.0025
ERROR - 2019-09-18 11:03:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:03:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:03:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:03:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:03:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:03:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:03:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 950
DEBUG - 2019-09-18 11:03:32 --> Total execution time: 0.0026
ERROR - 2019-09-18 11:03:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:03:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:03:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:03:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 950
DEBUG - 2019-09-18 11:03:33 --> Total execution time: 0.0025
ERROR - 2019-09-18 11:04:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:04:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:04:40 --> Total execution time: 0.0038
ERROR - 2019-09-18 11:04:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:04:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:04:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 11:04:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:04:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:04:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:04:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:04:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:04:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:04:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:04:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:04:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:04:47 --> Total execution time: 0.0030
ERROR - 2019-09-18 11:05:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:05:02 --> Total execution time: 0.0038
ERROR - 2019-09-18 11:05:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:05:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:05:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:05:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 11:05:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:05:06 --> Total execution time: 0.0037
ERROR - 2019-09-18 11:05:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:05:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 11:05:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:05:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:05:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:05:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:05:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:05:39 --> Total execution time: 0.0020
ERROR - 2019-09-18 11:05:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:05:46 --> Total execution time: 0.0029
ERROR - 2019-09-18 11:05:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:05:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 11:05:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:05:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:05:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:05:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:05:53 --> Total execution time: 0.0042
ERROR - 2019-09-18 11:05:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:05:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:05:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:05:57 --> Total execution time: 0.0045
ERROR - 2019-09-18 11:05:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:05:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:05:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:05:57 --> Total execution time: 0.0044
ERROR - 2019-09-18 11:06:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:06:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:06:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:06:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:06:03 --> Total execution time: 0.0030
ERROR - 2019-09-18 11:06:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:06:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:06:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:06:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:06:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:06:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:06:06 --> Severity: error --> Exception: Call to undefined method m_fees::getContent() /var/www/html/school/application/controllers/Api.php 48
ERROR - 2019-09-18 11:06:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:06:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:06:44 --> Total execution time: 0.0020
ERROR - 2019-09-18 11:06:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:06:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:06:46 --> Total execution time: 0.0019
ERROR - 2019-09-18 11:07:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:07:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:07:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:07:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:07:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:07:18 --> Total execution time: 0.0035
ERROR - 2019-09-18 11:07:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:07:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:07:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:07:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:07:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:07:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:07:26 --> mPDF class is loaded.
ERROR - 2019-09-18 11:07:26 --> Severity: Warning --> include_once(/var/www/html/school/application//third_party/mpdf/mpdf.php): failed to open stream: No such file or directory /var/www/html/school/application/libraries/Pdf.php 11
ERROR - 2019-09-18 11:07:26 --> Severity: Warning --> include_once(): Failed opening '/var/www/html/school/application//third_party/mpdf/mpdf.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/school/application/libraries/Pdf.php 11
ERROR - 2019-09-18 11:07:26 --> Severity: error --> Exception: Class 'mPDF' not found /var/www/html/school/application/libraries/Pdf.php 16
ERROR - 2019-09-18 11:07:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:07:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:07:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:07:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:07:29 --> Total execution time: 0.0031
ERROR - 2019-09-18 11:07:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:07:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:07:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:07:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:07:34 --> mPDF class is loaded.
ERROR - 2019-09-18 11:07:34 --> Severity: Warning --> include_once(/var/www/html/school/application//third_party/mpdf/mpdf.php): failed to open stream: No such file or directory /var/www/html/school/application/libraries/Pdf.php 11
ERROR - 2019-09-18 11:07:34 --> Severity: Warning --> include_once(): Failed opening '/var/www/html/school/application//third_party/mpdf/mpdf.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/school/application/libraries/Pdf.php 11
ERROR - 2019-09-18 11:07:34 --> Severity: error --> Exception: Class 'mPDF' not found /var/www/html/school/application/libraries/Pdf.php 16
ERROR - 2019-09-18 11:10:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:10:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:10:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:10:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:10:39 --> Total execution time: 0.0034
ERROR - 2019-09-18 11:13:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:13:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:13:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:13:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:13:23 --> Total execution time: 0.0033
ERROR - 2019-09-18 11:13:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:13:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:13:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:13:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:13:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:13:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:13:38 --> mPDF class is loaded.
DEBUG - 2019-09-18 12:13:38 --> Total execution time: 0.4653
ERROR - 2019-09-18 11:17:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:17:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:17:45 --> Total execution time: 0.0043
ERROR - 2019-09-18 11:17:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:17:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:17:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 11:17:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:17:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:17:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 11:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:18:00 --> Total execution time: 0.0030
ERROR - 2019-09-18 11:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:18:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 11:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:18:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:18:10 --> Total execution time: 0.0032
ERROR - 2019-09-18 11:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:18:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 11:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:18:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:19:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:19:00 --> Total execution time: 0.0051
ERROR - 2019-09-18 11:19:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:19:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 11:19:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:19:00 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 11:19:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:19:13 --> Total execution time: 0.0038
ERROR - 2019-09-18 11:19:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:19:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-18 11:19:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:19:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:19:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:19:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-18 11:20:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:20:27 --> Total execution time: 0.0039
ERROR - 2019-09-18 11:20:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:20:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 11:20:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:20:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 11:20:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:20:43 --> Total execution time: 0.0040
ERROR - 2019-09-18 11:20:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:20:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 11:20:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:20:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 11:20:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:20:49 --> Total execution time: 0.0039
ERROR - 2019-09-18 11:20:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:20:50 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 11:20:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:20:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 11:20:50 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 11:21:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:21:17 --> Total execution time: 0.0020
ERROR - 2019-09-18 11:21:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 11:21:20 --> Total execution time: 0.0022
ERROR - 2019-09-18 11:21:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:21:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:21:28 --> Total execution time: 0.0045
ERROR - 2019-09-18 11:21:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:21:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:21:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:21:31 --> Total execution time: 0.0043
ERROR - 2019-09-18 11:21:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:21:31 --> Total execution time: 0.0043
ERROR - 2019-09-18 11:21:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:21:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:21:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:21:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:21:44 --> Total execution time: 0.0033
ERROR - 2019-09-18 11:24:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:24:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:24:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:24:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:24:43 --> Total execution time: 0.0043
ERROR - 2019-09-18 11:24:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:24:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:24:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:24:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:24:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:24:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:24:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:24:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:24:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:24:47 --> Total execution time: 0.0045
ERROR - 2019-09-18 11:24:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:24:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:24:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:24:47 --> Total execution time: 0.0045
ERROR - 2019-09-18 11:24:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:24:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:24:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:24:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:24:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:24:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:24:51 --> Total execution time: 0.0033
ERROR - 2019-09-18 11:25:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:25:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:25:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:25:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:25:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:25:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:25:16 --> Total execution time: 0.0034
ERROR - 2019-09-18 11:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:30:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:30:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:30:51 --> Total execution time: 0.0035
ERROR - 2019-09-18 11:32:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:32:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:32:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:32:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:32:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:32:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:32:40 --> Total execution time: 0.0043
ERROR - 2019-09-18 11:32:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:32:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:32:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:32:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:32:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:32:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:32:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:32:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:32:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:32:43 --> Total execution time: 0.0044
ERROR - 2019-09-18 11:32:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:32:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:32:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:32:44 --> Total execution time: 0.0044
ERROR - 2019-09-18 11:33:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:33:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:33:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:33:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:33:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:33:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:33:00 --> Total execution time: 0.0033
ERROR - 2019-09-18 11:39:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:39:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:39:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:39:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:39:19 --> Total execution time: 0.0051
ERROR - 2019-09-18 11:39:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:39:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:39:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:39:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:39:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:39:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:39:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:39:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:39:23 --> Total execution time: 0.0044
ERROR - 2019-09-18 11:39:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:39:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:39:23 --> Total execution time: 0.0044
ERROR - 2019-09-18 11:42:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:42:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:42:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:42:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:42:13 --> Total execution time: 0.0045
ERROR - 2019-09-18 11:42:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:42:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:42:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:42:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:42:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:42:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:42:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:42:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:42:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:42:16 --> Total execution time: 0.0047
ERROR - 2019-09-18 11:42:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:42:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:42:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:42:17 --> Total execution time: 0.0044
ERROR - 2019-09-18 11:53:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:53:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:53:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:53:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:53:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:53:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:53:29 --> Total execution time: 0.0065
ERROR - 2019-09-18 11:53:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:53:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:53:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:53:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:53:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:53:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:53:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:53:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:53:33 --> Total execution time: 0.0045
ERROR - 2019-09-18 11:53:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:53:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:53:33 --> Total execution time: 0.0043
ERROR - 2019-09-18 11:53:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:53:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:53:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:53:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:53:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:53:39 --> Total execution time: 0.0034
ERROR - 2019-09-18 11:55:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:55:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:55:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:55:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:55:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:55:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:55:44 --> Total execution time: 0.0040
ERROR - 2019-09-18 11:56:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:56:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:56:05 --> Total execution time: 0.0043
ERROR - 2019-09-18 11:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:56:07 --> Total execution time: 0.0025
ERROR - 2019-09-18 11:56:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:56:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:56:09 --> Total execution time: 0.0027
ERROR - 2019-09-18 11:56:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:56:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:56:13 --> Severity: Notice --> Undefined index: class /var/www/html/school/application/controllers/Api.php 1169
DEBUG - 2019-09-18 11:56:13 --> Total execution time: 0.0025
ERROR - 2019-09-18 11:56:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:56:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:56:38 --> Total execution time: 0.0044
ERROR - 2019-09-18 11:56:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:56:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:56:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:56:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:56:41 --> Total execution time: 0.0043
ERROR - 2019-09-18 11:57:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:57:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:57:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:57:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:57:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:57:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:57:48 --> Total execution time: 0.0042
ERROR - 2019-09-18 11:57:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:57:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:57:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:57:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:57:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:57:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:57:50 --> Total execution time: 0.0026
ERROR - 2019-09-18 11:57:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:57:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:57:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:57:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:57:54 --> Total execution time: 0.0028
ERROR - 2019-09-18 11:57:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:57:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:57:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:57:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:57:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:57:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:57:59 --> Total execution time: 0.0025
ERROR - 2019-09-18 11:58:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:58:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:58:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:58:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:58:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:58:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 11:58:05 --> Total execution time: 0.0025
ERROR - 2019-09-18 11:58:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:58:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:58:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:58:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 11:58:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 11:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 11:58:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 11:58:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 11:58:10 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 11:58:10 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 11:58:10 --> Total execution time: 0.0024
ERROR - 2019-09-18 12:09:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:09:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:09:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:09:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:09:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 12:09:10 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 12:09:10 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 12:09:10 --> Total execution time: 0.0023
ERROR - 2019-09-18 12:09:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:09:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:09:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:09:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:09:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 12:09:20 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 12:09:20 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 12:09:20 --> Total execution time: 0.0024
ERROR - 2019-09-18 12:09:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:09:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:09:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:09:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 12:09:21 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 12:09:21 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 12:09:21 --> Total execution time: 0.0023
ERROR - 2019-09-18 12:09:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:09:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:09:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:09:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:09:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:09:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 12:09:29 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 12:09:29 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 12:09:29 --> Total execution time: 0.0030
ERROR - 2019-09-18 12:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:11:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:11:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:11:55 --> Total execution time: 0.0042
ERROR - 2019-09-18 12:11:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:11:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:11:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:11:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:11:58 --> Total execution time: 0.0027
ERROR - 2019-09-18 12:12:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:12:01 --> Total execution time: 0.0028
ERROR - 2019-09-18 12:12:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:12:08 --> Total execution time: 0.0024
ERROR - 2019-09-18 12:12:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:12:12 --> Total execution time: 0.0026
ERROR - 2019-09-18 12:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:21 --> Severity: Notice --> Undefined index: attendance /var/www/html/school/application/controllers/Api.php 1269
ERROR - 2019-09-18 12:12:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 12:12:21 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 12:12:21 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 12:12:21 --> Total execution time: 0.0024
ERROR - 2019-09-18 12:12:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:32 --> Severity: Notice --> Undefined index: attendance /var/www/html/school/application/controllers/Api.php 1269
ERROR - 2019-09-18 12:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 12:12:32 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 12:12:32 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 12:12:32 --> Total execution time: 0.0025
ERROR - 2019-09-18 12:12:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:36 --> Severity: Notice --> Undefined index: attendance /var/www/html/school/application/controllers/Api.php 1269
ERROR - 2019-09-18 12:12:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 12:12:36 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 12:12:36 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 12:12:36 --> Total execution time: 0.0025
ERROR - 2019-09-18 12:12:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:12:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:12:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:12:41 --> Severity: Notice --> Undefined index: attendance /var/www/html/school/application/controllers/Api.php 1269
ERROR - 2019-09-18 12:12:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-18 12:12:41 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-18 12:12:41 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-18 12:12:41 --> Total execution time: 0.0021
ERROR - 2019-09-18 12:13:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:13:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 12:13:05 --> Total execution time: 0.0024
ERROR - 2019-09-18 12:13:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:13:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 12:13:10 --> Total execution time: 0.0024
ERROR - 2019-09-18 12:25:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:25:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:25:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:25:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:25:01 --> Total execution time: 0.0043
ERROR - 2019-09-18 12:25:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:25:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:25:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:25:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:25:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:25:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:25:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:25:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:25:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:25:04 --> Total execution time: 0.0044
ERROR - 2019-09-18 12:25:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:25:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:25:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:25:05 --> Total execution time: 0.0043
ERROR - 2019-09-18 12:25:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:25:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:25:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:25:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:25:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:25:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:25:15 --> Total execution time: 0.0034
ERROR - 2019-09-18 12:26:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:26:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:26:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:26:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:26:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:26:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:26:51 --> Total execution time: 0.0030
ERROR - 2019-09-18 12:29:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:29:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:29:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:29:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:29:50 --> Total execution time: 0.0042
ERROR - 2019-09-18 12:29:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:29:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:29:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:29:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:29:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:29:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:29:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:29:53 --> Total execution time: 0.0045
ERROR - 2019-09-18 12:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:29:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:29:54 --> Total execution time: 0.0044
ERROR - 2019-09-18 12:29:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:29:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:30:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:30:00 --> Total execution time: 0.0030
ERROR - 2019-09-18 12:30:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:30:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:30:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:30:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:30:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:30:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:30:03 --> mPDF class is loaded.
DEBUG - 2019-09-18 13:30:04 --> Total execution time: 0.3127
ERROR - 2019-09-18 12:30:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:30:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:30:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:30:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:30:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:30:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:30:59 --> Total execution time: 0.0030
ERROR - 2019-09-18 12:31:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:31:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:31:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:31:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:31:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:31:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:31:07 --> mPDF class is loaded.
DEBUG - 2019-09-18 13:31:07 --> Total execution time: 0.3066
ERROR - 2019-09-18 12:32:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:32:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:32:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:32:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:32:49 --> Total execution time: 0.0041
ERROR - 2019-09-18 12:32:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:32:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:32:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:32:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:32:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:32:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:32:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:32:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:32:53 --> Total execution time: 0.0046
ERROR - 2019-09-18 12:32:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:32:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:32:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:32:53 --> Total execution time: 0.0044
ERROR - 2019-09-18 12:33:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:33:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:33:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:33:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:33:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:33:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:33:01 --> Total execution time: 0.0030
ERROR - 2019-09-18 12:33:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:33:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:33:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:33:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:33:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:33:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:33:08 --> mPDF class is loaded.
DEBUG - 2019-09-18 13:33:08 --> Total execution time: 0.3008
ERROR - 2019-09-18 12:34:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:34:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:34:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:34:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:34:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:34:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:34:46 --> mPDF class is loaded.
DEBUG - 2019-09-18 13:34:46 --> Total execution time: 0.3079
ERROR - 2019-09-18 12:43:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:43:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 12:43:36 --> Total execution time: 0.0042
ERROR - 2019-09-18 12:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 12:43:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 12:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 12:43:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 12:47:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:47:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:47:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:47:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:47:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:47:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:47:48 --> Total execution time: 0.0041
ERROR - 2019-09-18 12:47:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:47:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:47:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:47:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:47:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:47:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:47:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:47:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:47:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:47:52 --> Total execution time: 0.0045
ERROR - 2019-09-18 12:47:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:47:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:47:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:47:52 --> Total execution time: 0.0044
ERROR - 2019-09-18 12:52:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:52:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:52:08 --> Total execution time: 0.0041
ERROR - 2019-09-18 12:52:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:52:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:52:12 --> Total execution time: 0.0046
ERROR - 2019-09-18 12:52:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:52:12 --> Total execution time: 0.0045
ERROR - 2019-09-18 12:52:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:52:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:52:21 --> Total execution time: 0.0032
ERROR - 2019-09-18 12:52:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:52:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:52:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:52:24 --> mPDF class is loaded.
DEBUG - 2019-09-18 13:52:25 --> Total execution time: 0.2988
ERROR - 2019-09-18 12:55:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:55:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:55:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 12:55:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 12:55:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 12:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 12:55:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 12:55:00 --> mPDF class is loaded.
DEBUG - 2019-09-18 13:55:00 --> Total execution time: 0.2745
ERROR - 2019-09-18 13:01:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:01:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:01:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:01:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:01:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:01:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:01:38 --> Total execution time: 0.0029
ERROR - 2019-09-18 13:01:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:01:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:01:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:01:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:01:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:01:48 --> mPDF class is loaded.
DEBUG - 2019-09-18 14:01:48 --> Total execution time: 0.2743
ERROR - 2019-09-18 13:02:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:02:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:02:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:02:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:02:13 --> mPDF class is loaded.
DEBUG - 2019-09-18 14:02:13 --> Total execution time: 0.2979
ERROR - 2019-09-18 13:04:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:04:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:04:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:04:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:04:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:04:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:04:32 --> Total execution time: 0.0044
ERROR - 2019-09-18 13:04:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:04:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:04:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:04:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:04:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:04:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:04:34 --> Severity: error --> Exception: syntax error, unexpected ';' /var/www/html/school/application/models/M_drivers.php 225
ERROR - 2019-09-18 13:11:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:11:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:11:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:11:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:11:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:11:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:11:12 --> Total execution time: 0.0019
ERROR - 2019-09-18 13:11:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:11:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:11:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:11:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:11:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:11:32 --> Total execution time: 0.0043
ERROR - 2019-09-18 13:11:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:11:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:11:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:11:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:11:40 --> Total execution time: 0.0044
ERROR - 2019-09-18 13:13:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:13:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:13:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:13:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:13:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:13:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:13:36 --> Total execution time: 0.0042
ERROR - 2019-09-18 13:13:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:13:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:13:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:13:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:13:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:13:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:13:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:13:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:13:42 --> Total execution time: 0.0048
ERROR - 2019-09-18 13:13:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:13:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:13:42 --> Total execution time: 0.0047
ERROR - 2019-09-18 13:14:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:14:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:14:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:14:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:14:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:14:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:14:09 --> Total execution time: 0.0033
ERROR - 2019-09-18 13:14:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:14:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:14:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:14:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:14:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:14:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:14:16 --> mPDF class is loaded.
DEBUG - 2019-09-18 14:14:16 --> Total execution time: 0.3060
ERROR - 2019-09-18 13:16:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 13:16:14 --> Total execution time: 0.0023
ERROR - 2019-09-18 13:16:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:16:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 13:16:26 --> Total execution time: 0.0024
ERROR - 2019-09-18 13:16:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 13:16:34 --> Total execution time: 0.0025
ERROR - 2019-09-18 13:16:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:16:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 13:16:51 --> Total execution time: 0.0027
ERROR - 2019-09-18 13:17:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:17:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 13:17:21 --> Total execution time: 0.0048
ERROR - 2019-09-18 13:17:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:17:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 13:17:29 --> Total execution time: 0.0044
ERROR - 2019-09-18 13:17:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 13:17:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 13:17:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 13:17:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 13:18:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:18:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 13:18:47 --> Total execution time: 0.0043
ERROR - 2019-09-18 13:18:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:18:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 13:18:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 13:18:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:18:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 13:18:48 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 13:20:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:20:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:20:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:20:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:20:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:20:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:20:50 --> Total execution time: 0.0043
ERROR - 2019-09-18 13:20:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:20:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:20:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:20:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:20:58 --> Total execution time: 0.0045
ERROR - 2019-09-18 13:22:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:22:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:22:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:22:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:22:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:22:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:22:37 --> Total execution time: 0.0193
ERROR - 2019-09-18 13:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:22:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:22:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:22:45 --> Total execution time: 0.0059
ERROR - 2019-09-18 13:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-18 13:26:25 --> Total execution time: 0.0185
ERROR - 2019-09-18 13:26:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 13:26:26 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-18 13:26:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 13:26:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-18 13:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:35:19 --> Total execution time: 0.0048
ERROR - 2019-09-18 13:35:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:35:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:35:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:35:23 --> Total execution time: 0.0062
ERROR - 2019-09-18 13:35:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:35:23 --> Total execution time: 0.0047
ERROR - 2019-09-18 13:35:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:35:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:35:35 --> Total execution time: 0.0033
ERROR - 2019-09-18 13:35:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:35:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:35:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:35:39 --> mPDF class is loaded.
DEBUG - 2019-09-18 14:35:39 --> Total execution time: 0.4530
ERROR - 2019-09-18 13:36:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:36:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:36:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:36:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:36:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:36:15 --> Driver Route Token ::::: 89527_2019/09/18-13:09:45
ERROR - 2019-09-18 13:36:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1358
DEBUG - 2019-09-18 13:36:15 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 0
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4763702  Threads: 1  Questions: 187609  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39029
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 0
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:36:15 --> Total execution time: 0.0045
ERROR - 2019-09-18 13:36:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:36:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:36:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:36:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:36:34 --> Total execution time: 0.0029
ERROR - 2019-09-18 13:38:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:38:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:38:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:38:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:38:08 --> Total execution time: 0.0048
ERROR - 2019-09-18 13:38:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:38:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:38:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:38:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:38:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:38:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:38:50 --> mPDF class is loaded.
DEBUG - 2019-09-18 14:38:50 --> Total execution time: 0.2781
ERROR - 2019-09-18 13:40:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:40:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:40:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:40:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:40:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:40:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:40:12 --> Total execution time: 0.0040
ERROR - 2019-09-18 13:41:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:41:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:41:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:41:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:41:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:41:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:41:30 --> Total execution time: 0.0046
ERROR - 2019-09-18 13:49:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:49:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:49:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:49:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:49:43 --> Total execution time: 0.0028
ERROR - 2019-09-18 13:51:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:51:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:51:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:51:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:51:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:51:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:51:10 --> Total execution time: 0.0027
ERROR - 2019-09-18 13:51:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:51:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:51:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:51:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:51:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:51:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:51:16 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
ERROR - 2019-09-18 13:51:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1358
DEBUG - 2019-09-18 13:51:16 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 0
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4764603  Threads: 1  Questions: 187709  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39053
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 0
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:51:16 --> Total execution time: 0.0037
ERROR - 2019-09-18 13:53:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:53:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:53:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:53:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:53:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:53:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:53:41 --> Total execution time: 0.0043
ERROR - 2019-09-18 13:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:53:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:53:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:53:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:53:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:53:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:53:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:53:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:53:45 --> Total execution time: 0.0045
ERROR - 2019-09-18 13:53:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:53:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:53:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:53:45 --> Total execution time: 0.0043
ERROR - 2019-09-18 13:54:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:54:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:54:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:54:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:54:21 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 13:54:21 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4764788  Threads: 1  Questions: 187753  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39061
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:54:21 --> Total execution time: 0.0035
ERROR - 2019-09-18 13:55:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:55:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:55:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:55:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:55:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:55:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:55:39 --> Total execution time: 0.0037
ERROR - 2019-09-18 13:55:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:55:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:55:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:55:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:55:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:55:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:55:42 --> mPDF class is loaded.
DEBUG - 2019-09-18 14:55:42 --> Total execution time: 0.3058
ERROR - 2019-09-18 13:55:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:55:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:55:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:55:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:55:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:55:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:55:57 --> mPDF class is loaded.
DEBUG - 2019-09-18 14:55:57 --> Total execution time: 0.2988
ERROR - 2019-09-18 13:56:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:56:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:56:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:56:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:56:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:56:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:56:01 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
ERROR - 2019-09-18 13:56:01 --> Severity: Notice --> Array to string conversion /var/www/html/school/application/controllers/Api.php 1358
DEBUG - 2019-09-18 13:56:01 --> Driver ::::: Array
DEBUG - 2019-09-18 13:56:01 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4764888  Threads: 1  Questions: 187792  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39069
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:56:01 --> Total execution time: 0.0037
ERROR - 2019-09-18 13:56:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:56:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:56:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:56:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:56:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:56:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:56:42 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
ERROR - 2019-09-18 13:56:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/school/application/controllers/Api.php 1358
DEBUG - 2019-09-18 13:56:42 --> Driver ::::: 
DEBUG - 2019-09-18 13:56:42 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4764929  Threads: 1  Questions: 187802  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39071
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:56:42 --> Total execution time: 0.0038
ERROR - 2019-09-18 13:57:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:57:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:57:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:57:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:57:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:57:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:57:07 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
ERROR - 2019-09-18 13:57:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/school/application/controllers/Api.php 1358
DEBUG - 2019-09-18 13:57:07 --> Driver ::::: 
DEBUG - 2019-09-18 13:57:07 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4764954  Threads: 1  Questions: 187812  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39073
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:57:07 --> Total execution time: 0.0037
ERROR - 2019-09-18 13:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:57:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:57:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:57:53 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
ERROR - 2019-09-18 13:57:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/school/application/controllers/Api.php 1358
DEBUG - 2019-09-18 13:57:53 --> Driver ::::: 
DEBUG - 2019-09-18 13:57:53 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4765000  Threads: 1  Questions: 187822  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39075
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:57:53 --> Total execution time: 0.0038
ERROR - 2019-09-18 13:59:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:59:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:59:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:59:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:59:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:59:08 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 13:59:08 --> Driver ::::: 112
DEBUG - 2019-09-18 13:59:08 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4765075  Threads: 1  Questions: 187832  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39077
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:59:08 --> Total execution time: 0.0035
ERROR - 2019-09-18 13:59:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:59:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:59:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 13:59:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 13:59:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 13:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 13:59:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 13:59:38 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 13:59:38 --> Driver ::::: 10
DEBUG - 2019-09-18 13:59:38 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 20
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4765105  Threads: 1  Questions: 187842  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39079
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 20
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-18 13:59:38 --> Total execution time: 0.0036
ERROR - 2019-09-18 14:02:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:02:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:02:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:02:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:02:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:02:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:02:53 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:02:53 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:02:53 --> Total execution time: 0.0039
ERROR - 2019-09-18 14:09:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:09:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:09:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:09:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:09:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:09:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:09:06 --> Total execution time: 0.0027
ERROR - 2019-09-18 14:09:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:09:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:09:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:09:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:09:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:09:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:09:09 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:09:09 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:09:09 --> Total execution time: 0.0035
ERROR - 2019-09-18 14:20:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:20:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:20:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:20:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:20:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:20:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:20:09 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:20:09 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:20:09 --> Total execution time: 0.0033
ERROR - 2019-09-18 14:21:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:21:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:21:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:21:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:21:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:21:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:21:26 --> Total execution time: 0.0027
ERROR - 2019-09-18 14:21:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:21:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:21:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:21:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:21:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:21:27 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:21:27 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:21:27 --> Total execution time: 0.0032
ERROR - 2019-09-18 14:25:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:25:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:25:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:25:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:25:44 --> Total execution time: 0.0026
ERROR - 2019-09-18 14:25:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:25:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:25:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:25:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:25:45 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:25:45 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:25:45 --> Total execution time: 0.0032
ERROR - 2019-09-18 14:30:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:30:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:30:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:30:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:30:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:30:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:30:24 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:30:24 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:30:24 --> Total execution time: 0.0032
ERROR - 2019-09-18 14:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:32:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:32:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:32:06 --> Total execution time: 0.0027
ERROR - 2019-09-18 14:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:32:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:32:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:32:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:32:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:32:07 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:32:07 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:32:07 --> Total execution time: 0.0032
ERROR - 2019-09-18 14:34:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:34:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:34:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:34:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:34:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:34:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:34:23 --> Total execution time: 0.0028
ERROR - 2019-09-18 14:34:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:34:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:34:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:34:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:34:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:34:25 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:34:25 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:34:25 --> Total execution time: 0.0033
ERROR - 2019-09-18 14:52:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:52:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 14:52:54 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/school/application/controllers/Api.php 1375
ERROR - 2019-09-18 14:53:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 14:53:00 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/school/application/controllers/Api.php 1375
ERROR - 2019-09-18 14:53:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:53:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 14:53:12 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/school/application/controllers/Api.php 1375
ERROR - 2019-09-18 14:53:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:53:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:53:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 14:53:15 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/school/application/controllers/Api.php 1375
ERROR - 2019-09-18 14:53:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:53:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-18 14:53:18 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/school/application/controllers/Api.php 1375
ERROR - 2019-09-18 14:54:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:54:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:54:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:54:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:54:02 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:54:02 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:54:02 --> Total execution time: 0.0032
ERROR - 2019-09-18 14:54:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:54:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:54:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:54:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:54:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:54:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:54:06 --> Total execution time: 0.0019
ERROR - 2019-09-18 14:57:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:57:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:57:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:57:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:57:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:57:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:57:47 --> Total execution time: 0.0026
ERROR - 2019-09-18 14:57:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:57:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:57:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:57:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:57:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:57:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:57:49 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 14:57:49 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 14:57:49 --> Total execution time: 0.0034
ERROR - 2019-09-18 14:57:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:57:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 14:57:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 14:57:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 14:57:51 --> Points ::::: 7,8,9
ERROR - 2019-09-18 14:57:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '7,8,9' at line 3 - Invalid query: SELECT *
FROM `pickup_point`
WHERE id in 7,8,9
ERROR - 2019-09-18 14:57:51 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_route.php 93
ERROR - 2019-09-18 15:00:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:00:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:00:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:00:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:00:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:00:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:00:29 --> Points ::::: 7,8,9
DEBUG - 2019-09-18 15:00:29 --> Total execution time: 0.0026
ERROR - 2019-09-18 15:08:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:08:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:08:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:08:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:08:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:08:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:08:06 --> Total execution time: 0.0025
ERROR - 2019-09-18 15:08:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:08:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:08:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:08:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:08:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:08:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:08:11 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 15:08:11 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 15:08:11 --> Total execution time: 0.0028
ERROR - 2019-09-18 15:08:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:08:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:08:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:08:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:08:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:08:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:08:14 --> Points ::::: 7,8,9
DEBUG - 2019-09-18 15:08:14 --> Total execution time: 0.0023
ERROR - 2019-09-18 15:09:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:09:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:09:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:09:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:09:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:09:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:09:09 --> Total execution time: 0.0024
ERROR - 2019-09-18 15:09:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:09:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:09:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:09:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:09:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:09:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:09:12 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 15:09:12 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 15:09:12 --> Total execution time: 0.0029
ERROR - 2019-09-18 15:09:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:09:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:09:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:09:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:09:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:09:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:09:15 --> Points ::::: 7,8,9
DEBUG - 2019-09-18 15:09:15 --> Total execution time: 0.0022
ERROR - 2019-09-18 15:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:10:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:10:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:10:47 --> Total execution time: 0.0025
ERROR - 2019-09-18 15:10:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:10:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:10:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:10:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:10:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:10:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:10:52 --> Driver Route Token ::::: 69342_2019/09/18-13:09:30
DEBUG - 2019-09-18 15:10:52 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 15:10:52 --> Total execution time: 0.0027
ERROR - 2019-09-18 15:10:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:10:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:10:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:10:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:10:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:10:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:10:55 --> Points ::::: 7,8,9
DEBUG - 2019-09-18 15:10:55 --> Total execution time: 0.0022
ERROR - 2019-09-18 15:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:49:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:49:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:49:31 --> Total execution time: 0.0044
ERROR - 2019-09-18 15:49:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:49:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:49:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:49:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:49:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:49:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:49:32 --> Total execution time: 0.0025
ERROR - 2019-09-18 15:49:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:49:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:49:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:49:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:49:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:49:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:49:39 --> Driver Route Token ::::: 62594_2019/09/18-15:09:31
DEBUG - 2019-09-18 15:49:39 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-18 15:49:39 --> Total execution time: 0.0029
ERROR - 2019-09-18 15:49:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:49:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:49:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-18 15:49:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-18 15:49:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-18 15:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-18 15:49:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-18 15:49:46 --> Points ::::: 7,8,9
DEBUG - 2019-09-18 15:49:46 --> Total execution time: 0.0022
