<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-18 10:23:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 10:23:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 10:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-18 10:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-18 10:23:09 --> Total execution time: 2.3857
ERROR - 2019-10-18 10:23:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 10:23:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 10:23:18 --> No URI present. Default controller set.
DEBUG - 2019-10-18 10:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-18 10:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-18 10:23:19 --> Total execution time: 1.2963
ERROR - 2019-10-18 10:23:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 10:23:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 10:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-18 10:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-18 10:23:31 --> Total execution time: 0.1302
ERROR - 2019-10-18 10:23:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 10:23:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 10:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-18 10:23:32 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-18 11:35:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 11:35:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 11:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-18 11:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-18 11:35:56 --> Total execution time: 0.0066
ERROR - 2019-10-18 18:53:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:53:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-18 18:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-18 18:53:29 --> Total execution time: 0.0030
ERROR - 2019-10-18 18:53:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:53:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:53:32 --> No URI present. Default controller set.
DEBUG - 2019-10-18 18:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-18 18:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-18 18:53:32 --> Total execution time: 0.0073
ERROR - 2019-10-18 18:53:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-18 18:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-18 18:53:35 --> Total execution time: 0.0055
ERROR - 2019-10-18 18:53:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-18 18:53:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-18 18:53:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-18 18:53:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-18 18:53:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-18 18:53:35 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-18 18:53:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-18 18:53:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-18 18:53:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-18 18:53:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-18 18:54:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-18 18:54:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-18 18:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-18 18:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-18 18:54:06 --> Total execution time: 0.0050
