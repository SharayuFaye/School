<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-14 10:56:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 10:56:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 10:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 10:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 10:56:41 --> Total execution time: 5.2972
ERROR - 2019-10-14 11:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 11:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 11:10:47 --> No URI present. Default controller set.
DEBUG - 2019-10-14 11:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 11:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 11:10:48 --> Total execution time: 0.9883
ERROR - 2019-10-14 11:11:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 11:11:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 11:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 11:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 11:11:00 --> Total execution time: 0.0030
ERROR - 2019-10-14 11:11:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 11:11:09 --> No URI present. Default controller set.
DEBUG - 2019-10-14 11:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 11:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 11:11:09 --> Total execution time: 0.0122
ERROR - 2019-10-14 11:12:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 11:12:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 11:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 11:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 11:12:32 --> Total execution time: 0.0056
ERROR - 2019-10-14 11:12:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 11:12:36 --> No URI present. Default controller set.
DEBUG - 2019-10-14 11:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 11:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 11:12:36 --> Total execution time: 0.0074
ERROR - 2019-10-14 12:01:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:01:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:01:02 --> No URI present. Default controller set.
DEBUG - 2019-10-14 12:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:01:02 --> Total execution time: 0.0032
ERROR - 2019-10-14 12:01:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:01:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:01:04 --> No URI present. Default controller set.
DEBUG - 2019-10-14 12:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:01:04 --> Total execution time: 0.0110
ERROR - 2019-10-14 12:05:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:05:25 --> Total execution time: 0.1516
ERROR - 2019-10-14 12:05:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:05:26 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-14 12:05:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:05:29 --> Total execution time: 0.0048
ERROR - 2019-10-14 12:05:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:05:29 --> Total execution time: 0.0048
ERROR - 2019-10-14 12:05:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:05:32 --> Total execution time: 0.0030
ERROR - 2019-10-14 12:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:05:33 --> Total execution time: 0.0116
ERROR - 2019-10-14 12:05:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:05:52 --> Total execution time: 0.0093
ERROR - 2019-10-14 12:05:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:05:55 --> You did not select a file to upload.
DEBUG - 2019-10-14 12:05:55 --> Total execution time: 0.1313
ERROR - 2019-10-14 12:05:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:05:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:05:55 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-14 12:06:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:06:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:06:34 --> Total execution time: 0.0063
ERROR - 2019-10-14 12:06:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:06:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:06:34 --> Total execution time: 0.0032
ERROR - 2019-10-14 12:14:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:14:23 --> Total execution time: 0.3344
ERROR - 2019-10-14 12:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:14:59 --> Total execution time: 0.0139
ERROR - 2019-10-14 12:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:14:59 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-14 12:15:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:15:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-14 12:15:07 --> Severity: Notice --> Undefined property: Welcome::$m_students /var/www/html/School19/application/controllers/Welcome.php 573
ERROR - 2019-10-14 12:15:07 --> Severity: error --> Exception: Call to a member function students_fetch() on null /var/www/html/School19/application/controllers/Welcome.php 573
ERROR - 2019-10-14 12:17:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:17:37 --> Total execution time: 0.1543
ERROR - 2019-10-14 12:17:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:17:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:17:37 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-14 12:18:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:18:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:18:25 --> You did not select a file to upload.
DEBUG - 2019-10-14 12:18:25 --> Total execution time: 0.0090
ERROR - 2019-10-14 12:18:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:18:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:18:25 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-14 12:21:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:21:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:21:12 --> Total execution time: 0.0100
ERROR - 2019-10-14 12:26:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:26:14 --> Total execution time: 0.0063
ERROR - 2019-10-14 12:26:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:26:14 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-14 12:26:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:26:46 --> Total execution time: 0.0024
ERROR - 2019-10-14 12:26:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:51 --> No URI present. Default controller set.
DEBUG - 2019-10-14 12:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:26:51 --> Total execution time: 0.0088
ERROR - 2019-10-14 12:26:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:26:57 --> Total execution time: 0.0637
ERROR - 2019-10-14 12:26:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:26:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 12:26:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:26:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 12:26:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:26:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 12:26:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:26:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 12:28:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:28:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:28:55 --> Total execution time: 0.0062
ERROR - 2019-10-14 12:28:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:28:58 --> No URI present. Default controller set.
DEBUG - 2019-10-14 12:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:28:58 --> Total execution time: 0.0112
ERROR - 2019-10-14 12:29:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:29:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:29:01 --> Total execution time: 0.0156
ERROR - 2019-10-14 12:33:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:33:19 --> Total execution time: 0.1703
ERROR - 2019-10-14 12:35:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:35:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:35:35 --> Total execution time: 0.0067
ERROR - 2019-10-14 12:35:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:35:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:35:43 --> Total execution time: 0.0090
ERROR - 2019-10-14 12:35:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:35:53 --> Total execution time: 0.2367
ERROR - 2019-10-14 12:35:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:35:56 --> UTF-8 Support Enabled
ERROR - 2019-10-14 12:35:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:35:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:35:56 --> Total execution time: 0.0028
DEBUG - 2019-10-14 12:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:35:56 --> Total execution time: 0.0045
ERROR - 2019-10-14 12:35:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:35:59 --> Total execution time: 1.0072
ERROR - 2019-10-14 12:38:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 12:38:13 --> Total execution time: 0.0071
ERROR - 2019-10-14 12:38:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:38:13 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-14 12:38:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-14 12:38:38 --> Query error: Duplicate entry '123' for key 'password' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES (123, 123, '3', 'teacher', '2019-10-14', '34')
DEBUG - 2019-10-14 12:38:38 --> Total execution time: 1.4710
ERROR - 2019-10-14 12:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:38:38 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-14 12:38:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 12:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-14 12:38:44 --> Query error: Duplicate entry '123' for key 'password' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES (123, 123, '3', 'teacher', '2019-10-14', '34')
DEBUG - 2019-10-14 12:38:44 --> Total execution time: 0.0818
ERROR - 2019-10-14 12:38:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 12:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 12:38:44 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-14 13:14:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:14:15 --> Total execution time: 0.0027
ERROR - 2019-10-14 13:14:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:19 --> No URI present. Default controller set.
DEBUG - 2019-10-14 13:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:14:19 --> Total execution time: 0.0077
ERROR - 2019-10-14 13:14:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:14:21 --> Total execution time: 0.0074
ERROR - 2019-10-14 13:14:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:14:22 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 13:14:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:14:22 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 13:14:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:14:22 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 13:14:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:14:22 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 13:14:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:14:23 --> Total execution time: 0.0030
ERROR - 2019-10-14 13:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:14:25 --> Total execution time: 0.0248
ERROR - 2019-10-14 13:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:14:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:14:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:14:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:14:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-14 13:16:37 --> Severity: Notice --> Undefined index: sections /var/www/html/School19/application/views/timetables.php 102
DEBUG - 2019-10-14 13:16:37 --> Total execution time: 0.0104
ERROR - 2019-10-14 13:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:16:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:16:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:16:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:16:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:17:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:17:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:17:22 --> Total execution time: 0.0101
ERROR - 2019-10-14 13:17:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:17:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:17:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:17:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:17:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:17:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:17:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:17:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:17:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:17:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:17:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:17:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:18:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-14 13:19:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-14 13:19:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:19:28 --> Total execution time: 0.0118
ERROR - 2019-10-14 13:19:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:19:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:19:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:19:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:19:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:19:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:19:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:19:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:19:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:19:51 --> Total execution time: 0.0066
ERROR - 2019-10-14 13:19:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:19:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:19:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:19:51 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:19:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:19:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:19:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:19:51 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:20:06 --> Total execution time: 0.0122
ERROR - 2019-10-14 13:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:20:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:20:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:20:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:20:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:20:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 13:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 13:20:23 --> Total execution time: 0.0066
ERROR - 2019-10-14 13:20:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:20:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:20:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:20:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 13:20:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:20:24 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 13:20:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 13:20:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 13:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 13:20:24 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 15:48:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 15:48:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 15:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 15:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 15:48:04 --> Total execution time: 0.0032
ERROR - 2019-10-14 15:48:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 15:48:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 15:48:08 --> No URI present. Default controller set.
DEBUG - 2019-10-14 15:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 15:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 15:48:08 --> Total execution time: 0.0091
ERROR - 2019-10-14 15:48:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 15:48:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 15:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 15:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 15:48:10 --> Total execution time: 0.0511
ERROR - 2019-10-14 15:48:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 15:48:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 15:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 15:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 15:48:47 --> Total execution time: 0.0023
ERROR - 2019-10-14 16:19:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 16:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 16:19:18 --> Total execution time: 0.0022
ERROR - 2019-10-14 16:19:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:21 --> No URI present. Default controller set.
DEBUG - 2019-10-14 16:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 16:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 16:19:21 --> Total execution time: 0.0112
ERROR - 2019-10-14 16:19:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 16:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 16:19:33 --> Total execution time: 0.0019
ERROR - 2019-10-14 16:19:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:38 --> No URI present. Default controller set.
DEBUG - 2019-10-14 16:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 16:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 16:19:38 --> Total execution time: 0.0086
ERROR - 2019-10-14 16:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 16:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 16:19:42 --> Total execution time: 0.1496
ERROR - 2019-10-14 16:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 16:19:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 16:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 16:19:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 16:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 16:19:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 16:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 16:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 16:19:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:14:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:14:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-14 17:14:20 --> Severity: Notice --> Undefined property: Welcome::$m_timetables /var/www/html/School19/application/controllers/Welcome.php 2649
ERROR - 2019-10-14 17:14:20 --> Severity: error --> Exception: Call to a member function class_show_teacher() on null /var/www/html/School19/application/controllers/Welcome.php 2649
ERROR - 2019-10-14 17:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:14:49 --> Total execution time: 0.0154
ERROR - 2019-10-14 17:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:14:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:14:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:14:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:14:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:14:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:14:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:14:55 --> Total execution time: 0.0046
ERROR - 2019-10-14 17:14:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:14:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:14:56 --> Total execution time: 0.0055
ERROR - 2019-10-14 17:16:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:16:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:16:17 --> Total execution time: 0.0895
ERROR - 2019-10-14 17:16:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:16:18 --> Total execution time: 0.0086
ERROR - 2019-10-14 17:16:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:16:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:16:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:16:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:16:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:16:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:16:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:16:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:20:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:20:16 --> Total execution time: 0.0032
ERROR - 2019-10-14 17:20:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:20:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:20:19 --> Total execution time: 0.0041
ERROR - 2019-10-14 17:21:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:21:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:21:38 --> Total execution time: 0.0093
ERROR - 2019-10-14 17:21:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:21:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:21:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:21:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:21:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:21:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:21:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:21:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:21:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:21:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:21:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:21:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:21:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:21:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:22:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:22:11 --> Total execution time: 0.0099
ERROR - 2019-10-14 17:22:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:22:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:22:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:22:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:22:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:22:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:22:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:22:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:22:45 --> Total execution time: 0.0096
ERROR - 2019-10-14 17:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:22:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:22:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:22:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:22:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:23:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:23:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:23:14 --> Total execution time: 0.0057
ERROR - 2019-10-14 17:23:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:23:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:23:25 --> Total execution time: 0.0025
ERROR - 2019-10-14 17:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:23:29 --> No URI present. Default controller set.
DEBUG - 2019-10-14 17:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:23:29 --> Total execution time: 0.0073
ERROR - 2019-10-14 17:24:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:24:01 --> Total execution time: 0.0093
ERROR - 2019-10-14 17:24:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:24:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:24:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:24:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:24:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:24:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:24:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:24:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:24:09 --> Total execution time: 0.1662
ERROR - 2019-10-14 17:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:24:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:24:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:24:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:24:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:25:01 --> Total execution time: 0.0047
ERROR - 2019-10-14 17:25:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:06 --> No URI present. Default controller set.
DEBUG - 2019-10-14 17:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:25:06 --> Total execution time: 0.0071
ERROR - 2019-10-14 17:25:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:25:08 --> Total execution time: 0.0089
ERROR - 2019-10-14 17:25:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:25:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:25:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 17:25:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 17:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:25:38 --> Total execution time: 0.1106
ERROR - 2019-10-14 17:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 17:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 17:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 17:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 17:25:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:25:46 --> Total execution time: 0.0861
ERROR - 2019-10-14 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:25:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 17:54:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:54:53 --> Total execution time: 0.0044
ERROR - 2019-10-14 17:54:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:54:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:54:56 --> No URI present. Default controller set.
DEBUG - 2019-10-14 17:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:54:56 --> Total execution time: 0.0083
ERROR - 2019-10-14 17:55:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:55:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:55:00 --> Total execution time: 0.0077
ERROR - 2019-10-14 17:55:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:55:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:55:03 --> Total execution time: 0.0062
ERROR - 2019-10-14 17:55:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:55:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 17:55:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 17:55:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 17:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 17:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:55:09 --> Total execution time: 0.0029
DEBUG - 2019-10-14 17:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 17:55:09 --> Total execution time: 0.0026
ERROR - 2019-10-14 18:12:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:12:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:12:03 --> Total execution time: 0.0027
ERROR - 2019-10-14 18:12:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:12:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:12:06 --> No URI present. Default controller set.
DEBUG - 2019-10-14 18:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:12:06 --> Total execution time: 0.0099
ERROR - 2019-10-14 18:12:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:12:08 --> Total execution time: 0.1123
ERROR - 2019-10-14 18:12:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:12:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:12:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:12:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:12:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:12:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:12:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:12:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:14:27 --> Total execution time: 0.0126
ERROR - 2019-10-14 18:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-14 18:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:27 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-14 18:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:14:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:14:32 --> Total execution time: 0.0033
ERROR - 2019-10-14 18:14:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:14:34 --> Total execution time: 0.0052
ERROR - 2019-10-14 18:14:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:34 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:14:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:14:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:34 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:14:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:14:59 --> Total execution time: 0.0088
ERROR - 2019-10-14 18:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:14:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:17:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:17:05 --> Total execution time: 0.0064
ERROR - 2019-10-14 18:17:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-14 18:17:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:05 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-14 18:17:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:17:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:17:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:17:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:17:26 --> Total execution time: 0.0088
ERROR - 2019-10-14 18:17:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:17:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:17:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:17:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:17:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:17:36 --> Total execution time: 0.0059
ERROR - 2019-10-14 18:17:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:17:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:17:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:17:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:17:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:18:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:18:07 --> Total execution time: 0.0058
ERROR - 2019-10-14 18:18:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:18:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:18:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:18:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:18:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:18:36 --> Total execution time: 0.0075
ERROR - 2019-10-14 18:18:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:18:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:18:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-14 18:18:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-14 18:18:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-14 18:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-14 18:18:42 --> Total execution time: 0.1673
ERROR - 2019-10-14 18:18:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:42 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 18:18:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:42 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-14 18:18:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-14 18:18:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-14 18:18:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-14 18:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-14 18:18:43 --> 404 Page Not Found: Welcome/js
