<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-23 10:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 10:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 10:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 10:24:05 --> Total execution time: 11.4774
ERROR - 2019-10-23 10:38:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 10:38:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 10:38:42 --> No URI present. Default controller set.
DEBUG - 2019-10-23 10:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 10:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 10:38:43 --> Total execution time: 1.4970
ERROR - 2019-10-23 11:19:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:19:22 --> Total execution time: 0.1408
ERROR - 2019-10-23 11:19:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:19:23 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 11:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:23:53 --> Total execution time: 0.0571
ERROR - 2019-10-23 11:31:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:31:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:31:40 --> Total execution time: 0.0520
ERROR - 2019-10-23 11:31:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 11:31:51 --> Query error: Duplicate entry 'English' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('3', 'English', '2019-10-23', '34')
DEBUG - 2019-10-23 11:31:51 --> Total execution time: 0.1802
ERROR - 2019-10-23 11:32:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:32:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:32:23 --> Total execution time: 0.0391
ERROR - 2019-10-23 11:32:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:32:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:32:29 --> Total execution time: 0.0210
ERROR - 2019-10-23 11:34:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:34:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:34:38 --> Total execution time: 0.0085
ERROR - 2019-10-23 11:34:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:34:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:34:49 --> Total execution time: 0.0069
ERROR - 2019-10-23 11:35:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:35:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:35:05 --> Total execution time: 0.0110
ERROR - 2019-10-23 11:37:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:37:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:37:08 --> Total execution time: 0.0097
ERROR - 2019-10-23 11:37:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:37:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:37:11 --> Total execution time: 0.0028
ERROR - 2019-10-23 11:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:37:13 --> Total execution time: 0.0043
ERROR - 2019-10-23 11:37:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:37:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:37:20 --> Total execution time: 0.0560
ERROR - 2019-10-23 11:38:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:38:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 89
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 94
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 89
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 94
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 89
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 94
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 89
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 94
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 89
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 94
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 89
ERROR - 2019-10-23 11:38:09 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/subject_allocation.php 94
DEBUG - 2019-10-23 11:38:09 --> Total execution time: 0.0322
ERROR - 2019-10-23 11:38:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:38:52 --> Total execution time: 0.0103
ERROR - 2019-10-23 11:39:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:39:22 --> Total execution time: 0.0091
ERROR - 2019-10-23 11:39:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:39:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:39:26 --> Total execution time: 0.1429
ERROR - 2019-10-23 11:39:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:39:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:39:30 --> Total execution time: 0.0032
ERROR - 2019-10-23 11:39:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:39:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:39:33 --> Total execution time: 0.0046
ERROR - 2019-10-23 11:39:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:39:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:39:34 --> Total execution time: 0.0612
ERROR - 2019-10-23 11:39:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:39:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:39:43 --> Total execution time: 0.0028
ERROR - 2019-10-23 11:39:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:39:44 --> Total execution time: 0.0058
ERROR - 2019-10-23 11:39:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:39:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:39:56 --> Total execution time: 0.0042
ERROR - 2019-10-23 11:40:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:40:02 --> Total execution time: 0.0026
ERROR - 2019-10-23 11:40:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:40:04 --> Total execution time: 0.0033
ERROR - 2019-10-23 11:40:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:40:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:40:14 --> Total execution time: 0.0038
ERROR - 2019-10-23 11:40:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:40:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:40:15 --> Total execution time: 0.0035
ERROR - 2019-10-23 11:41:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:41:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:41:01 --> Total execution time: 0.0073
ERROR - 2019-10-23 11:41:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:41:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:41:04 --> Total execution time: 0.0023
ERROR - 2019-10-23 11:41:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:41:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:41:05 --> Total execution time: 0.0047
ERROR - 2019-10-23 11:41:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:41:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:41:08 --> Total execution time: 0.0044
ERROR - 2019-10-23 11:41:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:41:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:41:10 --> Total execution time: 0.0049
ERROR - 2019-10-23 11:42:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:42:07 --> Total execution time: 0.0104
ERROR - 2019-10-23 11:42:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:42:09 --> Total execution time: 0.0023
ERROR - 2019-10-23 11:42:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:42:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:42:11 --> Total execution time: 0.0051
ERROR - 2019-10-23 11:42:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:42:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:42:42 --> Total execution time: 0.0126
ERROR - 2019-10-23 11:42:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:42:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:42:45 --> Total execution time: 0.0035
ERROR - 2019-10-23 11:42:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:42:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:42:47 --> Total execution time: 0.0048
ERROR - 2019-10-23 11:43:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:43:49 --> Total execution time: 0.0086
ERROR - 2019-10-23 11:43:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:43:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:43:50 --> Total execution time: 0.0082
ERROR - 2019-10-23 11:43:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:43:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:43:50 --> Total execution time: 0.0076
ERROR - 2019-10-23 11:44:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:44:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:44:00 --> Total execution time: 0.0098
ERROR - 2019-10-23 11:44:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:44:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:44:04 --> Total execution time: 0.0021
ERROR - 2019-10-23 11:44:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:44:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:44:05 --> Total execution time: 0.0048
ERROR - 2019-10-23 11:47:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:01 --> Total execution time: 0.0091
ERROR - 2019-10-23 11:47:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:06 --> Total execution time: 0.0028
ERROR - 2019-10-23 11:47:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:07 --> Total execution time: 0.0053
ERROR - 2019-10-23 11:47:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:12 --> Total execution time: 0.0022
ERROR - 2019-10-23 11:47:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:14 --> Total execution time: 0.0036
ERROR - 2019-10-23 11:47:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:26 --> Total execution time: 0.0143
ERROR - 2019-10-23 11:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:28 --> Total execution time: 0.0024
ERROR - 2019-10-23 11:47:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:29 --> Total execution time: 0.0049
ERROR - 2019-10-23 11:47:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:32 --> Total execution time: 0.0023
ERROR - 2019-10-23 11:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:33 --> Total execution time: 0.0026
ERROR - 2019-10-23 11:47:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:40 --> Total execution time: 0.0040
ERROR - 2019-10-23 11:47:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:41 --> Total execution time: 0.0046
ERROR - 2019-10-23 11:47:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:47:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:47:56 --> Total execution time: 0.0091
ERROR - 2019-10-23 11:48:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:01 --> Total execution time: 0.0028
ERROR - 2019-10-23 11:48:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:02 --> Total execution time: 0.0021
ERROR - 2019-10-23 11:48:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:05 --> Total execution time: 0.0548
ERROR - 2019-10-23 11:48:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:18 --> Total execution time: 0.0489
ERROR - 2019-10-23 11:48:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:20 --> Total execution time: 0.0045
ERROR - 2019-10-23 11:48:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:21 --> Total execution time: 0.0075
ERROR - 2019-10-23 11:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:23 --> Total execution time: 0.0046
ERROR - 2019-10-23 11:48:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:24 --> Total execution time: 0.0074
ERROR - 2019-10-23 11:48:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:48:24 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 11:48:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:29 --> Total execution time: 0.0024
ERROR - 2019-10-23 11:48:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:39 --> Total execution time: 0.0046
ERROR - 2019-10-23 11:48:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 11:48:43 --> Query error: Duplicate entry 'd41d8cd98f00b204e9800998ecf8427e' for key 'password' - Invalid query: UPDATE `users` SET `username` = 'suq@gmail.com', `password` = 'd41d8cd98f00b204e9800998ecf8427e', `updated_date` = '2019-10-23', `updated_by` = '34'
WHERE `id` = '178'
DEBUG - 2019-10-23 11:48:43 --> Total execution time: 0.1993
ERROR - 2019-10-23 11:48:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:48:43 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-23 11:48:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:53 --> Total execution time: 0.0528
ERROR - 2019-10-23 11:48:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:48:55 --> Total execution time: 0.0085
ERROR - 2019-10-23 11:48:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:48:55 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 11:49:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:01 --> Total execution time: 0.0468
ERROR - 2019-10-23 11:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:08 --> Total execution time: 0.0048
ERROR - 2019-10-23 11:49:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:10 --> Total execution time: 0.0044
ERROR - 2019-10-23 11:49:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:12 --> Total execution time: 0.0071
ERROR - 2019-10-23 11:49:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:22 --> Total execution time: 0.0111
ERROR - 2019-10-23 11:49:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:49:22 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 11:49:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:26 --> Total execution time: 0.0088
ERROR - 2019-10-23 11:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:31 --> Total execution time: 0.0028
ERROR - 2019-10-23 11:49:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:32 --> Total execution time: 0.0046
ERROR - 2019-10-23 11:49:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:33 --> Total execution time: 0.0031
ERROR - 2019-10-23 11:49:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:35 --> Total execution time: 0.1113
ERROR - 2019-10-23 11:49:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:44 --> Total execution time: 0.0056
ERROR - 2019-10-23 11:49:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:46 --> Total execution time: 0.0027
ERROR - 2019-10-23 11:49:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:47 --> Total execution time: 0.0051
ERROR - 2019-10-23 11:49:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:56 --> Total execution time: 0.0555
ERROR - 2019-10-23 11:49:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:49:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:49:57 --> Total execution time: 0.1103
ERROR - 2019-10-23 11:50:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:03 --> Total execution time: 0.0410
ERROR - 2019-10-23 11:50:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:08 --> Total execution time: 0.0047
ERROR - 2019-10-23 11:50:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:09 --> Total execution time: 0.0028
ERROR - 2019-10-23 11:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:16 --> Total execution time: 0.0614
ERROR - 2019-10-23 11:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:30 --> Total execution time: 0.0072
ERROR - 2019-10-23 11:50:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:34 --> Total execution time: 0.0429
ERROR - 2019-10-23 11:50:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:39 --> Total execution time: 0.0031
ERROR - 2019-10-23 11:50:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:50:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:40 --> Total execution time: 0.0059
DEBUG - 2019-10-23 11:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:40 --> Total execution time: 0.0031
ERROR - 2019-10-23 11:50:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:48 --> Total execution time: 0.0061
ERROR - 2019-10-23 11:50:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:49 --> UTF-8 Support Enabled
ERROR - 2019-10-23 11:50:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:50:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:50:49 --> Total execution time: 0.0034
DEBUG - 2019-10-23 11:50:49 --> Total execution time: 0.0060
ERROR - 2019-10-23 11:52:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:01 --> Total execution time: 0.0094
ERROR - 2019-10-23 11:52:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:05 --> Total execution time: 0.0023
ERROR - 2019-10-23 11:52:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:07 --> Total execution time: 0.0026
ERROR - 2019-10-23 11:52:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:52:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:08 --> Total execution time: 0.0034
DEBUG - 2019-10-23 11:52:08 --> Total execution time: 0.0027
ERROR - 2019-10-23 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:11 --> Total execution time: 0.0064
ERROR - 2019-10-23 11:52:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-23 11:52:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:12 --> Total execution time: 0.0020
DEBUG - 2019-10-23 11:52:12 --> Total execution time: 0.0030
ERROR - 2019-10-23 11:52:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:17 --> Total execution time: 0.0037
ERROR - 2019-10-23 11:52:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:18 --> UTF-8 Support Enabled
ERROR - 2019-10-23 11:52:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:18 --> Total execution time: 0.0025
DEBUG - 2019-10-23 11:52:18 --> Total execution time: 0.0027
ERROR - 2019-10-23 11:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:26 --> Total execution time: 0.0029
ERROR - 2019-10-23 11:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:52:27 --> Total execution time: 0.1118
ERROR - 2019-10-23 11:52:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:52:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 11:52:43 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/marks.php 75
DEBUG - 2019-10-23 11:52:43 --> Total execution time: 0.0879
ERROR - 2019-10-23 11:53:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:53:44 --> Total execution time: 0.0812
ERROR - 2019-10-23 11:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:00 --> Total execution time: 0.0132
ERROR - 2019-10-23 11:54:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:04 --> Total execution time: 0.0089
ERROR - 2019-10-23 11:54:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:23 --> Total execution time: 0.0081
ERROR - 2019-10-23 11:54:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:24 --> Total execution time: 0.0426
ERROR - 2019-10-23 11:54:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:30 --> Total execution time: 0.0050
ERROR - 2019-10-23 11:54:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:31 --> Total execution time: 0.0029
ERROR - 2019-10-23 11:54:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:33 --> Total execution time: 0.0786
ERROR - 2019-10-23 11:54:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:41 --> Total execution time: 0.0046
ERROR - 2019-10-23 11:54:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:42 --> Total execution time: 0.0029
ERROR - 2019-10-23 11:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:45 --> Total execution time: 0.0563
ERROR - 2019-10-23 11:54:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:47 --> Total execution time: 0.0330
ERROR - 2019-10-23 11:54:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:54 --> Total execution time: 0.0029
ERROR - 2019-10-23 11:54:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:57 --> Total execution time: 0.0032
ERROR - 2019-10-23 11:54:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:54:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:54:58 --> Total execution time: 0.0063
ERROR - 2019-10-23 11:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:04 --> Total execution time: 0.0971
ERROR - 2019-10-23 11:55:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:11 --> Total execution time: 0.0034
ERROR - 2019-10-23 11:55:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:20 --> Total execution time: 0.0216
ERROR - 2019-10-23 11:55:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:23 --> Total execution time: 0.0161
ERROR - 2019-10-23 11:55:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:26 --> Total execution time: 0.0070
ERROR - 2019-10-23 11:55:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:47 --> Total execution time: 0.0033
ERROR - 2019-10-23 11:55:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:49 --> Total execution time: 0.0089
ERROR - 2019-10-23 11:55:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:52 --> Total execution time: 0.0071
ERROR - 2019-10-23 11:55:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:55 --> Total execution time: 0.0090
ERROR - 2019-10-23 11:55:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:55:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:55:58 --> Total execution time: 0.0263
ERROR - 2019-10-23 11:56:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:56:01 --> Total execution time: 0.0030
ERROR - 2019-10-23 11:56:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:56:02 --> Total execution time: 0.0105
ERROR - 2019-10-23 11:56:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:56:05 --> Total execution time: 0.0115
ERROR - 2019-10-23 11:56:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-23 11:56:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:56:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 11:56:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 11:56:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:56:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 11:56:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:56:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 11:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:56:07 --> Total execution time: 0.0022
ERROR - 2019-10-23 11:56:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:56:08 --> Total execution time: 0.0032
ERROR - 2019-10-23 11:56:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:56:20 --> Total execution time: 0.0568
ERROR - 2019-10-23 11:56:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:56:24 --> Total execution time: 0.0031
ERROR - 2019-10-23 11:56:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:56:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:56:25 --> Total execution time: 0.0057
ERROR - 2019-10-23 11:57:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:57:54 --> Total execution time: 0.0076
ERROR - 2019-10-23 11:57:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:57:57 --> Total execution time: 0.0312
ERROR - 2019-10-23 11:57:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:57:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 11:57:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:57:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 11:57:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:57:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 11:57:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:57:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:57:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:57:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 11:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:58:44 --> Total execution time: 0.0111
ERROR - 2019-10-23 11:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-23 11:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:58:44 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-23 11:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:58:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 11:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:58:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 11:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:58:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 11:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:58:49 --> Total execution time: 0.0823
ERROR - 2019-10-23 11:58:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:58:52 --> Total execution time: 0.0028
ERROR - 2019-10-23 11:58:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:58:53 --> Total execution time: 0.0105
ERROR - 2019-10-23 11:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:58:55 --> Total execution time: 0.0402
ERROR - 2019-10-23 11:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:58:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 11:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:58:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 11:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:58:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 11:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:58:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 11:58:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:58:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:58:57 --> Total execution time: 0.0035
ERROR - 2019-10-23 11:59:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:59:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:59:15 --> No URI present. Default controller set.
DEBUG - 2019-10-23 11:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:59:15 --> Total execution time: 0.0320
ERROR - 2019-10-23 11:59:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:59:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:59:18 --> Total execution time: 0.0072
ERROR - 2019-10-23 11:59:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:59:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:59:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 11:59:18 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 11:59:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:59:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:59:22 --> Total execution time: 0.0038
ERROR - 2019-10-23 11:59:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:59:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:59:29 --> No URI present. Default controller set.
DEBUG - 2019-10-23 11:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:59:29 --> Total execution time: 0.0051
ERROR - 2019-10-23 11:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:59:42 --> No URI present. Default controller set.
DEBUG - 2019-10-23 11:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:59:42 --> Total execution time: 0.0052
ERROR - 2019-10-23 11:59:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:59:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:59:48 --> No URI present. Default controller set.
DEBUG - 2019-10-23 11:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:59:48 --> Total execution time: 0.0027
ERROR - 2019-10-23 11:59:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 11:59:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 11:59:57 --> No URI present. Default controller set.
DEBUG - 2019-10-23 11:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 11:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 11:59:57 --> Total execution time: 0.0933
ERROR - 2019-10-23 12:00:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:00 --> Total execution time: 0.0332
ERROR - 2019-10-23 12:00:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:01 --> Total execution time: 0.0088
ERROR - 2019-10-23 12:00:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:06 --> Total execution time: 0.1643
ERROR - 2019-10-23 12:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:08 --> Total execution time: 0.0099
ERROR - 2019-10-23 12:00:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:18 --> Total execution time: 0.0029
ERROR - 2019-10-23 12:00:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:19 --> Total execution time: 0.0048
ERROR - 2019-10-23 12:00:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:22 --> Total execution time: 0.0783
ERROR - 2019-10-23 12:00:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:24 --> Total execution time: 0.0066
ERROR - 2019-10-23 12:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:27 --> Total execution time: 0.0024
ERROR - 2019-10-23 12:00:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:39 --> Total execution time: 0.0102
ERROR - 2019-10-23 12:00:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:42 --> Total execution time: 0.0037
ERROR - 2019-10-23 12:00:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:43 --> Total execution time: 0.0088
ERROR - 2019-10-23 12:00:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:44 --> Total execution time: 0.0153
ERROR - 2019-10-23 12:00:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-23 12:00:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:00:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 12:00:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 12:00:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:00:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 12:00:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:00:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 12:00:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:00:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:00:57 --> Total execution time: 0.0544
ERROR - 2019-10-23 12:01:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:07 --> Total execution time: 0.0039
ERROR - 2019-10-23 12:01:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:15 --> No URI present. Default controller set.
DEBUG - 2019-10-23 12:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:15 --> Total execution time: 0.0334
ERROR - 2019-10-23 12:01:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:18 --> Total execution time: 0.0088
ERROR - 2019-10-23 12:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:21 --> Total execution time: 0.0042
ERROR - 2019-10-23 12:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:01:21 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 12:01:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:25 --> Total execution time: 0.0074
ERROR - 2019-10-23 12:01:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 12:01:32 --> Query error: Duplicate entry 'English' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('3', 'English', '2019-10-23', '34')
DEBUG - 2019-10-23 12:01:32 --> Total execution time: 0.1669
ERROR - 2019-10-23 12:01:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:34 --> Total execution time: 0.0022
ERROR - 2019-10-23 12:01:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:41 --> No URI present. Default controller set.
DEBUG - 2019-10-23 12:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:41 --> Total execution time: 0.0265
ERROR - 2019-10-23 12:01:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:43 --> Total execution time: 0.0075
ERROR - 2019-10-23 12:01:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:01:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 12:01:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:01:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 12:01:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:01:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 12:01:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:01:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 12:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:52 --> Total execution time: 0.0081
ERROR - 2019-10-23 12:01:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:54 --> Total execution time: 0.0033
ERROR - 2019-10-23 12:01:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:01:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:01:55 --> Total execution time: 0.0110
ERROR - 2019-10-23 12:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:02:00 --> Total execution time: 0.0097
ERROR - 2019-10-23 12:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:02:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 12:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:02:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 12:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:02:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 12:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:02:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 12:02:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:02:06 --> Total execution time: 0.0078
ERROR - 2019-10-23 12:02:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:02:11 --> Total execution time: 0.0026
ERROR - 2019-10-23 12:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:02:19 --> Total execution time: 0.0038
ERROR - 2019-10-23 12:02:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:02:20 --> Total execution time: 0.0030
ERROR - 2019-10-23 12:02:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:02:24 --> Total execution time: 0.0089
ERROR - 2019-10-23 12:02:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:02:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:02:27 --> Total execution time: 0.0030
ERROR - 2019-10-23 12:03:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:28 --> Total execution time: 0.0095
ERROR - 2019-10-23 12:03:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:32 --> Total execution time: 0.0023
ERROR - 2019-10-23 12:03:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:34 --> Total execution time: 0.0052
ERROR - 2019-10-23 12:03:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:36 --> Total execution time: 0.0029
ERROR - 2019-10-23 12:03:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:37 --> Total execution time: 0.0020
ERROR - 2019-10-23 12:03:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:40 --> Total execution time: 0.0047
ERROR - 2019-10-23 12:03:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:41 --> Total execution time: 0.0037
ERROR - 2019-10-23 12:03:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:44 --> Total execution time: 0.1355
ERROR - 2019-10-23 12:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:03:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:03:49 --> Total execution time: 0.1640
ERROR - 2019-10-23 12:04:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:04:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:04:08 --> Total execution time: 0.0698
ERROR - 2019-10-23 12:04:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:04:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:04:12 --> Total execution time: 0.0048
ERROR - 2019-10-23 12:04:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:04:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:04:19 --> Total execution time: 0.0029
ERROR - 2019-10-23 12:04:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:04:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:04:55 --> Total execution time: 0.0032
ERROR - 2019-10-23 12:05:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:02 --> Total execution time: 0.0078
ERROR - 2019-10-23 12:05:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:08 --> Total execution time: 0.0031
ERROR - 2019-10-23 12:05:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:11 --> Total execution time: 0.0771
ERROR - 2019-10-23 12:05:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:17 --> Total execution time: 0.0186
ERROR - 2019-10-23 12:05:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:23 --> Total execution time: 0.0307
ERROR - 2019-10-23 12:05:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:25 --> Total execution time: 0.0082
ERROR - 2019-10-23 12:05:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:28 --> Total execution time: 0.0033
ERROR - 2019-10-23 12:05:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:34 --> No URI present. Default controller set.
DEBUG - 2019-10-23 12:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:34 --> Total execution time: 0.0238
ERROR - 2019-10-23 12:05:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:40 --> Total execution time: 0.0096
ERROR - 2019-10-23 12:05:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:43 --> Total execution time: 0.0023
ERROR - 2019-10-23 12:05:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:05:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:05:46 --> Total execution time: 0.0086
ERROR - 2019-10-23 12:06:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:06:08 --> Total execution time: 0.0064
ERROR - 2019-10-23 12:06:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:06:08 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 12:06:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:06:13 --> Total execution time: 0.0080
ERROR - 2019-10-23 12:06:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:06:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:06:38 --> Total execution time: 0.0075
ERROR - 2019-10-23 12:06:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:06:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:06:50 --> Total execution time: 0.1183
ERROR - 2019-10-23 12:08:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:08:20 --> Total execution time: 0.0072
ERROR - 2019-10-23 12:08:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:08:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:08:24 --> Total execution time: 0.0022
ERROR - 2019-10-23 12:08:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:08:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:08:25 --> Total execution time: 0.0027
ERROR - 2019-10-23 12:25:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:25:19 --> Total execution time: 0.0095
ERROR - 2019-10-23 12:25:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:25:26 --> Total execution time: 0.0023
ERROR - 2019-10-23 12:25:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:25:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:25:28 --> Total execution time: 0.0063
ERROR - 2019-10-23 12:25:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:25:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:25:36 --> Total execution time: 0.1919
ERROR - 2019-10-23 12:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:26:15 --> Total execution time: 0.0675
ERROR - 2019-10-23 12:26:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:26:36 --> Total execution time: 0.0696
ERROR - 2019-10-23 12:26:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:26:49 --> Total execution time: 0.0692
ERROR - 2019-10-23 12:27:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:27:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:27:16 --> Total execution time: 0.0666
ERROR - 2019-10-23 12:27:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:27:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:27:26 --> Total execution time: 0.0555
ERROR - 2019-10-23 12:27:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:27:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:27:30 --> Total execution time: 0.1112
ERROR - 2019-10-23 12:27:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:27:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:27:41 --> Total execution time: 0.1825
ERROR - 2019-10-23 12:27:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:27:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:27:50 --> Total execution time: 0.1295
ERROR - 2019-10-23 12:27:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:27:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:27:55 --> Total execution time: 0.2313
ERROR - 2019-10-23 12:28:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:28:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:28:01 --> Total execution time: 0.2265
ERROR - 2019-10-23 12:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:28:07 --> Total execution time: 0.1164
ERROR - 2019-10-23 12:28:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:28:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:28:12 --> Total execution time: 0.0083
ERROR - 2019-10-23 12:28:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:28:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:28:17 --> Total execution time: 0.1606
ERROR - 2019-10-23 12:28:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:28:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 12:28:23 --> Query error: Duplicate entry 'English' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('3', 'English', '2019-10-23', '34')
DEBUG - 2019-10-23 12:28:23 --> Total execution time: 0.3004
ERROR - 2019-10-23 12:28:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:28:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:28:30 --> Total execution time: 0.1151
ERROR - 2019-10-23 12:28:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:28:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 12:28:51 --> Query error: Expression #1 of ORDER BY clause is not in SELECT list, references column 'db_school.c.id' which is not in SELECT list; this is incompatible with DISTINCT - Invalid query: SELECT DISTINCT `c`.`class` as `class`, `b`.`class_id` as `id`
FROM `sections` `b`
LEFT JOIN `class` `c` ON `c`.`id`=`b`.`class_id`
ORDER BY `c`.`id` DESC
ERROR - 2019-10-23 12:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/subject_allocation.php 370
ERROR - 2019-10-23 12:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/subject_allocation.php 458
DEBUG - 2019-10-23 12:28:51 --> Total execution time: 0.0110
ERROR - 2019-10-23 12:29:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:29:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 12:29:45 --> Query error: Expression #1 of ORDER BY clause is not in SELECT list, references column 'db_school.c.id' which is not in SELECT list; this is incompatible with DISTINCT - Invalid query: SELECT DISTINCT `c`.`class` as `class`, `b`.`class_id` as `id`
FROM `sections` `b`
LEFT JOIN `class` `c` ON `c`.`id`=`b`.`class_id`
ORDER BY `c`.`id` ASC
ERROR - 2019-10-23 12:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/subject_allocation.php 370
ERROR - 2019-10-23 12:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/subject_allocation.php 458
DEBUG - 2019-10-23 12:29:45 --> Total execution time: 0.0092
ERROR - 2019-10-23 12:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:30:51 --> Total execution time: 0.0100
ERROR - 2019-10-23 12:31:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:31:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 12:31:09 --> Query error: Expression #1 of ORDER BY clause is not in SELECT list, references column 'db_school.c.id' which is not in SELECT list; this is incompatible with DISTINCT - Invalid query: SELECT DISTINCT `c`.`class` as `class`, `b`.`class_id` as `id`
FROM `sections` `b`
LEFT JOIN `class` `c` ON `c`.`id`=`b`.`class_id`
ORDER BY `c`.`id` ASC
ERROR - 2019-10-23 12:31:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/subject_allocation.php 370
ERROR - 2019-10-23 12:31:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/subject_allocation.php 458
DEBUG - 2019-10-23 12:31:09 --> Total execution time: 0.0080
ERROR - 2019-10-23 12:31:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:31:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:31:21 --> Total execution time: 0.0098
ERROR - 2019-10-23 12:31:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:31:27 --> Total execution time: 0.0028
ERROR - 2019-10-23 12:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:31:29 --> Total execution time: 0.0054
ERROR - 2019-10-23 12:33:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:33:53 --> Total execution time: 0.0086
ERROR - 2019-10-23 12:34:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:34:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:34:01 --> Total execution time: 0.1166
ERROR - 2019-10-23 12:34:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:34:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:34:06 --> Total execution time: 0.1257
ERROR - 2019-10-23 12:34:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:34:31 --> Total execution time: 0.0064
ERROR - 2019-10-23 12:34:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:34:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 12:34:42 --> Query error: Duplicate entry 'English' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('3', 'English', '2019-10-23', '34')
DEBUG - 2019-10-23 12:34:42 --> Total execution time: 0.2008
ERROR - 2019-10-23 12:34:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:34:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:34:54 --> Total execution time: 0.1204
ERROR - 2019-10-23 12:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 12:35:08 --> Query error: Duplicate entry 'English' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('3', 'English', '2019-10-23', '34')
DEBUG - 2019-10-23 12:35:08 --> Total execution time: 0.1832
ERROR - 2019-10-23 12:35:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:20 --> Total execution time: 0.1276
ERROR - 2019-10-23 12:35:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:23 --> Total execution time: 0.0077
ERROR - 2019-10-23 12:35:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:28 --> Total execution time: 0.0024
ERROR - 2019-10-23 12:35:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:29 --> Total execution time: 0.0039
ERROR - 2019-10-23 12:35:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:32 --> Total execution time: 0.0622
ERROR - 2019-10-23 12:35:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:37 --> Total execution time: 0.0025
ERROR - 2019-10-23 12:35:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:39 --> Total execution time: 0.0042
ERROR - 2019-10-23 12:35:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:41 --> Total execution time: 0.2060
ERROR - 2019-10-23 12:35:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:45 --> Total execution time: 0.0045
ERROR - 2019-10-23 12:35:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:46 --> Total execution time: 0.0040
ERROR - 2019-10-23 12:35:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:48 --> Total execution time: 0.0052
ERROR - 2019-10-23 12:35:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:50 --> Total execution time: 0.0648
ERROR - 2019-10-23 12:35:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:35:54 --> Total execution time: 0.0099
ERROR - 2019-10-23 12:35:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:35:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:35:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:35:54 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 12:36:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:36:01 --> Total execution time: 0.0040
ERROR - 2019-10-23 12:36:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 12:36:05 --> Query error: Duplicate entry 'd41d8cd98f00b204e9800998ecf8427e' for key 'password' - Invalid query: UPDATE `users` SET `username` = 'suq@gmail.com', `password` = 'd41d8cd98f00b204e9800998ecf8427e', `updated_date` = '2019-10-23', `updated_by` = '34'
WHERE `id` = '178'
DEBUG - 2019-10-23 12:36:05 --> Total execution time: 0.2383
ERROR - 2019-10-23 12:36:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 12:36:05 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-23 12:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:36:10 --> Total execution time: 0.0080
ERROR - 2019-10-23 12:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:36:21 --> Total execution time: 0.0020
ERROR - 2019-10-23 12:36:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:36:22 --> Total execution time: 0.0057
ERROR - 2019-10-23 12:36:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:36:23 --> Total execution time: 0.0043
ERROR - 2019-10-23 12:36:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:36:25 --> Total execution time: 0.2292
ERROR - 2019-10-23 12:36:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 12:36:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 12:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 12:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 12:36:28 --> Total execution time: 0.0097
ERROR - 2019-10-23 13:45:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 13:45:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 13:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 13:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 13:45:43 --> Total execution time: 0.0128
ERROR - 2019-10-23 14:00:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:21 --> Total execution time: 0.0082
ERROR - 2019-10-23 14:00:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:22 --> Total execution time: 0.0080
ERROR - 2019-10-23 14:00:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:22 --> Total execution time: 0.0082
ERROR - 2019-10-23 14:00:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:22 --> Total execution time: 0.0076
ERROR - 2019-10-23 14:00:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:22 --> Total execution time: 0.0073
ERROR - 2019-10-23 14:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:23 --> Total execution time: 0.0083
ERROR - 2019-10-23 14:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:23 --> Total execution time: 0.0090
ERROR - 2019-10-23 14:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:23 --> Total execution time: 0.0097
ERROR - 2019-10-23 14:00:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:24 --> Total execution time: 0.0091
ERROR - 2019-10-23 14:00:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:24 --> Total execution time: 0.0075
ERROR - 2019-10-23 14:00:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:25 --> Total execution time: 0.0065
ERROR - 2019-10-23 14:00:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:25 --> Total execution time: 0.0080
ERROR - 2019-10-23 14:00:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:25 --> Total execution time: 0.0099
ERROR - 2019-10-23 14:00:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:25 --> Total execution time: 0.0078
ERROR - 2019-10-23 14:00:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:26 --> Total execution time: 0.0083
ERROR - 2019-10-23 14:00:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:26 --> Total execution time: 0.0065
ERROR - 2019-10-23 14:00:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:26 --> Total execution time: 0.0091
ERROR - 2019-10-23 14:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:27 --> Total execution time: 0.0087
ERROR - 2019-10-23 14:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:27 --> Total execution time: 0.0090
ERROR - 2019-10-23 14:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:00:27 --> Total execution time: 0.0076
ERROR - 2019-10-23 14:01:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:47 --> Total execution time: 0.0090
ERROR - 2019-10-23 14:01:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:48 --> Total execution time: 0.0081
ERROR - 2019-10-23 14:01:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:48 --> Total execution time: 0.0066
ERROR - 2019-10-23 14:01:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:48 --> Total execution time: 0.0087
ERROR - 2019-10-23 14:01:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:49 --> Total execution time: 0.0061
ERROR - 2019-10-23 14:01:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:49 --> Total execution time: 0.0078
ERROR - 2019-10-23 14:01:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:49 --> Total execution time: 0.0085
ERROR - 2019-10-23 14:01:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:50 --> Total execution time: 0.0073
ERROR - 2019-10-23 14:01:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:50 --> Total execution time: 0.0080
ERROR - 2019-10-23 14:01:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:50 --> Total execution time: 0.0085
ERROR - 2019-10-23 14:01:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:51 --> Total execution time: 0.0087
ERROR - 2019-10-23 14:01:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:51 --> Total execution time: 0.0072
ERROR - 2019-10-23 14:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:52 --> Total execution time: 0.0060
ERROR - 2019-10-23 14:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:52 --> Total execution time: 0.0099
ERROR - 2019-10-23 14:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:52 --> Total execution time: 0.0074
ERROR - 2019-10-23 14:01:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:53 --> Total execution time: 0.0076
ERROR - 2019-10-23 14:01:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:53 --> Total execution time: 0.0092
ERROR - 2019-10-23 14:01:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:53 --> Total execution time: 0.0090
ERROR - 2019-10-23 14:01:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:54 --> Total execution time: 0.0097
ERROR - 2019-10-23 14:01:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:54 --> Total execution time: 0.0100
ERROR - 2019-10-23 14:01:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:54 --> Total execution time: 0.0083
ERROR - 2019-10-23 14:01:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:01:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:01:55 --> Total execution time: 0.0064
ERROR - 2019-10-23 14:05:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:05:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:05:03 --> Total execution time: 0.0074
ERROR - 2019-10-23 14:05:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:05:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:05:03 --> Total execution time: 0.0064
ERROR - 2019-10-23 14:05:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:05:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:05:03 --> Total execution time: 0.0082
ERROR - 2019-10-23 14:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:05:04 --> Total execution time: 0.0066
ERROR - 2019-10-23 14:10:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:40 --> Total execution time: 0.0083
ERROR - 2019-10-23 14:10:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:41 --> Total execution time: 0.0061
ERROR - 2019-10-23 14:10:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:41 --> Total execution time: 0.0056
ERROR - 2019-10-23 14:10:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:41 --> Total execution time: 0.0097
ERROR - 2019-10-23 14:10:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:41 --> Total execution time: 0.0093
ERROR - 2019-10-23 14:10:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:42 --> Total execution time: 0.0091
ERROR - 2019-10-23 14:10:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:42 --> Total execution time: 0.0093
ERROR - 2019-10-23 14:10:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:42 --> Total execution time: 0.0077
ERROR - 2019-10-23 14:10:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:42 --> Total execution time: 0.0085
ERROR - 2019-10-23 14:10:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:43 --> Total execution time: 0.0093
ERROR - 2019-10-23 14:10:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:43 --> Total execution time: 0.0094
ERROR - 2019-10-23 14:10:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:43 --> Total execution time: 0.0098
ERROR - 2019-10-23 14:10:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:43 --> Total execution time: 0.0074
ERROR - 2019-10-23 14:10:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:44 --> Total execution time: 0.0067
ERROR - 2019-10-23 14:10:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:44 --> Total execution time: 0.0082
ERROR - 2019-10-23 14:10:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:44 --> Total execution time: 0.0083
ERROR - 2019-10-23 14:10:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:45 --> Total execution time: 0.0076
ERROR - 2019-10-23 14:10:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:45 --> Total execution time: 0.0052
ERROR - 2019-10-23 14:10:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:45 --> Total execution time: 0.0106
ERROR - 2019-10-23 14:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:46 --> Total execution time: 0.0069
ERROR - 2019-10-23 14:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:46 --> Total execution time: 0.0088
ERROR - 2019-10-23 14:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:46 --> Total execution time: 0.0095
ERROR - 2019-10-23 14:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:47 --> Total execution time: 0.0071
ERROR - 2019-10-23 14:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:47 --> Total execution time: 0.0083
ERROR - 2019-10-23 14:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:47 --> Total execution time: 0.0114
ERROR - 2019-10-23 14:10:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:48 --> Total execution time: 0.0063
ERROR - 2019-10-23 14:10:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:48 --> Total execution time: 0.0084
ERROR - 2019-10-23 14:10:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:10:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:10:48 --> Total execution time: 0.0070
ERROR - 2019-10-23 14:14:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:40 --> Total execution time: 0.0085
ERROR - 2019-10-23 14:14:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:40 --> Total execution time: 0.0080
ERROR - 2019-10-23 14:14:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:41 --> Total execution time: 0.0082
ERROR - 2019-10-23 14:14:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:41 --> Total execution time: 0.0094
ERROR - 2019-10-23 14:14:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:41 --> Total execution time: 0.0089
ERROR - 2019-10-23 14:14:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:41 --> Total execution time: 0.0086
ERROR - 2019-10-23 14:14:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:41 --> Total execution time: 0.0107
ERROR - 2019-10-23 14:14:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:42 --> Total execution time: 0.0094
ERROR - 2019-10-23 14:14:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:42 --> Total execution time: 0.0059
ERROR - 2019-10-23 14:14:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:42 --> Total execution time: 0.0084
ERROR - 2019-10-23 14:14:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:43 --> Total execution time: 0.0084
ERROR - 2019-10-23 14:14:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:43 --> Total execution time: 0.0058
ERROR - 2019-10-23 14:14:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:43 --> Total execution time: 0.0074
ERROR - 2019-10-23 14:14:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:44 --> Total execution time: 0.0058
ERROR - 2019-10-23 14:14:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:44 --> Total execution time: 0.0087
ERROR - 2019-10-23 14:14:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:44 --> Total execution time: 0.0063
ERROR - 2019-10-23 14:14:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:45 --> Total execution time: 0.0078
ERROR - 2019-10-23 14:14:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:45 --> Total execution time: 0.0064
ERROR - 2019-10-23 14:14:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:46 --> Total execution time: 0.0094
ERROR - 2019-10-23 14:14:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:46 --> Total execution time: 0.0077
ERROR - 2019-10-23 14:14:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:46 --> Total execution time: 0.0077
ERROR - 2019-10-23 14:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:47 --> Total execution time: 0.0099
ERROR - 2019-10-23 14:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:47 --> Total execution time: 0.0104
ERROR - 2019-10-23 14:14:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:48 --> Total execution time: 0.0067
ERROR - 2019-10-23 14:14:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:48 --> Total execution time: 0.0079
ERROR - 2019-10-23 14:14:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:48 --> Total execution time: 0.0064
ERROR - 2019-10-23 14:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:49 --> Total execution time: 0.0053
ERROR - 2019-10-23 14:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:49 --> Total execution time: 0.0062
ERROR - 2019-10-23 14:14:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:50 --> Total execution time: 0.0088
ERROR - 2019-10-23 14:14:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:50 --> Total execution time: 0.0111
ERROR - 2019-10-23 14:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:51 --> Total execution time: 0.0088
ERROR - 2019-10-23 14:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:51 --> Total execution time: 0.0064
ERROR - 2019-10-23 14:14:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:52 --> Total execution time: 0.0070
ERROR - 2019-10-23 14:14:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:52 --> Total execution time: 0.0057
ERROR - 2019-10-23 14:14:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:53 --> Total execution time: 0.0059
ERROR - 2019-10-23 14:14:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:53 --> Total execution time: 0.0070
ERROR - 2019-10-23 14:14:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:14:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:14:54 --> Total execution time: 0.0066
ERROR - 2019-10-23 14:17:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:10 --> Total execution time: 0.0072
ERROR - 2019-10-23 14:17:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:10 --> Total execution time: 0.0073
ERROR - 2019-10-23 14:17:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:11 --> Total execution time: 0.0059
ERROR - 2019-10-23 14:17:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:17 --> Total execution time: 0.0065
ERROR - 2019-10-23 14:17:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:23 --> Total execution time: 0.0033
ERROR - 2019-10-23 14:17:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:25 --> Total execution time: 0.0029
ERROR - 2019-10-23 14:17:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:26 --> Total execution time: 0.0045
ERROR - 2019-10-23 14:17:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 14:17:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:30 --> Total execution time: 0.0616
DEBUG - 2019-10-23 14:17:30 --> Total execution time: 0.0649
ERROR - 2019-10-23 14:17:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:34 --> Total execution time: 0.0082
ERROR - 2019-10-23 14:17:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:41 --> Total execution time: 0.0033
ERROR - 2019-10-23 14:17:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:45 --> Total execution time: 0.0040
ERROR - 2019-10-23 14:17:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:49 --> Total execution time: 0.0048
ERROR - 2019-10-23 14:17:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:17:50 --> Total execution time: 0.0044
ERROR - 2019-10-23 14:59:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:59:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:59:27 --> Total execution time: 11.0073
ERROR - 2019-10-23 14:59:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 14:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 14:59:54 --> Total execution time: 0.2408
ERROR - 2019-10-23 15:17:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 15:17:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 15:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 15:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 15:17:43 --> Total execution time: 0.1066
ERROR - 2019-10-23 15:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 15:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 15:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 15:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 15:18:10 --> Total execution time: 0.0756
ERROR - 2019-10-23 15:18:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 15:18:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 15:18:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 15:18:11 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 15:18:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 15:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 15:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 15:18:38 --> Total execution time: 0.0086
ERROR - 2019-10-23 15:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 15:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 15:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 15:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 15:50:41 --> Total execution time: 0.0258
ERROR - 2019-10-23 15:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 15:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 15:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 15:50:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 16:46:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:46:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:46:43 --> Total execution time: 0.0464
ERROR - 2019-10-23 16:46:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:46:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:46:50 --> No URI present. Default controller set.
DEBUG - 2019-10-23 16:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:46:51 --> Total execution time: 0.3092
ERROR - 2019-10-23 16:46:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:46:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:46:57 --> No URI present. Default controller set.
DEBUG - 2019-10-23 16:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:46:57 --> Total execution time: 0.0040
ERROR - 2019-10-23 16:47:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:03 --> No URI present. Default controller set.
DEBUG - 2019-10-23 16:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:03 --> Total execution time: 0.0043
ERROR - 2019-10-23 16:47:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:09 --> No URI present. Default controller set.
DEBUG - 2019-10-23 16:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:09 --> Total execution time: 0.0543
ERROR - 2019-10-23 16:47:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:14 --> Total execution time: 0.0068
ERROR - 2019-10-23 16:47:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 16:47:14 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 16:47:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:18 --> Total execution time: 0.0021
ERROR - 2019-10-23 16:47:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:25 --> No URI present. Default controller set.
DEBUG - 2019-10-23 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:25 --> Total execution time: 0.0947
ERROR - 2019-10-23 16:47:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:27 --> Total execution time: 0.1537
ERROR - 2019-10-23 16:47:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:27 --> UTF-8 Support Enabled
ERROR - 2019-10-23 16:47:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:27 --> UTF-8 Support Enabled
ERROR - 2019-10-23 16:47:27 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-23 16:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 16:47:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 16:47:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 16:47:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-23 16:47:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 16:47:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-23 16:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:33 --> Total execution time: 0.0159
ERROR - 2019-10-23 16:47:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:35 --> Total execution time: 0.0832
ERROR - 2019-10-23 16:47:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:36 --> Total execution time: 0.0126
ERROR - 2019-10-23 16:47:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:37 --> Total execution time: 0.0231
ERROR - 2019-10-23 16:47:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:39 --> Total execution time: 0.0025
ERROR - 2019-10-23 16:47:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:41 --> Total execution time: 0.0040
ERROR - 2019-10-23 16:47:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:43 --> Total execution time: 0.0057
ERROR - 2019-10-23 16:47:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:46 --> Total execution time: 0.0950
ERROR - 2019-10-23 16:47:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:57 --> Total execution time: 0.0431
ERROR - 2019-10-23 16:47:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:47:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:47:59 --> Total execution time: 0.0024
ERROR - 2019-10-23 16:48:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:48:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:48:01 --> Total execution time: 0.0035
ERROR - 2019-10-23 16:50:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 16:50:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 16:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 16:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 16:50:54 --> Total execution time: 0.0200
ERROR - 2019-10-23 17:35:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 17:35:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 17:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 17:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 17:35:15 --> Total execution time: 0.0035
ERROR - 2019-10-23 17:35:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 17:35:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 17:35:23 --> No URI present. Default controller set.
DEBUG - 2019-10-23 17:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 17:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 17:35:23 --> Total execution time: 0.0349
ERROR - 2019-10-23 17:35:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 17:35:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 17:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 17:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 17:35:26 --> Total execution time: 0.0109
ERROR - 2019-10-23 17:35:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 17:35:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 17:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 17:35:26 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-23 17:35:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 17:35:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 17:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 17:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 17:35:56 --> Total execution time: 0.0041
ERROR - 2019-10-23 17:36:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 17:36:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 17:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 17:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 17:36:22 --> Total execution time: 0.0032
ERROR - 2019-10-23 17:36:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 17:36:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 17:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 17:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 17:36:32 --> Query error: Duplicate entry 's@gmail.com' for key 'username' - Invalid query: UPDATE `users` SET `username` = 's@gmail.com', `password` = '8ce8124b1e6a380c7b96bd9675c14088', `updated_date` = '2019-10-23', `updated_by` = '34'
WHERE `id` = '174'
DEBUG - 2019-10-23 17:36:32 --> Total execution time: 0.2581
ERROR - 2019-10-23 17:36:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 17:36:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 17:36:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 17:36:32 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-23 18:31:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 18:31:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 18:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 18:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 18:31:21 --> Query error: Duplicate entry 's@gmail.com' for key 'username' - Invalid query: UPDATE `users` SET `username` = 's@gmail.com', `password` = '8ce8124b1e6a380c7b96bd9675c14088', `updated_date` = '2019-10-23', `updated_by` = '34'
WHERE `id` = '174'
DEBUG - 2019-10-23 18:31:21 --> Total execution time: 0.1257
ERROR - 2019-10-23 18:31:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 18:31:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 18:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 18:31:21 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-23 18:32:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 18:32:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 18:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 18:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 18:32:36 --> Query error: Duplicate entry 's@gmail.com' for key 'username' - Invalid query: UPDATE `users` SET `username` = 's@gmail.com', `password` = '8ce8124b1e6a380c7b96bd9675c14088', `updated_date` = '2019-10-23', `updated_by` = '34'
WHERE `id` = '174'
ERROR - 2019-10-23 18:33:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 18:33:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 18:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 18:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 18:33:20 --> Query error: Duplicate entry 's@gmail.com' for key 'username' - Invalid query: UPDATE `users` SET `username` = 's@gmail.com', `password` = '8ce8124b1e6a380c7b96bd9675c14088', `updated_date` = '2019-10-23', `updated_by` = '34'
WHERE `id` = '174'
ERROR - 2019-10-23 18:35:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 18:35:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 18:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 18:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-23 18:35:16 --> Query error: Duplicate entry 's@gmail.com' for key 'username' - Invalid query: UPDATE `users` SET `username` = 's@gmail.com', `password` = '8ce8124b1e6a380c7b96bd9675c14088', `updated_date` = '2019-10-23', `updated_by` = '34'
WHERE `id` = '174'
DEBUG - 2019-10-23 18:35:16 --> Total execution time: 0.1184
ERROR - 2019-10-23 18:35:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 18:35:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 18:35:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-23 18:35:17 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-23 19:03:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-23 19:03:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-23 19:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-23 19:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-23 19:03:08 --> Total execution time: 0.0031
