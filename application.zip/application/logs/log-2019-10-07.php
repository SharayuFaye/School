<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-07 18:16:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:16:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:16:05 --> No URI present. Default controller set.
DEBUG - 2019-10-07 18:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:16:05 --> Total execution time: 0.0416
ERROR - 2019-10-07 18:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:16:10 --> No URI present. Default controller set.
DEBUG - 2019-10-07 18:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:16:10 --> Severity: error --> Exception: syntax error, unexpected ')' /var/www/html/School19/application/models/M_login.php 27
ERROR - 2019-10-07 18:18:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:16 --> No URI present. Default controller set.
DEBUG - 2019-10-07 18:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:18:16 --> Total execution time: 0.0175
ERROR - 2019-10-07 18:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:18:19 --> Total execution time: 0.0116
ERROR - 2019-10-07 18:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:18:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-07 18:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:18:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-07 18:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:18:19 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-07 18:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:18:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-07 18:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:18:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-07 18:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:18:21 --> Total execution time: 0.0025
ERROR - 2019-10-07 18:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:18:21 --> Total execution time: 0.0031
ERROR - 2019-10-07 18:18:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:18:40 --> Total execution time: 0.0048
ERROR - 2019-10-07 18:18:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:18:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:18:43 --> Total execution time: 0.0140
ERROR - 2019-10-07 18:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:19:03 --> Query error: Column 'route_id' cannot be null - Invalid query: INSERT INTO `students` (`users_id`, `class_id`, `sections_id`, `student_name`, `dob`, `adhar`, `profile`, `parent_name`, `parent_mob`, `mother_name`, `mother_mob`, `mother_mail`, `parent_scan_id`, `roll_number`, `batch`, `username`, `password`, `bus_id`, `route_id`, `transportation_id`, `join_date`, `school_id`, `created_date`, `created_by`) VALUES ('157', '1', '40', 'aa bbb', '2019-10-03', '1', 'pic11.jpg', 'rohan', '2147483647', 'rita', '2147483647', 'rita@gmail.com', '52', '32', '213', 'rohan@gmail.com', 'r1', '', NULL, NULL, '', '3', '2019-10-07', '34')
DEBUG - 2019-10-07 18:19:03 --> Total execution time: 0.0127
ERROR - 2019-10-07 18:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-07 18:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:19:03 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-07 18:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:19:03 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:19:03 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:19:03 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:19:03 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:19:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:19:14 --> Total execution time: 0.0055
ERROR - 2019-10-07 18:19:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:19:14 --> Total execution time: 0.0038
ERROR - 2019-10-07 18:19:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:19:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:21:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:21:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:21:21 --> Query error: Column 'route_id' cannot be null - Invalid query: INSERT INTO `students` (`users_id`, `class_id`, `sections_id`, `student_name`, `dob`, `adhar`, `profile`, `parent_name`, `parent_mob`, `mother_name`, `mother_mob`, `mother_mail`, `parent_scan_id`, `roll_number`, `batch`, `username`, `password`, `bus_id`, `route_id`, `transportation_id`, `join_date`, `school_id`, `created_date`, `created_by`) VALUES ('157', '1', '40', 'aa bbb', '2019-10-03', '1', 'pic113.jpg', 'rohan', '2147483647', 'rita', '2147483647', 'rita@gmail.com', '52', '32', '213', 'rohan@gmail.com', 'r1', '', NULL, NULL, '', '3', '2019-10-07', '34')
DEBUG - 2019-10-07 18:21:21 --> Total execution time: 0.0116
ERROR - 2019-10-07 18:21:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:21:21 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:21:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:21:21 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:21:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:21:21 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:21:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:21:21 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:21:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:21:21 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:21:48 --> Total execution time: 0.0050
ERROR - 2019-10-07 18:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:21:48 --> Total execution time: 0.0023
ERROR - 2019-10-07 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:22:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:22:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:22:32 --> Query error: Column 'route_id' cannot be null - Invalid query: INSERT INTO `students` (`users_id`, `class_id`, `sections_id`, `student_name`, `dob`, `adhar`, `profile`, `parent_name`, `parent_mob`, `mother_name`, `mother_mob`, `mother_mail`, `parent_scan_id`, `roll_number`, `batch`, `username`, `password`, `bus_id`, `route_id`, `transportation_id`, `join_date`, `school_id`, `created_date`, `created_by`) VALUES ('157', '1', '40', 'aa bbb', '2019-10-03', '1', 'pic115.jpg', 'rohan', '2147483647', 'rita', '2147483647', 'rita@gmail.com', '52', '32', '213', 'rohan@gmail.com', 'r1', '', NULL, NULL, '', '3', '2019-10-07', '34')
ERROR - 2019-10-07 18:23:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:23:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:23:10 --> Query error: Column 'route_id' cannot be null - Invalid query: INSERT INTO `students` (`users_id`, `class_id`, `sections_id`, `student_name`, `dob`, `adhar`, `profile`, `parent_name`, `parent_mob`, `mother_name`, `mother_mob`, `mother_mail`, `parent_scan_id`, `roll_number`, `batch`, `username`, `password`, `bus_id`, `route_id`, `transportation_id`, `join_date`, `school_id`, `created_date`, `created_by`) VALUES ('157', '1', '40', 'aa bbb', '2019-10-03', '1', 'pic116.jpg', 'rohan', '2147483647', 'rita', '2147483647', 'rita@gmail.com', '52', '32', '213', 'rohan@gmail.com', 'r1', '', NULL, NULL, '', '3', '2019-10-07', '34')
ERROR - 2019-10-07 18:23:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:23:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:23:21 --> Total execution time: 0.0099
ERROR - 2019-10-07 18:23:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:23:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:23:26 --> Total execution time: 0.0049
ERROR - 2019-10-07 18:23:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:23:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:23:27 --> Total execution time: 0.0024
ERROR - 2019-10-07 18:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:23:29 --> Total execution time: 0.0043
ERROR - 2019-10-07 18:23:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:23:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:23:42 --> Total execution time: 0.0053
ERROR - 2019-10-07 18:23:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:23:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:09 --> Total execution time: 0.0071
ERROR - 2019-10-07 18:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:09 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:24:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:11 --> Total execution time: 0.0031
ERROR - 2019-10-07 18:24:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:11 --> Total execution time: 0.0022
ERROR - 2019-10-07 18:24:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:17 --> Total execution time: 0.0053
ERROR - 2019-10-07 18:24:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:21 --> Total execution time: 0.0029
ERROR - 2019-10-07 18:24:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:24:34 --> Query error: Column 'route_id' cannot be null - Invalid query: INSERT INTO `students` (`users_id`, `class_id`, `sections_id`, `student_name`, `dob`, `adhar`, `profile`, `parent_name`, `parent_mob`, `mother_name`, `mother_mob`, `mother_mail`, `parent_scan_id`, `roll_number`, `batch`, `username`, `password`, `bus_id`, `route_id`, `transportation_id`, `join_date`, `school_id`, `created_date`, `created_by`) VALUES ('157', '1', '40', ' rwer we e', '2019-10-03', '33', 'pic12.jpg', 'rohan', '2147483647', 'rita', '2147483647', 'rita@gmail.com', '52', '2', 'Afternoon', 'rohan@gmail.com', 'r1', '', NULL, NULL, '', '3', '2019-10-07', '34')
ERROR - 2019-10-07 18:24:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:38 --> Total execution time: 0.0097
ERROR - 2019-10-07 18:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:46 --> Total execution time: 0.0085
ERROR - 2019-10-07 18:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-07 18:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:24:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:46 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:24:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:46 --> Total execution time: 0.0026
ERROR - 2019-10-07 18:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:46 --> Total execution time: 0.0024
ERROR - 2019-10-07 18:24:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:24:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:24:49 --> Total execution time: 0.0021
ERROR - 2019-10-07 18:25:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:25:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:25:08 --> Total execution time: 0.0031
ERROR - 2019-10-07 18:25:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:25:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:25:13 --> Query error: Column 'route_id' cannot be null - Invalid query: INSERT INTO `students` (`users_id`, `class_id`, `sections_id`, `student_name`, `dob`, `adhar`, `profile`, `parent_name`, `parent_mob`, `mother_name`, `mother_mob`, `mother_mail`, `parent_scan_id`, `roll_number`, `batch`, `username`, `password`, `bus_id`, `route_id`, `transportation_id`, `join_date`, `school_id`, `created_date`, `created_by`) VALUES ('157', '1', '40', 'kfg nagar', '2019-10-01', '22', 'pic121.jpg', 'rohan', '2147483647', 'rita', '2147483647', 'rita@gmail.com', '52', '2', '2', 'rohan@gmail.com', 'r1', '', NULL, NULL, '2019-10-03', '3', '2019-10-07', '34')
ERROR - 2019-10-07 18:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:26:13 --> Query error: Column 'route_id' cannot be null - Invalid query: INSERT INTO `students` (`users_id`, `class_id`, `sections_id`, `student_name`, `dob`, `adhar`, `profile`, `parent_name`, `parent_mob`, `mother_name`, `mother_mob`, `mother_mail`, `parent_scan_id`, `roll_number`, `batch`, `username`, `password`, `bus_id`, `route_id`, `transportation_id`, `join_date`, `school_id`, `created_date`, `created_by`) VALUES ('157', '1', '40', 'kfg nagar', '2019-10-01', '22', 'pic122.jpg', 'rohan', '2147483647', 'rita', '2147483647', 'rita@gmail.com', '52', '2', '2', 'rohan@gmail.com', 'r1', '', NULL, NULL, '2019-10-03', '3', '2019-10-07', '34')
ERROR - 2019-10-07 18:26:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:14 --> Total execution time: 0.0083
ERROR - 2019-10-07 18:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:15 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:26:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:17 --> Total execution time: 0.0044
ERROR - 2019-10-07 18:26:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:17 --> Total execution time: 0.0029
ERROR - 2019-10-07 18:26:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:20 --> Total execution time: 0.0032
ERROR - 2019-10-07 18:26:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:22 --> Total execution time: 0.0021
ERROR - 2019-10-07 18:26:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:36 --> Total execution time: 0.0023
ERROR - 2019-10-07 18:26:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:39 --> Total execution time: 0.0060
ERROR - 2019-10-07 18:26:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:40 --> Total execution time: 0.0049
ERROR - 2019-10-07 18:26:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:26:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:26:52 --> Total execution time: 0.0069
ERROR - 2019-10-07 18:26:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:26:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:26:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:53 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:26:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:26:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:26:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:26:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:27:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:27:13 --> Total execution time: 0.0055
ERROR - 2019-10-07 18:27:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-07 18:27:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:27:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:27:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:13 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:27:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:27:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:27:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:27:14 --> Total execution time: 0.0023
ERROR - 2019-10-07 18:27:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:27:14 --> Total execution time: 0.0024
ERROR - 2019-10-07 18:27:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:27:16 --> Total execution time: 0.0037
ERROR - 2019-10-07 18:27:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:27:32 --> Total execution time: 0.0031
ERROR - 2019-10-07 18:27:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-07 18:27:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:27:43 --> Total execution time: 0.0607
ERROR - 2019-10-07 18:27:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:27:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:27:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:43 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:27:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:44 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:27:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:27:44 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:27:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:27:58 --> Total execution time: 0.0031
ERROR - 2019-10-07 18:27:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:27:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:27:58 --> Total execution time: 0.0022
ERROR - 2019-10-07 18:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:28:07 --> Total execution time: 0.0732
ERROR - 2019-10-07 18:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:28:07 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:28:07 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:28:07 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-07 18:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:28:07 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-07 18:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-07 18:28:07 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-07 18:28:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:28:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:28:10 --> Total execution time: 0.0045
ERROR - 2019-10-07 18:28:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-07 18:28:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-07 18:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-07 18:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-07 18:28:10 --> Total execution time: 0.0048
