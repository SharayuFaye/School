<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-05 15:55:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-05 15:55:10 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_students.php 158
ERROR - 2019-11-05 15:55:11 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_bus.php 138
ERROR - 2019-11-05 15:55:11 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_sel_route.php 55
ERROR - 2019-11-05 15:55:11 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_route.php 49
ERROR - 2019-11-05 15:55:11 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_sections.php 137
ERROR - 2019-11-05 15:55:11 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_teachers.php 135
DEBUG - 2019-11-05 15:55:11 --> Total execution time: 1.5727
ERROR - 2019-11-05 15:55:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-05 15:55:12 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-05 15:55:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-05 15:55:14 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_students.php 238
DEBUG - 2019-11-05 15:55:14 --> Total execution time: 0.0031
ERROR - 2019-11-05 15:55:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-05 15:55:14 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_students.php 238
DEBUG - 2019-11-05 15:55:14 --> Total execution time: 0.0027
ERROR - 2019-11-05 15:55:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-05 15:55:15 --> Total execution time: 0.0240
ERROR - 2019-11-05 15:55:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:25 --> No URI present. Default controller set.
DEBUG - 2019-11-05 15:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-05 15:55:25 --> disha :: Disha@123
DEBUG - 2019-11-05 15:55:25 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-05 15:55:25 --> Total execution time: 0.5435
ERROR - 2019-11-05 15:55:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-05 15:55:34 --> Total execution time: 0.0087
ERROR - 2019-11-05 15:55:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-05 15:55:34 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-05 15:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-05 15:55:36 --> Total execution time: 0.0036
ERROR - 2019-11-05 15:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-05 15:55:36 --> Total execution time: 0.0034
ERROR - 2019-11-05 15:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-05 15:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-05 15:55:36 --> Total execution time: 0.0441
DEBUG - 2019-11-05 15:55:36 --> Total execution time: 0.0103
ERROR - 2019-11-05 15:55:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:55:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-05 15:55:51 --> Total execution time: 0.2982
ERROR - 2019-11-05 15:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-05 15:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-05 15:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-05 15:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-05 15:58:20 --> Total execution time: 0.0109
