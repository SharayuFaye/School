<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-28 11:22:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:22:31 --> Total execution time: 0.0044
ERROR - 2019-09-28 11:22:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:22:31 --> Total execution time: 0.0075
ERROR - 2019-09-28 11:22:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:22:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:22:34 --> Query error: Duplicate entry 'pass1' for key 'password' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s21@gmail.com', 'pass1', '3', 'student', '2019-09-28', '34')
DEBUG - 2019-09-28 11:22:34 --> Total execution time: 0.1992
ERROR - 2019-09-28 11:22:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 11:22:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:22:34 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-28 11:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:22:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:22:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:22:34 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:22:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:22:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:22:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:22:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:23:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:23:21 --> Total execution time: 0.0058
ERROR - 2019-09-28 11:23:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:23:21 --> Total execution time: 0.0041
ERROR - 2019-09-28 11:23:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:23:27 --> Total execution time: 0.0201
ERROR - 2019-09-28 11:23:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:23:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:23:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:23:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:23:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:23:27 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:23:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:23:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:23:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:23:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:25:01 --> Total execution time: 0.0030
ERROR - 2019-09-28 11:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:25:01 --> Total execution time: 0.0050
ERROR - 2019-09-28 11:28:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:28:12 --> Total execution time: 0.0072
ERROR - 2019-09-28 11:42:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:42:33 --> Total execution time: 0.0026
ERROR - 2019-09-28 11:42:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:38 --> No URI present. Default controller set.
DEBUG - 2019-09-28 11:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:42:38 --> Total execution time: 0.0118
ERROR - 2019-09-28 11:42:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:42:45 --> Total execution time: 0.0086
ERROR - 2019-09-28 11:42:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 11:42:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 11:42:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:46 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-28 11:42:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 11:42:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 11:42:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:42:52 --> Total execution time: 0.1202
ERROR - 2019-09-28 11:42:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:42:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:42:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:52 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:42:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:42:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:42:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:43:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:43:17 --> Total execution time: 0.0930
ERROR - 2019-09-28 11:43:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:17 --> UTF-8 Support Enabled
ERROR - 2019-09-28 11:43:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:43:17 --> UTF-8 Support Enabled
ERROR - 2019-09-28 11:43:17 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-09-28 11:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:43:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:17 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:43:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:43:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:43:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:43:21 --> Total execution time: 0.0159
ERROR - 2019-09-28 11:43:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 11:43:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 11:43:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:21 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-09-28 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:21 --> 404 Page Not Found: Welcome/profile
DEBUG - 2019-09-28 11:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:21 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:43:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:43:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:43:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:49:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:49:14 --> Total execution time: 0.0245
ERROR - 2019-09-28 11:49:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:49:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:49:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:15 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:49:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:49:38 --> Total execution time: 0.0145
ERROR - 2019-09-28 11:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 11:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:49:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:38 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:49:58 --> Total execution time: 0.0159
ERROR - 2019-09-28 11:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:58 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:58 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:58 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:58 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:49:58 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:50:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:50:26 --> Total execution time: 0.0225
ERROR - 2019-09-28 11:50:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:50:26 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:50:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:50:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:50:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:50:26 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:50:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:50:26 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:50:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:50:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:50:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:50:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:51:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:51:11 --> Total execution time: 0.0204
ERROR - 2019-09-28 11:51:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:51:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:51:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:51:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:51:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:51:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:51:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:51:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:51:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:51:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:51:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:51:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:52:11 --> Total execution time: 0.0203
ERROR - 2019-09-28 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:52:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:52:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/students.php 48
DEBUG - 2019-09-28 11:52:32 --> Total execution time: 0.0157
ERROR - 2019-09-28 11:52:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:33 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:52:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:33 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:52:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:33 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:52:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:33 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:52:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:33 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:52:48 --> Total execution time: 0.0169
ERROR - 2019-09-28 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:48 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:48 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:52:48 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:53:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:53:10 --> Total execution time: 0.0225
ERROR - 2019-09-28 11:53:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 11:53:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:53:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:53:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:53:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:10 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:53:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:53:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:53:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:53:56 --> Total execution time: 0.0174
ERROR - 2019-09-28 11:53:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:56 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:53:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:56 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:53:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:56 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:53:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:56 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:53:57 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:54:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:54:11 --> Total execution time: 0.0190
ERROR - 2019-09-28 11:54:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 11:54:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:54:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:54:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:54:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:54:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:54:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:54:34 --> Total execution time: 0.0181
ERROR - 2019-09-28 11:54:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:54:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:54:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:34 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:54:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:54:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:54:45 --> Total execution time: 0.0157
ERROR - 2019-09-28 11:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:45 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:54:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:54:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:54:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:55:02 --> Total execution time: 0.0142
ERROR - 2019-09-28 11:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:02 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:55:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:55:38 --> Total execution time: 0.0148
ERROR - 2019-09-28 11:55:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:55:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:55:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:38 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:55:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:55:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:55:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:55:45 --> Total execution time: 0.0160
ERROR - 2019-09-28 11:55:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:45 --> UTF-8 Support Enabled
ERROR - 2019-09-28 11:55:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:55:45 --> UTF-8 Support Enabled
ERROR - 2019-09-28 11:55:45 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-09-28 11:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:55:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:45 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:55:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:55:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:55:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 11:56:06 --> Total execution time: 0.0133
ERROR - 2019-09-28 11:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:56:06 --> UTF-8 Support Enabled
ERROR - 2019-09-28 11:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:56:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:56:06 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-09-28 11:56:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:56:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:56:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:56:06 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 11:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:56:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:56:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 11:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:56:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 11:56:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 11:56:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:56:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:56:50 --> Severity: Compile Error --> Can't use function return value in write context /var/www/html/School19/application/models/M_students.php 235
ERROR - 2019-09-28 11:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:57:41 --> Severity: Compile Error --> Can't use function return value in write context /var/www/html/School19/application/models/M_students.php 235
ERROR - 2019-09-28 11:58:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:58:47 --> Severity: Compile Error --> Can't use function return value in write context /var/www/html/School19/application/models/M_students.php 235
ERROR - 2019-09-28 11:59:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 11:59:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 11:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 11:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 11:59:31 --> Severity: Compile Error --> Can't use function return value in write context /var/www/html/School19/application/models/M_students.php 235
ERROR - 2019-09-28 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:00:14 --> Total execution time: 0.0150
ERROR - 2019-09-28 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:00:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:00:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:00:14 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:00:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:00:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:30:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:30:06 --> Total execution time: 0.0112
ERROR - 2019-09-28 12:30:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 12:30:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:30:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:30:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:06 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:30:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:30:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:30:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:30:21 --> Total execution time: 0.0141
ERROR - 2019-09-28 12:30:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:21 --> UTF-8 Support Enabled
ERROR - 2019-09-28 12:30:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:21 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-09-28 12:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:21 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:30:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:21 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:30:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:30:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:30:43 --> Total execution time: 0.0157
ERROR - 2019-09-28 12:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:43 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:30:51 --> Total execution time: 0.0677
ERROR - 2019-09-28 12:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:51 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:51 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:30:51 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:31:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:31:27 --> Total execution time: 0.0091
ERROR - 2019-09-28 12:31:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:31:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:31:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:27 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:31:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:31:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:31:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:31:36 --> Total execution time: 0.0179
ERROR - 2019-09-28 12:31:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:31:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:31:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:36 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:31:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:31:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:31:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:33:41 --> Total execution time: 0.0088
ERROR - 2019-09-28 12:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:33:41 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:33:41 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:33:41 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:33:41 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:33:41 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:33:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:33:52 --> Total execution time: 0.0030
ERROR - 2019-09-28 12:33:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:33:53 --> Total execution time: 0.0043
ERROR - 2019-09-28 12:33:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:33:55 --> Total execution time: 0.0036
ERROR - 2019-09-28 12:33:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:33:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:33:56 --> Total execution time: 0.0043
ERROR - 2019-09-28 12:34:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:34:55 --> Total execution time: 0.0078
ERROR - 2019-09-28 12:34:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:34:55 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:34:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:34:55 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:34:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:34:55 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:34:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:34:55 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:34:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:34:55 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:35:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:35:07 --> Total execution time: 0.1160
ERROR - 2019-09-28 12:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:07 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:07 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:07 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:07 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:07 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:35:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:35:14 --> Total execution time: 0.0029
ERROR - 2019-09-28 12:35:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:35:16 --> Total execution time: 0.0038
ERROR - 2019-09-28 12:35:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:35:17 --> Total execution time: 0.0025
ERROR - 2019-09-28 12:35:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:35:19 --> Total execution time: 0.3467
ERROR - 2019-09-28 12:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 12:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:35:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:19 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-28 12:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:35:27 --> Total execution time: 0.0048
ERROR - 2019-09-28 12:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:27 --> UTF-8 Support Enabled
ERROR - 2019-09-28 12:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:27 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-28 12:35:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 12:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 12:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:35:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:35:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:35:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 12:46:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:46:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:46:53 --> Total execution time: 0.0292
ERROR - 2019-09-28 12:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 12:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:46:53 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-28 12:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:46:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 12:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:46:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 12:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:46:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 12:47:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:47:00 --> Total execution time: 0.0111
ERROR - 2019-09-28 12:47:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:47:00 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:47:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:47:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:47:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:47:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:47:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:47:00 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:47:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:47:35 --> Total execution time: 0.0128
ERROR - 2019-09-28 12:47:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:47:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:47:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:47:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:47:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:47:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:47:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:47:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 12:48:23 --> Query error: Duplicate entry '11' for key 'drivers_mobile' - Invalid query: INSERT INTO `drivers` (`users_id`, `drivers_name`, `drivers_address`, `drivers_mobile`, `join_date`, `created_date`, `created_by`) VALUES ('163', 'd33', 11, 11, '07/01/19', '2019-09-28', '34')
DEBUG - 2019-09-28 12:48:23 --> Total execution time: 0.4767
ERROR - 2019-09-28 12:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:48:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:48:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:48:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:48:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:48:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:48:40 --> Total execution time: 0.0112
ERROR - 2019-09-28 12:48:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:48:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:48:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:48:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:48:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:48:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:48:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:48:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:49:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:49:09 --> Total execution time: 0.0127
ERROR - 2019-09-28 12:49:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:49:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:49:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:49:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:49:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:49:40 --> Total execution time: 0.0110
ERROR - 2019-09-28 12:49:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:49:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:49:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:49:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:49:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:49:51 --> Total execution time: 0.0070
ERROR - 2019-09-28 12:49:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 12:49:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 12:49:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 12:49:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:49:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:49:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:49:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 12:52:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:52:56 --> Total execution time: 0.0074
ERROR - 2019-09-28 12:52:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:52:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 12:52:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:52:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 12:52:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:52:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 12:52:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:52:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 12:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:53:09 --> Total execution time: 0.0169
ERROR - 2019-09-28 12:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:53:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:53:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:53:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:53:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:55:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 12:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 12:55:12 --> Total execution time: 0.1172
ERROR - 2019-09-28 12:55:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:55:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:55:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:55:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 12:55:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:55:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 12:55:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 12:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 12:55:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:10:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:10:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:10:12 --> Total execution time: 0.0145
ERROR - 2019-09-28 14:10:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:10:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:10:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:10:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:10:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:10:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:10:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:10:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:10:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:10:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:10:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:10:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:11:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:11:29 --> Total execution time: 0.0058
ERROR - 2019-09-28 14:11:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:11:37 --> Total execution time: 0.0024
ERROR - 2019-09-28 14:11:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:43 --> No URI present. Default controller set.
DEBUG - 2019-09-28 14:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:11:43 --> Total execution time: 0.0094
ERROR - 2019-09-28 14:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:11:50 --> Total execution time: 0.0097
ERROR - 2019-09-28 14:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:11:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:11:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:11:50 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-09-28 14:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:11:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:11:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:11:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:11:57 --> Total execution time: 0.0450
ERROR - 2019-09-28 14:11:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:11:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:11:58 --> Total execution time: 0.0022
ERROR - 2019-09-28 14:12:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:12:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:12:14 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2019-09-28 14:12:15 --> Total execution time: 0.0649
ERROR - 2019-09-28 14:12:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:12:15 --> Total execution time: 0.0085
ERROR - 2019-09-28 14:12:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:12:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:12:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:12:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:12:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:12:15 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-09-28 14:12:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:12:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:12:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:12:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:14:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:14:12 --> Total execution time: 0.0109
ERROR - 2019-09-28 14:14:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 14:14:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:14:12 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-09-28 14:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:14:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:14:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:14:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:14:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:14:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:20:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:20:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:20:33 --> Total execution time: 0.0127
ERROR - 2019-09-28 14:20:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:20:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:20:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:20:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:20:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:20:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:20:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:20:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:20:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:20:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:20:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:20:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:21:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:21:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 14:21:00 --> Severity: Notice --> Undefined property: Welcome::$upload /var/www/html/School19/application/controllers/Welcome.php 2328
ERROR - 2019-09-28 14:21:00 --> Severity: error --> Exception: Call to a member function do_upload() on null /var/www/html/School19/application/controllers/Welcome.php 2328
ERROR - 2019-09-28 14:23:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:23:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-28 14:23:19 --> Severity: Notice --> Undefined property: Welcome::$upload /var/www/html/School19/application/controllers/Welcome.php 2328
ERROR - 2019-09-28 14:23:19 --> Severity: error --> Exception: Call to a member function do_upload() on null /var/www/html/School19/application/controllers/Welcome.php 2328
ERROR - 2019-09-28 14:25:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:25:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:25:10 --> You have not specified any allowed file types.
DEBUG - 2019-09-28 14:25:10 --> The filetype you are attempting to upload is not allowed.
ERROR - 2019-09-28 14:25:10 --> Severity: Notice --> Undefined variable: image /var/www/html/School19/application/controllers/Welcome.php 2352
DEBUG - 2019-09-28 14:25:10 --> Total execution time: 0.0590
ERROR - 2019-09-28 14:25:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:25:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:25:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:25:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:25:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:25:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:25:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:25:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:25:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:25:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:25:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:25:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:27:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:27:51 --> Total execution time: 0.0075
ERROR - 2019-09-28 14:27:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 14:27:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:27:51 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-28 14:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:27:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:27:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:27:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:27:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:27:51 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:28:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:28:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:28:02 --> You have not specified any allowed file types.
DEBUG - 2019-09-28 14:28:02 --> The filetype you are attempting to upload is not allowed.
ERROR - 2019-09-28 14:28:02 --> Severity: Notice --> Undefined variable: image /var/www/html/School19/application/controllers/Welcome.php 2352
DEBUG - 2019-09-28 14:28:02 --> Total execution time: 0.1043
ERROR - 2019-09-28 14:28:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:28:03 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:28:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:28:03 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:28:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:28:03 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:28:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:28:03 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:28:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:28:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:28:44 --> You have not specified any allowed file types.
DEBUG - 2019-09-28 14:28:44 --> The filetype you are attempting to upload is not allowed.
ERROR - 2019-09-28 14:32:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:32:01 --> Total execution time: 0.0763
ERROR - 2019-09-28 14:32:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 14:32:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:32:01 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-28 14:32:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:32:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:32:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:32:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:32:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:32:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:32:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:32:26 --> Total execution time: 0.0876
ERROR - 2019-09-28 14:32:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:32:26 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:32:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:32:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:32:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:32:26 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:32:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:32:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:32:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:33:34 --> Total execution time: 0.1367
ERROR - 2019-09-28 14:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:34 --> UTF-8 Support Enabled
ERROR - 2019-09-28 14:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:33:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:33:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:33:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:33:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:33:44 --> Total execution time: 0.0074
ERROR - 2019-09-28 14:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:33:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:33:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:33:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:33:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:41:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:41:32 --> Total execution time: 0.0213
ERROR - 2019-09-28 14:41:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 14:41:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:41:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:41:32 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:41:32 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:41:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:41:32 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:41:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:41:32 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:41:37 --> Total execution time: 0.0602
ERROR - 2019-09-28 14:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:37 --> UTF-8 Support Enabled
ERROR - 2019-09-28 14:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:41:37 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-09-28 14:41:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:41:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:41:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:41:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:41:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:41:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:43:37 --> Total execution time: 0.0179
ERROR - 2019-09-28 14:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:43:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:43:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:43:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:43:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:44:25 --> Total execution time: 0.0586
ERROR - 2019-09-28 14:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 14:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:44:25 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-28 14:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:44:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:44:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:44:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:44:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:44:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:44:30 --> Total execution time: 0.1022
ERROR - 2019-09-28 14:44:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 14:44:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:44:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:44:30 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-28 14:44:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:44:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:44:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:44:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:44:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:44:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:44:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:44:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:47:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:47:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:47:20 --> Total execution time: 0.0044
ERROR - 2019-09-28 14:47:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:47:25 --> No URI present. Default controller set.
DEBUG - 2019-09-28 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:47:25 --> Total execution time: 0.0129
ERROR - 2019-09-28 14:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:47:28 --> Total execution time: 0.0107
ERROR - 2019-09-28 14:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:47:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:47:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:47:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:47:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:49:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:49:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:49:02 --> Total execution time: 0.0093
ERROR - 2019-09-28 14:49:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 14:49:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:49:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:49:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:49:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:49:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:49:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:49:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:49:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:49:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:49:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:49:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:52:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:52:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:52:51 --> Total execution time: 0.0129
ERROR - 2019-09-28 14:52:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:52:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 14:52:52 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-28 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:52:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:52:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:52:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:52:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:52:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:52:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:52:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:52:56 --> Total execution time: 0.0024
ERROR - 2019-09-28 14:52:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:52:57 --> Total execution time: 0.0029
ERROR - 2019-09-28 14:52:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:52:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:52:58 --> Total execution time: 0.0032
ERROR - 2019-09-28 14:54:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:01 --> Total execution time: 0.0082
ERROR - 2019-09-28 14:54:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:54:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:02 --> Total execution time: 0.0127
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:02 --> Total execution time: 0.0091
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:02 --> Total execution time: 0.0098
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:54:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:07 --> Total execution time: 0.0032
ERROR - 2019-09-28 14:54:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:08 --> Total execution time: 0.0028
ERROR - 2019-09-28 14:54:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:29 --> Total execution time: 0.0102
ERROR - 2019-09-28 14:54:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:54:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:54:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:54:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:54:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:54:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:33 --> Total execution time: 0.0032
ERROR - 2019-09-28 14:54:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:54:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:54:34 --> Total execution time: 0.0049
ERROR - 2019-09-28 14:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:55:40 --> Total execution time: 0.0092
ERROR - 2019-09-28 14:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:55:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:55:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:55:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:55:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:55:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:55:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:55:44 --> Total execution time: 0.0023
ERROR - 2019-09-28 14:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:57:52 --> Total execution time: 0.0147
ERROR - 2019-09-28 14:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:57:52 --> UTF-8 Support Enabled
ERROR - 2019-09-28 14:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:57:52 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-28 14:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:57:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:57:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-28 14:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:57:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-28 14:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:57:55 --> Total execution time: 0.0048
ERROR - 2019-09-28 14:57:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:57:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:57:58 --> Total execution time: 0.0028
ERROR - 2019-09-28 14:57:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:57:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:57:59 --> Total execution time: 0.0065
ERROR - 2019-09-28 14:58:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:58:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:58:02 --> Total execution time: 0.1335
ERROR - 2019-09-28 14:58:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:58:02 --> UTF-8 Support Enabled
ERROR - 2019-09-28 14:58:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:58:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:58:02 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-28 14:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:58:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:58:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:58:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:58:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:58:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:58:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:58:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:59:44 --> Total execution time: 0.0075
ERROR - 2019-09-28 14:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:59:44 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:59:44 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:59:44 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 14:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 14:59:44 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 14:59:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:59:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:59:50 --> Total execution time: 0.0041
ERROR - 2019-09-28 14:59:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 14:59:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 14:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 14:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 14:59:58 --> ROLE ::::: student
DEBUG - 2019-09-28 14:59:58 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => c2YdyZRcPFY:APA91bHP5e5FsLwrjfCruEbsZZBYeRY9U1xDktiPJ1PX_X4ebwlQ8ixB1z1LbafTUEA0ayK16GIQOBapxOj5oZFGRoTe6VNKZa1o_Bnbb1LG2mMuKrB_3DzuBdXZNdxKY2dLKwvvkRf-
    [2] => chlGxvP9M6M:APA91bHiG9OKxhaN-zpWp7v8Ueel9PNOozxupjK9lciwIrl7rQGg9tGqB9InKED54DpZ1oFuEkYGME0xFPabN1RIYOKR2miw_rVoEyZiFvasgdpY1gXq830F42Htpkbv533qku8RE1Zw
    [3] => cdIrbAvnajU:APA91bGOfq44KK9Up1OkkdG6K_7z8NqrpHayZiszoX_vokwXF9fufU5jPH-eyGJM1seU-yA9bsLDICzGX6QpgApU9kePtD8tmwwXLq2A5WARXX5ZgoyEnSTOA3HD_cFgJ03DNcUeJLWm
    [4] => eIxMlMoHgw4:APA91bHZvlIlT27UNhHPekD67ADyvjoW87tcwNtq827g6QpIwteKaD47wToIj33n7fPqKGeYbDuBiUpMc8UVUkFyCI1DwdlPoYffNjV2ubYJEw8Ufbk_Kc6RPOx4t0dzE5IFxL4MpMLl
    [5] => fzL5VgZIflE:APA91bEvGp9M6k3KujY0xlIqhk_gB5tPNde1E-lPpoVi0pvgIOhBLQh80ciFfo-JvGdOenb9rHpKY6YdDaCQiFnv4sf0IXcUeQBdRfQMo7Q8nLsmiULaChjYmj8RC1-nf4l6Rx5B-PUU
)

DEBUG - 2019-09-28 14:59:58 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => c2YdyZRcPFY:APA91bHP5e5FsLwrjfCruEbsZZBYeRY9U1xDktiPJ1PX_X4ebwlQ8ixB1z1LbafTUEA0ayK16GIQOBapxOj5oZFGRoTe6VNKZa1o_Bnbb1LG2mMuKrB_3DzuBdXZNdxKY2dLKwvvkRf-
    [2] => chlGxvP9M6M:APA91bHiG9OKxhaN-zpWp7v8Ueel9PNOozxupjK9lciwIrl7rQGg9tGqB9InKED54DpZ1oFuEkYGME0xFPabN1RIYOKR2miw_rVoEyZiFvasgdpY1gXq830F42Htpkbv533qku8RE1Zw
    [3] => cdIrbAvnajU:APA91bGOfq44KK9Up1OkkdG6K_7z8NqrpHayZiszoX_vokwXF9fufU5jPH-eyGJM1seU-yA9bsLDICzGX6QpgApU9kePtD8tmwwXLq2A5WARXX5ZgoyEnSTOA3HD_cFgJ03DNcUeJLWm
    [4] => eIxMlMoHgw4:APA91bHZvlIlT27UNhHPekD67ADyvjoW87tcwNtq827g6QpIwteKaD47wToIj33n7fPqKGeYbDuBiUpMc8UVUkFyCI1DwdlPoYffNjV2ubYJEw8Ufbk_Kc6RPOx4t0dzE5IFxL4MpMLl
    [5] => fzL5VgZIflE:APA91bEvGp9M6k3KujY0xlIqhk_gB5tPNde1E-lPpoVi0pvgIOhBLQh80ciFfo-JvGdOenb9rHpKY6YdDaCQiFnv4sf0IXcUeQBdRfQMo7Q8nLsmiULaChjYmj8RC1-nf4l6Rx5B-PUU
)

ERROR - 2019-09-28 14:59:58 --> Severity: error --> Exception: Call to undefined function curl_init() /var/www/html/School19/application/controllers/Welcome.php 2022
ERROR - 2019-09-28 15:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 15:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 15:00:27 --> Total execution time: 0.0122
ERROR - 2019-09-28 15:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-28 15:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:27 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-28 15:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 15:00:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 15:00:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 15:00:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 15:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 15:00:33 --> Total execution time: 0.0046
ERROR - 2019-09-28 15:00:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 15:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 15:00:35 --> Total execution time: 0.0061
ERROR - 2019-09-28 15:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 15:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 15:00:36 --> Total execution time: 0.1344
ERROR - 2019-09-28 15:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 15:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 15:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 15:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 15:00:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 15:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 15:00:41 --> Total execution time: 0.0025
ERROR - 2019-09-28 15:00:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 15:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 15:00:43 --> Total execution time: 0.0050
ERROR - 2019-09-28 15:00:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-28 15:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-28 15:00:46 --> Total execution time: 0.1193
ERROR - 2019-09-28 15:00:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 15:00:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-28 15:00:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-28 15:00:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-28 15:00:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-28 15:00:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-28 15:00:46 --> 404 Page Not Found: Welcome/js
