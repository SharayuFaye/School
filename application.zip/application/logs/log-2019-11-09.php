<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-09 18:35:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:35:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:35:39 --> Total execution time: 0.7750
ERROR - 2019-11-09 18:35:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-09 18:35:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:35:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:35:47 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:35:47 --> admin :: admin
DEBUG - 2019-11-09 18:35:47 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-09 18:35:48 --> Total execution time: 0.8681
ERROR - 2019-11-09 18:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:35:59 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:35:59 --> admin :: admin
DEBUG - 2019-11-09 18:35:59 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-09 18:35:59 --> Total execution time: 0.0190
ERROR - 2019-11-09 18:37:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:37:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:37:01 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:37:01 --> admin :: admin
DEBUG - 2019-11-09 18:37:01 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-09 18:37:01 --> Total execution time: 0.0309
ERROR - 2019-11-09 18:37:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:37:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:37:06 --> Total execution time: 0.0043
ERROR - 2019-11-09 18:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:37:13 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:37:13 --> disha :: Disha@123
DEBUG - 2019-11-09 18:37:13 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-09 18:37:13 --> Total execution time: 0.0823
ERROR - 2019-11-09 18:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:38:30 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:38:30 --> disha :: Disha@123
DEBUG - 2019-11-09 18:38:30 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-09 18:38:30 --> Total execution time: 0.0395
ERROR - 2019-11-09 18:38:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:38:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-09 18:38:31 --> 404 Page Not Found: Localhost/user_guide
ERROR - 2019-11-09 18:38:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:38:53 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:38:53 --> disha :: Disha@123
DEBUG - 2019-11-09 18:38:53 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-09 18:38:53 --> Total execution time: 0.0293
ERROR - 2019-11-09 18:39:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:39:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:39:15 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:39:15 --> disha :: Disha@123
DEBUG - 2019-11-09 18:39:15 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-09 18:39:15 --> Total execution time: 0.0383
ERROR - 2019-11-09 18:39:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-09 18:39:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:39:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:39:26 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:39:26 --> disha :: Disha@123
DEBUG - 2019-11-09 18:39:26 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-09 18:39:26 --> Total execution time: 0.0435
ERROR - 2019-11-09 18:39:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-09 18:39:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-09 18:39:44 --> No URI present. Default controller set.
DEBUG - 2019-11-09 18:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-09 18:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-09 18:39:44 --> disha :: Disha@123
DEBUG - 2019-11-09 18:39:44 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-09 18:39:44 --> Total execution time: 0.0354
ERROR - 2019-11-09 18:39:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
