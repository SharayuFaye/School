<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-30 10:01:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:01:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 10:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 10:01:17 --> Total execution time: 7.3858
ERROR - 2019-09-30 10:02:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:02:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:02:26 --> No URI present. Default controller set.
DEBUG - 2019-09-30 10:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 10:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 10:02:28 --> Total execution time: 2.4698
ERROR - 2019-09-30 10:02:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:02:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 10:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 10:02:53 --> Total execution time: 0.8264
ERROR - 2019-09-30 10:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:02:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 10:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:02:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 10:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:02:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 10:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:02:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 10:31:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 10:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 10:31:53 --> Total execution time: 0.1933
ERROR - 2019-09-30 10:31:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:31:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 10:31:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:31:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 10:31:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:31:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 10:31:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:31:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 10:31:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 10:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 10:31:56 --> Total execution time: 0.1243
ERROR - 2019-09-30 10:31:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:31:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 10:31:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:31:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 10:31:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:31:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 10:31:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 10:31:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 10:54:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 10:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 10:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 10:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 10:54:14 --> Total execution time: 0.0113
ERROR - 2019-09-30 11:27:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:27:48 --> Severity: Compile Error --> Cannot redeclare Welcome::homework() /var/www/html/School19/application/controllers/Welcome.php 2410
ERROR - 2019-09-30 11:27:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:27:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 11:27:57 --> Total execution time: 0.0110
ERROR - 2019-09-30 11:28:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:01 --> No URI present. Default controller set.
DEBUG - 2019-09-30 11:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 11:28:01 --> Total execution time: 0.0167
ERROR - 2019-09-30 11:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:28:07 --> Severity: Notice --> Undefined variable: homework_show /var/www/html/School19/application/views/homework.php 68
ERROR - 2019-09-30 11:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/homework.php 68
DEBUG - 2019-09-30 11:28:07 --> Total execution time: 0.0366
ERROR - 2019-09-30 11:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:28:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:28:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:28:41 --> Severity: Notice --> Undefined variable: homework_show /var/www/html/School19/application/views/homework.php 68
ERROR - 2019-09-30 11:28:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/homework.php 68
DEBUG - 2019-09-30 11:28:41 --> Total execution time: 0.0052
ERROR - 2019-09-30 11:28:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:28:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:28:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:28:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:28:57 --> Severity: Notice --> Undefined variable: homework_show /var/www/html/School19/application/views/homework.php 68
ERROR - 2019-09-30 11:28:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/homework.php 68
DEBUG - 2019-09-30 11:28:57 --> Total execution time: 0.0073
ERROR - 2019-09-30 11:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 11:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:57 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-09-30 11:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:28:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 11:28:58 --> Total execution time: 0.0271
ERROR - 2019-09-30 11:28:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:28:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:28:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:28:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:28:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:29:01 --> Severity: Notice --> Undefined variable: homework_show /var/www/html/School19/application/views/homework.php 68
ERROR - 2019-09-30 11:29:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/homework.php 68
DEBUG - 2019-09-30 11:29:01 --> Total execution time: 0.0062
ERROR - 2019-09-30 11:29:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 11:29:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 11:29:02 --> Total execution time: 0.0074
ERROR - 2019-09-30 11:29:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:29:03 --> Severity: Notice --> Undefined variable: homework_show /var/www/html/School19/application/views/homework.php 68
ERROR - 2019-09-30 11:29:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/homework.php 68
DEBUG - 2019-09-30 11:29:03 --> Total execution time: 0.0068
ERROR - 2019-09-30 11:29:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:29:30 --> Severity: Notice --> Undefined variable: homework_show /var/www/html/School19/application/views/homework.php 68
ERROR - 2019-09-30 11:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/homework.php 68
DEBUG - 2019-09-30 11:29:30 --> Total execution time: 0.0075
ERROR - 2019-09-30 11:29:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:29:33 --> Severity: Notice --> Undefined variable: homework_show /var/www/html/School19/application/views/homework.php 68
ERROR - 2019-09-30 11:29:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/homework.php 68
DEBUG - 2019-09-30 11:29:33 --> Total execution time: 0.0073
ERROR - 2019-09-30 11:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 11:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:33 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-09-30 11:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 11:29:34 --> Total execution time: 0.0066
ERROR - 2019-09-30 11:29:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 11:29:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:34 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 11:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:34 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:34 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:29:36 --> Severity: Notice --> Undefined variable: homework_show /var/www/html/School19/application/views/homework.php 68
ERROR - 2019-09-30 11:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/homework.php 68
DEBUG - 2019-09-30 11:29:36 --> Total execution time: 0.0073
ERROR - 2019-09-30 11:29:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:29:58 --> Severity: Notice --> Undefined variable: students_show /var/www/html/School19/application/views/leaves.php 107
ERROR - 2019-09-30 11:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/leaves.php 107
DEBUG - 2019-09-30 11:29:58 --> Total execution time: 0.0140
ERROR - 2019-09-30 11:29:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:29:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:29:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:29:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:30:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:30:44 --> Severity: Notice --> Undefined variable: students_show /var/www/html/School19/application/views/leaves.php 84
ERROR - 2019-09-30 11:30:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/leaves.php 84
DEBUG - 2019-09-30 11:30:44 --> Total execution time: 0.0062
ERROR - 2019-09-30 11:30:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:30:44 --> UTF-8 Support Enabled
ERROR - 2019-09-30 11:30:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:30:44 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-09-30 11:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:30:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:30:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:30:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:30:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:30:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:48:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:48:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:48:11 --> Severity: Notice --> Undefined property: Welcome::$m_attendances /var/www/html/School19/application/controllers/Welcome.php 2467
ERROR - 2019-09-30 11:48:11 --> Severity: error --> Exception: Call to a member function leaves_show_id() on null /var/www/html/School19/application/controllers/Welcome.php 2467
ERROR - 2019-09-30 11:52:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:52:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:52:00 --> Severity: Warning --> Missing argument 1 for m_attendances::leaves_show_id(), called in /var/www/html/School19/application/controllers/Welcome.php on line 2458 and defined /var/www/html/School19/application/models/M_attendances.php 37
ERROR - 2019-09-30 11:52:00 --> Severity: Notice --> Undefined variable: teacher_id /var/www/html/School19/application/models/M_attendances.php 44
ERROR - 2019-09-30 11:52:00 --> Query error: Unknown column 'l.approver' in 'on clause' - Invalid query: SELECT `s`.`class_id`, `s`.`sections`, `s`.`id` as `sec`, `l`.*, `st`.`student_name`
FROM `sections` `s`
LEFT JOIN `teachers` `t` ON `l`.`approver` = `t`.`id`
LEFT JOIN `students` `st` ON `st`.`sections_id` = `s`.`id`
LEFT JOIN `leaves` `l` ON `l`.`student_id` = `st`.`id`
WHERE `l`.`approver` IS NULL
ERROR - 2019-09-30 11:52:00 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 46
ERROR - 2019-09-30 11:52:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:52:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:52:42 --> Query error: Unknown column 'l.approver' in 'on clause' - Invalid query: SELECT `s`.`class_id`, `s`.`sections`, `s`.`id` as `sec`, `l`.*, `st`.`student_name`
FROM `sections` `s`
LEFT JOIN `teachers` `t` ON `l`.`approver` = `t`.`id`
LEFT JOIN `students` `st` ON `st`.`sections_id` = `s`.`id`
LEFT JOIN `leaves` `l` ON `l`.`student_id` = `st`.`id`
WHERE `l`.`approver` = '110'
ERROR - 2019-09-30 11:52:42 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 46
ERROR - 2019-09-30 11:53:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 11:53:51 --> Total execution time: 0.0064
ERROR - 2019-09-30 11:53:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:53:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:53:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:53:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:53:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:53:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 11:53:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 11:53:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 11:57:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 11:57:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 11:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 11:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 12:03:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 12:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:03:11 --> Total execution time: 0.0050
ERROR - 2019-09-30 12:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:03:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:03:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:03:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:03:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
ERROR - 2019-09-30 12:03:49 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/leaves.php 77
DEBUG - 2019-09-30 12:03:49 --> Total execution time: 0.0072
ERROR - 2019-09-30 12:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:49 --> UTF-8 Support Enabled
ERROR - 2019-09-30 12:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:03:49 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 12:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:03:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:03:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:03:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:03:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:04:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:04:04 --> Total execution time: 0.0063
ERROR - 2019-09-30 12:04:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 12:04:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:04 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:04:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:04:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:04:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:04:29 --> Total execution time: 0.0067
ERROR - 2019-09-30 12:04:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 12:04:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:29 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-09-30 12:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:04:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:04:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:04:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:04:38 --> Total execution time: 0.0053
ERROR - 2019-09-30 12:04:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:04:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:04:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:04:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:04:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:05:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:05:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:05:11 --> Total execution time: 0.0040
ERROR - 2019-09-30 12:15:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:15:47 --> Total execution time: 0.0064
ERROR - 2019-09-30 12:15:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 12:15:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:15:47 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 12:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:15:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:15:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:15:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:15:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:15:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:16:10 --> Total execution time: 0.0040
ERROR - 2019-09-30 12:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:16:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:16:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:16:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:16:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:18:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:18:05 --> Total execution time: 0.0044
ERROR - 2019-09-30 12:18:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:18:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 12:18:05 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:18:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:18:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:18:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:18:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:18:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:19:03 --> Total execution time: 0.0048
ERROR - 2019-09-30 12:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:19:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:19:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:19:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:19:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:19:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:19:32 --> Total execution time: 0.0055
ERROR - 2019-09-30 12:19:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 12:19:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:19:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:19:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:19:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:19:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:19:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:19:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:19:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:19:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:19:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:56:07 --> Total execution time: 0.0039
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:56:07 --> Total execution time: 0.0058
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:56:07 --> Total execution time: 0.0047
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:56:52 --> Total execution time: 0.0054
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:56:53 --> Total execution time: 0.0037
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:56:53 --> Total execution time: 0.0053
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:56:53 --> Total execution time: 0.0042
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:56:54 --> Total execution time: 0.0033
ERROR - 2019-09-30 12:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:56:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:57:44 --> Total execution time: 0.0082
ERROR - 2019-09-30 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:57:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:57:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:57:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:57:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 12:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 12:57:44 --> Total execution time: 0.0064
ERROR - 2019-09-30 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 12:57:44 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-09-30 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:57:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 12:57:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:57:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 12:57:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 12:57:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 12:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 12:57:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:01:00 --> Total execution time: 0.0057
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:01:00 --> Total execution time: 0.0033
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:01:00 --> Total execution time: 0.0040
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:01:00 --> Total execution time: 0.0039
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:01:01 --> Total execution time: 0.0031
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:01:01 --> Total execution time: 0.0035
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:01:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:49:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:49:03 --> Total execution time: 0.0065
ERROR - 2019-09-30 13:49:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 13:49:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:03 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-09-30 13:49:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:49:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:49:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:49:03 --> Total execution time: 0.0053
ERROR - 2019-09-30 13:49:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:49:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:49:04 --> Total execution time: 0.0069
ERROR - 2019-09-30 13:49:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:49:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:49:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:49:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:49:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 13:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 13:49:15 --> Total execution time: 0.0041
ERROR - 2019-09-30 13:49:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:49:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 13:49:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 13:49:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 13:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 13:49:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:06:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:06:10 --> Total execution time: 0.0120
ERROR - 2019-09-30 14:06:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:06:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:06:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:06:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:06:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:06:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:06:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:06:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:08:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:08:01 --> Total execution time: 0.0042
ERROR - 2019-09-30 14:08:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 14:08:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:08:01 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:08:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:08:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:08:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:08:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:08:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:08:36 --> Total execution time: 0.0056
ERROR - 2019-09-30 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:08:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:08:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:08:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:08:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:09:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:09:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:09:54 --> Total execution time: 0.0063
ERROR - 2019-09-30 14:09:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 14:09:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:09:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:09:54 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 14:09:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:09:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:09:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:09:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:09:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:09:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:09:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:09:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:11:55 --> Total execution time: 0.0083
ERROR - 2019-09-30 14:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:11:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:11:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:11:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:11:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:11:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:11:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:11:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:11:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:14:00 --> Total execution time: 0.0059
ERROR - 2019-09-30 14:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:14:00 --> Total execution time: 0.0040
ERROR - 2019-09-30 14:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:14:01 --> Total execution time: 0.0067
ERROR - 2019-09-30 14:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:14:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:14:04 --> Total execution time: 0.0181
ERROR - 2019-09-30 14:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:14:25 --> Total execution time: 0.0056
ERROR - 2019-09-30 14:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 14:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:25 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 14:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:14:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:14:26 --> Total execution time: 0.0053
ERROR - 2019-09-30 14:14:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:14:39 --> Total execution time: 0.0056
ERROR - 2019-09-30 14:14:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:14:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:14:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:14:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:15:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:15:09 --> Total execution time: 0.0040
ERROR - 2019-09-30 14:15:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:15:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:15:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:15:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:15:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:15:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:15:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:15:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:15:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:15:11 --> Total execution time: 0.0030
ERROR - 2019-09-30 14:15:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:15:55 --> Total execution time: 0.0093
ERROR - 2019-09-30 14:15:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 14:15:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:15:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:15:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:15:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:15:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:15:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:15:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:15:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:15:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:15:57 --> Total execution time: 0.0026
ERROR - 2019-09-30 14:16:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:17 --> Total execution time: 0.0055
ERROR - 2019-09-30 14:16:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:16:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:16:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:16:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:16:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:16:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:16:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:16:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:16:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:21 --> Total execution time: 0.0025
ERROR - 2019-09-30 14:16:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:23 --> Total execution time: 0.0020
ERROR - 2019-09-30 14:16:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:25 --> Total execution time: 0.0028
ERROR - 2019-09-30 14:16:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:25 --> Total execution time: 0.0028
ERROR - 2019-09-30 14:16:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:25 --> Total execution time: 0.0035
ERROR - 2019-09-30 14:16:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:25 --> Total execution time: 0.0046
ERROR - 2019-09-30 14:16:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:25 --> Total execution time: 0.0025
ERROR - 2019-09-30 14:16:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:26 --> Total execution time: 0.0022
ERROR - 2019-09-30 14:16:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:16:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:16:47 --> Total execution time: 0.0028
ERROR - 2019-09-30 14:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:18:00 --> Total execution time: 0.0069
ERROR - 2019-09-30 14:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 14:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:18:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:18:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:18:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:18:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:18:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:18:02 --> Total execution time: 0.0033
ERROR - 2019-09-30 14:18:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:18:03 --> Total execution time: 0.0024
ERROR - 2019-09-30 14:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:18:04 --> Total execution time: 0.0040
ERROR - 2019-09-30 14:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:18:04 --> Total execution time: 0.0024
ERROR - 2019-09-30 14:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:18:04 --> Total execution time: 0.0051
ERROR - 2019-09-30 14:18:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:18:16 --> Total execution time: 0.0106
ERROR - 2019-09-30 14:18:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:18:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:18:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:18:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:18:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:18:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:18:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:18:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:18:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:18:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:18:18 --> Total execution time: 0.0025
ERROR - 2019-09-30 14:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:19:35 --> Total execution time: 0.0044
ERROR - 2019-09-30 14:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:19:35 --> UTF-8 Support Enabled
ERROR - 2019-09-30 14:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:19:35 --> UTF-8 Support Enabled
ERROR - 2019-09-30 14:19:35 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 14:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:19:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:19:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:19:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:19:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:19:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:19:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:19:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:19:37 --> Total execution time: 0.0032
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:20:05 --> Total execution time: 0.0060
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:20:05 --> Total execution time: 0.0036
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:05 --> 404 Page Not Found: Js/examples
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:20:05 --> Total execution time: 0.0031
ERROR - 2019-09-30 14:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:20:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:20:32 --> Total execution time: 0.0046
ERROR - 2019-09-30 14:20:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:32 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:32 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:20:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:32 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:32 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:20:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:20:36 --> Total execution time: 0.0737
ERROR - 2019-09-30 14:20:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:20:47 --> Total execution time: 0.0035
ERROR - 2019-09-30 14:20:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:20:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:20:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:20:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:20:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:21:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:21:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:21:20 --> Total execution time: 0.0041
ERROR - 2019-09-30 14:21:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:21:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:21:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:21:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:21:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:21:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:21:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:21:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:21:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:21:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:21:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:21:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:21:23 --> Total execution time: 0.1459
ERROR - 2019-09-30 14:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:25:01 --> Total execution time: 0.0135
ERROR - 2019-09-30 14:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:25:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:25:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:25:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:25:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:25:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:25:04 --> Total execution time: 0.0509
ERROR - 2019-09-30 14:25:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:25:54 --> Total execution time: 0.0099
ERROR - 2019-09-30 14:25:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:25:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:25:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:25:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:25:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:25:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:25:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:25:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:25:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:25:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:26:08 --> Total execution time: 0.0034
ERROR - 2019-09-30 14:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:26:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:26:11 --> Total execution time: 0.0473
ERROR - 2019-09-30 14:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:26:15 --> Total execution time: 0.0037
ERROR - 2019-09-30 14:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:26:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:26:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:26:30 --> Total execution time: 0.0689
ERROR - 2019-09-30 14:26:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:26:33 --> Total execution time: 0.0058
ERROR - 2019-09-30 14:26:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:26:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:26:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:26:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:26:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:27:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:27:35 --> Total execution time: 0.0034
ERROR - 2019-09-30 14:27:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:27:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:27:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:27:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:27:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:27:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:27:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:27:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:27:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:27:42 --> Total execution time: 0.0480
ERROR - 2019-09-30 14:27:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:27:42 --> Total execution time: 0.0033
ERROR - 2019-09-30 14:27:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:27:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:27:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:27:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:27:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:27:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:27:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:27:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:28:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:28:53 --> Total execution time: 0.0040
ERROR - 2019-09-30 14:28:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:28:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:28:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:28:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:28:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:28:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:28:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:28:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:28:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:28:56 --> Total execution time: 0.0637
ERROR - 2019-09-30 14:28:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:28:56 --> Total execution time: 0.0035
ERROR - 2019-09-30 14:28:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:28:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:28:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:28:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:28:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:28:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:28:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:28:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 14:32:35 --> Severity: Notice --> Undefined variable: success_msg /var/www/html/School19/application/views/leaves.php 35
DEBUG - 2019-09-30 14:32:35 --> Total execution time: 0.0043
ERROR - 2019-09-30 14:32:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 14:32:37 --> Severity: Notice --> Undefined variable: success_msg /var/www/html/School19/application/views/leaves.php 35
DEBUG - 2019-09-30 14:32:37 --> Total execution time: 0.0049
ERROR - 2019-09-30 14:32:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 14:32:38 --> Severity: Notice --> Undefined variable: success_msg /var/www/html/School19/application/views/leaves.php 35
DEBUG - 2019-09-30 14:32:38 --> Total execution time: 0.0040
ERROR - 2019-09-30 14:32:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 14:32:39 --> Severity: Notice --> Undefined variable: success_msg /var/www/html/School19/application/views/leaves.php 35
DEBUG - 2019-09-30 14:32:39 --> Total execution time: 0.0053
ERROR - 2019-09-30 14:32:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-30 14:32:40 --> Severity: Notice --> Undefined variable: success_msg /var/www/html/School19/application/views/leaves.php 35
DEBUG - 2019-09-30 14:32:40 --> Total execution time: 0.0046
ERROR - 2019-09-30 14:32:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:32:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:32:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:32:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:33:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:33:01 --> Total execution time: 0.0039
ERROR - 2019-09-30 14:33:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:33:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:33:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:33:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:33:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:33:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:33:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:33:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:33:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:33:03 --> Total execution time: 0.0733
ERROR - 2019-09-30 14:33:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:33:03 --> Total execution time: 0.0040
ERROR - 2019-09-30 14:33:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:33:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:33:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:33:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:33:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:33:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:33:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:33:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:34:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:34:43 --> Total execution time: 0.0571
ERROR - 2019-09-30 14:34:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:34:43 --> Total execution time: 0.0035
ERROR - 2019-09-30 14:34:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:34:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:34:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:34:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:34:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:34:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:34:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:34:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:35:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:35:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:35:48 --> Total execution time: 0.0552
ERROR - 2019-09-30 14:35:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:35:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:35:48 --> Total execution time: 0.0042
ERROR - 2019-09-30 14:35:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:35:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:35:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:35:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:35:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:35:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:35:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:35:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:35:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:35:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:39:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:39:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:39:06 --> Total execution time: 0.0084
ERROR - 2019-09-30 14:39:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:39:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:39:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:39:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:39:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:39:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:39:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:39:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:39:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:39:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:39:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:39:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:40:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:40:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:40:16 --> Total execution time: 0.0083
ERROR - 2019-09-30 14:40:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-09-30 14:40:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:40:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:40:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:40:16 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-09-30 14:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:40:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:40:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:40:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:40:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-30 14:40:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:40:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-30 14:40:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-30 14:43:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-09-30 14:43:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-30 14:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-30 14:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-30 14:43:08 --> Total execution time: 0.0102
