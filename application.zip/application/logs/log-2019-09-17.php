<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-17 04:56:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 04:56:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 04:56:55 --> No URI present. Default controller set.
DEBUG - 2019-09-17 04:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 04:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 04:56:55 --> Total execution time: 0.0349
ERROR - 2019-09-17 04:57:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 04:57:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 04:57:37 --> No URI present. Default controller set.
DEBUG - 2019-09-17 04:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 04:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 04:57:38 --> Total execution time: 0.0113
ERROR - 2019-09-17 05:23:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:23:14 --> Total execution time: 0.0062
ERROR - 2019-09-17 05:23:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 05:23:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:23:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 05:23:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:23:29 --> Total execution time: 0.0046
ERROR - 2019-09-17 05:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 05:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:23:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:23:44 --> Total execution time: 0.0036
ERROR - 2019-09-17 05:23:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 05:23:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:23:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 05:23:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:23:47 --> Total execution time: 0.0071
ERROR - 2019-09-17 05:23:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:23:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 05:23:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:23:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:23:50 --> Total execution time: 0.0050
ERROR - 2019-09-17 05:23:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:23:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 05:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:23:53 --> Total execution time: 0.0128
ERROR - 2019-09-17 05:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 05:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:23:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:36:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:36:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:36:39 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 05:36:39 --> Total execution time: 0.0044
ERROR - 2019-09-17 05:36:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:36:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:36:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 05:36:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:36:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:36:47 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 05:36:47 --> Total execution time: 0.0048
ERROR - 2019-09-17 05:36:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:36:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:36:59 --> Total execution time: 0.0021
ERROR - 2019-09-17 05:36:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 05:37:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:37:09 --> No URI present. Default controller set.
DEBUG - 2019-09-17 05:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:37:09 --> Total execution time: 0.0046
ERROR - 2019-09-17 05:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 05:37:13 --> Total execution time: 0.0028
ERROR - 2019-09-17 05:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:37:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 05:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:37:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:37:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:37:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 05:37:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 05:37:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:37:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:37:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:37:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:37:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:37:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:37:19 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 05:37:19 --> Total execution time: 0.0050
ERROR - 2019-09-17 05:40:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:40:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:40:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:40:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:40:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:40:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:40:41 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 05:40:41 --> Total execution time: 0.0047
ERROR - 2019-09-17 05:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:40:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 05:40:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 05:40:57 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 05:40:57 --> Total execution time: 0.0044
ERROR - 2019-09-17 06:02:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 06:02:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 06:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 06:02:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 06:02:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 06:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 06:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 06:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 06:02:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 06:02:55 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 06:02:55 --> Total execution time: 0.0045
ERROR - 2019-09-17 06:07:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 06:07:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 06:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 06:07:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 06:07:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 06:07:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 06:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 06:07:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 06:07:56 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 06:07:56 --> Total execution time: 0.0047
ERROR - 2019-09-17 06:52:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 06:52:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 06:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 06:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 06:52:19 --> Total execution time: 0.0043
ERROR - 2019-09-17 07:14:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 07:14:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 07:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 07:14:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 07:14:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 07:14:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 07:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 07:14:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 07:14:54 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 07:14:54 --> Total execution time: 0.0046
ERROR - 2019-09-17 07:15:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 07:15:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 07:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 07:15:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 07:15:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 07:15:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 07:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 07:15:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 07:15:22 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 07:15:22 --> Total execution time: 0.0044
ERROR - 2019-09-17 08:31:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:31:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:31:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:31:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:31:51 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:31:51 --> Total execution time: 0.0045
ERROR - 2019-09-17 08:31:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:31:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:31:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:31:56 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:31:56 --> Total execution time: 0.0045
ERROR - 2019-09-17 08:32:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:32:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:32:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:32:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:32:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:32:04 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:32:04 --> Total execution time: 0.0044
ERROR - 2019-09-17 08:32:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:32:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:32:09 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:32:09 --> Total execution time: 0.0044
ERROR - 2019-09-17 08:32:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:32:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:32:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:32:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:32:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:32:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:32:18 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:32:18 --> Total execution time: 0.0044
ERROR - 2019-09-17 08:32:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:32:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:32:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:32:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:32:32 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:32:32 --> Total execution time: 0.0050
ERROR - 2019-09-17 08:33:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:33:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:33:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:33:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:33:28 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:33:28 --> Total execution time: 0.0043
ERROR - 2019-09-17 08:33:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:33:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:33:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:33:32 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:33:32 --> Total execution time: 0.0046
ERROR - 2019-09-17 08:46:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:46:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:46:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:46:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:46:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:46:35 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:46:35 --> Total execution time: 0.0046
ERROR - 2019-09-17 08:46:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:46:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:46:39 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 08:46:39 --> Total execution time: 0.0045
ERROR - 2019-09-17 08:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:56:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:56:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:56:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:56:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 08:56:53 --> Total execution time: 0.0045
ERROR - 2019-09-17 08:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:56:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:56:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:56:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 08:56:54 --> Total execution time: 0.0043
ERROR - 2019-09-17 08:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:56:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 08:56:54 --> Total execution time: 0.0041
ERROR - 2019-09-17 08:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:57:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:57:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:57:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:57:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 08:57:42 --> Total execution time: 0.0045
ERROR - 2019-09-17 08:57:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:57:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:57:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:57:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:57:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:57:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 08:57:43 --> Total execution time: 0.0025
ERROR - 2019-09-17 08:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:57:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 08:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 08:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 08:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 08:57:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 08:57:53 --> Total execution time: 0.0042
ERROR - 2019-09-17 09:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:01:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:01:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 09:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:01:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:01:29 --> Total execution time: 0.0045
ERROR - 2019-09-17 09:01:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:01:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:01:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:01:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:01:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:01:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:01:33 --> Total execution time: 0.0044
ERROR - 2019-09-17 09:01:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:01:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:01:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:01:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 09:01:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:01:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:01:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:01:45 --> Total execution time: 0.0044
ERROR - 2019-09-17 09:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:02:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:02:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:02:00 --> Total execution time: 0.0041
ERROR - 2019-09-17 09:02:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:02:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:02:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:02:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:02:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:02:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:02:07 --> Total execution time: 0.0038
ERROR - 2019-09-17 09:02:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:02:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:02:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:02:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:02:19 --> Total execution time: 0.0042
ERROR - 2019-09-17 09:20:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:20:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:20:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:20:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:20:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:20:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:20:49 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 09:20:49 --> Total execution time: 0.0044
ERROR - 2019-09-17 09:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:25:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:25:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:25:46 --> Total execution time: 0.0042
ERROR - 2019-09-17 09:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:25:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:25:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:25:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:25:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:25:47 --> Total execution time: 0.0026
ERROR - 2019-09-17 09:26:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:26:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:26:00 --> Total execution time: 0.0033
ERROR - 2019-09-17 09:26:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:26:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:26:04 --> Total execution time: 0.0024
ERROR - 2019-09-17 09:26:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:26:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:26:07 --> Total execution time: 0.0024
ERROR - 2019-09-17 09:26:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:26:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:26:29 --> Total execution time: 0.0042
ERROR - 2019-09-17 09:26:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:26:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:26:45 --> Total execution time: 0.0049
ERROR - 2019-09-17 09:26:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:26:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:26:46 --> Total execution time: 0.0043
ERROR - 2019-09-17 09:26:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:26:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:26:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:26:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:26:59 --> Total execution time: 0.0048
ERROR - 2019-09-17 09:27:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:27:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:27:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:27:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:27:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:27:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:27:06 --> Total execution time: 0.0031
ERROR - 2019-09-17 09:27:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:27:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:27:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:27:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:27:08 --> Total execution time: 0.0030
ERROR - 2019-09-17 09:27:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:27:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:27:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:27:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:27:26 --> Total execution time: 0.0032
ERROR - 2019-09-17 09:27:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:27:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:27:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:27:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:27:30 --> Total execution time: 0.0029
ERROR - 2019-09-17 09:36:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:36:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:36:29 --> Total execution time: 0.0044
ERROR - 2019-09-17 09:36:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:36:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:36:30 --> Total execution time: 0.0026
ERROR - 2019-09-17 09:36:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:36:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:36:32 --> Total execution time: 0.0030
ERROR - 2019-09-17 09:36:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:36:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 09:36:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:36:49 --> Total execution time: 0.0030
ERROR - 2019-09-17 09:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:36:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:36:52 --> Total execution time: 0.0026
ERROR - 2019-09-17 09:37:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:37:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:37:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:37:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:37:09 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 09:37:09 --> Total execution time: 0.0044
ERROR - 2019-09-17 09:37:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:37:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:37:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:37:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:37:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:37:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:37:57 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 09:37:57 --> Total execution time: 0.0045
ERROR - 2019-09-17 09:39:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:39:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:39:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:39:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:39:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:39:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:39:37 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-17 09:39:37 --> Total execution time: 0.0045
ERROR - 2019-09-17 09:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:58:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:58:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:58:44 --> Total execution time: 0.0044
ERROR - 2019-09-17 09:58:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:58:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 09:58:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 09:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 09:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 09:58:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 09:58:45 --> Total execution time: 0.0043
ERROR - 2019-09-17 10:12:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:12:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:12:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:12:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:12:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:12:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:12:05 --> Total execution time: 0.0045
ERROR - 2019-09-17 10:12:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:12:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:12:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:12:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:12:06 --> Total execution time: 0.0043
ERROR - 2019-09-17 10:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:26:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:26:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:26:25 --> Total execution time: 0.0041
ERROR - 2019-09-17 10:26:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:26:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:26:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:26:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:26:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:26:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 10:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:26:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:26:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:26:27 --> Total execution time: 0.0067
DEBUG - 2019-09-17 10:26:27 --> Total execution time: 0.0072
ERROR - 2019-09-17 10:35:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:35:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:35:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:35:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:35:35 --> Total execution time: 0.0044
ERROR - 2019-09-17 10:35:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:35:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:35:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:35:40 --> Total execution time: 0.0044
ERROR - 2019-09-17 10:38:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:38:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:38:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:38:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:38:13 --> Total execution time: 0.0044
ERROR - 2019-09-17 10:38:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:38:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:38:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:38:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:38:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:38:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:38:55 --> Total execution time: 0.0040
ERROR - 2019-09-17 10:39:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:39:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:39:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:39:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:39:18 --> Total execution time: 0.0052
ERROR - 2019-09-17 10:39:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:39:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:39:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:39:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:39:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:39:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:39:21 --> Total execution time: 0.0026
ERROR - 2019-09-17 10:39:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:39:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:39:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:39:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:39:24 --> Total execution time: 0.0028
ERROR - 2019-09-17 10:40:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:40:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:40:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:40:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:40:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:40:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:40:09 --> Total execution time: 0.0040
ERROR - 2019-09-17 10:40:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:40:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:40:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:40:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:40:13 --> Total execution time: 0.0043
ERROR - 2019-09-17 10:40:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:40:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:40:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:40:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:40:41 --> Total execution time: 0.0035
ERROR - 2019-09-17 10:48:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:48:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:48:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:48:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:48:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:48:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:48:38 --> Total execution time: 0.0038
ERROR - 2019-09-17 10:48:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:48:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:48:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:48:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:48:50 --> Total execution time: 0.0045
ERROR - 2019-09-17 10:48:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:48:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:48:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:48:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:48:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:48:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:48:52 --> Total execution time: 0.0025
ERROR - 2019-09-17 10:49:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:49:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:49:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:49:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:49:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:49:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:49:05 --> Total execution time: 0.0025
ERROR - 2019-09-17 10:59:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:59:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:59:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:59:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:59:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:59:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:59:20 --> Total execution time: 0.0043
ERROR - 2019-09-17 10:59:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:59:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:59:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 10:59:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 10:59:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 10:59:21 --> Total execution time: 0.0043
ERROR - 2019-09-17 11:01:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:01:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:01:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:01:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:01:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:01:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:01:26 --> Total execution time: 0.0042
ERROR - 2019-09-17 11:01:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:01:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:01:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:01:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:01:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:01:27 --> Total execution time: 0.0024
ERROR - 2019-09-17 11:01:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:01:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:01:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:01:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:01:39 --> Total execution time: 0.0043
ERROR - 2019-09-17 11:05:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:05:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:05:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:05:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:05:28 --> Total execution time: 0.0043
ERROR - 2019-09-17 11:05:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:05:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:05:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:05:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:05:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:05:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:05:29 --> Total execution time: 0.0042
ERROR - 2019-09-17 11:05:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:05:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:05:29 --> Total execution time: 0.0038
ERROR - 2019-09-17 11:11:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:11:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:11:20 --> No URI present. Default controller set.
DEBUG - 2019-09-17 11:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:11:20 --> Total execution time: 0.0018
ERROR - 2019-09-17 11:11:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:11:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:11:28 --> No URI present. Default controller set.
DEBUG - 2019-09-17 11:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:11:28 --> Total execution time: 0.0047
ERROR - 2019-09-17 11:11:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:11:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:11:52 --> Total execution time: 0.0049
ERROR - 2019-09-17 11:11:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:11:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:11:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:11:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 11:11:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:11:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:11:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:11:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 11:11:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:11:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:11:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 11:11:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:11:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:11:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 11:12:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:12:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:12:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:12:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:12:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:12:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:12:50 --> Total execution time: 0.0041
ERROR - 2019-09-17 11:12:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:12:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:12:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:12:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:12:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:12:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:12:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:12:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:12:53 --> Total execution time: 0.0042
ERROR - 2019-09-17 11:12:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:12:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:12:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:12:54 --> Total execution time: 0.0042
ERROR - 2019-09-17 11:13:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:13:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:13:00 --> Total execution time: 0.0040
ERROR - 2019-09-17 11:13:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:13:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:13:14 --> Total execution time: 0.0048
ERROR - 2019-09-17 11:13:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:13:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:13:16 --> Total execution time: 0.0026
ERROR - 2019-09-17 11:13:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:13:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:13:18 --> Total execution time: 0.0027
ERROR - 2019-09-17 11:13:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:13:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:13:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:13:32 --> Severity: Notice --> Undefined index: class /var/www/html/school/application/controllers/Api.php 1124
DEBUG - 2019-09-17 11:13:32 --> Total execution time: 0.0026
ERROR - 2019-09-17 11:18:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:18:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:18:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:18:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:18:18 --> Total execution time: 0.0043
ERROR - 2019-09-17 11:25:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:25:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:25:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:25:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:25:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:25:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:25:36 --> Total execution time: 0.0039
ERROR - 2019-09-17 11:25:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:25:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:25:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:25:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:25:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:25:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:25:40 --> Total execution time: 0.0043
ERROR - 2019-09-17 11:26:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:26:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:26:24 --> Total execution time: 0.0088
ERROR - 2019-09-17 11:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:26:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:26:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 11:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:26:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:26:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 11:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:26:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:26:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 11:26:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:26:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 11:26:55 --> Severity: error --> Exception: Call to undefined function curl_init() /var/www/html/school/application/controllers/Welcome.php 1956
ERROR - 2019-09-17 11:27:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:27:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:27:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:27:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:27:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:27:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:27:46 --> Total execution time: 0.0107
ERROR - 2019-09-17 11:27:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:27:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:27:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:27:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:27:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:27:49 --> Total execution time: 0.0026
ERROR - 2019-09-17 11:27:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:27:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:27:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:27:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:27:52 --> Total execution time: 0.0027
ERROR - 2019-09-17 11:27:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:27:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:27:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:27:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:27:56 --> Total execution time: 0.0026
ERROR - 2019-09-17 11:28:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:28:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:28:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:28:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:28:03 --> Total execution time: 0.0030
ERROR - 2019-09-17 11:28:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:28:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:28:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:28:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:28:06 --> Query error: Unknown column 'class' in 'field list' - Invalid query: INSERT INTO `attendance` (`attendance`, `class`, `section`, `date`, `teacher_id`, `students_id`, `created_date`, `created_by`, `school_id`) VALUES ('1', '1', '40', '2019-09-17T11:27:51.482Z', '5', '14', '2019-09-17', '110', '3')
DEBUG - 2019-09-17 11:28:06 --> Total execution time: 0.0025
ERROR - 2019-09-17 11:28:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:28:26 --> Total execution time: 0.0017
ERROR - 2019-09-17 11:28:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:30 --> No URI present. Default controller set.
DEBUG - 2019-09-17 11:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:28:30 --> Total execution time: 0.0045
ERROR - 2019-09-17 11:28:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:28:37 --> Total execution time: 0.0039
ERROR - 2019-09-17 11:28:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:28:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 11:28:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:28:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 11:28:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:28:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:28:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 11:30:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:30:46 --> Total execution time: 0.0589
ERROR - 2019-09-17 11:30:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:30:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:30:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:30:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:30:47 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:30:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:32:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 11:32:58 --> Severity: error --> Exception: Call to undefined function curl_init() /var/www/html/school/application/controllers/Welcome.php 1956
ERROR - 2019-09-17 11:32:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:39:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:39:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:39:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:39:06 --> Total execution time: 0.0142
ERROR - 2019-09-17 11:39:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:39:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:39:08 --> Total execution time: 0.0038
ERROR - 2019-09-17 11:39:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:39:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:39:11 --> Total execution time: 0.0028
ERROR - 2019-09-17 11:39:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:39:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:39:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:39:22 --> Total execution time: 0.0030
ERROR - 2019-09-17 11:39:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:39:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:39:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:39:36 --> Total execution time: 0.0038
ERROR - 2019-09-17 11:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:39:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:39:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:39:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:39:40 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-17 11:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1231
ERROR - 2019-09-17 11:39:40 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1241
DEBUG - 2019-09-17 11:39:40 --> Total execution time: 0.0023
ERROR - 2019-09-17 11:41:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:41:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:41:00 --> Total execution time: 0.0355
ERROR - 2019-09-17 11:41:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:41:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:41:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:41:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:41:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:41:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:41:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:41:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 11:41:33 --> Severity: error --> Exception: Call to undefined function curl_init() /var/www/html/school/application/controllers/Welcome.php 1956
ERROR - 2019-09-17 11:41:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:44:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:44:25 --> Total execution time: 0.0052
ERROR - 2019-09-17 11:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:44:28 --> Total execution time: 0.0032
ERROR - 2019-09-17 11:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:44:31 --> Total execution time: 0.0027
ERROR - 2019-09-17 11:44:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:44:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:44:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:44:38 --> Total execution time: 0.0030
ERROR - 2019-09-17 11:44:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:44:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:44:42 --> Total execution time: 0.0028
ERROR - 2019-09-17 11:44:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:44:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:44:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:44:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:44:45 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-17 11:44:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-17 11:44:45 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1241
ERROR - 2019-09-17 11:44:45 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1242
DEBUG - 2019-09-17 11:44:45 --> Total execution time: 0.0024
ERROR - 2019-09-17 11:46:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:46:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:46:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:46:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:46:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:46:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:46:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:46:39 --> Total execution time: 0.0046
ERROR - 2019-09-17 11:46:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:46:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:46:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:46:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:46:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:46:48 --> Total execution time: 0.0047
ERROR - 2019-09-17 11:46:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:46:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:46:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:46:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:46:57 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/school/application/controllers/Api.php 1232
ERROR - 2019-09-17 11:46:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1233
ERROR - 2019-09-17 11:46:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1233
ERROR - 2019-09-17 11:46:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1233
ERROR - 2019-09-17 11:46:57 --> Query error: Unknown column 'class' in 'field list' - Invalid query: INSERT INTO `attendance` (`attendance`, `class`, `section`, `date`, `teacher_id`, `students_id`, `created_date`, `created_by`, `school_id`) VALUES ('1', '1', '40', '2019-09-17T11:44:30.898Z', '5', NULL, '2019-09-17', NULL, NULL)
DEBUG - 2019-09-17 11:46:57 --> Total execution time: 0.0031
ERROR - 2019-09-17 11:47:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:47:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:47:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:47:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:47:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:47:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:47:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:47:57 --> Total execution time: 0.0057
ERROR - 2019-09-17 11:48:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:48:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:48:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:48:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:48:00 --> Total execution time: 0.0051
ERROR - 2019-09-17 11:48:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:48:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:48:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:48:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:48:04 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1232
ERROR - 2019-09-17 11:48:04 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1232
ERROR - 2019-09-17 11:48:04 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1232
ERROR - 2019-09-17 11:48:04 --> Query error: Unknown column 'class' in 'field list' - Invalid query: INSERT INTO `attendance` (`attendance`, `class`, `section`, `date`, `teacher_id`, `students_id`, `created_date`, `created_by`, `school_id`) VALUES ('1', '1', '40', '2019-09-17T11:44:30.898Z', '5', NULL, '2019-09-17', NULL, NULL)
DEBUG - 2019-09-17 11:48:04 --> Total execution time: 0.0046
ERROR - 2019-09-17 11:48:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:48:27 --> Total execution time: 0.0682
ERROR - 2019-09-17 11:48:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:48:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:48:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:48:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:48:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:48:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:48:50 --> Total execution time: 0.0054
ERROR - 2019-09-17 11:48:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:48:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:48:50 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:48:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:48:50 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:48:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:49:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:49:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:49:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:49:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:49:24 --> Total execution time: 0.0134
ERROR - 2019-09-17 11:49:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:49:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:49:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:49:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:49:27 --> Total execution time: 0.0042
ERROR - 2019-09-17 11:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:49:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:49:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:49:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1232
ERROR - 2019-09-17 11:49:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1232
ERROR - 2019-09-17 11:49:31 --> Query error: Unknown column 'class' in 'field list' - Invalid query: INSERT INTO `attendance` (`attendance`, `class`, `section`, `date`, `teacher_id`, `students_id`, `created_date`, `created_by`, `school_id`) VALUES ('1', '1', '40', '2019-09-17T11:44:30.898Z', '5', '13', '2019-09-17', NULL, NULL)
DEBUG - 2019-09-17 11:49:31 --> Total execution time: 0.0035
ERROR - 2019-09-17 11:49:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:49:41 --> Total execution time: 0.0053
ERROR - 2019-09-17 11:49:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:49:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:49:41 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:49:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:49:41 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:51:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:51:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:51:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:51:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:51:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:51:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:51:40 --> Total execution time: 0.0044
ERROR - 2019-09-17 11:51:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:51:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:51:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:51:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:51:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 11:51:48 --> Total execution time: 0.0050
ERROR - 2019-09-17 11:51:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:51:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:51:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:51:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:51:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:51:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 11:51:57 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/school/application/controllers/Api.php 1232
ERROR - 2019-09-17 11:51:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1233
ERROR - 2019-09-17 11:51:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1233
ERROR - 2019-09-17 11:51:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1233
ERROR - 2019-09-17 11:51:57 --> Query error: Unknown column 'class' in 'field list' - Invalid query: INSERT INTO `attendance` (`attendance`, `class`, `section`, `date`, `teacher_id`, `students_id`, `created_date`, `created_by`, `school_id`) VALUES ('1', '1', '40', '2019-09-17T11:44:30.898Z', '5', NULL, '2019-09-17', NULL, NULL)
DEBUG - 2019-09-17 11:51:57 --> Total execution time: 0.0027
ERROR - 2019-09-17 11:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:54:52 --> Total execution time: 0.0661
ERROR - 2019-09-17 11:54:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:54:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:54:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:54:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:54:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:54:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:54:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:54:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:54:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:54:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:55:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:55:17 --> Total execution time: 0.0056
ERROR - 2019-09-17 11:55:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:55:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:55:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:55:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:55:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:55:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-17 11:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:58:12 --> Total execution time: 0.0344
ERROR - 2019-09-17 11:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:58:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:58:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:58:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:58:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:58:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:58:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:59:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:59:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 11:59:17 --> Total execution time: 0.0056
ERROR - 2019-09-17 11:59:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:59:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:59:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 11:59:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:59:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 11:59:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 11:59:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 11:59:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 11:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 11:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 11:59:56 --> Severity: error --> Exception: Call to undefined function curl_init() /var/www/html/school/application/controllers/Welcome.php 1956
ERROR - 2019-09-17 12:00:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:00:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:00:54 --> Total execution time: 0.0754
ERROR - 2019-09-17 12:00:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:00:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:00:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:00:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:00:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:00:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:01:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:01:19 --> Total execution time: 0.0664
ERROR - 2019-09-17 12:01:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:01:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:01:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:01:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:03:15 --> Total execution time: 0.0103
ERROR - 2019-09-17 12:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:03:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:03:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:03:16 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:05:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:05:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:05:03 --> Total execution time: 0.0104
ERROR - 2019-09-17 12:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:05:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:05:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:05:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:06:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:06:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:06:37 --> Total execution time: 0.0134
ERROR - 2019-09-17 12:06:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:06:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:06:40 --> Total execution time: 0.0040
ERROR - 2019-09-17 12:06:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:06:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:06:43 --> Total execution time: 0.0031
ERROR - 2019-09-17 12:06:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:06:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:06:48 --> Total execution time: 0.0027
ERROR - 2019-09-17 12:06:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:06:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:06:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:06:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:06:52 --> Total execution time: 0.0036
ERROR - 2019-09-17 12:07:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:07:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:07:33 --> Total execution time: 0.0058
ERROR - 2019-09-17 12:07:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:07:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:07:33 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:07:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:07:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:07:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:07:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:08:15 --> Total execution time: 0.0093
ERROR - 2019-09-17 12:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:08:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:08:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:08:16 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:08:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:08:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:08:39 --> Total execution time: 0.0341
ERROR - 2019-09-17 12:08:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:08:39 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:08:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:08:39 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:09:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:09:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 12:09:40 --> Severity: Warning --> Missing argument 2 for log_message(), called in /var/www/html/school/application/controllers/Welcome.php on line 1968 and defined /var/www/html/school/system/core/Common.php 459
ERROR - 2019-09-17 12:09:40 --> Severity: Notice --> Undefined variable: message /var/www/html/school/system/core/Common.php 469
ERROR - 2019-09-17 12:09:40 --> Severity: Notice --> Undefined index: HELLO /var/www/html/school/system/core/Log.php 180
ERROR - 2019-09-17 12:09:40 --> Severity: Warning --> Missing argument 2 for log_message(), called in /var/www/html/school/application/controllers/Welcome.php on line 1969 and defined /var/www/html/school/system/core/Common.php 459
ERROR - 2019-09-17 12:09:40 --> Severity: Notice --> Undefined variable: message /var/www/html/school/system/core/Common.php 469
ERROR - 2019-09-17 12:09:40 --> Severity: Notice --> Undefined index: <HTML>
<HEAD>
<TITLE>UNAUTHORIZED</TITLE>
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000">
<H1>UNAUTHORIZED</H1>
<H2>ERROR 401</H2>
</BODY>
</HTML>
 /var/www/html/school/system/core/Log.php 180
DEBUG - 2019-09-17 12:09:40 --> Total execution time: 0.0596
ERROR - 2019-09-17 12:09:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:09:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:09:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:09:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:09:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:09:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:11:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:11:34 --> HELLO
DEBUG - 2019-09-17 12:11:34 --> <HTML>
<HEAD>
<TITLE>Unauthorized</TITLE>
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000">
<H1>Unauthorized</H1>
<H2>Error 401</H2>
</BODY>
</HTML>

DEBUG - 2019-09-17 12:11:34 --> Total execution time: 0.0559
ERROR - 2019-09-17 12:11:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:34 --> UTF-8 Support Enabled
ERROR - 2019-09-17 12:11:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:11:34 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-09-17 12:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:11:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:11:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:11:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:11:50 --> Total execution time: 0.0059
ERROR - 2019-09-17 12:11:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:11:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:11:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:11:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:11:52 --> Total execution time: 0.0036
ERROR - 2019-09-17 12:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:11:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:11:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:11:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:11:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:11:56 --> Total execution time: 0.0031
ERROR - 2019-09-17 12:12:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:12:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:12:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:12:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:12:02 --> Total execution time: 0.0033
ERROR - 2019-09-17 12:12:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:12:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:12:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:12:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:12:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:12:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:12:07 --> Total execution time: 0.0031
ERROR - 2019-09-17 12:12:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:12:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:12:53 --> HELLO
DEBUG - 2019-09-17 12:12:53 --> {"multicast_id":9139004790813028043,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568722373579275%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 12:12:53 --> Total execution time: 0.0683
ERROR - 2019-09-17 12:12:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:12:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:12:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:12:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:12:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:12:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:12:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:12:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:13:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:13:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:13:10 --> Total execution time: 0.0047
ERROR - 2019-09-17 12:13:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:13:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:13:29 --> Total execution time: 0.0054
ERROR - 2019-09-17 12:13:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:13:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:13:30 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:13:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:13:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:13:46 --> Total execution time: 0.0045
ERROR - 2019-09-17 12:13:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:13:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 126
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 128
ERROR - 2019-09-17 12:13:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `home_page_menu` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 130
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 132
ERROR - 2019-09-17 12:13:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT `s`.`school_name`, `b`.*
FROM `backgrounds` `b`
LEFT JOIN `school` `s` ON `b`.`school_id`=
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-17 12:13:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 134
ERROR - 2019-09-17 12:13:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-17 12:13:49 --> Total execution time: 0.0074
ERROR - 2019-09-17 12:13:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:13:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:13:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:13:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:13:58 --> Total execution time: 0.0036
ERROR - 2019-09-17 12:14:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:14:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:14:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:14:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:14:24 --> Total execution time: 0.0045
ERROR - 2019-09-17 12:14:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:14:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:14:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:14:28 --> Total execution time: 0.0046
ERROR - 2019-09-17 12:14:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:14:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:14:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:14:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:14:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:14:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:14:31 --> Total execution time: 0.0045
ERROR - 2019-09-17 12:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:16:37 --> HELLO
DEBUG - 2019-09-17 12:16:37 --> {"multicast_id":8146505467633208630,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568722597331838%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 12:16:37 --> Total execution time: 0.0763
ERROR - 2019-09-17 12:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:16:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:16:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:16:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:16:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:16:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:16:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:16:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:16:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:16:57 --> Total execution time: 0.0046
ERROR - 2019-09-17 12:16:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:16:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:16:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:17:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:17:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:17:00 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:17:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:17:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:17:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:17:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:17:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:17:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:17:03 --> Total execution time: 0.0030
ERROR - 2019-09-17 12:17:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:17:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:17:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:17:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:17:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:17:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:17:08 --> Total execution time: 0.0027
ERROR - 2019-09-17 12:17:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:17:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:17:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:17:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:17:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:17:13 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:20:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:20:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:20:16 --> Total execution time: 0.0042
ERROR - 2019-09-17 12:20:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:20:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:20:19 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:20:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:20:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:20:27 --> Total execution time: 0.0029
ERROR - 2019-09-17 12:20:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:20:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:20:31 --> Total execution time: 0.0027
ERROR - 2019-09-17 12:20:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:20:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:20:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:20:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:20:35 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:23:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:23:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:23:18 --> Total execution time: 0.0045
ERROR - 2019-09-17 12:23:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:23:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:23:21 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:23:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:23:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:23:24 --> Total execution time: 0.0030
ERROR - 2019-09-17 12:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:23:29 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:23:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:23:37 --> Total execution time: 0.0027
ERROR - 2019-09-17 12:23:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:23:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:23:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:23:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:23:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-17 12:23:39 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1241
ERROR - 2019-09-17 12:23:39 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1242
DEBUG - 2019-09-17 12:23:39 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:46:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:46:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:46:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:46:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:46:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-17 12:46:00 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1241
ERROR - 2019-09-17 12:46:00 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1242
DEBUG - 2019-09-17 12:46:00 --> Total execution time: 0.0028
ERROR - 2019-09-17 12:46:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:46:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:46:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:46:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:46:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:46:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:46:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-17 12:46:13 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1241
ERROR - 2019-09-17 12:46:13 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1242
DEBUG - 2019-09-17 12:46:13 --> Total execution time: 0.0029
ERROR - 2019-09-17 12:52:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:52:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:52:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:52:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:52:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:52:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:52:45 --> Total execution time: 0.0045
ERROR - 2019-09-17 12:52:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:52:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:52:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:52:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:52:48 --> Total execution time: 0.0027
ERROR - 2019-09-17 12:52:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:52:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:52:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:52:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:52:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:52:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:52:51 --> Total execution time: 0.0030
ERROR - 2019-09-17 12:53:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:53:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:53:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:53:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:53:03 --> Total execution time: 0.0033
ERROR - 2019-09-17 12:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:53:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:53:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:53:09 --> Total execution time: 0.0032
ERROR - 2019-09-17 12:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 12:53:57 --> HELLO
DEBUG - 2019-09-17 12:53:57 --> {"multicast_id":7279075116281502200,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568724837706200%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 12:53:57 --> Total execution time: 0.0909
ERROR - 2019-09-17 12:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:53:57 --> UTF-8 Support Enabled
ERROR - 2019-09-17 12:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:53:57 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-17 12:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:53:57 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 12:53:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:53:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:53:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 12:53:58 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 12:54:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:54:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:54:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:54:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:54:51 --> Total execution time: 0.0039
ERROR - 2019-09-17 12:54:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:54:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:54:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:54:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:54:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:54:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:54:58 --> Total execution time: 0.0046
ERROR - 2019-09-17 12:55:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:55:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:55:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:55:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:55:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:55:08 --> Total execution time: 0.0045
ERROR - 2019-09-17 12:55:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:55:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:55:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:55:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:55:36 --> Total execution time: 0.0035
ERROR - 2019-09-17 12:55:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:55:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 12:55:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 12:55:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 12:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 12:55:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 12:55:52 --> Total execution time: 0.0046
ERROR - 2019-09-17 13:03:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:03:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:03:02 --> Total execution time: 0.0038
ERROR - 2019-09-17 13:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:03:19 --> Total execution time: 0.0043
ERROR - 2019-09-17 13:03:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:03:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:03:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:03:21 --> Total execution time: 0.0041
ERROR - 2019-09-17 13:03:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:03:23 --> Total execution time: 0.0041
ERROR - 2019-09-17 13:03:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:03:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:03:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:03:30 --> Total execution time: 0.0033
ERROR - 2019-09-17 13:07:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:07:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:07:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:07:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:07:13 --> Total execution time: 0.0034
ERROR - 2019-09-17 13:08:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:08:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:08:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:08:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:08:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:08:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:08:42 --> Total execution time: 0.0044
ERROR - 2019-09-17 13:08:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:08:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:08:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:08:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:08:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:08:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:08:58 --> Total execution time: 0.0042
ERROR - 2019-09-17 13:14:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:14:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:14:36 --> Total execution time: 0.0043
ERROR - 2019-09-17 13:14:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:14:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:14:38 --> Total execution time: 0.0025
ERROR - 2019-09-17 13:14:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:14:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:14:42 --> Total execution time: 0.0027
ERROR - 2019-09-17 13:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:14:47 --> Total execution time: 0.0025
ERROR - 2019-09-17 13:14:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:14:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:14:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:14:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:14:54 --> Total execution time: 0.0025
ERROR - 2019-09-17 13:15:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:15:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:15:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:15:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:15:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:15:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:15:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-17 13:15:01 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1241
ERROR - 2019-09-17 13:15:01 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1242
DEBUG - 2019-09-17 13:15:01 --> Total execution time: 0.0023
ERROR - 2019-09-17 13:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 13:16:37 --> Severity: Warning --> Missing argument 2 for log_message(), called in /var/www/html/school/application/controllers/Welcome.php on line 1879 and defined /var/www/html/school/system/core/Common.php 459
ERROR - 2019-09-17 13:16:37 --> Severity: Notice --> Undefined variable: message /var/www/html/school/system/core/Common.php 469
ERROR - 2019-09-17 13:16:37 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given /var/www/html/school/system/core/Log.php 177
ERROR - 2019-09-17 13:16:37 --> Severity: Notice --> Undefined index:  /var/www/html/school/system/core/Log.php 180
ERROR - 2019-09-17 13:16:37 --> Severity: error --> Exception: Call to undefined method Welcome::send_notificatio() /var/www/html/school/application/controllers/Welcome.php 1880
ERROR - 2019-09-17 13:17:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:17:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:19:08 --> Total execution time: 0.0062
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:19:08 --> Total execution time: 0.0025
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:19:08 --> Total execution time: 0.0030
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:19:08 --> Total execution time: 0.0024
ERROR - 2019-09-17 13:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:19:08 --> Total execution time: 0.0019
ERROR - 2019-09-17 13:19:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:09 --> No URI present. Default controller set.
DEBUG - 2019-09-17 13:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:19:09 --> Total execution time: 0.0127
ERROR - 2019-09-17 13:19:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:23 --> No URI present. Default controller set.
DEBUG - 2019-09-17 13:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:19:23 --> Total execution time: 0.0110
ERROR - 2019-09-17 13:19:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:19:28 --> Total execution time: 0.0062
ERROR - 2019-09-17 13:19:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:19:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 13:19:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:19:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 13:19:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:19:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 13:21:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:21:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:21:50 --> No URI present. Default controller set.
DEBUG - 2019-09-17 13:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:21:50 --> Total execution time: 0.0292
ERROR - 2019-09-17 13:22:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:22:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:22:05 --> No URI present. Default controller set.
DEBUG - 2019-09-17 13:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:22:05 --> Total execution time: 0.0095
ERROR - 2019-09-17 13:22:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:22:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:22:12 --> Total execution time: 0.0065
ERROR - 2019-09-17 13:22:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:22:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:22:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 13:22:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:22:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:22:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 13:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:22:45 --> Array
(
    [0] => stdClass Object
        (
            [fcm_token] => 
        )

    [1] => stdClass Object
        (
            [fcm_token] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
        )

    [2] => stdClass Object
        (
            [fcm_token] => 
        )

    [3] => stdClass Object
        (
            [fcm_token] => 
        )

    [4] => stdClass Object
        (
            [fcm_token] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
        )

    [5] => stdClass Object
        (
            [fcm_token] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
        )

)

DEBUG - 2019-09-17 13:22:45 --> HELLO
DEBUG - 2019-09-17 13:22:45 --> {"multicast_id":5179764867120613838,"success":0,"failure":6,"canonical_ids":0,"results":[{"error":"InvalidRegistration"},{"error":"InvalidRegistration"},{"error":"InvalidRegistration"},{"error":"InvalidRegistration"},{"error":"InvalidRegistration"},{"error":"InvalidRegistration"}]}
DEBUG - 2019-09-17 13:22:45 --> Total execution time: 0.0535
ERROR - 2019-09-17 13:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:22:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 13:22:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:22:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:24:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:24:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:24:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:24:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:24:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:24:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:24:45 --> Total execution time: 0.0057
ERROR - 2019-09-17 13:24:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:24:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:24:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:24:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:24:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:24:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:24:48 --> Total execution time: 0.0029
ERROR - 2019-09-17 13:25:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:25:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:25:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:25:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:25:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:25:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:25:05 --> Total execution time: 0.0036
ERROR - 2019-09-17 13:25:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:25:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:25:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:25:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:25:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:25:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:25:09 --> Total execution time: 0.0027
ERROR - 2019-09-17 13:25:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:25:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:25:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:25:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:25:16 --> Total execution time: 0.0036
ERROR - 2019-09-17 13:25:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:25:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:25:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:25:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:25:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:25:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:25:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1230
ERROR - 2019-09-17 13:25:21 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1241
ERROR - 2019-09-17 13:25:21 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1242
DEBUG - 2019-09-17 13:25:21 --> Total execution time: 0.0029
ERROR - 2019-09-17 13:28:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:28:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 13:28:59 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) /var/www/html/school/application/models/M_login.php 153
ERROR - 2019-09-17 13:29:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:29:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 13:29:24 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/school/application/models/M_login.php 73
ERROR - 2019-09-17 13:30:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:30:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 13:30:04 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/school/application/models/M_login.php 73
ERROR - 2019-09-17 13:30:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:30:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:30:48 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 13:30:48 --> HELLO
DEBUG - 2019-09-17 13:30:48 --> {"multicast_id":5368849806915824783,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568727048938453%ec14b888ec14b888"},{"message_id":"0:1568727048938454%ec14b888ec14b888"},{"message_id":"0:1568727048904764%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 13:30:48 --> Total execution time: 0.1044
ERROR - 2019-09-17 13:30:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:30:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 13:30:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:30:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:33:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:33:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:33:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:33:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:33:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:33:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:33:55 --> Total execution time: 0.0053
ERROR - 2019-09-17 13:33:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:33:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:33:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:33:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:33:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:33:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:33:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:33:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:33:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:33:56 --> Total execution time: 0.0050
ERROR - 2019-09-17 13:33:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:33:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:33:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:33:56 --> Total execution time: 0.0039
ERROR - 2019-09-17 13:35:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:35:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:35:03 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 13:35:03 --> HELLO
DEBUG - 2019-09-17 13:35:03 --> {"multicast_id":7554897409624820487,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568727303609110%ec14b888ec14b888"},{"message_id":"0:1568727303608823%ec14b888ec14b888"},{"message_id":"0:1568727303598742%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 13:35:03 --> Total execution time: 0.0876
ERROR - 2019-09-17 13:35:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:35:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:35:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:35:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 13:35:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:35:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:35:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:35:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:35:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:35:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:35:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:35:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 13:35:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:35:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:35:05 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:36:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:36:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:36:53 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 13:36:53 --> HELLO
DEBUG - 2019-09-17 13:36:53 --> {"multicast_id":9066217265673853105,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568727413822915%ec14b888ec14b888"},{"message_id":"0:1568727413822916%ec14b888ec14b888"},{"message_id":"0:1568727413822908%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 13:36:53 --> Total execution time: 0.0807
ERROR - 2019-09-17 13:36:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:36:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:36:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 13:36:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:36:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:36:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:37:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:37:52 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 13:37:52 --> HELLO
DEBUG - 2019-09-17 13:37:52 --> {"multicast_id":6071055223765736736,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568727472839685%ec14b888ec14b888"},{"message_id":"0:1568727472839951%ec14b888ec14b888"},{"message_id":"0:1568727472836087%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 13:37:52 --> Total execution time: 0.0716
ERROR - 2019-09-17 13:37:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:37:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 13:37:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:37:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:38:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:38:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:38:32 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 13:38:32 --> HELLO
DEBUG - 2019-09-17 13:38:32 --> {"multicast_id":7517063289668967177,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568727512326887%ec14b888ec14b888"},{"message_id":"0:1568727512326885%ec14b888ec14b888"},{"message_id":"0:1568727512327484%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 13:38:32 --> Total execution time: 0.0615
ERROR - 2019-09-17 13:38:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:38:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:38:32 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 13:38:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:38:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:38:32 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:39:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:39:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 13:39:28 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 13:39:28 --> HELLO
DEBUG - 2019-09-17 13:39:28 --> {"multicast_id":6644902887807876412,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568727568584779%ec14b888ec14b888"},{"message_id":"0:1568727568584777%ec14b888ec14b888"},{"message_id":"0:1568727568584775%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 13:39:28 --> Total execution time: 0.0705
ERROR - 2019-09-17 13:39:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:39:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:39:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:39:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:39:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:39:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:39:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:39:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 13:39:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:39:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:39:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 13:39:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 13:42:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:42:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:42:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:42:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:42:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:42:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:42:54 --> Total execution time: 0.0046
ERROR - 2019-09-17 13:42:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:42:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:42:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:42:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:42:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:42:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:42:57 --> Total execution time: 0.0028
ERROR - 2019-09-17 13:43:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:43:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:43:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 13:43:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 13:43:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 13:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 13:43:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 13:43:02 --> Total execution time: 0.0039
ERROR - 2019-09-17 14:22:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:22:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 14:22:48 --> Total execution time: 0.0021
ERROR - 2019-09-17 14:29:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:29:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 14:29:30 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 14:29:30 --> HELLO
DEBUG - 2019-09-17 14:29:30 --> {"multicast_id":5242971196193405302,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568730570133333%ec14b888ec14b888"},{"message_id":"0:1568730570133334%ec14b888ec14b888"},{"message_id":"0:1568730570131883%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 14:29:30 --> Total execution time: 0.0777
ERROR - 2019-09-17 14:29:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:29:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:29:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 14:29:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:29:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:29:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 14:31:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:31:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 14:31:18 --> Severity: Notice --> Undefined variable: data /var/www/html/school/application/controllers/Welcome.php 1873
DEBUG - 2019-09-17 14:31:18 --> Total execution time: 0.0086
ERROR - 2019-09-17 14:31:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:31:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 14:31:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:31:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 14:31:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:31:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 14:31:37 --> Total execution time: 0.0038
ERROR - 2019-09-17 14:31:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:31:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 14:31:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:31:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 14:32:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:32:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 14:32:15 --> Severity: Notice --> Undefined variable: data /var/www/html/school/application/controllers/Welcome.php 1873
DEBUG - 2019-09-17 14:32:15 --> Total execution time: 0.0047
ERROR - 2019-09-17 14:32:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:32:16 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 14:32:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:32:16 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 14:33:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 14:33:04 --> ROLE ::::: teacher
DEBUG - 2019-09-17 14:33:04 --> Total execution time: 0.0114
ERROR - 2019-09-17 14:33:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:33:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 14:33:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:33:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 14:49:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:49:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-17 14:49:27 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /var/www/html/school/application/models/M_teachers.php 238
ERROR - 2019-09-17 14:49:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:49:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 14:49:57 --> Total execution time: 0.0047
ERROR - 2019-09-17 14:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:49:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 14:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:49:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 14:50:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:50:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 14:50:20 --> ROLE ::::: teacher
ERROR - 2019-09-17 14:50:20 --> Severity: Notice --> Undefined property: Welcome::$m_teacher /var/www/html/school/application/controllers/Welcome.php 1881
ERROR - 2019-09-17 14:50:20 --> Severity: error --> Exception: Call to a member function get_teachers_id() on null /var/www/html/school/application/controllers/Welcome.php 1881
ERROR - 2019-09-17 14:51:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:51:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 14:51:18 --> ROLE ::::: teacher
DEBUG - 2019-09-17 14:51:18 --> Array
(
    [0] => stdClass Object
        (
            [users_id] => 110
        )

    [1] => stdClass Object
        (
            [users_id] => 111
        )

)

DEBUG - 2019-09-17 14:51:18 --> Total execution time: 0.0123
ERROR - 2019-09-17 14:51:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:51:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:51:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:51:18 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 14:51:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:51:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:51:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 14:51:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 14:57:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 14:57:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 14:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 14:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 14:57:38 --> ROLE ::::: teacher
DEBUG - 2019-09-17 14:57:38 --> Array
(
    [0] => stdClass Object
        (
            [users_id] => 110
        )

    [1] => stdClass Object
        (
            [users_id] => 111
        )

)

ERROR - 2019-09-17 14:57:38 --> Severity: Notice --> Array to string conversion /var/www/html/school/system/database/DB_query_builder.php 2442
ERROR - 2019-09-17 14:57:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `fcm_token`
FROM `users`
WHERE `id` = Array
ERROR - 2019-09-17 14:57:38 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_login.php 72
ERROR - 2019-09-17 15:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:00:04 --> ROLE ::::: teacher
DEBUG - 2019-09-17 15:00:04 --> Array
(
    [0] => stdClass Object
        (
            [users_id] => 110
        )

    [1] => stdClass Object
        (
            [users_id] => 111
        )

)

ERROR - 2019-09-17 15:00:04 --> Severity: Notice --> Array to string conversion /var/www/html/school/system/database/DB_query_builder.php 2442
ERROR - 2019-09-17 15:00:04 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `fcm_token`
FROM `users`
WHERE `id` = Array
ERROR - 2019-09-17 15:00:04 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_login.php 72
ERROR - 2019-09-17 15:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:05:04 --> ROLE ::::: teacher
DEBUG - 2019-09-17 15:05:04 --> Array
(
    [0] => stdClass Object
        (
            [users_id] => 110
        )

    [1] => stdClass Object
        (
            [users_id] => 111
        )

)

ERROR - 2019-09-17 15:05:04 --> Severity: Notice --> Array to string conversion /var/www/html/school/system/database/DB_query_builder.php 2442
ERROR - 2019-09-17 15:05:04 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `fcm_token`
FROM `users`
WHERE `id` = Array
ERROR - 2019-09-17 15:05:04 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_login.php 72
ERROR - 2019-09-17 15:06:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:06:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:06:25 --> ROLE ::::: teacher
ERROR - 2019-09-17 15:06:25 --> Severity: error --> Exception: Call to undefined method m_teachers::get_teachers_fcm() /var/www/html/school/application/controllers/Welcome.php 1881
ERROR - 2019-09-17 15:06:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:06:57 --> ROLE ::::: teacher
DEBUG - 2019-09-17 15:06:57 --> Array
(
    [0] => stdClass Object
        (
            [fcm_token] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
        )

    [1] => stdClass Object
        (
            [fcm_token] => 
        )

)

DEBUG - 2019-09-17 15:06:57 --> Total execution time: 0.0077
ERROR - 2019-09-17 15:06:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:06:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:06:57 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:06:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:06:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:06:57 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:08:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:08:17 --> ROLE ::::: teacher
DEBUG - 2019-09-17 15:08:17 --> Array
(
    [0] => stdClass Object
        (
            [fcm_token] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
        )

    [1] => stdClass Object
        (
            [fcm_token] => 
        )

)

DEBUG - 2019-09-17 15:08:17 --> Array
(
    [0] => stdClass Object
        (
            [fcm_token] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
        )

    [1] => stdClass Object
        (
            [fcm_token] => 
        )

)

DEBUG - 2019-09-17 15:08:17 --> HELLO
DEBUG - 2019-09-17 15:08:17 --> {"multicast_id":8032677959672318773,"success":0,"failure":2,"canonical_ids":0,"results":[{"error":"InvalidRegistration"},{"error":"InvalidRegistration"}]}
DEBUG - 2019-09-17 15:08:17 --> Total execution time: 0.0531
ERROR - 2019-09-17 15:08:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:08:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:08:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:08:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:09:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:09:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:09:01 --> ROLE ::::: student
DEBUG - 2019-09-17 15:09:01 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:09:01 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:09:01 --> HELLO
DEBUG - 2019-09-17 15:09:01 --> {"multicast_id":8541072021189149853,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568732941918301%ec14b888ec14b888"},{"message_id":"0:1568732941918578%ec14b888ec14b888"},{"message_id":"0:1568732941925404%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:09:01 --> Total execution time: 0.0756
ERROR - 2019-09-17 15:09:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:09:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:09:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:09:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:12:18 --> ROLE ::::: teacher
DEBUG - 2019-09-17 15:12:18 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-17 15:12:18 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-17 15:12:18 --> HELLO
DEBUG - 2019-09-17 15:12:18 --> {"multicast_id":8270631027662425639,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568733138790830%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:12:18 --> Total execution time: 0.0737
ERROR - 2019-09-17 15:12:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:12:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:12:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:12:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:13:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:13:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:13:13 --> ROLE ::::: teacher
DEBUG - 2019-09-17 15:13:13 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-17 15:13:13 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
)

DEBUG - 2019-09-17 15:13:13 --> HELLO
DEBUG - 2019-09-17 15:13:13 --> {"multicast_id":4798260011447563364,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568733193204943%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:13:13 --> Total execution time: 0.0609
ERROR - 2019-09-17 15:13:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:13:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:13:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:13:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:13:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:13:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:19:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:19:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:19:31 --> ROLE ::::: driver
DEBUG - 2019-09-17 15:19:31 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:19:31 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:19:31 --> HELLO
DEBUG - 2019-09-17 15:19:31 --> {"multicast_id":5322600245358927362,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568733571729646%ec14b888ec14b888"},{"message_id":"0:1568733571729645%ec14b888ec14b888"},{"message_id":"0:1568733571709674%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:19:31 --> Total execution time: 0.0852
ERROR - 2019-09-17 15:19:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:19:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:19:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:19:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:19:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:19:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:19:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:19:32 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:23:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:23:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:23:14 --> ROLE ::::: driver
DEBUG - 2019-09-17 15:23:14 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:23:14 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:23:14 --> HELLO
DEBUG - 2019-09-17 15:23:14 --> {"multicast_id":6930902023686960652,"success":3,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568733794488184%ec14b888ec14b888"},{"message_id":"0:1568733794488485%ec14b888ec14b888"},{"message_id":"0:1568733794487725%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:23:14 --> Total execution time: 0.0770
ERROR - 2019-09-17 15:23:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:23:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:23:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:23:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:23:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:23:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:26:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:26:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:26:47 --> ROLE ::::: driver
ERROR - 2019-09-17 15:26:47 --> Query error: Unknown column 'b.school_id' in 'where clause' - Invalid query: SELECT `u`.`fcm_token`
FROM `drivers` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
ERROR - 2019-09-17 15:26:47 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_drivers.php 208
ERROR - 2019-09-17 15:28:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:28:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:28:29 --> ROLE ::::: driver
ERROR - 2019-09-17 15:28:29 --> Query error: Unknown column 'b.school_id' in 'where clause' - Invalid query: SELECT `u`.`fcm_token`
FROM `drivers` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
ERROR - 2019-09-17 15:28:29 --> 
ERROR - 2019-09-17 15:28:29 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_drivers.php 209
ERROR - 2019-09-17 15:29:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:29:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:29:13 --> ROLE ::::: driver
ERROR - 2019-09-17 15:29:13 --> Query error: Unknown column 'b.school_id' in 'where clause' - Invalid query: SELECT `u`.`fcm_token`
FROM `drivers` `b`
LEFT JOIN `users` `u` ON `b`.`drivers_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
ERROR - 2019-09-17 15:29:13 --> 
ERROR - 2019-09-17 15:29:13 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/school/application/models/M_drivers.php 209
ERROR - 2019-09-17 15:33:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:33:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:33:10 --> ROLE ::::: driver
ERROR - 2019-09-17 15:33:10 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4684317  Threads: 1  Questions: 174056  Slow queries: 0  Opens: 6915  Flush tables: 1  Open tables: 791  Queries per second avg: 0.037
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 36276
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-17 15:33:10 --> Array
(
)

DEBUG - 2019-09-17 15:33:10 --> Array
(
)

DEBUG - 2019-09-17 15:33:10 --> HELLO
DEBUG - 2019-09-17 15:33:10 --> "registration_ids" field cannot be empty

DEBUG - 2019-09-17 15:33:10 --> Total execution time: 0.0582
ERROR - 2019-09-17 15:33:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:33:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:33:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:33:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:42:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:42:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 15:42:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:42:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 15:42:12 --> Total execution time: 0.0047
ERROR - 2019-09-17 15:42:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:42:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-17 15:42:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:42:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-17 15:42:13 --> Total execution time: 0.0024
ERROR - 2019-09-17 15:42:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:42:35 --> ROLE ::::: driver
ERROR - 2019-09-17 15:42:35 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4684882  Threads: 2  Questions: 174113  Slow queries: 0  Opens: 6915  Flush tables: 1  Open tables: 791  Queries per second avg: 0.037
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 36282
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-17 15:42:35 --> Array
(
    [0] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:42:35 --> Array
(
    [0] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:42:35 --> HELLO
DEBUG - 2019-09-17 15:42:35 --> {"multicast_id":5012035652701090228,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568734955419984%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:42:35 --> Total execution time: 0.0917
ERROR - 2019-09-17 15:42:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:42:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:42:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:42:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:42:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:42:50 --> ROLE ::::: driver
ERROR - 2019-09-17 15:42:50 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 1
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4684897  Threads: 2  Questions: 174123  Slow queries: 0  Opens: 6915  Flush tables: 1  Open tables: 791  Queries per second avg: 0.037
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 36283
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 1
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-17 15:42:50 --> Array
(
    [0] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:42:50 --> Array
(
    [0] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:42:50 --> HELLO
DEBUG - 2019-09-17 15:42:50 --> {"multicast_id":7874147842291524343,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568734970664683%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:42:50 --> Total execution time: 0.0697
ERROR - 2019-09-17 15:42:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:42:50 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:42:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:42:50 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:44:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:44:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:44:00 --> Total execution time: 0.0040
ERROR - 2019-09-17 15:44:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:44:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:44:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:44:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:44:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:44:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 15:44:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:44:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:44:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:48:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:48:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:48:37 --> Total execution time: 0.0045
ERROR - 2019-09-17 15:48:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:48:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:48:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:48:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:48:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:48:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:48:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:48:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 15:49:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:49:41 --> Total execution time: 0.0044
ERROR - 2019-09-17 15:49:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:49:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 15:49:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:49:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:51:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:51:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:51:47 --> Total execution time: 0.0044
ERROR - 2019-09-17 15:51:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:51:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:51:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:51:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:51:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:51:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:51:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:51:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 15:51:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:51:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:51:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:51:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:52:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:52:03 --> Total execution time: 0.0030
ERROR - 2019-09-17 15:52:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:52:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:52:32 --> ROLE ::::: section
DEBUG - 2019-09-17 15:52:32 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:52:32 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:52:32 --> HELLO
DEBUG - 2019-09-17 15:52:32 --> {"multicast_id":7377905419973040601,"success":4,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568735552634326%ec14b888ec14b888"},{"message_id":"0:1568735552629879%ec14b888ec14b888"},{"message_id":"0:1568735552631514%ec14b888ec14b888"},{"message_id":"0:1568735552629880%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:52:32 --> Total execution time: 0.0919
ERROR - 2019-09-17 15:52:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:52:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:52:32 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:52:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:52:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:52:33 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:53:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:53:04 --> ROLE ::::: section
DEBUG - 2019-09-17 15:53:04 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:53:04 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:53:05 --> HELLO
DEBUG - 2019-09-17 15:53:05 --> {"multicast_id":6460941794058231148,"success":4,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568735585002662%ec14b888ec14b888"},{"message_id":"0:1568735585002175%ec14b888ec14b888"},{"message_id":"0:1568735585002663%ec14b888ec14b888"},{"message_id":"0:1568735585002421%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:53:05 --> Total execution time: 0.0816
ERROR - 2019-09-17 15:53:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:53:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:53:05 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:53:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:53:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:53:05 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:55:36 --> Total execution time: 0.0049
ERROR - 2019-09-17 15:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:55:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:55:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:55:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:55:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:55:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:55:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 15:56:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:56:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:56:19 --> ROLE ::::: section
DEBUG - 2019-09-17 15:56:19 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:56:19 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 15:56:20 --> HELLO
DEBUG - 2019-09-17 15:56:20 --> {"multicast_id":5655744354452405928,"success":4,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568735779989795%ec14b888ec14b888"},{"message_id":"0:1568735779986410%ec14b888ec14b888"},{"message_id":"0:1568735779989911%ec14b888ec14b888"},{"message_id":"0:1568735779986937%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 15:56:20 --> Total execution time: 0.0836
ERROR - 2019-09-17 15:56:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:56:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:56:20 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 15:56:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:56:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:56:20 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 15:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:58:20 --> Total execution time: 0.0046
ERROR - 2019-09-17 15:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:58:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:58:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 15:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:58:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:58:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 15:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 15:59:44 --> Total execution time: 0.0048
ERROR - 2019-09-17 15:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:59:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 15:59:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:59:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:59:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 15:59:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:59:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:59:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 15:59:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 15:59:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 15:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 15:59:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 16:00:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:00:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:00:55 --> Total execution time: 0.0048
ERROR - 2019-09-17 16:00:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:00:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:00:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 16:00:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:00:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:00:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 16:01:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:01:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:01:04 --> ROLE ::::: parent
DEBUG - 2019-09-17 16:01:04 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 16:01:04 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 16:01:04 --> HELLO
DEBUG - 2019-09-17 16:01:04 --> {"multicast_id":5559862954742691770,"success":4,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568736064910819%ec14b888ec14b888"},{"message_id":"0:1568736064941879%ec14b888ec14b888"},{"message_id":"0:1568736064910820%ec14b888ec14b888"},{"message_id":"0:1568736064941881%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 16:01:04 --> Total execution time: 0.1092
ERROR - 2019-09-17 16:01:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:01:05 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 16:01:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:01:05 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 16:01:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:01:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:01:45 --> ROLE ::::: student
DEBUG - 2019-09-17 16:01:45 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 16:01:45 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 16:01:45 --> HELLO
DEBUG - 2019-09-17 16:01:45 --> {"multicast_id":5159142416203474411,"success":4,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568736105651742%ec14b888ec14b888"},{"message_id":"0:1568736105651345%ec14b888ec14b888"},{"message_id":"0:1568736105651743%ec14b888ec14b888"},{"message_id":"0:1568736105651054%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 16:01:45 --> Total execution time: 0.0737
ERROR - 2019-09-17 16:01:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:01:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:01:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 16:01:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:01:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:01:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 16:18:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:18:37 --> Total execution time: 0.0052
ERROR - 2019-09-17 16:18:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:18:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 16:18:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:18:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 16:18:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:18:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:18:59 --> ROLE ::::: section
DEBUG - 2019-09-17 16:18:59 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 16:18:59 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
    [2] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [3] => fin8QkEiroI:APA91bHSuddPlk7rYrCLNtCT0fjJa1SzO7f1H0cnZQVuuFJI1NNJ4bsXPdWA-i71TbBRrOWdgO4IpvKPChcXSdLTDKtg2khNQt63xTsqtbY03endhfhOY_IE5eBlhOjBy439WJYaPblS
)

DEBUG - 2019-09-17 16:18:59 --> HELLO
DEBUG - 2019-09-17 16:18:59 --> {"multicast_id":6598969122638246626,"success":4,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568737139198476%ec14b888ec14b888"},{"message_id":"0:1568737139196980%ec14b888ec14b888"},{"message_id":"0:1568737139198478%ec14b888ec14b888"},{"message_id":"0:1568737139196979%ec14b888ec14b888"}]}
DEBUG - 2019-09-17 16:18:59 --> Total execution time: 0.0822
ERROR - 2019-09-17 16:18:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:18:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:18:59 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 16:18:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:18:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:18:59 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:21:46 --> Total execution time: 0.0091
ERROR - 2019-09-17 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:21:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:21:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:21:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 16:21:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:21:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:21:59 --> ROLE ::::: section
DEBUG - 2019-09-17 16:21:59 --> Array
(
)

DEBUG - 2019-09-17 16:21:59 --> Array
(
)

DEBUG - 2019-09-17 16:22:00 --> HELLO
DEBUG - 2019-09-17 16:22:00 --> "registration_ids" field cannot be empty

DEBUG - 2019-09-17 16:22:00 --> Total execution time: 0.0714
ERROR - 2019-09-17 16:22:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:22:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:22:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 16:22:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:22:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:22:00 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-17 16:25:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:25:48 --> Total execution time: 0.0053
ERROR - 2019-09-17 16:25:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:25:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 16:25:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:25:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-17 16:25:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:25:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:25:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:25:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-17 16:26:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-17 16:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-17 16:26:00 --> ROLE ::::: section
DEBUG - 2019-09-17 16:26:00 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`sections_id` = '*'
AND `b`.`class_id` = '*'
DEBUG - 2019-09-17 16:26:00 --> Array
(
)

DEBUG - 2019-09-17 16:26:00 --> Array
(
)

DEBUG - 2019-09-17 16:26:01 --> HELLO
DEBUG - 2019-09-17 16:26:01 --> "registration_ids" field cannot be empty

DEBUG - 2019-09-17 16:26:01 --> Total execution time: 0.0528
ERROR - 2019-09-17 16:26:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:26:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-17 16:26:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-17 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-17 16:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-17 16:26:01 --> 404 Page Not Found: Welcome/js
