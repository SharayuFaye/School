<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-15 11:55:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 11:55:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 11:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 11:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 11:55:51 --> Total execution time: 3.7641
ERROR - 2019-10-15 11:56:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 11:56:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 11:56:04 --> No URI present. Default controller set.
DEBUG - 2019-10-15 11:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 11:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 11:56:06 --> Total execution time: 1.9510
ERROR - 2019-10-15 11:56:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 11:56:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 11:56:19 --> No URI present. Default controller set.
DEBUG - 2019-10-15 11:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 11:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 11:56:21 --> Total execution time: 2.1945
ERROR - 2019-10-15 12:01:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:01:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:01:48 --> Total execution time: 0.3295
ERROR - 2019-10-15 12:02:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:02:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:02:30 --> Total execution time: 0.0021
ERROR - 2019-10-15 12:02:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:02:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:02:33 --> No URI present. Default controller set.
DEBUG - 2019-10-15 12:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:02:33 --> Total execution time: 0.0078
ERROR - 2019-10-15 12:02:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:02:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:02:36 --> Total execution time: 0.1215
ERROR - 2019-10-15 12:02:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:02:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:02:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:02:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:02:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:02:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:07:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:07:40 --> Total execution time: 0.0470
ERROR - 2019-10-15 12:07:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:07:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:07:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:07:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:07:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:07:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:07:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:07:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 12:07:43 --> Severity: Notice --> Undefined variable: class_show /var/www/html/School19/application/views/my_class.php 59
ERROR - 2019-10-15 12:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 59
ERROR - 2019-10-15 12:07:43 --> Severity: Notice --> Undefined variable: sections_show /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 12:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 12:07:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/my_class.php 90
ERROR - 2019-10-15 12:07:43 --> Severity: Notice --> Undefined variable: class /var/www/html/School19/application/views/my_class.php 90
ERROR - 2019-10-15 12:07:43 --> Severity: Notice --> Undefined variable: msg /var/www/html/School19/application/views/my_class.php 131
DEBUG - 2019-10-15 12:07:43 --> Total execution time: 0.0307
ERROR - 2019-10-15 12:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 12:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:07:43 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 12:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:07:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:07:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:07:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 12:09:37 --> Severity: Notice --> Undefined variable: class_show /var/www/html/School19/application/views/my_class.php 59
ERROR - 2019-10-15 12:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 59
ERROR - 2019-10-15 12:09:37 --> Severity: Notice --> Undefined variable: sections_show /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 12:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 12:09:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/my_class.php 90
ERROR - 2019-10-15 12:09:37 --> Severity: Notice --> Undefined variable: class /var/www/html/School19/application/views/my_class.php 90
ERROR - 2019-10-15 12:09:37 --> Severity: Notice --> Undefined variable: msg /var/www/html/School19/application/views/my_class.php 131
DEBUG - 2019-10-15 12:09:37 --> Total execution time: 0.0060
ERROR - 2019-10-15 12:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:09:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:09:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:09:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:09:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:10:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 12:10:25 --> Severity: Notice --> Undefined variable: msg /var/www/html/School19/application/views/my_class.php 77
DEBUG - 2019-10-15 12:10:25 --> Total execution time: 0.0050
ERROR - 2019-10-15 12:10:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:10:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:10:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:10:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:10:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:10:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:10:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:10:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:12:44 --> Total execution time: 0.0121
ERROR - 2019-10-15 12:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:12:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:12:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:12:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:12:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:55:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:55:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 12:55:26 --> Severity: Notice --> Undefined property: Welcome::$m_timetables /var/www/html/School19/application/controllers/Welcome.php 2672
ERROR - 2019-10-15 12:55:26 --> Severity: error --> Exception: Call to a member function timetables_my_class() on null /var/www/html/School19/application/controllers/Welcome.php 2672
ERROR - 2019-10-15 12:56:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 12:56:08 --> Severity: Notice --> Undefined variable: section_id /var/www/html/School19/application/models/M_timetables.php 163
ERROR - 2019-10-15 12:56:08 --> Query error: Unknown column 'c.class' in 'field list' - Invalid query: SELECT `f`.*, `c`.`class`, `sec`.`sections`
FROM `timetable` `f`
LEFT JOIN `subject_allocation` `sub` ON `sub`.`sections_id`=`f`.`sections_id`
LEFT JOIN `sections` `sec` ON `f`.`sections_id`=`sec`.`id`
WHERE `f`.`school_id` = '11'
AND `sub`.`teachers_id` = '7'
AND `f`.`sections_id` IS NULL
DEBUG - 2019-10-15 12:56:08 --> Total execution time: 0.0125
ERROR - 2019-10-15 12:56:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:56:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:56:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:56:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:56:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:56:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:56:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:56:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 12:56:49 --> Query error: Unknown column 'c.class' in 'field list' - Invalid query: SELECT `f`.*, `c`.`class`, `sec`.`sections`
FROM `timetable` `f`
LEFT JOIN `subject_allocation` `sub` ON `sub`.`sections_id`=`f`.`sections_id`
LEFT JOIN `sections` `sec` ON `f`.`sections_id`=`sec`.`id`
WHERE `f`.`school_id` = '11'
AND `sub`.`teachers_id` = '7'
DEBUG - 2019-10-15 12:56:49 --> Total execution time: 0.0048
ERROR - 2019-10-15 12:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 12:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:56:49 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 12:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:56:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:56:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:56:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:57:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:57:06 --> Total execution time: 0.0044
ERROR - 2019-10-15 12:57:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:09 --> No URI present. Default controller set.
DEBUG - 2019-10-15 12:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:57:09 --> Total execution time: 0.0123
ERROR - 2019-10-15 12:57:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:57:11 --> Total execution time: 0.0078
ERROR - 2019-10-15 12:57:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:57:15 --> Total execution time: 0.0455
ERROR - 2019-10-15 12:57:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:57:16 --> Total execution time: 0.0027
ERROR - 2019-10-15 12:57:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:57:28 --> Total execution time: 0.0884
ERROR - 2019-10-15 12:57:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:57:30 --> Total execution time: 0.0024
ERROR - 2019-10-15 12:57:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:35 --> No URI present. Default controller set.
DEBUG - 2019-10-15 12:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:57:35 --> Total execution time: 0.0102
ERROR - 2019-10-15 12:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 12:57:41 --> Query error: Unknown column 'c.class' in 'field list' - Invalid query: SELECT `f`.*, `c`.`class`, `sec`.`sections`
FROM `timetable` `f`
LEFT JOIN `subject_allocation` `sub` ON `sub`.`sections_id`=`f`.`sections_id`
LEFT JOIN `sections` `sec` ON `f`.`sections_id`=`sec`.`id`
WHERE `f`.`school_id` = '3'
AND `sub`.`teachers_id` = '5'
DEBUG - 2019-10-15 12:57:41 --> Total execution time: 0.0079
ERROR - 2019-10-15 12:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:57:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:57:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:57:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:57:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:57:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:59:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 12:59:04 --> Total execution time: 0.0073
ERROR - 2019-10-15 12:59:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:59:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:59:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:59:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 12:59:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:59:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 12:59:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 12:59:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:02:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:07 --> Total execution time: 0.0048
ERROR - 2019-10-15 13:02:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:10 --> No URI present. Default controller set.
DEBUG - 2019-10-15 13:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:10 --> Total execution time: 0.0077
ERROR - 2019-10-15 13:02:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:12 --> Total execution time: 0.0081
ERROR - 2019-10-15 13:02:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:14 --> Total execution time: 0.0057
ERROR - 2019-10-15 13:02:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:16 --> Total execution time: 0.0046
ERROR - 2019-10-15 13:02:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:20 --> Total execution time: 0.3426
ERROR - 2019-10-15 13:02:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:23 --> Total execution time: 0.0019
ERROR - 2019-10-15 13:02:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:31 --> No URI present. Default controller set.
DEBUG - 2019-10-15 13:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:31 --> Total execution time: 0.0119
ERROR - 2019-10-15 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:38 --> Total execution time: 0.0055
ERROR - 2019-10-15 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:02:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:44 --> Total execution time: 0.0096
ERROR - 2019-10-15 13:02:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:02:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:02:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:02:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:02:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:47 --> Total execution time: 0.0030
ERROR - 2019-10-15 13:02:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:49 --> Total execution time: 0.0199
ERROR - 2019-10-15 13:02:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 13:02:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:49 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-15 13:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:02:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:02:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:02:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:02:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:51 --> Total execution time: 0.0039
ERROR - 2019-10-15 13:02:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:02:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:02:53 --> Total execution time: 0.0024
ERROR - 2019-10-15 13:03:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:03:04 --> Total execution time: 0.0028
ERROR - 2019-10-15 13:03:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:06 --> No URI present. Default controller set.
DEBUG - 2019-10-15 13:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:03:06 --> Total execution time: 0.0130
ERROR - 2019-10-15 13:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:03:11 --> Total execution time: 0.0104
ERROR - 2019-10-15 13:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:11 --> UTF-8 Support Enabled
ERROR - 2019-10-15 13:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:11 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 13:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:03:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:03:13 --> Total execution time: 0.0025
ERROR - 2019-10-15 13:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:03:15 --> Total execution time: 0.0136
ERROR - 2019-10-15 13:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 13:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 13:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 13:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 13:03:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:03:16 --> Total execution time: 0.0036
ERROR - 2019-10-15 13:03:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:16 --> UTF-8 Support Enabled
ERROR - 2019-10-15 13:03:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:16 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:03:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:03:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:03:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:03:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:03:17 --> Total execution time: 0.0048
ERROR - 2019-10-15 13:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:03:19 --> Total execution time: 0.0048
ERROR - 2019-10-15 13:04:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:04:06 --> Total execution time: 0.0563
ERROR - 2019-10-15 13:04:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:04:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 13:04:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:04:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 13:04:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:04:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 13:04:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:04:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 13:04:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:04:10 --> Total execution time: 0.0018
ERROR - 2019-10-15 13:04:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:15 --> No URI present. Default controller set.
DEBUG - 2019-10-15 13:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:04:15 --> Total execution time: 0.0080
ERROR - 2019-10-15 13:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:04:21 --> Total execution time: 0.0047
ERROR - 2019-10-15 13:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:04:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:04:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:04:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:04:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:05:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:05:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 13:06:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:06:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:06:14 --> Total execution time: 0.0044
ERROR - 2019-10-15 13:06:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:06:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:06:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:06:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:06:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:06:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:06:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:06:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:06:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:06:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:06:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:06:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:06:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:06:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:06:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:06:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:08:11 --> Total execution time: 0.0061
ERROR - 2019-10-15 13:08:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 13:08:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:08:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:08:15 --> Total execution time: 0.0035
ERROR - 2019-10-15 13:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:08:28 --> Total execution time: 0.0040
ERROR - 2019-10-15 13:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:08:29 --> Total execution time: 0.0069
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:08:29 --> Total execution time: 0.0046
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:08:56 --> Total execution time: 0.0072
ERROR - 2019-10-15 13:08:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:08:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:08:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:08:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:08:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:50:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:50:04 --> Total execution time: 0.0069
ERROR - 2019-10-15 13:50:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 13:50:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:50:04 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 13:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:50:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:50:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:50:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:50:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:50:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:50:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:50:14 --> Total execution time: 0.0060
ERROR - 2019-10-15 13:50:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:50:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:50:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:50:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:50:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:50:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:50:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:50:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:50:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:51:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:51:33 --> Total execution time: 0.0041
ERROR - 2019-10-15 13:51:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 13:51:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:51:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:51:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:51:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:51:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:51:34 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:51:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:51:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:51:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 13:51:53 --> Severity: Notice --> Undefined variable: week /var/www/html/School19/application/views/my_class.php 50
ERROR - 2019-10-15 13:51:53 --> Severity: Notice --> Undefined variable: week /var/www/html/School19/application/views/my_class.php 50
ERROR - 2019-10-15 13:51:53 --> Severity: Notice --> Undefined variable: week /var/www/html/School19/application/views/my_class.php 50
ERROR - 2019-10-15 13:51:53 --> Severity: Notice --> Undefined variable: week /var/www/html/School19/application/views/my_class.php 50
ERROR - 2019-10-15 13:51:53 --> Severity: Notice --> Undefined variable: week /var/www/html/School19/application/views/my_class.php 50
ERROR - 2019-10-15 13:51:53 --> Severity: Notice --> Undefined variable: week /var/www/html/School19/application/views/my_class.php 50
ERROR - 2019-10-15 13:51:53 --> Severity: Notice --> Undefined variable: week /var/www/html/School19/application/views/my_class.php 50
DEBUG - 2019-10-15 13:51:53 --> Total execution time: 0.0057
ERROR - 2019-10-15 13:51:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:51:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:51:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:51:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:51:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:51:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:51:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:51:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:52:14 --> Total execution time: 0.0065
ERROR - 2019-10-15 13:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:52:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:52:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:52:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:52:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:52:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:52:46 --> Total execution time: 0.0046
ERROR - 2019-10-15 13:52:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:52:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:52:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:52:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:52:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:52:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:52:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:52:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:52:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 13:53:30 --> Severity: error --> Exception: syntax error, unexpected 'for' (T_FOR) /var/www/html/School19/application/views/my_class.php 65
ERROR - 2019-10-15 13:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 13:53:43 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 58
ERROR - 2019-10-15 13:53:43 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 58
DEBUG - 2019-10-15 13:53:43 --> Total execution time: 0.0063
ERROR - 2019-10-15 13:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:53:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:53:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:53:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:53:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:54:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:54:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 13:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 13:54:18 --> Total execution time: 0.0091
ERROR - 2019-10-15 13:54:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:54:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:54:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:54:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:54:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 13:54:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:54:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:54:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:54:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 13:54:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 13:54:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 13:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 13:54:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:00:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:00:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:01:52 --> Severity: Notice --> Undefined variable: j /var/www/html/School19/application/views/my_class.php 68
DEBUG - 2019-10-15 14:01:52 --> Total execution time: 0.0055
ERROR - 2019-10-15 14:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:01:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:01:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:01:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:01:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:02:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:02:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:02:18 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /var/www/html/School19/application/views/my_class.php 77
ERROR - 2019-10-15 14:02:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 64
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 64
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 64
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 64
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Undefined offset: 6 /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 14:02:27 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 64
DEBUG - 2019-10-15 14:02:27 --> Total execution time: 0.0059
ERROR - 2019-10-15 14:02:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:02:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:02:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:02:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:02:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:02:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:02:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:02:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:03:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:03:01 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /var/www/html/School19/application/views/my_class.php 76
ERROR - 2019-10-15 14:03:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:03:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:03:13 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file /var/www/html/School19/application/views/my_class.php 76
ERROR - 2019-10-15 14:03:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:03:20 --> Total execution time: 0.0063
ERROR - 2019-10-15 14:03:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:03:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:03:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:03:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:03:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:03:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:03:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:03:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:05:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:05:59 --> Total execution time: 0.0061
ERROR - 2019-10-15 14:05:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 14:05:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:05:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:05:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:05:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:05:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:05:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:05:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:07:23 --> Total execution time: 0.0117
ERROR - 2019-10-15 14:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 14:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:07:23 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:07:23 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:07:23 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:07:23 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:07:38 --> Total execution time: 0.0091
ERROR - 2019-10-15 14:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 14:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:07:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:07:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:07:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:07:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:16:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:16:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:16:50 --> Severity: Notice --> Use of undefined constant subject_allocation - assumed 'subject_allocation' /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:16:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:17:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:17:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:17:06 --> Severity: Notice --> Use of undefined constant subject_allocation - assumed 'subject_allocation' /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:17:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:17:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:17:32 --> Severity: Notice --> Use of undefined constant subject_allocation - assumed 'subject_allocation' /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:17:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:17:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:17:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:17:40 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 14:18:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:18:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:18:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:18:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:19:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:19:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:19:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:19:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:19:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:20:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:20:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:20:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:20:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:20:27 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:20:27 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:20:27 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:20:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:20:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:20:46 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:20:46 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:21:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:21:19 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:21:19 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:21:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:21:23 --> Total execution time: 0.0083
ERROR - 2019-10-15 14:21:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:21:28 --> Total execution time: 0.0085
ERROR - 2019-10-15 14:21:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:21:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:21:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:21:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:21:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:21:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:21:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:21:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:21:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:21:30 --> Total execution time: 0.0046
ERROR - 2019-10-15 14:21:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:21:31 --> Total execution time: 0.0088
ERROR - 2019-10-15 14:21:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 14:21:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:21:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:21:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:21:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:21:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:21:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:21:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:24:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:24:43 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:24:43 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:26:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:26:44 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:27:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:27:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:27:18 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:28:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:17 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:28:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:28:51 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:31:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:31:52 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 67
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:32:10 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 70
ERROR - 2019-10-15 14:33:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 69
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 71
ERROR - 2019-10-15 14:33:21 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:33:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:33:32 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sat /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:35:24 --> Severity: Notice --> Undefined index: subject_sun /var/www/html/School19/application/views/my_class.php 72
ERROR - 2019-10-15 14:36:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:36:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:36:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:37:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:37:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:37:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:37:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 14:38:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:38:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:38:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:39:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:39:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:40:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:43:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:43:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:48:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:48:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:52:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:52:35 --> Severity: Notice --> Undefined variable: sub /var/www/html/School19/application/views/my_class.php 64
ERROR - 2019-10-15 14:52:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:52:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:53:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:54:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:54:46 --> Total execution time: 0.0120
ERROR - 2019-10-15 14:54:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 14:54:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:46 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-15 14:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:54:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:54:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:47 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:54:49 --> Total execution time: 0.0091
ERROR - 2019-10-15 14:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:54:52 --> Total execution time: 0.0090
ERROR - 2019-10-15 14:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:54:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:54:55 --> Total execution time: 0.0030
ERROR - 2019-10-15 14:54:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:54:56 --> Total execution time: 0.0058
ERROR - 2019-10-15 14:54:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:54:58 --> Total execution time: 0.0109
ERROR - 2019-10-15 14:54:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 14:54:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:58 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:54:58 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:54:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:58 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:54:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:54:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:54:58 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:55:04 --> Total execution time: 0.0272
ERROR - 2019-10-15 14:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:55:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:55:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:55:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 14:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:55:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 14:56:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:56:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:56:21 --> Severity: Notice --> Undefined variable: sub /var/www/html/School19/application/views/my_class.php 64
ERROR - 2019-10-15 14:56:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:57:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 14:57:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:57:24 --> Total execution time: 0.0055
ERROR - 2019-10-15 14:57:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:24 --> UTF-8 Support Enabled
ERROR - 2019-10-15 14:57:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:57:24 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-15 14:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:57:24 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:57:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:57:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:57:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:57:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:57:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:57:28 --> Total execution time: 0.0027
ERROR - 2019-10-15 14:57:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 14:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 14:57:29 --> Total execution time: 0.0089
ERROR - 2019-10-15 14:57:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:57:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 14:57:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:57:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:57:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:57:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 14:57:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 14:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 14:57:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:01:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:01:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:02:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:02:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:03:15 --> Severity: error --> Exception: syntax error, unexpected end of file /var/www/html/School19/application/views/my_class.php 207
ERROR - 2019-10-15 15:03:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:03:39 --> Total execution time: 0.0067
ERROR - 2019-10-15 15:03:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:03:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:03:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:03:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:03:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:03:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:03:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:03:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:04:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:04:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:04:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /var/www/html/School19/application/views/my_class.php 77
ERROR - 2019-10-15 15:04:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:04:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:04:20 --> Total execution time: 0.0034
ERROR - 2019-10-15 15:04:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:04:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:04:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:04:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:04:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:04:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:04:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:04:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:07:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:07:13 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /var/www/html/School19/application/views/my_class.php 78
ERROR - 2019-10-15 15:07:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:07:21 --> Total execution time: 0.0095
ERROR - 2019-10-15 15:07:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:07:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:07:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:07:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:07:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:07:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:07:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:07:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:07:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:07:54 --> Total execution time: 0.0087
ERROR - 2019-10-15 15:07:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:07:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:07:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:07:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:07:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:07:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:07:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:07:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:07:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:08:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:08:03 --> Total execution time: 0.0053
ERROR - 2019-10-15 15:08:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:08:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:08:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:08:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:08:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:08:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:08:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:08:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:10:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:10:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:10:03 --> Severity: error --> Exception: syntax error, unexpected end of file /var/www/html/School19/application/views/my_class.php 198
ERROR - 2019-10-15 15:10:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:10:13 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/School19/application/views/my_class.php 59
ERROR - 2019-10-15 15:10:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:10:26 --> Total execution time: 0.0080
ERROR - 2019-10-15 15:10:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:10:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:10:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:10:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:10:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:10:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:10:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:10:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:22:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:22:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:22:12 --> Total execution time: 0.0063
ERROR - 2019-10-15 15:22:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:22:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:22:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:22:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:22:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:22:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:22:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:22:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:22:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:22:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:22:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:22:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:22:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:25:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:25:57 --> Total execution time: 0.0077
ERROR - 2019-10-15 15:25:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:25:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:25:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:25:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:25:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:25:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:25:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:25:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:27:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:27:20 --> Total execution time: 0.0102
ERROR - 2019-10-15 15:27:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:27:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:27:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:27:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:27:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:27:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:27:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:27:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:27:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:27:48 --> Total execution time: 0.0098
ERROR - 2019-10-15 15:27:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:27:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:27:48 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-15 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:27:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:27:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:27:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:27:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:27:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:28:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:10 --> Total execution time: 0.0074
ERROR - 2019-10-15 15:28:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:20 --> Total execution time: 0.0021
ERROR - 2019-10-15 15:28:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:23 --> No URI present. Default controller set.
DEBUG - 2019-10-15 15:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:23 --> Total execution time: 0.0132
ERROR - 2019-10-15 15:28:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:25 --> Total execution time: 0.0093
ERROR - 2019-10-15 15:28:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:28:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:25 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-15 15:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:28:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:28:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:28:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:27 --> Total execution time: 0.0029
ERROR - 2019-10-15 15:28:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:28 --> Total execution time: 0.0087
ERROR - 2019-10-15 15:28:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:35 --> Total execution time: 0.0116
ERROR - 2019-10-15 15:28:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:39 --> Total execution time: 0.0082
ERROR - 2019-10-15 15:28:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:39 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:39 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:39 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:39 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:41 --> Total execution time: 0.0026
ERROR - 2019-10-15 15:28:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:41 --> Total execution time: 0.0052
ERROR - 2019-10-15 15:28:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:28:43 --> Total execution time: 0.0082
ERROR - 2019-10-15 15:28:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:28:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:28:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:28:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:28:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:28:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:29:46 --> Total execution time: 0.0093
ERROR - 2019-10-15 15:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:29:48 --> Total execution time: 0.0096
ERROR - 2019-10-15 15:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:48 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:29:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:29:50 --> Total execution time: 0.0078
ERROR - 2019-10-15 15:29:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:50 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:29:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:50 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:29:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:50 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:29:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:50 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:29:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:29:52 --> Total execution time: 0.0040
ERROR - 2019-10-15 15:29:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:29:53 --> Total execution time: 0.0047
ERROR - 2019-10-15 15:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:29:54 --> Total execution time: 0.0107
ERROR - 2019-10-15 15:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 15:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:29:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 15:30:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:30:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2672
ERROR - 2019-10-15 15:30:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2672
ERROR - 2019-10-15 15:30:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2673
ERROR - 2019-10-15 15:30:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2673
DEBUG - 2019-10-15 15:30:16 --> Total execution time: 0.0043
ERROR - 2019-10-15 15:30:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:30:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:30:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:30:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:30:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:30:18 --> Total execution time: 0.0030
ERROR - 2019-10-15 15:30:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:24 --> No URI present. Default controller set.
DEBUG - 2019-10-15 15:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:30:24 --> Total execution time: 0.0079
ERROR - 2019-10-15 15:30:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:30:29 --> Total execution time: 0.0084
ERROR - 2019-10-15 15:30:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:30:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:30:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:30:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:30:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:30:30 --> Total execution time: 0.0085
ERROR - 2019-10-15 15:30:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:30:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:30 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 15:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:30:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:30:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:30:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:32:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:32:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:32:12 --> Total execution time: 0.0094
ERROR - 2019-10-15 15:32:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:32:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:32:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:32:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:32:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:32:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:32:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:32:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:32:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:32:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:32:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:32:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:32:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:35:40 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/my_class.php 73
ERROR - 2019-10-15 15:35:40 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/my_class.php 73
ERROR - 2019-10-15 15:35:40 --> Severity: Notice --> Undefined property: stdClass::$class /var/www/html/School19/application/views/my_class.php 73
DEBUG - 2019-10-15 15:35:40 --> Total execution time: 0.0089
ERROR - 2019-10-15 15:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:35:40 --> UTF-8 Support Enabled
ERROR - 2019-10-15 15:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:35:40 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:35:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:35:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:35:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:36:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:36:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:36:03 --> Total execution time: 0.0081
ERROR - 2019-10-15 15:36:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:36:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:36:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:36:03 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-15 15:36:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:36:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:36:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:36:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:37:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:37:27 --> Total execution time: 0.0078
ERROR - 2019-10-15 15:37:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:37:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:37:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:37:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:37:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:37:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:37:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:37:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:37:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:40:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:40:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:40:11 --> Severity: error --> Exception: syntax error, unexpected end of file /var/www/html/School19/application/views/my_class.php 293
ERROR - 2019-10-15 15:41:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:41:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:41:09 --> Total execution time: 0.0107
ERROR - 2019-10-15 15:41:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:41:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:41:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:41:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:41:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:41:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:41:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:41:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:41:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:41:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:41:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:41:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:42:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:42:39 --> Total execution time: 0.0118
ERROR - 2019-10-15 15:42:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:42:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:42:53 --> Total execution time: 0.0043
ERROR - 2019-10-15 15:42:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:42:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:42:55 --> No URI present. Default controller set.
DEBUG - 2019-10-15 15:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:42:55 --> Total execution time: 0.0080
ERROR - 2019-10-15 15:42:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:42:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:42:57 --> Total execution time: 0.0094
ERROR - 2019-10-15 15:43:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:43:00 --> Total execution time: 0.0021
ERROR - 2019-10-15 15:43:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:43:01 --> Total execution time: 0.0029
ERROR - 2019-10-15 15:43:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:43:06 --> Total execution time: 0.1284
ERROR - 2019-10-15 15:43:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:43:09 --> Total execution time: 0.0028
ERROR - 2019-10-15 15:43:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:13 --> No URI present. Default controller set.
DEBUG - 2019-10-15 15:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:43:13 --> Total execution time: 0.0090
ERROR - 2019-10-15 15:43:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:43:19 --> Total execution time: 0.0106
ERROR - 2019-10-15 15:43:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:43:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:43:19 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-15 15:43:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:43:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:43:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:43:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:43:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:43:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:43:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:43:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 15:46:59 --> Total execution time: 0.0115
ERROR - 2019-10-15 15:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:46:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:46:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:46:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:47:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:47:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:47:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:49:31 --> Severity: Notice --> Use of undefined constant sections_id - assumed 'sections_id' /var/www/html/School19/application/models/M_timetables.php 161
ERROR - 2019-10-15 15:49:31 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:31 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:31 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:31 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-15 15:49:31 --> Total execution time: 0.0162
ERROR - 2019-10-15 15:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:49:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:32 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:49:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:32 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:49:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:49:56 --> Severity: Notice --> Use of undefined constant sections_id - assumed 'sections_id' /var/www/html/School19/application/models/M_timetables.php 161
ERROR - 2019-10-15 15:49:56 --> Query error: Unknown column 'f.sections' in 'where clause' - Invalid query: SELECT `f`.*, `sec`.`sections`
FROM `timetable` `f`
LEFT JOIN `sections` `sec` ON `f`.`sections_id`=`sec`.`id`
WHERE `f`.`school_id` = '3'
AND `f`.`sections` = 'sections_id'
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 58
ERROR - 2019-10-15 15:49:56 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 83
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 98
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 113
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 128
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 143
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 158
ERROR - 2019-10-15 15:49:56 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:56 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-15 15:49:56 --> Total execution time: 0.0078
ERROR - 2019-10-15 15:49:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:49:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:49:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:49:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:49:59 --> Severity: Notice --> Use of undefined constant sections_id - assumed 'sections_id' /var/www/html/School19/application/models/M_timetables.php 161
ERROR - 2019-10-15 15:49:59 --> Query error: Unknown column 'f.section' in 'where clause' - Invalid query: SELECT `f`.*, `sec`.`sections`
FROM `timetable` `f`
LEFT JOIN `sections` `sec` ON `f`.`sections_id`=`sec`.`id`
WHERE `f`.`school_id` = '3'
AND `f`.`section` = 'sections_id'
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 58
ERROR - 2019-10-15 15:49:59 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 83
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 98
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 113
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 128
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 143
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 158
ERROR - 2019-10-15 15:49:59 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:49:59 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-15 15:49:59 --> Total execution time: 0.0063
ERROR - 2019-10-15 15:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:49:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:50:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:50:08 --> Query error: Unknown column 'f.sections' in 'where clause' - Invalid query: SELECT `f`.*, `sec`.`sections`
FROM `timetable` `f`
LEFT JOIN `sections` `sec` ON `f`.`sections_id`=`sec`.`id`
WHERE `f`.`school_id` = '3'
AND `f`.`sections` = '5'
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 58
ERROR - 2019-10-15 15:50:08 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 68
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 83
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 98
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 113
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 128
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 143
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/my_class.php 158
ERROR - 2019-10-15 15:50:08 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:50:08 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-15 15:50:08 --> Total execution time: 0.0095
ERROR - 2019-10-15 15:50:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 15:50:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:50:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:50:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:50:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:50:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:50:17 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:50:17 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:50:17 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:50:17 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-15 15:50:17 --> Total execution time: 0.0081
ERROR - 2019-10-15 15:50:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:50:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:50:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:50:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:50:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:50:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:51:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:51:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:51:19 --> Severity: Notice --> Undefined property: stdClass::$id /var/www/html/School19/application/controllers/Welcome.php 2673
ERROR - 2019-10-15 15:51:19 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:51:19 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:51:19 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 15:51:19 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-15 15:51:19 --> Total execution time: 0.0134
ERROR - 2019-10-15 15:51:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:51:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:51:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:51:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:51:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:51:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:51:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:51:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:51:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 15:51:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:51:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 15:51:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 15:51:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:51:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:52:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:52:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 15:52:09 --> Query error: Unknown column 'sa.sections_id' in 'field list' - Invalid query: SELECT `sa`.`subject`, `sa`.`sections_id`
FROM `subject_allocation` `s`
LEFT JOIN `subject` `sa` ON `sa`.`id` = `s`.`subject_id`
WHERE `s`.`teachers_id` = '5'
ERROR - 2019-10-15 15:52:09 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_subject_allocation.php 95
ERROR - 2019-10-15 15:52:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 15:52:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 15:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 15:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:21:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:21:29 --> Total execution time: 0.0081
ERROR - 2019-10-15 16:21:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:43 --> No URI present. Default controller set.
DEBUG - 2019-10-15 16:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:21:43 --> Total execution time: 0.0091
ERROR - 2019-10-15 16:21:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:21:50 --> Total execution time: 0.0047
ERROR - 2019-10-15 16:21:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:21:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:21:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:21:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:21:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:21:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:21:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:21:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:21:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:21:52 --> Total execution time: 0.0037
ERROR - 2019-10-15 16:21:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:21:53 --> Total execution time: 0.0068
ERROR - 2019-10-15 16:21:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:21:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:21:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:21:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:21:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:21:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:21:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:21:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:21:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:22:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:22:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:22:17 --> Severity: Notice --> Undefined property: stdClass::$id /var/www/html/School19/application/controllers/Welcome.php 2674
ERROR - 2019-10-15 16:22:17 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 16:22:17 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 16:22:17 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-15 16:22:17 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-15 16:22:17 --> Total execution time: 0.0050
ERROR - 2019-10-15 16:22:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:22:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:22:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:22:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:22:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:22:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:22:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:22:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:22:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:22:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:22:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:22:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:22:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:22:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:22:41 --> Severity: Notice --> Undefined property: stdClass::$id /var/www/html/School19/application/controllers/Welcome.php 2674
ERROR - 2019-10-15 16:23:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:23:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:23:16 --> Total execution time: 0.0025
ERROR - 2019-10-15 16:23:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:23:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:23:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:23:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:23:39 --> No URI present. Default controller set.
DEBUG - 2019-10-15 16:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:23:39 --> Total execution time: 0.0026
ERROR - 2019-10-15 16:23:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:23:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:23:44 --> No URI present. Default controller set.
DEBUG - 2019-10-15 16:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:23:44 --> Total execution time: 0.0121
ERROR - 2019-10-15 16:23:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:24:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:24:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:25:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:25:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:26:06 --> Total execution time: 0.0093
ERROR - 2019-10-15 16:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:26:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:26:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:26:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:26:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:30:00 --> Severity: error --> Exception: syntax error, unexpected end of file /var/www/html/School19/application/views/timetables.php 248
ERROR - 2019-10-15 16:30:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:30:15 --> Severity: error --> Exception: syntax error, unexpected end of file /var/www/html/School19/application/views/timetables.php 248
ERROR - 2019-10-15 16:30:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:31 --> Total execution time: 0.0114
ERROR - 2019-10-15 16:30:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:30:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:30:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:30:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:30:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:35 --> Total execution time: 0.0030
ERROR - 2019-10-15 16:30:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:36 --> Total execution time: 0.0028
ERROR - 2019-10-15 16:30:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:38 --> Total execution time: 0.0104
ERROR - 2019-10-15 16:30:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:30:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:30:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:30:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:30:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:43 --> Total execution time: 0.0026
ERROR - 2019-10-15 16:30:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:45 --> Total execution time: 0.0026
ERROR - 2019-10-15 16:30:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:47 --> Total execution time: 0.0052
ERROR - 2019-10-15 16:30:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:50 --> Total execution time: 0.0035
ERROR - 2019-10-15 16:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:30:52 --> Total execution time: 0.0067
ERROR - 2019-10-15 16:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:30:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:31:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:31:02 --> Total execution time: 0.0088
ERROR - 2019-10-15 16:31:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:31:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:31:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:31:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:31:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:31:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:31:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:31:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:31:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:31:04 --> Total execution time: 0.0022
ERROR - 2019-10-15 16:31:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:31:06 --> Total execution time: 0.0077
ERROR - 2019-10-15 16:31:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:31:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:31:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:31:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:31:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:31:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 16:31:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:31:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 16:47:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:47:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:47:01 --> Total execution time: 0.0379
ERROR - 2019-10-15 16:47:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:47:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:47:04 --> No URI present. Default controller set.
DEBUG - 2019-10-15 16:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:47:04 --> Total execution time: 0.0112
ERROR - 2019-10-15 16:47:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:47:06 --> Total execution time: 0.0991
ERROR - 2019-10-15 16:47:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:47:06 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-15 16:47:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:47:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:47:08 --> Total execution time: 0.0026
ERROR - 2019-10-15 16:47:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:47:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:47:08 --> Total execution time: 0.0025
ERROR - 2019-10-15 16:54:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:54:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:54:55 --> Total execution time: 0.0113
ERROR - 2019-10-15 16:54:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:54:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:54:55 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-15 16:54:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:54:56 --> Total execution time: 0.0037
ERROR - 2019-10-15 16:54:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:54:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:54:56 --> Total execution time: 0.0022
ERROR - 2019-10-15 16:55:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:55:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:55:44 --> Total execution time: 0.0105
ERROR - 2019-10-15 16:55:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:55:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:55:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:55:44 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-15 16:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 16:56:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:56:06 --> Total execution time: 0.2565
DEBUG - 2019-10-15 16:56:06 --> Total execution time: 0.4204
ERROR - 2019-10-15 16:56:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:56:07 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-15 16:58:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:58:45 --> Total execution time: 0.0046
ERROR - 2019-10-15 16:58:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:58:45 --> Total execution time: 0.0039
ERROR - 2019-10-15 16:58:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:58:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:58:52 --> Total execution time: 0.0607
ERROR - 2019-10-15 16:59:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:59:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:59:00 --> Total execution time: 0.0497
ERROR - 2019-10-15 16:59:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:59:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:59:07 --> Total execution time: 0.0304
ERROR - 2019-10-15 16:59:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:59:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:59:13 --> Total execution time: 0.0379
ERROR - 2019-10-15 16:59:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:59:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 16:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 16:59:20 --> Total execution time: 0.0376
ERROR - 2019-10-15 16:59:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:59:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:59:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:59:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:59:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:59:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:59:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:59:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 16:59:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:59:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 16:59:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 16:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 16:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 16:59:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:00:36 --> Total execution time: 0.0088
ERROR - 2019-10-15 17:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 17:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:00:36 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-15 17:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:00:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:00:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:00:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:00:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:00:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:01:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:01:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:01:07 --> Total execution time: 0.0078
ERROR - 2019-10-15 17:01:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:01:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:01:17 --> Total execution time: 0.0120
ERROR - 2019-10-15 17:01:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:01:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:01:56 --> Total execution time: 0.0084
ERROR - 2019-10-15 17:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:02:13 --> Total execution time: 0.0095
ERROR - 2019-10-15 17:02:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:02:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:02:44 --> Total execution time: 0.0108
ERROR - 2019-10-15 17:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:02:55 --> Total execution time: 0.0259
ERROR - 2019-10-15 17:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:02:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:02:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:02:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:02:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:02:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:02:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:02:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:02:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:03:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:03:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:03:51 --> Total execution time: 0.0116
ERROR - 2019-10-15 17:03:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 17:03:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:03:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:03:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:03:51 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 17:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:03:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:03:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:03:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:03:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:03:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:03:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:03:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:04:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:04:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:04:12 --> Total execution time: 0.0070
ERROR - 2019-10-15 17:04:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:04:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:04:25 --> Total execution time: 0.0918
ERROR - 2019-10-15 17:04:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:04:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:04:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:04:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:04:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:04:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:04:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:04:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:04:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:04:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:04:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:04:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:05:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:05:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:05:49 --> Total execution time: 0.0101
ERROR - 2019-10-15 17:06:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:06:23 --> Total execution time: 0.0061
ERROR - 2019-10-15 17:06:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:06:23 --> Total execution time: 0.0093
ERROR - 2019-10-15 17:06:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:06:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:06:49 --> Total execution time: 0.0088
ERROR - 2019-10-15 17:07:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:07:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:07:06 --> Total execution time: 0.0107
ERROR - 2019-10-15 17:07:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:07:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:07:41 --> Total execution time: 0.0117
ERROR - 2019-10-15 17:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:07:50 --> Total execution time: 0.0083
ERROR - 2019-10-15 17:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:07:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:07:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:07:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:07:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:08:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:08:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:08:26 --> Total execution time: 0.0027
ERROR - 2019-10-15 17:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:08:27 --> Total execution time: 0.0097
ERROR - 2019-10-15 17:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 17:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:08:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 17:08:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 17:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:08:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-15 17:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:08:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-15 17:08:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:08:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:08:56 --> Total execution time: 0.0078
ERROR - 2019-10-15 17:09:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:25 --> Total execution time: 0.0078
ERROR - 2019-10-15 17:09:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:41 --> Total execution time: 0.0127
ERROR - 2019-10-15 17:09:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:44 --> Total execution time: 0.0291
ERROR - 2019-10-15 17:09:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 17:09:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:09:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:09:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:09:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:09:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:09:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:09:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:09:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:48 --> Total execution time: 0.0037
ERROR - 2019-10-15 17:09:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:52 --> No URI present. Default controller set.
DEBUG - 2019-10-15 17:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:52 --> Total execution time: 0.0118
ERROR - 2019-10-15 17:09:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:54 --> Total execution time: 0.0118
ERROR - 2019-10-15 17:09:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:56 --> Total execution time: 0.0067
ERROR - 2019-10-15 17:09:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:57 --> Total execution time: 0.0073
ERROR - 2019-10-15 17:09:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:09:59 --> Total execution time: 0.0088
ERROR - 2019-10-15 17:09:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:09:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:09:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:09:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:09:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:09:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:09:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:09:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:09:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:09:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:10:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:10:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:10:01 --> Total execution time: 0.0076
ERROR - 2019-10-15 17:10:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:10:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:10:03 --> Total execution time: 0.0361
ERROR - 2019-10-15 17:10:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 17:10:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:10:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:10:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:10:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:10:03 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 17:10:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:10:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:10:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:10:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:10:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:10:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:10:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:10:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:10:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:10:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:11:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:11:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:11:05 --> Total execution time: 0.0095
ERROR - 2019-10-15 17:11:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:11:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:11:11 --> Total execution time: 0.0055
ERROR - 2019-10-15 17:11:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:11:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:11:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:11:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:11:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:11:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:11:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:11:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:11:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:11:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:11:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:11:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:12:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:12:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:12:00 --> Total execution time: 0.0052
ERROR - 2019-10-15 17:12:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:12:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:12:07 --> Total execution time: 0.0279
ERROR - 2019-10-15 17:12:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 17:12:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:12:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:12:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:12:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:12:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:12:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:12:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:12:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:12:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:12:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:12:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:13:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:13:01 --> Total execution time: 0.0036
ERROR - 2019-10-15 17:14:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:14:42 --> Total execution time: 0.0106
ERROR - 2019-10-15 17:14:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:14:51 --> Total execution time: 0.4919
ERROR - 2019-10-15 17:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:14:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:14:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:14:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:14:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:14:59 --> 404 Page Not Found: Attendancesphp/index
ERROR - 2019-10-15 17:15:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:15:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 17:15:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:15:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:15:01 --> Total execution time: 0.5099
DEBUG - 2019-10-15 17:15:01 --> Total execution time: 0.0704
ERROR - 2019-10-15 17:25:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:15 --> Total execution time: 0.0032
ERROR - 2019-10-15 17:25:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:23 --> No URI present. Default controller set.
DEBUG - 2019-10-15 17:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:23 --> Total execution time: 0.0076
ERROR - 2019-10-15 17:25:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:26 --> Total execution time: 0.0248
ERROR - 2019-10-15 17:25:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:25:26 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-15 17:25:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:36 --> Total execution time: 0.0210
ERROR - 2019-10-15 17:25:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:43 --> Total execution time: 0.0510
ERROR - 2019-10-15 17:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:44 --> Total execution time: 0.0038
ERROR - 2019-10-15 17:25:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:46 --> Total execution time: 0.0473
ERROR - 2019-10-15 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:25:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:25:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:25:46 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-15 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:25:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:25:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:25:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:49 --> Total execution time: 0.0028
ERROR - 2019-10-15 17:25:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:25:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:25:52 --> No URI present. Default controller set.
DEBUG - 2019-10-15 17:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:25:52 --> Total execution time: 0.0080
ERROR - 2019-10-15 17:27:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:27:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:27:19 --> Total execution time: 0.0023
ERROR - 2019-10-15 17:27:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:27:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:27:24 --> No URI present. Default controller set.
DEBUG - 2019-10-15 17:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:27:24 --> Total execution time: 0.0087
ERROR - 2019-10-15 17:27:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:27:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:27:31 --> Total execution time: 0.0097
ERROR - 2019-10-15 17:28:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:28:32 --> Total execution time: 0.4888
ERROR - 2019-10-15 17:28:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 17:28:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:32 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 17:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:32 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:28:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:28:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:28:40 --> Total execution time: 0.0106
ERROR - 2019-10-15 17:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:28:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:28:44 --> 404 Page Not Found: Class_attendancephp/index
ERROR - 2019-10-15 17:28:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:28:46 --> Total execution time: 0.0075
ERROR - 2019-10-15 17:28:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:28:47 --> Total execution time: 0.6770
ERROR - 2019-10-15 17:28:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:28:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:28:48 --> Total execution time: 0.0091
ERROR - 2019-10-15 17:42:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:42:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:42:09 --> Total execution time: 0.0083
ERROR - 2019-10-15 17:46:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:46:12 --> Total execution time: 0.5567
ERROR - 2019-10-15 17:46:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:46:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:46:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:46:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:46:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:46:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:46:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:46:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:46:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:46:29 --> Total execution time: 0.0098
ERROR - 2019-10-15 17:46:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:46:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:46:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:46:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:46:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:46:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:46:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:46:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:46:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:46:35 --> Total execution time: 0.5075
ERROR - 2019-10-15 17:46:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:46:36 --> Total execution time: 0.0071
ERROR - 2019-10-15 17:46:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:46:47 --> Total execution time: 0.0085
ERROR - 2019-10-15 17:46:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:46:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:46:50 --> Total execution time: 0.0086
ERROR - 2019-10-15 17:49:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:49:35 --> Total execution time: 0.0082
ERROR - 2019-10-15 17:49:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:49:36 --> Total execution time: 0.0067
ERROR - 2019-10-15 17:49:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:36 --> UTF-8 Support Enabled
ERROR - 2019-10-15 17:49:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:49:36 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 17:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:49:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:49:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:49:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 17:49:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 17:49:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 17:49:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:49:41 --> Total execution time: 0.0042
ERROR - 2019-10-15 17:49:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:49:43 --> Total execution time: 0.0074
ERROR - 2019-10-15 17:49:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:49:44 --> Total execution time: 0.0113
ERROR - 2019-10-15 17:49:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:49:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 17:49:46 --> Total execution time: 0.0063
ERROR - 2019-10-15 17:50:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 65
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 66
ERROR - 2019-10-15 17:50:22 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 79
DEBUG - 2019-10-15 17:50:22 --> Total execution time: 0.0085
ERROR - 2019-10-15 17:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:02 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 72
DEBUG - 2019-10-15 17:55:02 --> Total execution time: 0.0125
ERROR - 2019-10-15 17:55:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:12 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 72
DEBUG - 2019-10-15 17:55:12 --> Total execution time: 0.0125
ERROR - 2019-10-15 17:55:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:55:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 72
DEBUG - 2019-10-15 17:55:28 --> Total execution time: 0.0133
ERROR - 2019-10-15 17:55:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 17:55:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 17:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 17:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 17:55:38 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 72
DEBUG - 2019-10-15 17:55:38 --> Total execution time: 0.0125
ERROR - 2019-10-15 18:09:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:09:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:09:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 72
DEBUG - 2019-10-15 18:09:54 --> Total execution time: 0.0109
ERROR - 2019-10-15 18:28:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:28:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:13 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:28:13 --> Total execution time: 0.0215
ERROR - 2019-10-15 18:28:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:28:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:28 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:28:28 --> Total execution time: 0.0120
ERROR - 2019-10-15 18:28:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:28:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:28:43 --> Total execution time: 0.0149
ERROR - 2019-10-15 18:28:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:28:59 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:28:59 --> Total execution time: 0.0119
ERROR - 2019-10-15 18:29:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:29:05 --> Total execution time: 0.0064
ERROR - 2019-10-15 18:29:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:29:09 --> Total execution time: 0.0038
ERROR - 2019-10-15 18:29:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:29:10 --> Total execution time: 0.0065
ERROR - 2019-10-15 18:29:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:29:11 --> Total execution time: 0.0072
ERROR - 2019-10-15 18:29:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:29:13 --> Total execution time: 0.0088
ERROR - 2019-10-15 18:29:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:13 --> UTF-8 Support Enabled
ERROR - 2019-10-15 18:29:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:29:13 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 18:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:29:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 18:29:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:29:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 18:29:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:29:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 18:29:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:29:14 --> Total execution time: 0.0092
ERROR - 2019-10-15 18:29:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:29:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:29:18 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:29:18 --> Total execution time: 0.0104
ERROR - 2019-10-15 18:30:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:30:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:30:39 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:30:39 --> Total execution time: 0.0088
ERROR - 2019-10-15 18:31:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:31:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:31:41 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:31:41 --> Total execution time: 0.0095
ERROR - 2019-10-15 18:33:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:33:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:33:30 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:33:30 --> Total execution time: 0.0111
ERROR - 2019-10-15 18:34:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:34:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:34:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:34:05 --> Total execution time: 0.0112
ERROR - 2019-10-15 18:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:35:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:35:27 --> Total execution time: 0.5975
ERROR - 2019-10-15 18:35:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:35:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:35:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 18:35:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:35:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:35:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 18:35:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:35:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:35:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 18:35:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:35:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:35:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 18:35:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:35:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:35:29 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:35:29 --> Total execution time: 0.0098
ERROR - 2019-10-15 18:38:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:38:39 --> Total execution time: 0.0061
ERROR - 2019-10-15 18:38:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:38:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:38:42 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:38:42 --> Total execution time: 0.0107
ERROR - 2019-10-15 18:39:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:39:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:05 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:39:05 --> Total execution time: 0.0083
ERROR - 2019-10-15 18:39:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:39:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:39:07 --> 404 Page Not Found: Welcome/attemdances
ERROR - 2019-10-15 18:39:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:39:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:14 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:39:14 --> Total execution time: 0.0096
ERROR - 2019-10-15 18:39:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:39:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:39:16 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:39:16 --> Total execution time: 0.0082
ERROR - 2019-10-15 18:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:53:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:53:57 --> Total execution time: 0.0103
ERROR - 2019-10-15 18:54:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:54:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:37 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:54:37 --> Total execution time: 0.0162
ERROR - 2019-10-15 18:54:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:54:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:54:57 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:54:57 --> Total execution time: 0.0173
ERROR - 2019-10-15 18:55:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:55:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:55:09 --> Total execution time: 0.0037
ERROR - 2019-10-15 18:55:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:55:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:55:11 --> No URI present. Default controller set.
DEBUG - 2019-10-15 18:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:55:11 --> Total execution time: 0.0105
ERROR - 2019-10-15 18:55:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:55:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:55:15 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:55:15 --> Total execution time: 0.0116
ERROR - 2019-10-15 18:56:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:04 --> Total execution time: 0.0102
ERROR - 2019-10-15 18:56:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:17 --> Total execution time: 0.0201
ERROR - 2019-10-15 18:56:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:20 --> Total execution time: 0.0060
ERROR - 2019-10-15 18:56:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:23 --> Total execution time: 0.0030
ERROR - 2019-10-15 18:56:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:25 --> Total execution time: 0.0055
ERROR - 2019-10-15 18:56:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:28 --> Total execution time: 0.0041
ERROR - 2019-10-15 18:56:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:30 --> Total execution time: 0.0023
ERROR - 2019-10-15 18:56:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:37 --> Total execution time: 0.0218
ERROR - 2019-10-15 18:56:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:39 --> Total execution time: 0.0080
ERROR - 2019-10-15 18:56:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 18:56:39 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-15 18:56:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:40 --> Total execution time: 0.0040
ERROR - 2019-10-15 18:56:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:40 --> Total execution time: 0.0028
ERROR - 2019-10-15 18:56:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:42 --> Total execution time: 0.0049
ERROR - 2019-10-15 18:56:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:44 --> Total execution time: 0.0039
ERROR - 2019-10-15 18:56:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:47 --> Total execution time: 0.0045
ERROR - 2019-10-15 18:56:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 18:56:51 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 18:56:51 --> Total execution time: 0.0129
ERROR - 2019-10-15 18:56:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:55 --> Total execution time: 0.0071
ERROR - 2019-10-15 18:56:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:57 --> Total execution time: 0.0077
ERROR - 2019-10-15 18:56:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:56:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:56:59 --> Total execution time: 0.0110
ERROR - 2019-10-15 18:57:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:57:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:57:00 --> Total execution time: 0.0084
ERROR - 2019-10-15 18:57:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:57:03 --> Total execution time: 0.0053
ERROR - 2019-10-15 18:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:57:05 --> Total execution time: 0.0028
ERROR - 2019-10-15 18:57:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:57:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:57:08 --> Total execution time: 0.0028
ERROR - 2019-10-15 18:57:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:57:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:57:20 --> Total execution time: 0.0615
ERROR - 2019-10-15 18:57:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:57:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:57:20 --> Total execution time: 0.0112
ERROR - 2019-10-15 18:57:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 18:57:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 18:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 18:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 18:57:34 --> Total execution time: 0.0090
ERROR - 2019-10-15 19:01:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 19:01:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 19:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 19:01:23 --> Total execution time: 0.0090
ERROR - 2019-10-15 19:01:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 19:01:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 19:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:01:24 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 19:01:24 --> Total execution time: 0.0095
ERROR - 2019-10-15 19:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 19:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 19:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 19:01:28 --> Total execution time: 0.0040
ERROR - 2019-10-15 19:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-15 19:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 19:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 19:01:28 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-15 19:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 19:01:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 19:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 19:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 19:01:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-15 19:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 19:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-15 19:01:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-15 19:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 19:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 19:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-15 19:01:29 --> Total execution time: 0.0062
ERROR - 2019-10-15 19:02:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-15 19:02:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-15 19:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-15 19:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-15 19:02:23 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-15 19:02:23 --> Total execution time: 0.0127
