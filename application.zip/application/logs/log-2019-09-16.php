<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-16 15:15:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:15:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:15:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:15:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:15:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:15:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:15:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:15:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:15:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:15:35 --> Severity: error --> Exception: syntax error, unexpected '"fcm_token"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/school/application/models/M_login.php 58
ERROR - 2019-09-16 15:15:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:15:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:15:35 --> Severity: error --> Exception: syntax error, unexpected '"fcm_token"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/school/application/models/M_login.php 58
ERROR - 2019-09-16 15:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:16:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:16:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:16:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:16:52 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-16 15:16:52 --> Total execution time: 0.0154
ERROR - 2019-09-16 15:17:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:17:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:17:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:17:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:17:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:17:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:17:07 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-16 15:17:07 --> Total execution time: 0.0047
ERROR - 2019-09-16 15:27:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:27:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:27:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:27:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:27:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:27:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:27:57 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-16 15:27:57 --> Total execution time: 0.0055
ERROR - 2019-09-16 15:31:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:31:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:31:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:31:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:31:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:31:51 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-16 15:31:51 --> Total execution time: 0.0074
ERROR - 2019-09-16 15:35:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:35:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:35:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:35:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:35:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:35:27 --> Severity: Notice --> Undefined index: fcm_token /var/www/html/school/application/controllers/Api.php 37
DEBUG - 2019-09-16 15:35:27 --> Total execution time: 0.0018
ERROR - 2019-09-16 15:37:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:37:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:37:01 --> Total execution time: 0.0018
ERROR - 2019-09-16 15:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:37:13 --> Total execution time: 0.0049
ERROR - 2019-09-16 15:37:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:37:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:37:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:37:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:37:14 --> Total execution time: 0.0070
ERROR - 2019-09-16 15:37:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:37:14 --> Total execution time: 0.0048
ERROR - 2019-09-16 15:37:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:37:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:37:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:37:32 --> Total execution time: 0.0049
ERROR - 2019-09-16 15:37:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:37:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:37:48 --> Total execution time: 0.0019
ERROR - 2019-09-16 15:37:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:37:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:37:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:37:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:37:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:37:56 --> Total execution time: 0.0048
ERROR - 2019-09-16 15:38:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:38:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:38:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_mbstring.dll' - /usr/lib/php/20151012/php_mbstring.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-09-16 15:38:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:38:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:38:22 --> Total execution time: 0.0033
ERROR - 2019-09-16 15:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:38:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-16 15:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-16 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-16 15:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-16 15:38:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-16 15:38:30 --> Total execution time: 0.0046
