<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-20 05:01:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:01:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:01:43 --> No URI present. Default controller set.
DEBUG - 2019-09-20 05:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-20 05:01:43 --> Total execution time: 0.0445
ERROR - 2019-09-20 05:01:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:01:52 --> No URI present. Default controller set.
DEBUG - 2019-09-20 05:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-20 05:01:52 --> Total execution time: 0.0123
ERROR - 2019-09-20 05:04:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:04:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:04:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:04:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:04:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:04:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:04:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:04:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:04:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:04:55 --> Total execution time: 0.0043
ERROR - 2019-09-20 05:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:04:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:04:56 --> Total execution time: 0.0039
ERROR - 2019-09-20 05:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:04:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:04:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:04:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1317
DEBUG - 2019-09-20 05:04:56 --> Total execution time: 0.0043
ERROR - 2019-09-20 05:05:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:05:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:05:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:05:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:05:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:05:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:05:17 --> Total execution time: 0.0045
ERROR - 2019-09-20 05:05:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:05:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:05:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:05:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:05:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:05:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:05:20 --> Total execution time: 0.0024
ERROR - 2019-09-20 05:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-20 05:05:33 --> Total execution time: 0.0093
ERROR - 2019-09-20 05:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:05:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-20 05:05:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:05:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:05:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-20 05:05:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:05:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:05:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-20 05:07:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:07:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:07:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:07:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:07:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:07:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:07:24 --> Total execution time: 0.0030
ERROR - 2019-09-20 05:07:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:07:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-20 05:07:44 --> ROLE ::::: driver
ERROR - 2019-09-20 05:07:44 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 2
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4905991  Threads: 1  Questions: 201499  Slow queries: 0  Opens: 6949  Flush tables: 1  Open tables: 825  Queries per second avg: 0.041
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 42345
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 2
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-20 05:07:44 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-20 05:07:44 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-20 05:07:44 --> HELLO
DEBUG - 2019-09-20 05:07:44 --> {"multicast_id":4643955221457597751,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568956064817895%ec14b888ec14b888"},{"message_id":"0:1568956064865893%ec14b888ec14b888"}]}
DEBUG - 2019-09-20 05:07:44 --> Total execution time: 0.1169
ERROR - 2019-09-20 05:07:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:07:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:07:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-20 05:07:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:07:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:07:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-20 05:08:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-20 05:08:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-20 05:08:10 --> Total execution time: 0.0051
ERROR - 2019-09-20 05:08:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-20 05:08:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-20 05:08:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-20 05:08:10 --> Total execution time: 0.0049
ERROR - 2019-09-20 05:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-20 05:08:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-20 05:08:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-20 05:08:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-20 05:08:15 --> Total execution time: 0.0049
ERROR - 2019-09-20 05:08:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-20 05:08:16 --> Total execution time: 0.0035
ERROR - 2019-09-20 05:08:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-20 05:08:19 --> Total execution time: 0.0035
ERROR - 2019-09-20 05:08:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:24 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:24 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:24 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:24 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-20 05:08:24 --> Total execution time: 0.0036
ERROR - 2019-09-20 05:08:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:08:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:08:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:08:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:08:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-20 05:08:33 --> Total execution time: 0.0037
ERROR - 2019-09-20 05:09:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:09:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:09:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:09:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:09:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:09:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:09:24 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:09:24 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:09:24 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-20 05:09:24 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-20 05:09:24 --> Total execution time: 0.0038
ERROR - 2019-09-20 05:10:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:10:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:10:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:10:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:10:26 --> Total execution time: 0.0040
ERROR - 2019-09-20 05:10:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:10:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:10:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:10:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:10:58 --> Total execution time: 0.0049
ERROR - 2019-09-20 05:10:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:10:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:10:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:10:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:10:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:10:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:10:59 --> Total execution time: 0.0026
ERROR - 2019-09-20 05:11:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:11:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-20 05:11:43 --> ROLE ::::: teacher
DEBUG - 2019-09-20 05:11:43 --> Array
(
    [0] => eqdGug4Wf3o:APA91bEzfGTvdDy5zSWdR_rlKYuB-cJDwa9OMRB3Bv-uSbCoQoAdsZHONEB04SenWIsn48albucxuDdj4mOUlRLB5uOXILAXGcR0U3Au3CKjfAMQVKMUsOE4D93aJguR6QlqahN4cqee
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-20 05:11:43 --> Array
(
    [0] => eqdGug4Wf3o:APA91bEzfGTvdDy5zSWdR_rlKYuB-cJDwa9OMRB3Bv-uSbCoQoAdsZHONEB04SenWIsn48albucxuDdj4mOUlRLB5uOXILAXGcR0U3Au3CKjfAMQVKMUsOE4D93aJguR6QlqahN4cqee
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-20 05:11:43 --> HELLO
DEBUG - 2019-09-20 05:11:43 --> {"multicast_id":5245741855069935137,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568956303076723%ec14b888ec14b888"},{"message_id":"0:1568956303094464%ec14b888ec14b888"}]}
DEBUG - 2019-09-20 05:11:43 --> Total execution time: 0.1009
ERROR - 2019-09-20 05:11:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:11:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-20 05:11:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:11:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-20 05:11:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:11:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:11:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:11:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:11:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:11:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:11:56 --> Total execution time: 0.0026
ERROR - 2019-09-20 05:12:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:12:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:12:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:12:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:12:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:12:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:12:11 --> Total execution time: 0.0026
ERROR - 2019-09-20 05:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:12:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-20 05:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:12:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-20 05:12:19 --> Total execution time: 0.0026
ERROR - 2019-09-20 05:13:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-20 05:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-20 05:13:31 --> Total execution time: 0.0066
ERROR - 2019-09-20 05:13:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:13:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-20 05:13:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-20 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-20 05:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-20 05:13:31 --> 404 Page Not Found: Js/examples
