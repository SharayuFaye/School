<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-22 10:26:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:26:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:26:35 --> Total execution time: 3.8884
ERROR - 2019-10-22 10:27:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:27:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:27:02 --> No URI present. Default controller set.
DEBUG - 2019-10-22 10:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:27:09 --> Total execution time: 6.8515
ERROR - 2019-10-22 10:27:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:27:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:27:46 --> Total execution time: 0.1620
ERROR - 2019-10-22 10:57:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:57:35 --> Total execution time: 0.1191
ERROR - 2019-10-22 10:57:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 10:57:35 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 10:57:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:57:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:57:37 --> Total execution time: 0.0051
ERROR - 2019-10-22 10:57:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:57:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:57:37 --> Total execution time: 0.0047
ERROR - 2019-10-22 10:58:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:58:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:58:19 --> Total execution time: 0.0051
ERROR - 2019-10-22 10:58:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:58:21 --> Total execution time: 0.2898
ERROR - 2019-10-22 10:58:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 10:58:22 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 10:59:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:59:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:59:33 --> Total execution time: 0.0111
ERROR - 2019-10-22 10:59:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:59:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 10:59:33 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 10:59:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:59:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:59:37 --> Total execution time: 0.0027
ERROR - 2019-10-22 10:59:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 10:59:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 10:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 10:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 10:59:37 --> Total execution time: 0.0044
ERROR - 2019-10-22 12:34:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:34:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:34:02 --> Total execution time: 0.1902
ERROR - 2019-10-22 12:34:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:34:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 12:34:02 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 12:34:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:34:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:34:05 --> Total execution time: 0.0037
ERROR - 2019-10-22 12:34:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:34:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:34:05 --> Total execution time: 0.0033
ERROR - 2019-10-22 12:35:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:35:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:35:16 --> Total execution time: 0.1517
ERROR - 2019-10-22 12:35:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:35:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 12:35:16 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 12:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:35:19 --> Total execution time: 0.0024
ERROR - 2019-10-22 12:35:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:35:19 --> Total execution time: 0.0023
ERROR - 2019-10-22 12:37:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:37:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:37:07 --> Total execution time: 0.1417
ERROR - 2019-10-22 12:37:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:37:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 12:37:07 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 12:37:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:37:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:37:11 --> Total execution time: 0.0040
ERROR - 2019-10-22 12:37:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:37:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:37:11 --> Total execution time: 0.0038
ERROR - 2019-10-22 12:38:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:38:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:38:41 --> Total execution time: 0.1425
ERROR - 2019-10-22 12:38:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:38:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:38:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 12:38:41 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 12:38:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:38:52 --> Total execution time: 0.0052
ERROR - 2019-10-22 12:38:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:38:52 --> Total execution time: 0.0031
ERROR - 2019-10-22 12:39:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:39:04 --> Total execution time: 0.0032
ERROR - 2019-10-22 12:40:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:40:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:40:31 --> Total execution time: 0.1156
ERROR - 2019-10-22 12:40:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:40:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 12:40:32 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 12:40:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:40:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:40:32 --> Total execution time: 0.1330
ERROR - 2019-10-22 12:40:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:40:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:40:33 --> Total execution time: 0.1213
ERROR - 2019-10-22 12:40:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:40:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 12:40:33 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 12:40:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:40:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:40:37 --> Total execution time: 0.0032
ERROR - 2019-10-22 12:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:41:11 --> Total execution time: 0.1309
ERROR - 2019-10-22 12:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 12:41:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 12:41:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:41:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:41:22 --> Total execution time: 0.0048
ERROR - 2019-10-22 12:41:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 12:41:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 12:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 12:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 12:41:28 --> Total execution time: 0.0042
ERROR - 2019-10-22 14:06:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:06:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 14:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 14:06:38 --> Total execution time: 14.3856
ERROR - 2019-10-22 14:06:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 14:06:48 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 14:10:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:10:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 14:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 14:10:02 --> Total execution time: 0.0487
ERROR - 2019-10-22 14:10:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:10:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 14:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 14:10:02 --> Total execution time: 0.0074
ERROR - 2019-10-22 14:45:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 14:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 14:45:00 --> Total execution time: 0.0035
ERROR - 2019-10-22 14:46:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:46:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:46:36 --> No URI present. Default controller set.
DEBUG - 2019-10-22 14:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 14:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 14:46:37 --> Total execution time: 1.2204
ERROR - 2019-10-22 14:46:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:46:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 14:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 14:46:55 --> Total execution time: 0.5444
ERROR - 2019-10-22 14:46:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:46:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 14:46:56 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 14:46:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:46:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:46:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 14:46:56 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 14:49:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 14:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 14:50:05 --> Total execution time: 13.2139
ERROR - 2019-10-22 14:50:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 14:50:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 14:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 14:50:06 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:03:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:03:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:03:00 --> Total execution time: 0.0284
ERROR - 2019-10-22 15:03:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:03:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:03:00 --> Total execution time: 0.0052
ERROR - 2019-10-22 15:05:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:05:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:05:10 --> Total execution time: 0.0103
ERROR - 2019-10-22 15:05:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:05:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:05:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:32:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:12 --> Total execution time: 0.0133
ERROR - 2019-10-22 15:32:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:32:13 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:32:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:13 --> Total execution time: 0.0078
ERROR - 2019-10-22 15:32:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:32:13 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:32:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:16 --> Total execution time: 0.0043
ERROR - 2019-10-22 15:32:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:16 --> Total execution time: 0.0032
ERROR - 2019-10-22 15:32:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:16 --> Total execution time: 0.0077
ERROR - 2019-10-22 15:32:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:32:16 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:32:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:17 --> Total execution time: 0.0031
ERROR - 2019-10-22 15:32:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:17 --> Total execution time: 0.0046
ERROR - 2019-10-22 15:32:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:17 --> Total execution time: 0.0124
ERROR - 2019-10-22 15:32:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:32:17 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:32:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:19 --> Total execution time: 0.0048
ERROR - 2019-10-22 15:32:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:32:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:32:19 --> Total execution time: 0.0051
ERROR - 2019-10-22 15:33:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:33:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:33:48 --> Total execution time: 0.0080
ERROR - 2019-10-22 15:33:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:33:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:33:50 --> Total execution time: 0.0065
ERROR - 2019-10-22 15:33:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:33:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:33:52 --> Total execution time: 0.0051
ERROR - 2019-10-22 15:34:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:34:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:34:57 --> Total execution time: 0.0034
ERROR - 2019-10-22 15:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:35:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:35:27 --> Total execution time: 0.0028
ERROR - 2019-10-22 15:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:36:04 --> Total execution time: 0.0034
ERROR - 2019-10-22 15:36:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:36:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:36:09 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:36:09 --> Total execution time: 0.0267
ERROR - 2019-10-22 15:36:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:36:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:36:12 --> Total execution time: 0.0113
ERROR - 2019-10-22 15:36:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:36:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:36:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:36:12 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 15:41:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:41:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:41:32 --> Total execution time: 0.0131
ERROR - 2019-10-22 15:41:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:41:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:41:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:41:33 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 15:41:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:41:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:41:43 --> Total execution time: 0.2477
ERROR - 2019-10-22 15:41:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:41:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:41:44 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:42:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:42:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:42:58 --> Total execution time: 0.3246
ERROR - 2019-10-22 15:42:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:42:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:42:58 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:43:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:43:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:43:28 --> Total execution time: 0.2433
ERROR - 2019-10-22 15:43:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:43:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:43:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:43:28 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:43:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:43:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:43:49 --> Total execution time: 0.0028
ERROR - 2019-10-22 15:43:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:43:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:43:56 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:43:56 --> Total execution time: 0.0045
ERROR - 2019-10-22 15:44:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:44:13 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:44:13 --> Total execution time: 0.0070
ERROR - 2019-10-22 15:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:44:31 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:44:31 --> Total execution time: 0.0035
ERROR - 2019-10-22 15:44:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:44:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:44:37 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:44:37 --> Total execution time: 0.0391
ERROR - 2019-10-22 15:44:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:44:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:44:41 --> Total execution time: 0.0116
ERROR - 2019-10-22 15:44:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:44:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:44:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 15:45:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:45:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:45:00 --> Total execution time: 0.1877
ERROR - 2019-10-22 15:45:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:45:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:45:00 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 15:45:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:45:21 --> Total execution time: 0.0054
ERROR - 2019-10-22 15:45:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:45:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:45:34 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:45:34 --> Total execution time: 0.0046
ERROR - 2019-10-22 15:45:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:45:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:45:39 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:45:39 --> Total execution time: 0.0294
ERROR - 2019-10-22 15:47:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:47:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:47:30 --> Total execution time: 0.0045
ERROR - 2019-10-22 15:47:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:47:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:47:46 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:47:46 --> Total execution time: 0.0257
ERROR - 2019-10-22 15:47:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:47:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:47:55 --> Total execution time: 0.0056
ERROR - 2019-10-22 15:47:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:47:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:47:58 --> No URI present. Default controller set.
DEBUG - 2019-10-22 15:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:47:59 --> Total execution time: 0.0291
ERROR - 2019-10-22 15:48:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:48:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 15:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 15:48:02 --> Total execution time: 0.0077
ERROR - 2019-10-22 15:48:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 15:48:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 15:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 15:48:02 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 16:16:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:16:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:16:16 --> Total execution time: 0.0191
ERROR - 2019-10-22 16:16:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:16:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 16:16:16 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 16:17:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:17:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:17:41 --> Total execution time: 0.0136
ERROR - 2019-10-22 16:17:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:17:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 16:17:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 16:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:18:00 --> Total execution time: 0.0183
ERROR - 2019-10-22 16:18:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:18:16 --> Total execution time: 0.0061
ERROR - 2019-10-22 16:18:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:18:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:18:22 --> Total execution time: 0.0055
ERROR - 2019-10-22 16:18:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:18:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:18:41 --> You did not select a file to upload.
DEBUG - 2019-10-22 16:18:41 --> Total execution time: 0.6283
ERROR - 2019-10-22 16:18:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:18:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:18:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 16:18:42 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 16:21:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:21:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:21:17 --> Total execution time: 0.2754
ERROR - 2019-10-22 16:21:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:21:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 16:21:17 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 16:21:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:21:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:21:54 --> Total execution time: 0.0147
ERROR - 2019-10-22 16:21:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:21:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 16:21:54 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 16:21:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:21:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:21:59 --> Total execution time: 0.0030
ERROR - 2019-10-22 16:22:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:22:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:22:03 --> No URI present. Default controller set.
DEBUG - 2019-10-22 16:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:22:03 --> Total execution time: 0.0213
ERROR - 2019-10-22 16:22:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:22:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:22:06 --> Total execution time: 0.0178
ERROR - 2019-10-22 16:23:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:23:35 --> Total execution time: 0.0067
ERROR - 2019-10-22 16:24:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:24:19 --> Total execution time: 0.0078
ERROR - 2019-10-22 16:24:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:24:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:24:38 --> Total execution time: 0.1835
ERROR - 2019-10-22 16:24:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:24:43 --> Total execution time: 0.0035
ERROR - 2019-10-22 16:24:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:24:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:24:47 --> No URI present. Default controller set.
DEBUG - 2019-10-22 16:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:24:47 --> Total execution time: 0.0056
ERROR - 2019-10-22 16:24:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:24:55 --> No URI present. Default controller set.
DEBUG - 2019-10-22 16:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:24:55 --> Total execution time: 0.0275
ERROR - 2019-10-22 16:27:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:27:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:27:19 --> Total execution time: 0.0054
ERROR - 2019-10-22 16:27:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:27:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:27:22 --> No URI present. Default controller set.
DEBUG - 2019-10-22 16:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:27:22 --> Total execution time: 0.0180
ERROR - 2019-10-22 16:27:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 16:27:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 16:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 16:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 16:27:26 --> Total execution time: 0.0034
ERROR - 2019-10-22 17:24:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:24:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:24:15 --> Total execution time: 0.0280
ERROR - 2019-10-22 17:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:24:27 --> Total execution time: 0.1910
ERROR - 2019-10-22 17:24:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:24:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:24:33 --> Total execution time: 0.0025
ERROR - 2019-10-22 17:24:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:24:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:24:38 --> No URI present. Default controller set.
DEBUG - 2019-10-22 17:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:24:38 --> Total execution time: 0.0024
ERROR - 2019-10-22 17:24:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:24:46 --> No URI present. Default controller set.
DEBUG - 2019-10-22 17:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:24:46 --> Total execution time: 0.0041
ERROR - 2019-10-22 17:24:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:24:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:24:53 --> No URI present. Default controller set.
DEBUG - 2019-10-22 17:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:24:53 --> Total execution time: 0.0292
ERROR - 2019-10-22 17:25:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:25:03 --> Total execution time: 0.0022
ERROR - 2019-10-22 17:25:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:25:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:25:08 --> No URI present. Default controller set.
DEBUG - 2019-10-22 17:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:25:08 --> Total execution time: 0.0072
ERROR - 2019-10-22 17:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:26:27 --> No URI present. Default controller set.
DEBUG - 2019-10-22 17:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:26:27 --> Total execution time: 0.0294
ERROR - 2019-10-22 17:26:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:26:32 --> Total execution time: 0.0058
ERROR - 2019-10-22 17:27:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:27:17 --> Total execution time: 0.0990
ERROR - 2019-10-22 17:27:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:27:23 --> Total execution time: 0.1204
ERROR - 2019-10-22 17:27:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 17:27:23 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-22 17:27:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 17:27:23 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-22 17:27:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 17:27:23 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-22 17:27:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:27:24 --> Total execution time: 0.2264
ERROR - 2019-10-22 17:27:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:27:25 --> Total execution time: 0.0399
ERROR - 2019-10-22 17:27:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 17:27:25 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-22 17:27:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:27:28 --> Total execution time: 0.0025
ERROR - 2019-10-22 17:27:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:36 --> No URI present. Default controller set.
DEBUG - 2019-10-22 17:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:27:36 --> Total execution time: 0.0224
ERROR - 2019-10-22 17:27:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:27:39 --> Total execution time: 0.0118
ERROR - 2019-10-22 17:27:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 17:27:39 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 17:27:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 17:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 17:27:42 --> Total execution time: 0.0057
ERROR - 2019-10-22 17:27:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 17:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 17:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 17:27:42 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 18:19:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:19:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:19:13 --> Total execution time: 0.0301
ERROR - 2019-10-22 18:19:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:19:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:19:13 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 18:19:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:19:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:19:40 --> Total execution time: 0.0053
ERROR - 2019-10-22 18:19:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:19:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:19:40 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 18:20:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:20:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:20:09 --> Total execution time: 0.2959
ERROR - 2019-10-22 18:20:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:20:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:20:09 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 18:22:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:22:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:22:25 --> Total execution time: 0.2298
ERROR - 2019-10-22 18:22:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:22:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:22:25 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 18:22:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:22:40 --> Total execution time: 0.3964
ERROR - 2019-10-22 18:22:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:22:40 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 18:23:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:23:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:23:02 --> Total execution time: 0.0033
ERROR - 2019-10-22 18:23:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:23:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:23:11 --> No URI present. Default controller set.
DEBUG - 2019-10-22 18:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:23:11 --> Total execution time: 0.0055
ERROR - 2019-10-22 18:23:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:23:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:23:28 --> No URI present. Default controller set.
DEBUG - 2019-10-22 18:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:23:28 --> Total execution time: 0.2050
ERROR - 2019-10-22 18:23:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:23:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:23:31 --> Total execution time: 0.3040
ERROR - 2019-10-22 18:23:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:23:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:23:33 --> Total execution time: 0.0041
ERROR - 2019-10-22 18:23:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:23:41 --> No URI present. Default controller set.
DEBUG - 2019-10-22 18:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:23:41 --> Total execution time: 0.0326
ERROR - 2019-10-22 18:23:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:23:44 --> Total execution time: 0.0042
ERROR - 2019-10-22 18:23:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:23:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:23:44 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-22 18:24:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:24:43 --> You did not select a file to upload.
DEBUG - 2019-10-22 18:24:44 --> Total execution time: 0.3804
ERROR - 2019-10-22 18:24:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:24:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:24:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:24:44 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 18:25:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:25:45 --> You did not select a file to upload.
DEBUG - 2019-10-22 18:25:46 --> Total execution time: 0.2716
ERROR - 2019-10-22 18:25:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:25:46 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 18:26:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:26:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:26:12 --> Total execution time: 0.1750
ERROR - 2019-10-22 18:26:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:26:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-22 18:26:12 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-22 18:26:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:26:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:26:22 --> Total execution time: 0.0890
ERROR - 2019-10-22 18:34:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:34:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:34:56 --> Total execution time: 0.0092
ERROR - 2019-10-22 18:35:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:35:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:35:46 --> Total execution time: 0.2085
ERROR - 2019-10-22 18:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:36:39 --> Total execution time: 0.0060
ERROR - 2019-10-22 18:37:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:37:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:37:15 --> Total execution time: 0.2536
ERROR - 2019-10-22 18:37:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:37:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:37:35 --> Total execution time: 0.1897
ERROR - 2019-10-22 18:49:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:49:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-22 18:49:54 --> Total execution time: 0.0068
ERROR - 2019-10-22 18:50:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-22 18:50:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-22 18:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-22 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-22 18:50:17 --> Query error: Duplicate entry '11' for key 'drivers_mobile' - Invalid query: INSERT INTO `drivers` (`users_id`, `drivers_name`, `drivers_address`, `drivers_mobile`, `join_date`, `created_date`, `created_by`) VALUES ('199', 'd33', 11, 11, '07/01/19', '2019-10-22', '34')
DEBUG - 2019-10-22 18:50:17 --> Total execution time: 2.9780
