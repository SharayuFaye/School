<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-18 16:15:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:15:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:15:41 --> Total execution time: 0.5591
ERROR - 2019-11-18 16:15:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-18 16:15:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:15:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:15:53 --> No URI present. Default controller set.
DEBUG - 2019-11-18 16:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:15:53 --> disha :: Disha@123
DEBUG - 2019-11-18 16:15:53 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-18 16:15:54 --> Total execution time: 1.4250
ERROR - 2019-11-18 16:15:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-18 16:16:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:01 --> Total execution time: 0.0139
ERROR - 2019-11-18 16:16:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-18 16:16:02 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-18 16:16:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-18 16:16:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:08 --> Total execution time: 0.0043
ERROR - 2019-11-18 16:16:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:08 --> Total execution time: 0.0050
ERROR - 2019-11-18 16:16:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-18 16:16:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:08 --> Total execution time: 0.0084
ERROR - 2019-11-18 16:16:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-18 16:16:08 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-18 16:16:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:09 --> Total execution time: 0.0086
ERROR - 2019-11-18 16:16:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-18 16:16:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-18 16:16:09 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-18 16:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:10 --> Total execution time: 0.0095
ERROR - 2019-11-18 16:16:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-18 16:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:10 --> Total execution time: 0.0098
ERROR - 2019-11-18 16:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:10 --> Total execution time: 0.0097
ERROR - 2019-11-18 16:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-18 16:16:10 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-18 16:16:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:10 --> Total execution time: 0.0089
ERROR - 2019-11-18 16:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-18 16:16:11 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-18 16:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:11 --> Total execution time: 0.0027
ERROR - 2019-11-18 16:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:11 --> Total execution time: 0.0034
ERROR - 2019-11-18 16:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-18 16:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-18 16:16:11 --> Total execution time: 0.0112
ERROR - 2019-11-18 16:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-18 16:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-18 16:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-18 16:16:11 --> 404 Page Not Found: Profile/logo.png
