<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-19 04:59:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 04:59:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 04:59:57 --> No URI present. Default controller set.
DEBUG - 2019-09-19 04:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 04:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 04:59:57 --> Total execution time: 0.0091
ERROR - 2019-09-19 05:00:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:00:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:00:05 --> No URI present. Default controller set.
DEBUG - 2019-09-19 05:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:00:06 --> Total execution time: 0.0072
ERROR - 2019-09-19 05:01:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:01:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:01:03 --> No URI present. Default controller set.
DEBUG - 2019-09-19 05:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:01:03 --> Total execution time: 0.0017
ERROR - 2019-09-19 05:01:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:01:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:01:32 --> No URI present. Default controller set.
DEBUG - 2019-09-19 05:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:01:32 --> Total execution time: 0.0046
ERROR - 2019-09-19 05:01:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:01:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:01:38 --> Total execution time: 0.0040
ERROR - 2019-09-19 05:02:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:02:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:02:03 --> No URI present. Default controller set.
DEBUG - 2019-09-19 05:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:02:03 --> Total execution time: 0.0016
ERROR - 2019-09-19 05:02:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:02:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:02:57 --> No URI present. Default controller set.
DEBUG - 2019-09-19 05:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:02:57 --> Total execution time: 0.0046
ERROR - 2019-09-19 05:03:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:03:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:03:29 --> Total execution time: 0.0039
ERROR - 2019-09-19 05:03:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:03:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 05:03:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:03:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 05:03:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:03:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 05:03:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:03:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 05:04:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:04:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:04:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:04:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:04:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:04:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:04:16 --> Total execution time: 0.0046
ERROR - 2019-09-19 05:04:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:04:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:04:16 --> Total execution time: 0.0041
ERROR - 2019-09-19 05:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:07:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:07:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:07:50 --> Total execution time: 0.0020
ERROR - 2019-09-19 05:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:08:27 --> Total execution time: 0.0355
ERROR - 2019-09-19 05:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:08:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:08:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:08:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:08:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:08:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:08:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:08:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:08:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:08:38 --> Total execution time: 0.0020
ERROR - 2019-09-19 05:08:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:08:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:08:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:08:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:08:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:08:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:08:46 --> Total execution time: 0.0020
ERROR - 2019-09-19 05:09:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:09:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:09:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:09:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:09:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:09:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:09:56 --> Total execution time: 0.0021
ERROR - 2019-09-19 05:10:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:10:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:10:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:10:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:10:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:10:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:10:38 --> Total execution time: 0.0020
ERROR - 2019-09-19 05:11:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:11:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:11:05 --> Total execution time: 0.0020
ERROR - 2019-09-19 05:11:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:11:06 --> Total execution time: 0.0020
ERROR - 2019-09-19 05:11:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:20 --> No URI present. Default controller set.
DEBUG - 2019-09-19 05:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:11:20 --> Total execution time: 0.0017
ERROR - 2019-09-19 05:11:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:20 --> No URI present. Default controller set.
DEBUG - 2019-09-19 05:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:11:20 --> Total execution time: 0.0016
ERROR - 2019-09-19 05:11:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:23 --> No URI present. Default controller set.
DEBUG - 2019-09-19 05:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:11:23 --> Total execution time: 0.0046
ERROR - 2019-09-19 05:11:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:11:28 --> Total execution time: 0.0027
ERROR - 2019-09-19 05:11:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:11:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 05:11:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:11:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 05:11:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:11:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 05:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:11:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:11:50 --> Total execution time: 0.0044
ERROR - 2019-09-19 05:11:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:11:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:11:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:11:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:11:51 --> Total execution time: 0.0026
ERROR - 2019-09-19 05:12:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:12:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:12:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:12:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:12:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:12:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:12:11 --> Total execution time: 0.0026
ERROR - 2019-09-19 05:15:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:15:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:15:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:15:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:15:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:15:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:15:24 --> Total execution time: 0.0025
ERROR - 2019-09-19 05:15:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:15:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:15:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:15:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:15:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:15:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:15:34 --> Total execution time: 0.0033
ERROR - 2019-09-19 05:15:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:15:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:15:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:15:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:15:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:15:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:15:49 --> Total execution time: 0.0027
ERROR - 2019-09-19 05:16:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:16:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:16:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:16:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:16:01 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:16:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:16:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:16:05 --> Total execution time: 0.0049
ERROR - 2019-09-19 05:16:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:16:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:16:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:16:05 --> Total execution time: 0.0048
ERROR - 2019-09-19 05:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:16:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:16:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:16:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:16:11 --> Total execution time: 0.0095
ERROR - 2019-09-19 05:16:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:16:11 --> Total execution time: 0.0049
ERROR - 2019-09-19 05:16:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:16:28 --> Total execution time: 0.0056
ERROR - 2019-09-19 05:16:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:16:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 05:16:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:16:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:16:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:16:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 05:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:21:46 --> ROLE ::::: teacher
DEBUG - 2019-09-19 05:21:46 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 05:21:46 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 05:21:46 --> HELLO
DEBUG - 2019-09-19 05:21:46 --> {"multicast_id":9117109639998334438,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568870506340860%ec14b888ec14b888"},{"message_id":"0:1568870506285984%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 05:21:46 --> Total execution time: 0.1267
ERROR - 2019-09-19 05:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:21:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:21:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:23:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:23:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:23:36 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:36 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:23:36 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:23:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:23:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:23:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:23:37 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:37 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:37 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:37 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:23:37 --> Total execution time: 0.0034
ERROR - 2019-09-19 05:23:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:23:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:23:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:23:41 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:41 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:23:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:23:41 --> Total execution time: 0.0038
ERROR - 2019-09-19 05:23:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:23:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:23:45 --> Total execution time: 0.0020
ERROR - 2019-09-19 05:24:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:24:01 --> Total execution time: 0.0069
ERROR - 2019-09-19 05:24:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:24:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:24:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:24:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:24:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:24:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:24:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:24:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:24:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:24:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:24:13 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:13 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:24:13 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:24:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:24:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:24:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:24:14 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:14 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:14 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:14 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:24:14 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:24:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:24:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:24:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:24:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:24:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:24:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:24:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:24:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:24:21 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:26:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:26:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:26:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:26:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:26:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:26:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:26:02 --> Total execution time: 0.0038
ERROR - 2019-09-19 05:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:26:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:26:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:26:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:26:13 --> Total execution time: 0.0042
ERROR - 2019-09-19 05:26:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:26:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:26:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:26:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:26:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:26:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:26:14 --> Total execution time: 0.0025
ERROR - 2019-09-19 05:26:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:26:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:26:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:26:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:26:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:26:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:26:23 --> Total execution time: 0.0028
ERROR - 2019-09-19 05:27:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:27:51 --> ROLE ::::: teacher
DEBUG - 2019-09-19 05:27:51 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 05:27:51 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 05:27:51 --> HELLO
DEBUG - 2019-09-19 05:27:51 --> {"multicast_id":5197676292834096041,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568870871322068%ec14b888ec14b888"},{"message_id":"0:1568870871296699%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 05:27:51 --> Total execution time: 0.0904
ERROR - 2019-09-19 05:27:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:27:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:27:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:27:51 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:16 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:28:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:19 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:28:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:22 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:28:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:25 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:28:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:29 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:29 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:29 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:29 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:29 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:28:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:31 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:28:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:33 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:28:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:42 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:28:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:28:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:28:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:28:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:28:42 --> Total execution time: 0.0030
ERROR - 2019-09-19 05:30:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:30:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:30:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:30:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:30:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:30:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:30:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:30:15 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:30:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:30:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:30:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:30:17 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:17 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:17 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:17 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:30:17 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:30:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:30:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:30:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:30:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:30:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:30:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:30:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:30:22 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:30:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:30:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:30:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:30:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:30:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:30:26 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:32:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:32:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:32:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:32:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:32:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:32:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:32:23 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:32:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:32:23 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:32:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:32:23 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:32:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:32:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:32:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:32:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:32:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:32:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:32:26 --> Total execution time: 0.0038
ERROR - 2019-09-19 05:33:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:33:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:33:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:33:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:33:30 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:33:30 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:33:30 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:33:30 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:33:30 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:33:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:33:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:33:52 --> Total execution time: 0.0054
ERROR - 2019-09-19 05:33:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:33:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:33:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:33:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 05:33:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:33:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:33:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:33:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 05:35:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:35:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:35:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:35:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:35:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:35:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:35:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:35:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:35:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:35:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:35:10 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:35:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:35:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:35:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:35:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:35:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:35:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:35:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:35:12 --> Total execution time: 0.0034
ERROR - 2019-09-19 05:35:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:35:25 --> Total execution time: 0.0166
ERROR - 2019-09-19 05:35:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:35:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:35:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:35:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:38:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:38:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:38:39 --> Total execution time: 0.0043
ERROR - 2019-09-19 05:38:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:38:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:38:41 --> Total execution time: 0.0045
ERROR - 2019-09-19 05:38:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:38:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:38:44 --> Total execution time: 0.0034
ERROR - 2019-09-19 05:38:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:38:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:38:50 --> Total execution time: 0.0050
ERROR - 2019-09-19 05:38:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:38:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:38:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:38:53 --> Total execution time: 0.0027
ERROR - 2019-09-19 05:39:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:39:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:39:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:39:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:39:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:39:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:39:31 --> Total execution time: 0.0031
ERROR - 2019-09-19 05:39:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:39:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:39:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:39:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:39:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:39:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:39:50 --> Total execution time: 0.0031
ERROR - 2019-09-19 05:40:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:40:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:40:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:40:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:40:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:40:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:40:29 --> Total execution time: 0.0032
ERROR - 2019-09-19 05:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:40:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:40:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:40:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:40:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:40:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:40:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:40:57 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:41:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:41:11 --> Total execution time: 0.0049
ERROR - 2019-09-19 05:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:41:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:41:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:41:11 --> Total execution time: 0.0043
ERROR - 2019-09-19 05:41:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:41:15 --> Total execution time: 0.0034
ERROR - 2019-09-19 05:41:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:34 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:34 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:41:34 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:41:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:34 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:34 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:41:34 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:41:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:37 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:37 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:37 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:37 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:41:37 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:41:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:41 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:41 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:41:41 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:41:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:46 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:46 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:41:46 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:41:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:41:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:41:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:41:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:41:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:41:50 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:42:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:42:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:42:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:42:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:42:34 --> Total execution time: 0.0041
ERROR - 2019-09-19 05:42:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:42:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:42:34 --> Total execution time: 0.0019
ERROR - 2019-09-19 05:42:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:42:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:42:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:42:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:42:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:42:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:43:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:43:00 --> Total execution time: 0.0044
ERROR - 2019-09-19 05:43:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:43:00 --> Total execution time: 0.0040
ERROR - 2019-09-19 05:43:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:43:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:43:01 --> Total execution time: 0.0053
ERROR - 2019-09-19 05:43:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:43:01 --> Total execution time: 0.0042
ERROR - 2019-09-19 05:43:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:43:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:43:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 1317
DEBUG - 2019-09-19 05:43:01 --> Total execution time: 0.0025
ERROR - 2019-09-19 05:43:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:43:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:43:03 --> Total execution time: 0.0034
ERROR - 2019-09-19 05:43:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:43:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:43:08 --> Total execution time: 0.0025
ERROR - 2019-09-19 05:43:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:43:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:43:11 --> Total execution time: 0.0028
ERROR - 2019-09-19 05:43:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:43:14 --> Total execution time: 0.0047
ERROR - 2019-09-19 05:43:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:43:15 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 05:43:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:43:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:43:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:43:15 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 05:45:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:45:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:45:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:45:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:45:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:45:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:45:39 --> Total execution time: 0.0033
ERROR - 2019-09-19 05:45:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:45:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:45:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:45:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:45:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:45:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:45:43 --> Total execution time: 0.0029
ERROR - 2019-09-19 05:46:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:46:15 --> ROLE ::::: driver
ERROR - 2019-09-19 05:46:15 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 2
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4821902  Threads: 1  Questions: 189778  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39500
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 2
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-19 05:46:15 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 05:46:15 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 05:46:15 --> HELLO
DEBUG - 2019-09-19 05:46:15 --> {"multicast_id":8717658005018300459,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568871975484485%ec14b888ec14b888"},{"message_id":"0:1568871975448758%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 05:46:15 --> Total execution time: 0.1773
ERROR - 2019-09-19 05:46:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:46:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:46:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:46:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:46:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:46:33 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:46:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:46:33 --> Total execution time: 0.0031
ERROR - 2019-09-19 05:46:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:36 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:36 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:46:36 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:46:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:46:42 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:46:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:46:47 --> Total execution time: 0.0038
ERROR - 2019-09-19 05:46:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:46:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:46:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:46:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:46:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:46:56 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:47:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:47:06 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:47:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:47:08 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:47:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:47:12 --> Total execution time: 0.0034
ERROR - 2019-09-19 05:47:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:15 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:47:15 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:47:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:47:18 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:47:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:20 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:20 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:20 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:20 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:47:20 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:47:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:47:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:47:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:47:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:47:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:47:32 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:49:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:49:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:49:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:49:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:49:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:49:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:49:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:49:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:49:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:49:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:49:57 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:50:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:50:06 --> Total execution time: 0.0038
ERROR - 2019-09-19 05:50:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:07 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:07 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:50:07 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:50:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:50:12 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:50:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:30 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:30 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:30 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:50:30 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:50:30 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:50:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:50:46 --> Total execution time: 0.0046
ERROR - 2019-09-19 05:50:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:50:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:50:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:50:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:50:47 --> Total execution time: 0.0044
ERROR - 2019-09-19 05:51:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:51:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:51:03 --> ROLE ::::: driver
ERROR - 2019-09-19 05:51:03 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 2
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4822190  Threads: 1  Questions: 189953  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39535
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 2
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-19 05:51:03 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 05:51:03 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 05:51:03 --> HELLO
DEBUG - 2019-09-19 05:51:03 --> {"multicast_id":7070320542962321366,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568872263858173%ec14b888ec14b888"},{"message_id":"0:1568872263853575%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 05:51:03 --> Total execution time: 0.0783
ERROR - 2019-09-19 05:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:51:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:51:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:51:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:51:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:51:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:51:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:51:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:51:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:51:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:51:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:51:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:51:22 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:52:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:52:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:52:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:52:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:52:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:52:06 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:53:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:53:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:53:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:53:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:53:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:53:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:53:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:53:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:53:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:53:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:53:51 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:53:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:53:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:53:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:53:55 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:53:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:53:55 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:53:55 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:53:55 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:54:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:54:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:54:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:54:01 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:54:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:54:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:54:05 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:54:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:54:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:54:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:54:10 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:54:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:54:19 --> Total execution time: 0.0021
ERROR - 2019-09-19 05:54:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:54:35 --> Total execution time: 0.0068
ERROR - 2019-09-19 05:54:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:54:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:54:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:54:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:54:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:54:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:54:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:54:48 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:54:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:54:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:54:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:54:52 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:55:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:55:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:55:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:55:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:55:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:55:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:55:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:55:11 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:55:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:55:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:55:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:55:12 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:55:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:55:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:55:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:55:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:55:16 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:55:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:55:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:55:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:55:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:55:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:55:22 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:55:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:55:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:55:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:55:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:55:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:55:26 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:55:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:55:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:55:28 --> Total execution time: 0.0020
ERROR - 2019-09-19 05:56:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 05:56:23 --> Total execution time: 0.0076
ERROR - 2019-09-19 05:56:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:56:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 05:56:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 05:56:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 05:56:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:56:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:56:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:56:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:56:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:56:32 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:56:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:56:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:56:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:56:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:56:39 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:39 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:39 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:39 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:56:39 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:56:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:56:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:56:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:56:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:56:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:56:47 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:56:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:56:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:56:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:56:49 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:57:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:57:01 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:57:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:03 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:03 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:03 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:57:03 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:57:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:09 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:09 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:09 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:09 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:57:09 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:57:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:57:11 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:57:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:57:18 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:57:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:57:40 --> Total execution time: 0.0045
ERROR - 2019-09-19 05:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:57:41 --> Total execution time: 0.0044
ERROR - 2019-09-19 05:57:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:57:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:57:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:57:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:57:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:57:47 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:58:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:58:01 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:58:12 --> Total execution time: 0.0026
ERROR - 2019-09-19 05:58:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:14 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:14 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:14 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:14 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:58:14 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:58:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:58:16 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:58:26 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:44 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:44 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:58:44 --> Total execution time: 0.0037
ERROR - 2019-09-19 05:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:58:48 --> Total execution time: 0.0028
ERROR - 2019-09-19 05:58:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:58:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:58:57 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:58:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:58:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:58:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:58:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:58:58 --> Total execution time: 0.0026
ERROR - 2019-09-19 05:59:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:59:00 --> Total execution time: 0.0027
ERROR - 2019-09-19 05:59:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:59:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:59:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:59:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:59:11 --> Total execution time: 0.0035
ERROR - 2019-09-19 05:59:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:59:29 --> Total execution time: 0.0034
ERROR - 2019-09-19 05:59:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 05:59:36 --> Total execution time: 0.0027
ERROR - 2019-09-19 05:59:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:59:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:59:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 05:59:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 05:59:48 --> Total execution time: 0.0036
ERROR - 2019-09-19 05:59:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:59:50 --> Total execution time: 0.0049
ERROR - 2019-09-19 05:59:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:50 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:59:50 --> Total execution time: 0.0047
ERROR - 2019-09-19 05:59:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:59:51 --> Total execution time: 0.0049
ERROR - 2019-09-19 05:59:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:59:51 --> Total execution time: 0.0048
ERROR - 2019-09-19 05:59:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 05:59:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 05:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 05:59:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 05:59:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 05:59:51 --> Total execution time: 0.0047
ERROR - 2019-09-19 06:00:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:00:00 --> Total execution time: 0.0026
ERROR - 2019-09-19 06:00:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:00:07 --> Total execution time: 0.0242
ERROR - 2019-09-19 06:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 06:00:08 --> Total execution time: 0.0046
ERROR - 2019-09-19 06:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:08 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 06:00:08 --> Total execution time: 0.0047
ERROR - 2019-09-19 06:00:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 06:00:11 --> Total execution time: 0.0060
DEBUG - 2019-09-19 06:00:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:11 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 06:00:11 --> Total execution time: 0.0051
ERROR - 2019-09-19 06:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 06:00:16 --> Total execution time: 0.0050
ERROR - 2019-09-19 06:00:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 171
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 179
ERROR - 2019-09-19 06:00:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/school/system/core/Exceptions.php:271) /var/www/html/school/system/core/Common.php 570
DEBUG - 2019-09-19 06:00:16 --> Total execution time: 0.0045
ERROR - 2019-09-19 06:00:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:20 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:00:20 --> Total execution time: 0.0096
ERROR - 2019-09-19 06:00:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:25 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:00:25 --> Total execution time: 0.0045
ERROR - 2019-09-19 06:00:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:00:29 --> Total execution time: 0.0034
ERROR - 2019-09-19 06:00:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:00:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:00:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:00:31 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:00:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:00:31 --> Total execution time: 0.0035
ERROR - 2019-09-19 06:00:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:00:34 --> Total execution time: 0.0041
ERROR - 2019-09-19 06:00:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:00:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:00:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:00:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:00:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:00:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:00:57 --> Total execution time: 0.0031
ERROR - 2019-09-19 06:01:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:01:22 --> Total execution time: 0.0020
ERROR - 2019-09-19 06:01:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:01:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:01:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:01:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:01:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:01:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:01:54 --> Total execution time: 0.0075
ERROR - 2019-09-19 06:01:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:01:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:01:55 --> Total execution time: 0.0020
ERROR - 2019-09-19 06:01:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:01:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:01:56 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:01:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:01:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:01:56 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:02:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:02:12 --> Total execution time: 0.0042
ERROR - 2019-09-19 06:02:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:02:14 --> Total execution time: 0.0032
ERROR - 2019-09-19 06:02:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:02:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:02:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:02:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:02:16 --> Total execution time: 0.0036
ERROR - 2019-09-19 06:02:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:02:18 --> Total execution time: 0.0037
ERROR - 2019-09-19 06:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:19 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:02:19 --> Total execution time: 0.0017
ERROR - 2019-09-19 06:02:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:02:21 --> Total execution time: 0.0031
ERROR - 2019-09-19 06:02:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:22 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:02:22 --> Total execution time: 0.0035
ERROR - 2019-09-19 06:02:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:28 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:28 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:28 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:28 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:02:28 --> Total execution time: 0.0035
ERROR - 2019-09-19 06:02:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:02:37 --> Total execution time: 0.0030
ERROR - 2019-09-19 06:02:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:39 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:02:39 --> Total execution time: 0.0045
ERROR - 2019-09-19 06:02:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:02:42 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:02:42 --> Total execution time: 0.0035
ERROR - 2019-09-19 06:02:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:02:46 --> Total execution time: 0.0045
ERROR - 2019-09-19 06:02:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:02:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:02:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:02:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:02:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:02:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:02:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:02:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:02:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:02:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:02:50 --> Total execution time: 0.0028
ERROR - 2019-09-19 06:02:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:02:54 --> Total execution time: 0.0046
ERROR - 2019-09-19 06:02:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:02:54 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:02:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:02:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:02:54 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:04:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:04:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:04:05 --> Total execution time: 0.0020
ERROR - 2019-09-19 06:05:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:05:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:05:10 --> ROLE ::::: parent
DEBUG - 2019-09-19 06:05:10 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:05:10 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:05:11 --> HELLO
DEBUG - 2019-09-19 06:05:11 --> {"multicast_id":4622335344466082687,"success":7,"failure":1,"canonical_ids":0,"results":[{"message_id":"0:1568873111342696%ec14b888ec14b888"},{"error":"NotRegistered"},{"message_id":"0:1568873111345470%ec14b888ec14b888"},{"message_id":"0:1568873111339710%ec14b888ec14b888"},{"message_id":"0:1568873111343759%ec14b888ec14b888"},{"message_id":"0:1568873111342698%ec14b888ec14b888"},{"message_id":"0:1568873111342578%ec14b888ec14b888"},{"message_id":"0:1568873111342577%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:05:11 --> Total execution time: 1.0811
ERROR - 2019-09-19 06:05:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:05:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:05:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:05:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:05:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:05:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:05:16 --> Total execution time: 0.0020
ERROR - 2019-09-19 06:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:05:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:05:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:05:22 --> Total execution time: 0.0035
ERROR - 2019-09-19 06:05:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:05:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:05:25 --> Total execution time: 0.0034
ERROR - 2019-09-19 06:06:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:06:03 --> ROLE ::::: student
DEBUG - 2019-09-19 06:06:03 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:06:03 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:06:04 --> HELLO
DEBUG - 2019-09-19 06:06:04 --> {"multicast_id":5267459294581658539,"success":7,"failure":1,"canonical_ids":0,"results":[{"message_id":"0:1568873164099456%ec14b888ec14b888"},{"error":"NotRegistered"},{"message_id":"0:1568873164099996%ec14b888ec14b888"},{"message_id":"0:1568873164099989%ec14b888ec14b888"},{"message_id":"0:1568873164099455%ec14b888ec14b888"},{"message_id":"0:1568873164099990%ec14b888ec14b888"},{"message_id":"0:1568873164099457%ec14b888ec14b888"},{"message_id":"0:1568873164099994%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:06:04 --> Total execution time: 1.0685
ERROR - 2019-09-19 06:06:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:06:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:06:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:06:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:06:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:06:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:06:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:06:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:06:13 --> Total execution time: 0.0033
ERROR - 2019-09-19 06:06:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:06:45 --> ROLE ::::: student
DEBUG - 2019-09-19 06:06:45 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:06:45 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:06:46 --> HELLO
DEBUG - 2019-09-19 06:06:46 --> {"multicast_id":7870582014451324454,"success":7,"failure":1,"canonical_ids":0,"results":[{"message_id":"0:1568873206743593%ec14b888ec14b888"},{"error":"NotRegistered"},{"message_id":"0:1568873206744950%ec14b888ec14b888"},{"message_id":"0:1568873206744949%ec14b888ec14b888"},{"message_id":"0:1568873206744945%ec14b888ec14b888"},{"message_id":"0:1568873206743360%ec14b888ec14b888"},{"message_id":"0:1568873206743909%ec14b888ec14b888"},{"message_id":"0:1568873206744943%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:06:46 --> Total execution time: 1.0826
ERROR - 2019-09-19 06:06:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:06:47 --> ROLE ::::: parent
DEBUG - 2019-09-19 06:06:47 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:06:47 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

ERROR - 2019-09-19 06:06:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:06:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:06:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:06:47 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-09-19 06:06:48 --> HELLO
DEBUG - 2019-09-19 06:06:48 --> {"multicast_id":5015068085032310517,"success":7,"failure":1,"canonical_ids":0,"results":[{"message_id":"0:1568873208049849%ec14b888ec14b888"},{"error":"NotRegistered"},{"message_id":"0:1568873208049984%ec14b888ec14b888"},{"message_id":"0:1568873208049501%ec14b888ec14b888"},{"message_id":"0:1568873208049982%ec14b888ec14b888"},{"message_id":"0:1568873208049980%ec14b888ec14b888"},{"message_id":"0:1568873208050463%ec14b888ec14b888"},{"message_id":"0:1568873208049986%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:06:48 --> Total execution time: 1.0762
ERROR - 2019-09-19 06:06:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:06:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:06:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:06:48 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:07:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:07:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:07:05 --> Total execution time: 0.0056
ERROR - 2019-09-19 06:07:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:07:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:07:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:07:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:07:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:07:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:07:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:07:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:07:31 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:07:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:07:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:07:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:07:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:07:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:07:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:08:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:08:19 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:08:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:08:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:08:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:08:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:08:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:08:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:08:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:08:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:08:31 --> Total execution time: 0.0033
ERROR - 2019-09-19 06:08:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:08:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:08:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:08:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:08:53 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:08:53 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:08:53 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:08:53 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:08:53 --> Total execution time: 0.0037
ERROR - 2019-09-19 06:08:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:08:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:08:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:08:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:08:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:08:56 --> Total execution time: 0.0035
ERROR - 2019-09-19 06:09:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:09:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:09:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:09:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:09:08 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:09:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:09:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:09:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:09:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:09:15 --> Total execution time: 0.0033
ERROR - 2019-09-19 06:09:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:09:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:09:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:09:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:09:36 --> Total execution time: 0.0034
ERROR - 2019-09-19 06:09:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:09:40 --> Total execution time: 0.0027
ERROR - 2019-09-19 06:09:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:09:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:09:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:09:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:09:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:10:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:10:05 --> Total execution time: 0.0043
ERROR - 2019-09-19 06:10:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:10:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:10:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:10:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:10:45 --> Total execution time: 0.0049
ERROR - 2019-09-19 06:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:10:47 --> Total execution time: 0.0043
ERROR - 2019-09-19 06:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:10:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:10:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:10:52 --> ROLE ::::: parent
DEBUG - 2019-09-19 06:10:52 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:10:52 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:10:53 --> HELLO
DEBUG - 2019-09-19 06:10:53 --> {"multicast_id":5463183593797459630,"success":7,"failure":1,"canonical_ids":0,"results":[{"message_id":"0:1568873453788736%ec14b888ec14b888"},{"error":"NotRegistered"},{"message_id":"0:1568873453789474%ec14b888ec14b888"},{"message_id":"0:1568873453788969%ec14b888ec14b888"},{"message_id":"0:1568873453789054%ec14b888ec14b888"},{"message_id":"0:1568873453788738%ec14b888ec14b888"},{"message_id":"0:1568873453788965%ec14b888ec14b888"},{"message_id":"0:1568873453788966%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:10:53 --> Total execution time: 1.0944
ERROR - 2019-09-19 06:10:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:10:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:10:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:10:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:10:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:11:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:11:16 --> ROLE ::::: driver
ERROR - 2019-09-19 06:11:16 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 2
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4823403  Threads: 1  Questions: 190939  Slow queries: 0  Opens: 6929  Flush tables: 1  Open tables: 805  Queries per second avg: 0.039
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 39722
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 2
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-19 06:11:16 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:11:16 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:11:16 --> HELLO
DEBUG - 2019-09-19 06:11:16 --> {"multicast_id":7822058214610454746,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568873476077918%ec14b888ec14b888"},{"message_id":"0:1568873476077670%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:11:16 --> Total execution time: 0.0808
ERROR - 2019-09-19 06:11:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:11:16 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:11:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:11:16 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:11:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:11:26 --> ROLE ::::: parent
DEBUG - 2019-09-19 06:11:26 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:11:26 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [4] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:11:27 --> HELLO
DEBUG - 2019-09-19 06:11:27 --> {"multicast_id":8113739200629134890,"success":7,"failure":1,"canonical_ids":0,"results":[{"message_id":"0:1568873487242653%ec14b888ec14b888"},{"error":"NotRegistered"},{"message_id":"0:1568873487243601%ec14b888ec14b888"},{"message_id":"0:1568873487242652%ec14b888ec14b888"},{"message_id":"0:1568873487243979%ec14b888ec14b888"},{"message_id":"0:1568873487243599%ec14b888ec14b888"},{"message_id":"0:1568873487243976%ec14b888ec14b888"},{"message_id":"0:1568873487243981%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:11:27 --> Total execution time: 1.0768
ERROR - 2019-09-19 06:11:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:11:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:11:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:11:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:11:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:11:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:11:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:11:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:11:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:11:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:11:51 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:11:51 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:11:51 --> Total execution time: 0.0037
ERROR - 2019-09-19 06:11:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:11:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:11:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:11:53 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:11:53 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:11:53 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:11:53 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:11:53 --> Total execution time: 0.0036
ERROR - 2019-09-19 06:12:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:12:04 --> Total execution time: 0.0033
ERROR - 2019-09-19 06:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:12:18 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:12:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:12:20 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:12:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:12:21 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:12:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:12:21 --> Total execution time: 0.0036
ERROR - 2019-09-19 06:12:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:12:28 --> Total execution time: 0.0045
ERROR - 2019-09-19 06:12:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:12:31 --> Total execution time: 0.0039
ERROR - 2019-09-19 06:12:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:12:31 --> Total execution time: 0.0019
ERROR - 2019-09-19 06:12:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:39 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:12:39 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:12:39 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 06:12:39 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 06:12:39 --> Total execution time: 0.0037
ERROR - 2019-09-19 06:12:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:12:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:12:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:12:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:12:46 --> Total execution time: 0.0025
ERROR - 2019-09-19 06:13:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:13:03 --> Total execution time: 0.0021
ERROR - 2019-09-19 06:13:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:13:18 --> ROLE ::::: section
DEBUG - 2019-09-19 06:13:18 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`class_id` = '1'
AND `b`.`sections_id` = '40'
DEBUG - 2019-09-19 06:13:18 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
    [1] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-19 06:13:18 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
    [1] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
)

DEBUG - 2019-09-19 06:13:18 --> HELLO
DEBUG - 2019-09-19 06:13:18 --> {"multicast_id":6179948988921348483,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568873598164449%ec14b888ec14b888"},{"message_id":"0:1568873598163802%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:13:18 --> Total execution time: 0.0792
ERROR - 2019-09-19 06:13:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:13:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:13:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:13:18 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:13:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:13:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:13:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:13:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:13:22 --> Total execution time: 0.0020
ERROR - 2019-09-19 06:13:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:13:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:13:30 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:13:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:13:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:13:30 --> Total execution time: 0.0025
ERROR - 2019-09-19 06:13:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:13:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:13:34 --> Total execution time: 0.0030
ERROR - 2019-09-19 06:13:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:13:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:13:39 --> Total execution time: 0.0019
ERROR - 2019-09-19 06:13:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:13:57 --> Total execution time: 0.0016
ERROR - 2019-09-19 06:13:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:13:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:13:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:13:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:13:57 --> Total execution time: 0.0043
ERROR - 2019-09-19 06:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:01 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:01 --> Total execution time: 0.0021
ERROR - 2019-09-19 06:14:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:05 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:05 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:14:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:08 --> Total execution time: 0.0036
ERROR - 2019-09-19 06:14:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:14:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:14:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:10 --> Total execution time: 0.0019
ERROR - 2019-09-19 06:14:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:22 --> Total execution time: 0.0017
ERROR - 2019-09-19 06:14:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:23 --> ROLE ::::: section
DEBUG - 2019-09-19 06:14:23 --> SELECT `u`.`fcm_token`
FROM `students` `b`
LEFT JOIN `users` `u` ON `b`.`users_id`=`u`.`id`
WHERE `b`.`school_id` = '3'
AND `b`.`class_id` = '1'
AND `b`.`sections_id` = '40'
DEBUG - 2019-09-19 06:14:23 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
    [1] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
)

DEBUG - 2019-09-19 06:14:23 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
    [1] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
)

DEBUG - 2019-09-19 06:14:23 --> HELLO
DEBUG - 2019-09-19 06:14:23 --> {"multicast_id":5891720691240384193,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568873663675127%ec14b888ec14b888"},{"message_id":"0:1568873663689111%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:14:23 --> Total execution time: 0.0736
ERROR - 2019-09-19 06:14:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:14:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:14:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:26 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:26 --> Total execution time: 0.0051
ERROR - 2019-09-19 06:14:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:32 --> Total execution time: 0.0072
ERROR - 2019-09-19 06:14:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:32 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:14:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:32 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:14:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:32 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 06:14:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:14:35 --> ROLE ::::: teacher
DEBUG - 2019-09-19 06:14:35 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:14:35 --> Array
(
    [0] => dgt4ECSgpUA:APA91bEaZCDv2tEcNaAAwEFRZX72-0yt-0P-_5x321q0jz432CD2TkffCPu08KVAh91XA4nK_NBcEcSBGjhAVBcpqF3lZClz0I87J0sJFtgBg41cw8_8lJZXidzpV6BPY0oHy3RvD7Sd
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 06:14:35 --> HELLO
DEBUG - 2019-09-19 06:14:35 --> {"multicast_id":5753652655230747796,"success":1,"failure":1,"canonical_ids":0,"results":[{"error":"NotRegistered"},{"message_id":"0:1568873675864258%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 06:14:35 --> Total execution time: 0.0817
ERROR - 2019-09-19 06:14:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:14:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:14:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:14:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:14:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:14:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:14:42 --> Total execution time: 0.0039
ERROR - 2019-09-19 06:14:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:14:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:14:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:14:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:14:56 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:14:56 --> Total execution time: 0.0017
ERROR - 2019-09-19 06:15:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:15:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:15:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:15:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:15:39 --> Total execution time: 0.0034
ERROR - 2019-09-19 06:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:17:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:17:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:17:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:17:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:17:39 --> Total execution time: 0.0039
ERROR - 2019-09-19 06:17:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:17:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:17:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:17:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:17:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:17:57 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:17:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:17:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:17:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:17:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:17:57 --> Total execution time: 0.0024
ERROR - 2019-09-19 06:18:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:18:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:18:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:18:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:18:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:18:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:18:09 --> Total execution time: 0.0028
ERROR - 2019-09-19 06:19:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:19:06 --> Total execution time: 0.0043
ERROR - 2019-09-19 06:19:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:19:07 --> Total execution time: 0.0025
ERROR - 2019-09-19 06:19:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:19:09 --> Total execution time: 0.0028
ERROR - 2019-09-19 06:19:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:19:12 --> Total execution time: 0.0025
ERROR - 2019-09-19 06:19:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:19:25 --> Total execution time: 0.0025
ERROR - 2019-09-19 06:19:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:39 --> Severity: Notice --> Undefined index: attendance /var/www/html/school/application/controllers/Api.php 1269
ERROR - 2019-09-19 06:19:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-19 06:19:39 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-19 06:19:39 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-19 06:19:39 --> Total execution time: 0.0025
ERROR - 2019-09-19 06:19:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:45 --> Severity: Notice --> Undefined index: attendance /var/www/html/school/application/controllers/Api.php 1269
ERROR - 2019-09-19 06:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-19 06:19:45 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-19 06:19:45 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-19 06:19:45 --> Total execution time: 0.0023
ERROR - 2019-09-19 06:19:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:53 --> Severity: Notice --> Undefined index: attendance /var/www/html/school/application/controllers/Api.php 1269
ERROR - 2019-09-19 06:19:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-19 06:19:53 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-19 06:19:53 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-19 06:19:53 --> Total execution time: 0.0024
ERROR - 2019-09-19 06:19:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:19:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:19:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:19:57 --> Severity: Notice --> Undefined index: attendance /var/www/html/school/application/controllers/Api.php 1269
ERROR - 2019-09-19 06:19:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/school/application/controllers/Api.php 1275
ERROR - 2019-09-19 06:19:57 --> Severity: Notice --> Undefined variable: attend /var/www/html/school/application/controllers/Api.php 1286
ERROR - 2019-09-19 06:19:57 --> Severity: Notice --> Undefined variable: att /var/www/html/school/application/controllers/Api.php 1287
DEBUG - 2019-09-19 06:19:57 --> Total execution time: 0.0024
ERROR - 2019-09-19 06:20:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:20:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:20:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:20:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:20:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:20:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:20:55 --> Total execution time: 0.0025
ERROR - 2019-09-19 06:21:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:21:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:21:58 --> Total execution time: 0.0029
ERROR - 2019-09-19 06:21:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:21:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:21:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:21:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:21:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:21:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:23:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:23:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:23:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:23:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:23:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:23:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:23:47 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:23:47 --> Total execution time: 0.0017
ERROR - 2019-09-19 06:24:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:24:05 --> Total execution time: 0.0018
ERROR - 2019-09-19 06:24:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:09 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:24:09 --> Total execution time: 0.0046
ERROR - 2019-09-19 06:24:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:24:12 --> Total execution time: 0.0048
ERROR - 2019-09-19 06:24:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:24:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:24:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:24:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:24:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:24:13 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-09-19 06:24:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:24:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:24:16 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:24:16 --> Total execution time: 0.0018
ERROR - 2019-09-19 06:24:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:24:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:24:31 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:24:31 --> Total execution time: 0.0019
ERROR - 2019-09-19 06:24:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:24:34 --> Total execution time: 0.0016
ERROR - 2019-09-19 06:24:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:40 --> No URI present. Default controller set.
DEBUG - 2019-09-19 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:24:40 --> Total execution time: 0.0048
ERROR - 2019-09-19 06:24:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:24:47 --> Total execution time: 0.0036
ERROR - 2019-09-19 06:24:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:24:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:24:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:24:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:24:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:24:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:24:48 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-09-19 06:25:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:25:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:25:05 --> Total execution time: 0.0039
ERROR - 2019-09-19 06:25:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:25:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:25:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:25:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:25:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:25:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:26:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:26:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:26:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:26:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:26:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:26:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:26:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:26:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:26:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:26:05 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:26:05 --> Total execution time: 0.0018
ERROR - 2019-09-19 06:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:26:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:26:06 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:26:06 --> Total execution time: 0.0015
ERROR - 2019-09-19 06:26:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:26:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:26:10 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:26:10 --> Total execution time: 0.0018
ERROR - 2019-09-19 06:26:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:26:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:26:34 --> Total execution time: 0.0043
ERROR - 2019-09-19 06:26:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:26:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:26:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:26:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:26:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:26:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:32:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:32:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:32:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:32:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:32:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:32:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:32:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:32:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:32:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:32:29 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 164
DEBUG - 2019-09-19 06:32:29 --> Total execution time: 0.0018
ERROR - 2019-09-19 06:32:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:32:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:32:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:32:30 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 164
DEBUG - 2019-09-19 06:32:30 --> Total execution time: 0.0018
ERROR - 2019-09-19 06:33:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:33:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:33:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:33:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:33:17 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:33:17 --> Total execution time: 0.0018
ERROR - 2019-09-19 06:35:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:35:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:35:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:35:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:35:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:35:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:35:54 --> Total execution time: 0.0037
ERROR - 2019-09-19 06:36:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:36:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:36:06 --> Total execution time: 0.0043
ERROR - 2019-09-19 06:36:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:36:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:36:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:36:07 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:36:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:36:07 --> Total execution time: 0.0044
ERROR - 2019-09-19 06:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:36:10 --> Total execution time: 0.0023
ERROR - 2019-09-19 06:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:36:39 --> Total execution time: 0.0025
ERROR - 2019-09-19 06:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:36:42 --> Total execution time: 0.0028
ERROR - 2019-09-19 06:36:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:36:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:36:54 --> Total execution time: 0.0027
ERROR - 2019-09-19 06:36:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:36:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:36:59 --> Total execution time: 0.0033
ERROR - 2019-09-19 06:37:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:37:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:37:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:37:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:37:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:37:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:37:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:37:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:37:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:37:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:37:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:37:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:37:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:37:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:37:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:37:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:37:12 --> Total execution time: 0.0026
ERROR - 2019-09-19 06:37:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:37:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:37:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:37:16 --> Total execution time: 0.0026
ERROR - 2019-09-19 06:38:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:38:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:38:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:38:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:38:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:38:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:38:00 --> Total execution time: 0.0029
ERROR - 2019-09-19 06:38:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:38:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:38:14 --> Total execution time: 0.0021
ERROR - 2019-09-19 06:39:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:39:43 --> Total execution time: 0.0074
ERROR - 2019-09-19 06:39:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:39:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:39:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:39:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:39:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:39:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:40:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:40:11 --> Total execution time: 0.0040
ERROR - 2019-09-19 06:40:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:40:22 --> Total execution time: 0.0043
ERROR - 2019-09-19 06:40:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:24 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:40:24 --> Total execution time: 0.0019
ERROR - 2019-09-19 06:40:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:24 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:40:24 --> Total execution time: 0.0014
ERROR - 2019-09-19 06:40:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:26 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:40:26 --> Total execution time: 0.0018
ERROR - 2019-09-19 06:40:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:31 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:31 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:40:31 --> Total execution time: 0.0017
ERROR - 2019-09-19 06:40:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:34 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:40:34 --> Total execution time: 0.0019
ERROR - 2019-09-19 06:40:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:40:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:40:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:40:40 --> Severity: Notice --> Undefined index: token /var/www/html/school/application/controllers/Api.php 287
DEBUG - 2019-09-19 06:40:40 --> Total execution time: 0.0019
ERROR - 2019-09-19 06:46:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:46:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:46:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 06:46:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:46:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:46:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 06:46:39 --> Total execution time: 0.0036
ERROR - 2019-09-19 06:49:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:49:24 --> Total execution time: 0.0042
ERROR - 2019-09-19 06:49:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:49:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 06:49:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:49:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:49:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:49:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 06:49:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:49:40 --> Total execution time: 0.0041
ERROR - 2019-09-19 06:49:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:49:41 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:49:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:49:42 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 06:49:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 06:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 06:49:49 --> Total execution time: 0.0040
ERROR - 2019-09-19 06:49:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:49:50 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 06:49:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 06:49:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 06:49:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 06:49:50 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 07:13:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:13:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 07:13:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:13:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 07:13:01 --> Total execution time: 0.0090
ERROR - 2019-09-19 07:13:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:13:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:13:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 07:13:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:13:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:13:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 07:13:02 --> Total execution time: 0.0024
ERROR - 2019-09-19 07:42:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:42:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 07:42:02 --> Total execution time: 0.0041
ERROR - 2019-09-19 07:42:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:42:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:42:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:42:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 07:42:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:42:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:42:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:42:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 07:42:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:42:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:42:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:42:03 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 07:50:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 07:50:14 --> Total execution time: 0.0043
ERROR - 2019-09-19 07:50:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:50:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 07:50:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:50:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 07:50:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 07:50:24 --> Total execution time: 0.0054
ERROR - 2019-09-19 07:50:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:50:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 07:50:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:50:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 07:50:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 07:50:29 --> Total execution time: 0.0039
ERROR - 2019-09-19 07:50:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 07:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 07:50:29 --> Total execution time: 0.0037
ERROR - 2019-09-19 07:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:50:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 07:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:50:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 07:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 07:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 07:50:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 07:50:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 08:31:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:31:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:31:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:31:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:31:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:31:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:31:08 --> Total execution time: 0.0043
ERROR - 2019-09-19 08:31:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:31:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:31:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:31:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:31:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:31:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:31:11 --> Total execution time: 0.0045
ERROR - 2019-09-19 08:34:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:34:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:34:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:34:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:34:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:34:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:34:58 --> Total execution time: 0.0030
ERROR - 2019-09-19 08:37:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:37:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:37:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:37:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:37:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:37:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:37:50 --> Total execution time: 0.0021
ERROR - 2019-09-19 08:38:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:38:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:38:00 --> Total execution time: 0.0018
ERROR - 2019-09-19 08:38:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:38:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:38:06 --> No URI present. Default controller set.
DEBUG - 2019-09-19 08:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:38:06 --> Total execution time: 0.0049
ERROR - 2019-09-19 08:38:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:38:24 --> Total execution time: 0.0045
ERROR - 2019-09-19 08:38:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:38:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 08:38:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:38:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:38:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:38:25 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 08:38:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:38:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 08:38:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:38:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:39:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:39:01 --> Total execution time: 0.0033
ERROR - 2019-09-19 08:39:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:39:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 08:39:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:39:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:39:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:39:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:39:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:39:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:39:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:39:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:39:19 --> Total execution time: 0.0026
ERROR - 2019-09-19 08:39:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:39:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:39:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:39:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:39:22 --> Total execution time: 0.0028
ERROR - 2019-09-19 08:39:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-09-19 08:39:47 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Marathi', '2019-09-19', '148')
ERROR - 2019-09-19 08:39:47 --> Query error: Duplicate entry 'Hindi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Hindi', '2019-09-19', '148')
ERROR - 2019-09-19 08:39:47 --> Query error: Duplicate entry 'Maths' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Maths', '2019-09-19', '148')
ERROR - 2019-09-19 08:39:47 --> Query error: Duplicate entry 'Science' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Science', '2019-09-19', '148')
DEBUG - 2019-09-19 08:39:47 --> Total execution time: 0.0694
ERROR - 2019-09-19 08:39:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:39:47 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 08:39:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:39:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:39:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 08:40:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:40:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:40:03 --> Total execution time: 0.0047
ERROR - 2019-09-19 08:40:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:40:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:40:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:40:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 08:40:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:40:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:40:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:40:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:40:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:40:04 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 08:45:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:45:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:45:07 --> Total execution time: 0.0021
ERROR - 2019-09-19 08:46:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:46:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:46:27 --> Total execution time: 0.0046
ERROR - 2019-09-19 08:46:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:46:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:46:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:46:29 --> Total execution time: 0.0045
ERROR - 2019-09-19 08:46:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:46:29 --> Total execution time: 0.0044
ERROR - 2019-09-19 08:46:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:46:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:46:34 --> Total execution time: 0.0034
ERROR - 2019-09-19 08:46:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:46:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:46:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:46:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:46:52 --> Total execution time: 0.0030
ERROR - 2019-09-19 08:48:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:48:15 --> Total execution time: 0.0019
ERROR - 2019-09-19 08:48:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:48:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:48:24 --> Total execution time: 0.0057
ERROR - 2019-09-19 08:48:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:48:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:48:38 --> Total execution time: 0.0043
ERROR - 2019-09-19 08:48:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:48:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:48:40 --> Total execution time: 0.0026
ERROR - 2019-09-19 08:48:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:48:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:48:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:48:43 --> Total execution time: 0.0025
ERROR - 2019-09-19 08:49:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:49:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:49:37 --> You did not select a file to upload.
DEBUG - 2019-09-19 08:49:37 --> Total execution time: 0.0342
ERROR - 2019-09-19 08:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:49:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 08:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:49:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 08:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:49:38 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-19 08:50:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:50:21 --> Total execution time: 0.0045
ERROR - 2019-09-19 08:50:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:50:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:50:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:50:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 08:50:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:50:21 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 08:50:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:50:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:51:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:51:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:52:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:52:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:52:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:52:00 --> Total execution time: 0.0049
ERROR - 2019-09-19 08:52:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:52:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:52:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:52:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:52:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:52:02 --> Total execution time: 0.0026
ERROR - 2019-09-19 08:52:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:52:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:52:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:52:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:52:05 --> Total execution time: 0.0024
ERROR - 2019-09-19 08:52:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:52:50 --> Total execution time: 0.0020
ERROR - 2019-09-19 08:53:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:53:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:53:49 --> Total execution time: 0.0018
ERROR - 2019-09-19 08:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:54:02 --> Total execution time: 0.0046
ERROR - 2019-09-19 08:54:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:54:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:54:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:54:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 08:54:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:54:03 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 08:54:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:54:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:54:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:54:21 --> Total execution time: 0.0338
ERROR - 2019-09-19 08:54:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:54:21 --> Total execution time: 0.0021
ERROR - 2019-09-19 08:54:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:54:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 08:54:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:54:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 08:54:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:54:22 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-19 08:54:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:54:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:54:50 --> Total execution time: 0.0020
ERROR - 2019-09-19 08:55:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:55:18 --> Total execution time: 0.0020
ERROR - 2019-09-19 08:55:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:55:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:55:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:55:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:55:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:55:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:55:57 --> Total execution time: 0.0042
ERROR - 2019-09-19 08:55:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:55:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:55:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:55:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:55:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:55:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:55:58 --> Total execution time: 0.0045
ERROR - 2019-09-19 08:55:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:55:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:55:58 --> Total execution time: 0.0045
ERROR - 2019-09-19 08:56:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:56:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:56:34 --> Total execution time: 0.0044
ERROR - 2019-09-19 08:56:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:56:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:56:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 08:56:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:56:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:56:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 08:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:57:05 --> ROLE ::::: student
DEBUG - 2019-09-19 08:57:05 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
)

DEBUG - 2019-09-19 08:57:05 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
)

DEBUG - 2019-09-19 08:57:05 --> HELLO
DEBUG - 2019-09-19 08:57:05 --> {"multicast_id":5725527082084192064,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568883425661628%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 08:57:05 --> Total execution time: 0.0762
ERROR - 2019-09-19 08:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:57:05 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 08:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:57:05 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 08:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 08:57:55 --> Total execution time: 0.0067
ERROR - 2019-09-19 08:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:57:55 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 08:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:57:55 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 08:57:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:57:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:57:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 08:57:56 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 08:58:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:58:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:58:09 --> Total execution time: 0.0043
ERROR - 2019-09-19 08:58:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:58:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:58:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:58:10 --> Total execution time: 0.0045
ERROR - 2019-09-19 08:58:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:58:10 --> Total execution time: 0.0045
ERROR - 2019-09-19 08:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:58:48 --> Total execution time: 0.0021
ERROR - 2019-09-19 08:58:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:58:53 --> Total execution time: 0.0047
ERROR - 2019-09-19 08:58:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:58:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:58:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:58:54 --> Total execution time: 0.0049
ERROR - 2019-09-19 08:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:58:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:58:55 --> Total execution time: 0.0044
ERROR - 2019-09-19 08:59:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:59:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:59:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:59:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:59:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:59:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:59:56 --> Total execution time: 0.0044
ERROR - 2019-09-19 08:59:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:59:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:59:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 08:59:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 08:59:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 08:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 08:59:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 08:59:58 --> Total execution time: 0.0026
ERROR - 2019-09-19 09:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:00:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:00:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:00:08 --> Total execution time: 0.0025
ERROR - 2019-09-19 09:00:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:00:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:00:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:00:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:00:12 --> Total execution time: 0.0026
ERROR - 2019-09-19 09:03:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:03:37 --> Total execution time: 0.0021
ERROR - 2019-09-19 09:03:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:03:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:03:59 --> ROLE ::::: student
DEBUG - 2019-09-19 09:03:59 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
)

DEBUG - 2019-09-19 09:03:59 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
)

DEBUG - 2019-09-19 09:03:59 --> HELLO
DEBUG - 2019-09-19 09:03:59 --> {"multicast_id":5355579267530778074,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568883839450821%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 09:03:59 --> Total execution time: 0.0792
ERROR - 2019-09-19 09:03:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:03:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:03:59 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 09:03:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:03:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:03:59 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 09:05:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:05:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:05:12 --> Total execution time: 0.0056
ERROR - 2019-09-19 09:05:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:05:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:05:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:05:13 --> Total execution time: 0.0045
ERROR - 2019-09-19 09:05:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:05:14 --> Total execution time: 0.0044
ERROR - 2019-09-19 09:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:05:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:05:22 --> Total execution time: 0.0044
ERROR - 2019-09-19 09:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:05:22 --> Total execution time: 0.0043
ERROR - 2019-09-19 09:05:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:05:32 --> Total execution time: 0.0049
ERROR - 2019-09-19 09:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:05:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 09:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:05:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 09:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:05:33 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 09:06:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:06:34 --> Total execution time: 0.0183
ERROR - 2019-09-19 09:06:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:06:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 09:06:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:06:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 09:06:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:06:35 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-09-19 09:06:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:06:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:06:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:06:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:06:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:06:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:06:45 --> Total execution time: 0.0043
ERROR - 2019-09-19 09:06:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:06:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:06:45 --> Total execution time: 0.0045
ERROR - 2019-09-19 09:06:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:06:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:06:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:06:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:06:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:06:55 --> Total execution time: 0.0048
ERROR - 2019-09-19 09:07:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:07:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:07:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:07:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:07:06 --> Total execution time: 0.0041
ERROR - 2019-09-19 09:07:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:07:19 --> Total execution time: 0.0040
ERROR - 2019-09-19 09:07:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:07:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 09:07:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:07:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 09:07:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:07:22 --> Total execution time: 0.0022
ERROR - 2019-09-19 09:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:07:38 --> Total execution time: 0.0067
ERROR - 2019-09-19 09:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:07:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 09:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:07:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 09:10:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:10:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:10:29 --> ROLE ::::: student
DEBUG - 2019-09-19 09:10:29 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
)

DEBUG - 2019-09-19 09:10:29 --> Array
(
    [0] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
)

DEBUG - 2019-09-19 09:10:30 --> HELLO
DEBUG - 2019-09-19 09:10:30 --> {"multicast_id":9028445936115602344,"success":1,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568884230140901%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 09:10:30 --> Total execution time: 1.1091
ERROR - 2019-09-19 09:10:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:10:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:10:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 09:10:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:10:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:10:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 09:12:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:12:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:12:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:12:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:12:21 --> Total execution time: 0.0047
ERROR - 2019-09-19 09:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:12:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:12:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:12:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:12:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:12:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:12:22 --> Total execution time: 0.0045
ERROR - 2019-09-19 09:12:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:12:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:12:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:12:22 --> Total execution time: 0.0044
ERROR - 2019-09-19 09:13:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:13:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:13:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:13:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:13:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:13:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:13:13 --> Total execution time: 0.0044
ERROR - 2019-09-19 09:13:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:13:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:13:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:13:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:13:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:13:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:13:14 --> Total execution time: 0.0026
ERROR - 2019-09-19 09:16:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:16:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:16:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:16:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:16:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:16:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:16:23 --> Total execution time: 0.0044
ERROR - 2019-09-19 09:16:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:16:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:16:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:16:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:16:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:16:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:16:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:16:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:16:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:16:25 --> Total execution time: 0.0045
ERROR - 2019-09-19 09:16:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:16:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:16:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:16:25 --> Total execution time: 0.0043
ERROR - 2019-09-19 09:28:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:28:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:28:50 --> No URI present. Default controller set.
DEBUG - 2019-09-19 09:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:28:50 --> Total execution time: 0.0016
ERROR - 2019-09-19 09:28:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:28:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:28:59 --> No URI present. Default controller set.
DEBUG - 2019-09-19 09:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:28:59 --> Total execution time: 0.0045
ERROR - 2019-09-19 09:29:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:29:08 --> Total execution time: 0.0043
ERROR - 2019-09-19 09:29:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:29:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 09:29:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:29:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:29:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 09:29:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:29:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 09:29:22 --> ROLE ::::: parent
DEBUG - 2019-09-19 09:29:22 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => eqdGug4Wf3o:APA91bEzfGTvdDy5zSWdR_rlKYuB-cJDwa9OMRB3Bv-uSbCoQoAdsZHONEB04SenWIsn48albucxuDdj4mOUlRLB5uOXILAXGcR0U3Au3CKjfAMQVKMUsOE4D93aJguR6QlqahN4cqee
    [4] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 09:29:22 --> Array
(
    [0] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [1] => fZzhfl7F7zM:APA91bFPv0ciXuGPyX4PRLlv9A1ugWUCZYKhI0_llvAVTgyuFSArCQ1N62_XYtTkVUh-C9CJ_NWZB5kE-KgotCSl2WogILGrxLAfzZpgOk8AV2qQ-mnwGO1AHI9fNF_OvBBzEvEhFrxT
    [2] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [3] => eqdGug4Wf3o:APA91bEzfGTvdDy5zSWdR_rlKYuB-cJDwa9OMRB3Bv-uSbCoQoAdsZHONEB04SenWIsn48albucxuDdj4mOUlRLB5uOXILAXGcR0U3Au3CKjfAMQVKMUsOE4D93aJguR6QlqahN4cqee
    [4] => dPmqScfXmeI:APA91bFwe8Bn2_nr7NeVGHUdLc2nQCDMn3bs2Lwgxtf1jGDhZmmFl7ai7nxg-ZaPAgkRXiADlslhkl_yGv_Xj_sAcHx6afBX7zr0Y0vtQ8ZxhxbBz2k9uAiI3LuAR6UQFB-S330EYPMZ
    [5] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [6] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
    [7] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 09:29:23 --> HELLO
DEBUG - 2019-09-19 09:29:23 --> {"multicast_id":9169388716272272231,"success":8,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568885363257975%ec14b888ec14b888"},{"message_id":"0:1568885363264487%ec14b888ec14b888"},{"message_id":"0:1568885363261549%ec14b888ec14b888"},{"message_id":"0:1568885363260060%ec14b888ec14b888"},{"message_id":"0:1568885363269226%ec14b888ec14b888"},{"message_id":"0:1568885363257837%ec14b888ec14b888"},{"message_id":"0:1568885363257977%ec14b888ec14b888"},{"message_id":"0:1568885363257838%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 09:29:23 --> Total execution time: 1.0831
ERROR - 2019-09-19 09:29:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:29:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:29:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 09:29:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:29:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 09:29:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 09:34:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:34:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:34:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:34:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:34:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:34:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:34:53 --> Total execution time: 0.0042
ERROR - 2019-09-19 09:34:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:34:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:34:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:34:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:34:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:34:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:34:54 --> Total execution time: 0.0025
ERROR - 2019-09-19 09:34:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:34:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:34:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:34:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:34:58 --> Driver Route Token ::::: 22663_2019/09/19-09:09:53
DEBUG - 2019-09-19 09:34:58 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 09:34:58 --> Total execution time: 0.0030
ERROR - 2019-09-19 09:35:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:35:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:35:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 09:35:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 09:35:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 09:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 09:35:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 09:35:00 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 09:35:00 --> Total execution time: 0.0022
ERROR - 2019-09-19 10:03:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:03:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:03:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:03:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:03:04 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:03:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:03:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:03:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:03:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:03:06 --> Total execution time: 0.0025
ERROR - 2019-09-19 10:14:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:14:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:14:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:14:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:14:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:14:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:14:17 --> Total execution time: 0.0039
ERROR - 2019-09-19 10:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:14:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:14:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:14:47 --> Total execution time: 0.0042
ERROR - 2019-09-19 10:14:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:14:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:14:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:14:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:14:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:14:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:14:51 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:14:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:14:51 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:15:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:15:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:15:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:15:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:15:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:15:00 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:15:00 --> Total execution time: 0.0029
ERROR - 2019-09-19 10:17:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:17:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:17:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:17:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:17:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:17:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:17:11 --> Total execution time: 0.0024
ERROR - 2019-09-19 10:21:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:21:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:21:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:21:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:21:33 --> Total execution time: 0.0047
ERROR - 2019-09-19 10:21:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:21:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:21:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:21:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:21:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:21:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:21:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:21:37 --> Total execution time: 0.0046
ERROR - 2019-09-19 10:21:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:21:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:21:37 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:22:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:22:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:22:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:22:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:22:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:22:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:22:02 --> Total execution time: 0.0024
ERROR - 2019-09-19 10:23:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:23:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:23:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:23:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:23:02 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:23:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:23:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:23:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:23:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:23:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:23:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:23:25 --> Total execution time: 0.0042
ERROR - 2019-09-19 10:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:23:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:23:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:23:29 --> Total execution time: 0.0030
ERROR - 2019-09-19 10:28:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:28:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:28:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:28:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:28:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:28:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:28:21 --> Total execution time: 0.0041
ERROR - 2019-09-19 10:28:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:28:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:28:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:28:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:28:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:28:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:28:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:28:24 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:28:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:28:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:28:24 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:28:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:28:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:28:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:28:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:28:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:28:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:28:30 --> Total execution time: 0.0029
ERROR - 2019-09-19 10:34:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:34:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 10:34:54 --> Total execution time: 0.0018
ERROR - 2019-09-19 10:35:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:00 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:00 --> No URI present. Default controller set.
DEBUG - 2019-09-19 10:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 10:35:00 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 10:35:07 --> Total execution time: 0.0038
ERROR - 2019-09-19 10:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 10:35:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 10:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 10:35:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 10:35:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 10:35:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 10:35:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:35:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:35:32 --> Total execution time: 0.0042
ERROR - 2019-09-19 10:35:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:35:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:35:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:35:37 --> Total execution time: 0.0046
ERROR - 2019-09-19 10:35:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:35:37 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:35:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:35:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:35:44 --> Total execution time: 0.0033
ERROR - 2019-09-19 10:35:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:35:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:35:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:35:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:35:50 --> mPDF class is loaded.
DEBUG - 2019-09-19 11:35:50 --> Total execution time: 0.3262
ERROR - 2019-09-19 10:36:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:36:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:36:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:36:39 --> Total execution time: 0.0043
ERROR - 2019-09-19 10:36:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:36:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:36:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:36:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:36:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:36:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:36:41 --> Total execution time: 0.0046
ERROR - 2019-09-19 10:36:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:36:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:36:41 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:37:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:37:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:37:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:37:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:37:03 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:37:03 --> Total execution time: 0.0030
ERROR - 2019-09-19 10:37:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:37:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:37:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:37:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:37:05 --> mPDF class is loaded.
DEBUG - 2019-09-19 11:37:05 --> Total execution time: 0.2811
ERROR - 2019-09-19 10:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:45:22 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:45:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:45:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:25 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:25 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:45:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:45:26 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:45:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:45:26 --> Total execution time: 0.0045
ERROR - 2019-09-19 10:45:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:45:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:45:33 --> Total execution time: 0.0031
ERROR - 2019-09-19 10:45:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:45:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:45:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:45:42 --> mPDF class is loaded.
DEBUG - 2019-09-19 11:45:42 --> Total execution time: 0.3067
ERROR - 2019-09-19 10:48:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:48:15 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:48:15 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:48:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:48:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:48:16 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:48:16 --> Total execution time: 0.0042
ERROR - 2019-09-19 10:48:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:48:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:48:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:48:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:48:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:48:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:48:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:48:18 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:48:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:48:18 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:48:18 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:48:18 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:48:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:48:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:48:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:48:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:48:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:48:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:48:22 --> Total execution time: 0.0030
ERROR - 2019-09-19 10:51:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:51:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:51:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:51:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:51:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:51:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:51:50 --> Total execution time: 0.0043
ERROR - 2019-09-19 10:51:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:51:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:51:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:51:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:51:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:51:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:51:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:51:54 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:51:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:51:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:51:54 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:52:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:52:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:52:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:52:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:52:01 --> Total execution time: 0.0031
ERROR - 2019-09-19 10:55:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:55:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:55:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:55:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:55:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:55:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:55:43 --> Total execution time: 0.0046
ERROR - 2019-09-19 10:55:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:55:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:55:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:55:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:55:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:55:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:55:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:55:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:55:46 --> Total execution time: 0.0046
ERROR - 2019-09-19 10:55:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:55:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:55:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:55:46 --> Total execution time: 0.0042
ERROR - 2019-09-19 10:55:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:55:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:55:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:55:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:55:54 --> Total execution time: 0.0031
ERROR - 2019-09-19 10:58:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:58:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:58:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:58:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:58:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:58:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:58:49 --> Total execution time: 0.0043
ERROR - 2019-09-19 10:58:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:58:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:58:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:58:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:58:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:58:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:58:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:58:52 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:58:52 --> Total execution time: 0.0046
ERROR - 2019-09-19 10:58:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:58:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:58:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:58:53 --> Total execution time: 0.0044
ERROR - 2019-09-19 10:58:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:58:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:58:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 10:58:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 10:58:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 10:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 10:58:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 10:58:59 --> Total execution time: 0.0030
ERROR - 2019-09-19 11:11:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:11:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:11:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:11:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:11:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:11:08 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:11:08 --> Total execution time: 0.0043
ERROR - 2019-09-19 11:11:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:11:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:11:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:11:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:11:10 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:11:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:11:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:11:11 --> Total execution time: 0.0046
ERROR - 2019-09-19 11:11:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:11:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:11:12 --> Total execution time: 0.0045
ERROR - 2019-09-19 11:11:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:11:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:11:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:11:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:11:19 --> Total execution time: 0.0032
ERROR - 2019-09-19 11:17:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:17:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:17:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:17:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:17:36 --> Total execution time: 0.0051
ERROR - 2019-09-19 11:17:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:17:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:17:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:17:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:17:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:17:39 --> Total execution time: 0.0047
ERROR - 2019-09-19 11:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:17:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:17:39 --> Total execution time: 0.0044
ERROR - 2019-09-19 11:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:17:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:17:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:17:46 --> Total execution time: 0.0154
ERROR - 2019-09-19 11:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:18:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:18:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:18:04 --> Total execution time: 0.0145
ERROR - 2019-09-19 11:18:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:18:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:18:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:18:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:18:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:18:06 --> Total execution time: 0.0039
ERROR - 2019-09-19 11:23:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:23:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:23:32 --> Total execution time: 0.0043
ERROR - 2019-09-19 11:23:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:23:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:23:35 --> Total execution time: 0.0099
ERROR - 2019-09-19 11:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:23:36 --> Total execution time: 0.0043
ERROR - 2019-09-19 11:23:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:23:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:23:41 --> Total execution time: 0.0042
ERROR - 2019-09-19 11:23:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:23:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:23:55 --> Total execution time: 0.0045
ERROR - 2019-09-19 11:23:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:23:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:23:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:23:58 --> Total execution time: 0.0026
ERROR - 2019-09-19 11:24:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:24:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:24:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:24:01 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:24:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 11:24:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 11:24:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/school/application/controllers/Api.php 293
ERROR - 2019-09-19 11:24:01 --> Severity: Notice --> Trying to get property of non-object /var/www/html/school/application/controllers/Api.php 293
DEBUG - 2019-09-19 11:24:01 --> Total execution time: 0.0054
ERROR - 2019-09-19 11:25:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:25:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:25:34 --> Total execution time: 0.0160
ERROR - 2019-09-19 11:26:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:26:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:26:17 --> No URI present. Default controller set.
DEBUG - 2019-09-19 11:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:26:17 --> Total execution time: 0.0105
ERROR - 2019-09-19 11:27:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:27:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:27:12 --> Total execution time: 0.0095
ERROR - 2019-09-19 11:27:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:27:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:27:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:27:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:27:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:27:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:27:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:27:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:27:12 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 11:27:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:27:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:27:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:27:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:27:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:27:53 --> Total execution time: 0.0029
ERROR - 2019-09-19 11:27:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:27:53 --> Total execution time: 0.0019
ERROR - 2019-09-19 11:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:29:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:29:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:29:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:29:49 --> Total execution time: 0.0043
ERROR - 2019-09-19 11:29:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:29:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:29:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:29:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:29:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:29:51 --> Total execution time: 0.0027
ERROR - 2019-09-19 11:29:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:29:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:29:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:29:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:29:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:29:57 --> Total execution time: 0.0036
ERROR - 2019-09-19 11:30:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:30:58 --> Total execution time: 0.0073
ERROR - 2019-09-19 11:30:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:30:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:30:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:30:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:31:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:31:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:31:04 --> Total execution time: 0.0056
ERROR - 2019-09-19 11:31:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:31:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:31:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:31:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:31:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:31:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:31:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:31:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:31:09 --> Total execution time: 0.0042
ERROR - 2019-09-19 11:31:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:31:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:31:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:31:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:31:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:31:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:31:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:31:10 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:31:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:31:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:32:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:32:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:32:02 --> Total execution time: 0.0021
ERROR - 2019-09-19 11:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:32:06 --> Total execution time: 0.0020
ERROR - 2019-09-19 11:33:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:33:08 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:33:08 --> Total execution time: 0.0036
ERROR - 2019-09-19 11:33:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:33:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:33:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:33:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:33:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:33:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:33:20 --> Total execution time: 0.0056
ERROR - 2019-09-19 11:33:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:33:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:33:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:33:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:35:40 --> No URI present. Default controller set.
DEBUG - 2019-09-19 11:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:35:40 --> Total execution time: 0.0018
ERROR - 2019-09-19 11:39:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:39:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:39:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:39:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:39:44 --> Total execution time: 0.0046
ERROR - 2019-09-19 11:39:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:39:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:39:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:39:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:39:45 --> Total execution time: 0.0024
ERROR - 2019-09-19 11:41:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:41:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:41:30 --> ROLE ::::: driver
ERROR - 2019-09-19 11:41:30 --> CI_DB_mysqli_result Object
(
    [conn_id] => mysqli Object
        (
            [affected_rows] => 2
            [client_info] => mysqlnd 5.0.12-dev - 20150407 - $Id: b5c5906d452ec590732a93b051f3827e02749b83 $
            [client_version] => 50012
            [connect_errno] => 0
            [connect_error] => 
            [errno] => 0
            [error] => 
            [error_list] => Array
                (
                )

            [field_count] => 1
            [host_info] => 127.0.0.1 via TCP/IP
            [info] => 
            [insert_id] => 0
            [server_info] => 5.7.27-0ubuntu0.18.04.1
            [server_version] => 50727
            [stat] => Uptime: 4843217  Threads: 2  Questions: 197834  Slow queries: 0  Opens: 6930  Flush tables: 1  Open tables: 806  Queries per second avg: 0.040
            [sqlstate] => 00000
            [protocol_version] => 10
            [thread_id] => 41526
            [warning_count] => 0
        )

    [result_id] => mysqli_result Object
        (
            [current_field] => 0
            [field_count] => 1
            [lengths] => 
            [num_rows] => 2
            [type] => 0
        )

    [result_array] => Array
        (
        )

    [result_object] => Array
        (
        )

    [custom_result_object] => Array
        (
        )

    [current_row] => 0
    [num_rows] => 
    [row_data] => 
)

DEBUG - 2019-09-19 11:41:30 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 11:41:30 --> Array
(
    [0] => cEJefkfYlwA:APA91bFIXE-1wo8ELyxs-4ZRN2sf9DpXV_sh0gbTrhneZK8MUcmLb7u1J7ED-YVLcbWDiBelosOT_XPeFnAOuYZTIl0a2Uu1zL9iTe6UFyLGElCuJ7S0IQ5h2WtwGbZ067oEQo007Y2P
    [1] => fOh6bgGcDC4:APA91bGL1h16I3Ima6b8oXIDn54iunFL778dr6mMstvSkLIy_ZzmmwdxAZjk9On7nGiJ4oQthkNIZE6oD0A8feyI45bNaT32PBSriNnkFp2xE60raqwFg8mjIQH2FZIdmIcZVs7ySMBW
)

DEBUG - 2019-09-19 11:41:30 --> HELLO
DEBUG - 2019-09-19 11:41:30 --> {"multicast_id":7552789510875909348,"success":2,"failure":0,"canonical_ids":0,"results":[{"message_id":"0:1568893290320838%ec14b888ec14b888"},{"message_id":"0:1568893290319134%ec14b888ec14b888"}]}
DEBUG - 2019-09-19 11:41:30 --> Total execution time: 0.0817
ERROR - 2019-09-19 11:41:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:41:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:41:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 11:41:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:41:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:41:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 11:42:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:42:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:42:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 11:42:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:42:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:42:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 11:42:29 --> Total execution time: 0.0062
ERROR - 2019-09-19 11:45:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:45:57 --> Total execution time: 0.0046
ERROR - 2019-09-19 11:45:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:45:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:45:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:45:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:45:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:45:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:49:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:49:43 --> Total execution time: 0.0047
ERROR - 2019-09-19 11:49:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:49:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:49:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:49:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:49:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:49:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:49:59 --> Total execution time: 0.0065
ERROR - 2019-09-19 11:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:49:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:49:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:50:41 --> Total execution time: 0.0063
ERROR - 2019-09-19 11:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:50:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:50:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:50:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:50:56 --> Total execution time: 0.0042
ERROR - 2019-09-19 11:50:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:50:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:50:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:50:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:50:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:50:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:52:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:52:54 --> Total execution time: 0.0247
ERROR - 2019-09-19 11:52:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:52:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 11:52:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:52:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 11:53:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:53:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:53:05 --> Total execution time: 0.0027
ERROR - 2019-09-19 11:53:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:53:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:53:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:53:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:53:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:53:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 11:57:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:57:49 --> Total execution time: 0.0152
ERROR - 2019-09-19 11:57:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:57:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 11:57:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:57:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 11:59:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:59:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 11:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 11:59:59 --> Total execution time: 0.0035
ERROR - 2019-09-19 11:59:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:59:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:59:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 11:59:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 11:59:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 11:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 11:59:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:00:04 --> Total execution time: 0.0035
ERROR - 2019-09-19 12:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:00:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:00:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:00:14 --> Total execution time: 0.0057
ERROR - 2019-09-19 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:00:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:00:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:00:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:03:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:03:12 --> Total execution time: 0.0055
ERROR - 2019-09-19 12:03:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:03:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-09-19 12:03:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:03:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:03:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-09-19 12:03:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:03:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:03:26 --> Total execution time: 0.0043
ERROR - 2019-09-19 12:03:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:03:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:03:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:03:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:03:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:03:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:08:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:08:35 --> Total execution time: 0.0043
ERROR - 2019-09-19 12:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:08:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:08:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:08:36 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 12:08:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:08:43 --> Total execution time: 0.0021
ERROR - 2019-09-19 12:08:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:08:43 --> Total execution time: 0.0041
ERROR - 2019-09-19 12:08:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:08:43 --> Total execution time: 0.0017
ERROR - 2019-09-19 12:08:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:08:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:08:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:08:43 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-09-19 12:08:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:08:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:08:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:08:52 --> Total execution time: 0.0020
ERROR - 2019-09-19 12:08:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:08:52 --> Total execution time: 0.0045
ERROR - 2019-09-19 12:08:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:08:52 --> Total execution time: 0.0020
ERROR - 2019-09-19 12:08:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:08:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:08:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:08:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:08:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:10:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:10:16 --> Total execution time: 0.0032
ERROR - 2019-09-19 12:10:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:10:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:10:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:10:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:10:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:10:19 --> Total execution time: 0.0045
ERROR - 2019-09-19 12:10:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:10:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:10:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:10:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:10:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:10:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:10:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:10:24 --> Total execution time: 0.0041
ERROR - 2019-09-19 12:10:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:10:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:10:34 --> Total execution time: 0.0042
ERROR - 2019-09-19 12:11:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:11:41 --> Total execution time: 0.0026
ERROR - 2019-09-19 12:11:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:11:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:11:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:11:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:12:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:12:36 --> Total execution time: 0.0017
ERROR - 2019-09-19 12:19:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:19:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:19:16 --> Total execution time: 0.0074
ERROR - 2019-09-19 12:19:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:19:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:19:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:19:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:19:16 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:19:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:22:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:22:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:22:47 --> Total execution time: 0.0060
ERROR - 2019-09-19 12:22:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:22:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:22:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 12:22:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:22:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 12:22:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 12:33:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:33:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:33:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 12:33:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:33:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:33:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 12:33:22 --> Total execution time: 0.0041
ERROR - 2019-09-19 12:33:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:33:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:33:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 12:33:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:33:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 12:33:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:33:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:33:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 12:33:26 --> Total execution time: 0.0046
ERROR - 2019-09-19 12:33:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:33:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:33:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 12:33:26 --> Total execution time: 0.0045
ERROR - 2019-09-19 12:34:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:34:31 --> Total execution time: 0.0021
ERROR - 2019-09-19 12:34:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:34:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:34:57 --> Total execution time: 0.0021
ERROR - 2019-09-19 12:39:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:39:01 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:39:01 --> Total execution time: 0.0126
ERROR - 2019-09-19 12:39:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:39:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:39:13 --> Total execution time: 0.0020
ERROR - 2019-09-19 12:39:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:39:19 --> Total execution time: 0.0020
ERROR - 2019-09-19 12:39:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:39:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:39:22 --> Total execution time: 0.0021
ERROR - 2019-09-19 12:39:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:39:29 --> Total execution time: 0.0020
ERROR - 2019-09-19 12:39:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:39:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:39:41 --> Total execution time: 0.0030
ERROR - 2019-09-19 12:39:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:39:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 12:39:44 --> Total execution time: 0.0022
ERROR - 2019-09-19 12:54:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:54:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:54:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 12:54:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:54:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:54:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 12:54:04 --> Total execution time: 0.0025
ERROR - 2019-09-19 12:54:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:54:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:54:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 12:54:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:54:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:54:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 12:54:06 --> Driver Route Token ::::: 22663_2019/09/19-09:09:53
DEBUG - 2019-09-19 12:54:06 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 12:54:06 --> Total execution time: 0.0030
ERROR - 2019-09-19 12:54:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:54:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 12:54:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 12:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 12:54:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 12:54:09 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 12:54:09 --> Total execution time: 0.0022
ERROR - 2019-09-19 13:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:04:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:04:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:04:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:04:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:04:29 --> Total execution time: 0.0030
ERROR - 2019-09-19 13:04:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:04:32 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:04:32 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:04:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:04:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:04:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:04:33 --> Driver Route Token ::::: 22663_2019/09/19-09:09:53
DEBUG - 2019-09-19 13:04:33 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 13:04:33 --> Total execution time: 0.0028
ERROR - 2019-09-19 13:05:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:05:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:05:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:05:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:05:28 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:05:28 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:05:28 --> Total execution time: 0.0041
ERROR - 2019-09-19 13:05:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:05:40 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:05:40 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:05:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:05:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:05:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:05:41 --> Total execution time: 0.0042
ERROR - 2019-09-19 13:05:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:05:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:05:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:05:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:05:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:05:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:05:43 --> Total execution time: 0.0027
ERROR - 2019-09-19 13:11:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:11:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:11:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:11:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:11:20 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:11:20 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:11:20 --> Total execution time: 0.0046
ERROR - 2019-09-19 13:11:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:11:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:11:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:11:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:11:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:11:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:11:22 --> Total execution time: 0.0025
ERROR - 2019-09-19 13:15:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:15:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:15:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:15:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:15:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:15:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:15:44 --> Total execution time: 0.0194
ERROR - 2019-09-19 13:15:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:15:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:15:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:15:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:15:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:15:47 --> Total execution time: 0.0051
ERROR - 2019-09-19 13:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:18:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:18:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:18:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:18:05 --> Total execution time: 0.0051
ERROR - 2019-09-19 13:18:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:18:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:18:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:18:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:18:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:18:07 --> Total execution time: 0.0024
ERROR - 2019-09-19 13:18:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:18:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:18:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:18:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:18:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:18:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:18:14 --> Total execution time: 0.0034
ERROR - 2019-09-19 13:19:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:19:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 13:19:21 --> Total execution time: 0.0231
ERROR - 2019-09-19 13:19:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:19:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 13:19:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 13:19:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:19:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 13:19:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 13:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-09-19 13:19:42 --> Total execution time: 0.0061
ERROR - 2019-09-19 13:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 13:19:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-09-19 13:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 13:19:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-09-19 13:20:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:20:35 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:20:35 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:20:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:20:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:20:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:20:36 --> Total execution time: 0.0073
ERROR - 2019-09-19 13:20:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:20:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:20:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:20:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:20:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:20:39 --> Total execution time: 0.0032
ERROR - 2019-09-19 13:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:20:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:20:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:20:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:20:42 --> Total execution time: 0.0029
ERROR - 2019-09-19 13:23:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:23:11 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:23:11 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:23:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:23:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:23:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:23:12 --> Total execution time: 0.0044
ERROR - 2019-09-19 13:23:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:23:13 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:23:13 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:23:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:23:14 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:23:14 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:23:14 --> Total execution time: 0.0027
ERROR - 2019-09-19 13:25:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:25:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:25:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:25:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:25:26 --> Total execution time: 0.0047
ERROR - 2019-09-19 13:25:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:25:29 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:25:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:25:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:25:30 --> Total execution time: 0.0026
ERROR - 2019-09-19 13:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:37:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:37:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:37:33 --> Total execution time: 0.0046
ERROR - 2019-09-19 13:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:37:33 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:37:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:37:34 --> Total execution time: 0.0036
ERROR - 2019-09-19 13:37:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:37:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:37:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:37:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:37:36 --> Driver Route Token ::::: 40713_2019/09/19-13:09:33
DEBUG - 2019-09-19 13:37:36 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 13:37:36 --> Total execution time: 0.0029
ERROR - 2019-09-19 13:37:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:37:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:37:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:37:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:37:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:37:39 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 13:37:39 --> Total execution time: 0.0026
ERROR - 2019-09-19 13:44:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:44:44 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:44:44 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:44:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:44:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:44:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:44:45 --> Total execution time: 0.0043
ERROR - 2019-09-19 13:44:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:44:45 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:44:45 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:44:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:44:46 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:44:46 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:44:46 --> Total execution time: 0.0025
ERROR - 2019-09-19 13:44:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:44:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:44:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:44:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:44:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:44:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:44:49 --> Driver Route Token ::::: 20438_2019/09/19-13:09:45
DEBUG - 2019-09-19 13:44:49 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 13:44:49 --> Total execution time: 0.0029
ERROR - 2019-09-19 13:45:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:45:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:45:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:45:06 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:45:06 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 13:45:06 --> Total execution time: 0.0023
ERROR - 2019-09-19 13:46:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:46:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:34 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:34 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:46:34 --> Total execution time: 0.0045
ERROR - 2019-09-19 13:46:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:46:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:36 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:36 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:46:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:46:37 --> Total execution time: 0.0070
ERROR - 2019-09-19 13:46:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:37 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:37 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:46:37 --> Total execution time: 0.0045
ERROR - 2019-09-19 13:46:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:46:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:46:41 --> Total execution time: 0.0039
ERROR - 2019-09-19 13:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:46:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:46:53 --> Total execution time: 0.0044
ERROR - 2019-09-19 13:46:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 13:46:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 13:46:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 13:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 13:46:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 13:46:54 --> Total execution time: 0.0025
ERROR - 2019-09-19 14:07:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:07:21 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:07:21 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:07:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:07:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:07:22 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 14:07:22 --> Total execution time: 0.0025
ERROR - 2019-09-19 14:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:07:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:07:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:07:43 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 14:07:43 --> Total execution time: 0.0024
ERROR - 2019-09-19 14:10:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:10:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:10:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:10:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:10:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:10:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:10:54 --> Total execution time: 0.0050
ERROR - 2019-09-19 14:10:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:10:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:10:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:10:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:10:55 --> Total execution time: 0.0026
ERROR - 2019-09-19 14:10:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:10:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:10:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:10:59 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:10:59 --> Driver Route Token ::::: 63325_2019/09/19-14:09:54
DEBUG - 2019-09-19 14:10:59 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 14:10:59 --> Total execution time: 0.0034
ERROR - 2019-09-19 14:11:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:11:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:11:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:11:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:11:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:11:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:11:12 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 14:11:12 --> Total execution time: 0.0025
ERROR - 2019-09-19 14:11:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:11:12 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:11:12 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 14:11:12 --> Total execution time: 0.0025
ERROR - 2019-09-19 14:11:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:11:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:11:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:11:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:11:55 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:11:55 --> Total execution time: 0.0043
ERROR - 2019-09-19 14:12:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:12:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:12:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:12:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:12:49 --> Total execution time: 0.0044
ERROR - 2019-09-19 14:12:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:12:49 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 14:12:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 14:12:50 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 14:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 14:12:50 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 14:12:50 --> Total execution time: 0.0026
ERROR - 2019-09-19 15:04:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:04:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:04:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:04:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:04:07 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:04:07 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:04:07 --> Driver Route Token ::::: 99471_2019/09/19-14:09:49
DEBUG - 2019-09-19 15:04:07 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 15:04:07 --> Total execution time: 0.0028
ERROR - 2019-09-19 15:31:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:31:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:31:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:31:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:31:19 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:31:19 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:31:19 --> Driver Route Token ::::: 99471_2019/09/19-14:09:49
DEBUG - 2019-09-19 15:31:19 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 15:31:19 --> Total execution time: 0.0033
ERROR - 2019-09-19 15:31:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:31:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:31:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:31:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:31:24 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:31:24 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:31:24 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 15:31:24 --> Total execution time: 0.0026
ERROR - 2019-09-19 15:38:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:38:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:38:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:38:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:38:26 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:38:26 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:38:26 --> Total execution time: 0.0046
ERROR - 2019-09-19 15:38:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:38:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:38:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:38:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:38:27 --> Total execution time: 0.0027
ERROR - 2019-09-19 15:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:38:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:38:30 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:38:30 --> Driver Route Token ::::: 90893_2019/09/19-15:09:26
DEBUG - 2019-09-19 15:38:30 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 15:38:30 --> Total execution time: 0.0034
ERROR - 2019-09-19 15:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:38:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:38:38 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:38:38 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 15:38:38 --> Total execution time: 0.0025
ERROR - 2019-09-19 15:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:39:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:39:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:39:39 --> Severity: error --> Exception: syntax error, unexpected ''latitude'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/school/application/models/M_location.php 20
ERROR - 2019-09-19 15:40:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:40:41 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:40:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:40:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:40:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:40:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:40:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:40:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:40:42 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 15:40:42 --> Total execution time: 0.0024
ERROR - 2019-09-19 15:40:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:40:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:40:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:40:42 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 15:40:42 --> Total execution time: 0.0025
ERROR - 2019-09-19 15:40:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:40:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:40:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:40:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:40:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:40:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:40:43 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:40:43 --> Total execution time: 0.0061
ERROR - 2019-09-19 15:41:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:41:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:41:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:41:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:41:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:41:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:41:39 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:41:39 --> Total execution time: 0.0049
ERROR - 2019-09-19 15:41:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:41:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:41:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:41:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:41:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:41:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:41:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:41:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:41:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:41:48 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:41:48 --> Total execution time: 0.0047
ERROR - 2019-09-19 15:41:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:41:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:41:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:41:48 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:41:48 --> Total execution time: 0.0052
ERROR - 2019-09-19 15:42:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:42:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:42:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:42:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:42:39 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:42:39 --> Total execution time: 0.0048
ERROR - 2019-09-19 15:42:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:42:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:42:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:42:47 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:42:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:42:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:42:48 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:42:48 --> Total execution time: 0.0047
ERROR - 2019-09-19 15:42:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:42:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:42:48 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:42:48 --> Total execution time: 0.0043
ERROR - 2019-09-19 15:43:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:43:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:43:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:43:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:43:39 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:43:39 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:43:39 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:43:39 --> Total execution time: 0.0050
ERROR - 2019-09-19 15:43:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:43:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-09-19 15:43:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:43:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:43:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:43:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:43:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:43:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:43:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:43:48 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:43:48 --> Total execution time: 0.0049
ERROR - 2019-09-19 15:43:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:43:48 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:43:48 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:43:48 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:43:48 --> Total execution time: 0.0070
ERROR - 2019-09-19 15:44:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:44:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:44:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:44:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:44:53 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:44:53 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:44:53 --> Total execution time: 0.0044
ERROR - 2019-09-19 15:44:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:44:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:44:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:44:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:44:54 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:44:54 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:44:54 --> Total execution time: 0.0026
ERROR - 2019-09-19 15:44:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:44:56 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:44:56 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:44:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:44:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:44:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:44:57 --> Driver Route Token ::::: 14238_2019/09/19-15:09:53
DEBUG - 2019-09-19 15:44:57 --> Array
(
    [0] => stdClass Object
        (
            [id] => 15
            [bus_number] => mh12313213
            [route_id] => 15
            [student_strength] => 35
            [drivers_id] => 10
            [school_id] => 11
            [created_by] => 
            [created_date] => 
            [updated_by] => 115
            [updated_date] => 2019-09-14
            [active] => 1
            [pickup_point_id] => 7,8,9
            [route_name] => R1
        )

)

DEBUG - 2019-09-19 15:44:57 --> Total execution time: 0.0034
ERROR - 2019-09-19 15:45:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:45:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:45:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:45:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:45:02 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:45:02 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:45:02 --> Points ::::: 7,8,9
DEBUG - 2019-09-19 15:45:02 --> Total execution time: 0.0024
ERROR - 2019-09-19 15:46:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:46:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:46:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:46:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:46:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:46:04 --> Total execution time: 0.0051
ERROR - 2019-09-19 15:47:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:47:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:47:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:47:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:47:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:47:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:47:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:47:04 --> Total execution time: 0.0049
ERROR - 2019-09-19 15:48:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:48:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:48:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:48:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:48:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:48:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:48:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:48:04 --> Total execution time: 0.0046
ERROR - 2019-09-19 15:49:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:49:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:49:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:49:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:49:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:49:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:49:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:49:04 --> Total execution time: 0.0046
ERROR - 2019-09-19 15:50:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:50:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:50:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:50:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:50:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:50:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:50:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:50:04 --> Total execution time: 0.0044
ERROR - 2019-09-19 15:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:51:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:51:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:51:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:51:04 --> Total execution time: 0.0045
ERROR - 2019-09-19 15:52:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:52:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:52:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:52:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:52:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:52:04 --> Total execution time: 0.0047
ERROR - 2019-09-19 15:53:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:53:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:53:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:53:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:53:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:53:04 --> Total execution time: 0.0044
ERROR - 2019-09-19 15:54:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:54:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:54:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:54:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:54:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:54:04 --> Total execution time: 0.0044
ERROR - 2019-09-19 15:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:55:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:55:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:55:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:55:04 --> Total execution time: 0.0043
ERROR - 2019-09-19 15:56:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:56:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:56:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:56:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:56:09 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:56:09 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:56:09 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:56:09 --> Total execution time: 0.0044
ERROR - 2019-09-19 15:57:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:57:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:57:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:57:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:57:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:57:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:57:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:57:04 --> Total execution time: 0.0043
ERROR - 2019-09-19 15:58:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:58:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:58:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:58:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:58:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:58:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:58:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:58:04 --> Total execution time: 0.0052
ERROR - 2019-09-19 15:59:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:59:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:59:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 15:59:04 --> Total execution time: 0.0046
ERROR - 2019-09-19 15:59:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:59:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:27 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:27 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:59:27 --> Total execution time: 0.0042
ERROR - 2019-09-19 15:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:59:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:42 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:42 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:59:42 --> Total execution time: 0.0043
ERROR - 2019-09-19 15:59:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:59:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:59:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:59:43 --> Total execution time: 0.0045
ERROR - 2019-09-19 15:59:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:43 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:43 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:59:43 --> Total execution time: 0.0040
ERROR - 2019-09-19 15:59:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 15:59:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 15:59:51 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 15:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 15:59:51 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 15:59:51 --> Total execution time: 0.0044
ERROR - 2019-09-19 16:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:00:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:00:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:00:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:00:04 --> Total execution time: 0.0050
ERROR - 2019-09-19 16:00:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:00:22 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:00:22 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:00:23 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:00:23 --> Total execution time: 0.0052
ERROR - 2019-09-19 16:00:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:00:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:00:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:00:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:00:57 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:00:57 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:00:57 --> Total execution time: 0.0043
ERROR - 2019-09-19 16:00:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:00:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:00:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:00:58 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:00:58 --> Total execution time: 0.0028
ERROR - 2019-09-19 16:01:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:01:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:01:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:01:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:01:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:01:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:01:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:01:04 --> Total execution time: 0.0047
ERROR - 2019-09-19 16:01:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:01:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:01:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:01:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:01:17 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:01:17 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:01:17 --> Total execution time: 0.0045
ERROR - 2019-09-19 16:02:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:02:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:02:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:02:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:02:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:02:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:02:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:02:04 --> Total execution time: 0.0055
ERROR - 2019-09-19 16:03:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:03:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:03:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:03:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:03:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:03:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:03:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:03:04 --> Total execution time: 0.0048
ERROR - 2019-09-19 16:04:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:04:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:04:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:04:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:04:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:04:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:04:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:04:04 --> Total execution time: 0.0047
ERROR - 2019-09-19 16:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:05:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:05:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:05:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:05:04 --> Total execution time: 0.0048
ERROR - 2019-09-19 16:06:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:06:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:06:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:06:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:06:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:06:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:06:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:06:04 --> Total execution time: 0.0048
ERROR - 2019-09-19 16:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:07:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:07:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:07:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:07:04 --> Total execution time: 0.0048
ERROR - 2019-09-19 16:08:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:08:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:08:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:08:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:08:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:08:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:08:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:08:04 --> Total execution time: 0.0047
ERROR - 2019-09-19 16:09:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:09:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:09:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:09:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:09:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:09:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:09:05 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:09:05 --> Total execution time: 0.0054
ERROR - 2019-09-19 16:10:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:10:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:10:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:10:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:10:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:10:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:10:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:10:04 --> Total execution time: 0.0048
ERROR - 2019-09-19 16:11:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:11:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:11:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:11:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:11:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:11:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:11:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:11:04 --> Total execution time: 0.0047
ERROR - 2019-09-19 16:12:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:12:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:12:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:12:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:12:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:12:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:12:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:12:04 --> Total execution time: 0.0047
ERROR - 2019-09-19 16:13:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:13:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:13:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:13:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:13:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:13:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:13:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:13:04 --> Total execution time: 0.0045
ERROR - 2019-09-19 16:14:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:14:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:14:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:14:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:14:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:14:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:14:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:14:04 --> Total execution time: 0.0048
ERROR - 2019-09-19 16:15:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:15:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:15:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:15:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:15:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:15:04 --> Total execution time: 0.0049
ERROR - 2019-09-19 16:16:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:16:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:16:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:16:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:16:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:16:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:16:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:16:04 --> Total execution time: 0.0049
ERROR - 2019-09-19 16:17:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:17:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:17:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:17:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:17:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:17:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:17:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:17:04 --> Total execution time: 0.0050
ERROR - 2019-09-19 16:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:18:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:18:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:18:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:18:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:18:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:18:04 --> Total execution time: 0.0050
ERROR - 2019-09-19 16:19:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:19:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:19:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:19:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:19:05 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:19:05 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:19:05 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:19:05 --> Total execution time: 0.0051
ERROR - 2019-09-19 16:20:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:20:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:20:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:20:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:20:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:20:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:20:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:20:04 --> Total execution time: 0.0052
ERROR - 2019-09-19 16:21:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:21:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:21:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:21:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:21:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:21:04 --> Total execution time: 0.0050
ERROR - 2019-09-19 16:22:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:22:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:22:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
ERROR - 2019-09-19 16:22:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/school/application/vendor/autoload.php was not found.
DEBUG - 2019-09-19 16:22:04 --> UTF-8 Support Enabled
DEBUG - 2019-09-19 16:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-09-19 16:22:04 --> Config file loaded: /var/www/html/school/application/config/rest.php
DEBUG - 2019-09-19 16:22:04 --> Bus id ::::: Array
(
    [0] => stdClass Object
        (
            [id] => 27
        )

)

DEBUG - 2019-09-19 16:22:04 --> Total execution time: 0.0047
