<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-17 10:38:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 10:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 10:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 10:38:15 --> Total execution time: 6.9424
ERROR - 2019-10-17 10:38:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 10:38:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 10:38:41 --> No URI present. Default controller set.
DEBUG - 2019-10-17 10:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 10:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 10:38:46 --> Total execution time: 5.0736
ERROR - 2019-10-17 10:39:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 10:39:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 10:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 10:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 10:39:10 --> Total execution time: 0.0026
ERROR - 2019-10-17 10:39:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 10:39:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 10:39:17 --> No URI present. Default controller set.
DEBUG - 2019-10-17 10:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 10:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 10:39:17 --> Total execution time: 0.0115
ERROR - 2019-10-17 10:39:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 10:39:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 10:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 10:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 10:39:24 --> Total execution time: 0.5339
ERROR - 2019-10-17 10:59:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 10:59:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 10:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 10:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 10:59:14 --> Total execution time: 0.0083
ERROR - 2019-10-17 11:11:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:11:19 --> Total execution time: 0.0139
ERROR - 2019-10-17 11:11:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 11:11:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:11:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:11:27 --> Total execution time: 0.0085
ERROR - 2019-10-17 11:11:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:11:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:11:29 --> Total execution time: 0.0084
ERROR - 2019-10-17 11:11:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 11:11:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:11:35 --> Total execution time: 0.0121
ERROR - 2019-10-17 11:13:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:13:17 --> Total execution time: 0.0140
ERROR - 2019-10-17 11:13:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:13:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:13:23 --> Total execution time: 0.2711
ERROR - 2019-10-17 11:13:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:13:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:13:30 --> Total execution time: 0.1505
ERROR - 2019-10-17 11:13:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:13:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:13:37 --> Total execution time: 0.1290
ERROR - 2019-10-17 11:13:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:13:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:13:43 --> Total execution time: 0.1385
ERROR - 2019-10-17 11:17:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 11:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 11:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 11:17:27 --> Total execution time: 0.0473
ERROR - 2019-10-17 12:02:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:02:36 --> Total execution time: 0.0037
ERROR - 2019-10-17 12:02:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:02:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:02:39 --> No URI present. Default controller set.
DEBUG - 2019-10-17 12:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:02:39 --> Total execution time: 0.0088
ERROR - 2019-10-17 12:02:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:02:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:02:41 --> Total execution time: 0.0196
ERROR - 2019-10-17 12:02:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:02:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:02:41 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:04:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:04:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:04:19 --> Total execution time: 0.0047
ERROR - 2019-10-17 12:04:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:04:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:04:20 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:04:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:04:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:04:59 --> Total execution time: 0.0053
ERROR - 2019-10-17 12:04:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:04:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:04:59 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:05:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:05:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:05:09 --> Total execution time: 0.0087
ERROR - 2019-10-17 12:05:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:05:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:05:09 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:06:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:06:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:06:33 --> Total execution time: 0.0075
ERROR - 2019-10-17 12:06:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:06:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:06:33 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:07:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:07:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:07:01 --> Total execution time: 0.0077
ERROR - 2019-10-17 12:07:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:07:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:07:01 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:07:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:07:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:07:52 --> Total execution time: 0.0073
ERROR - 2019-10-17 12:07:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:07:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:07:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:07:52 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:07:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:07:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:07:59 --> Total execution time: 0.0057
ERROR - 2019-10-17 12:07:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:07:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:07:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:07:59 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:09:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:09:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:09:24 --> Total execution time: 0.0075
ERROR - 2019-10-17 12:09:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:09:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:09:24 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:10:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:10:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:10:30 --> Total execution time: 0.0269
ERROR - 2019-10-17 12:11:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:11:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:11:28 --> Total execution time: 0.0081
ERROR - 2019-10-17 12:11:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:11:35 --> Total execution time: 0.0900
ERROR - 2019-10-17 12:11:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:11:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:11:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:11:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:11:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:11:35 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:11:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:11:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:11:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:11:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:12:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:12:25 --> Total execution time: 0.0064
ERROR - 2019-10-17 12:12:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-17 12:12:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:12:25 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-17 12:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:12:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:12:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:12:25 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-17 12:12:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:12:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:12:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:12:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:12:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:12:36 --> Total execution time: 0.0659
ERROR - 2019-10-17 12:13:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:13:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:13:11 --> Total execution time: 0.0072
ERROR - 2019-10-17 12:13:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:13:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:13:18 --> Total execution time: 0.0026
ERROR - 2019-10-17 12:13:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:13:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:13:22 --> No URI present. Default controller set.
DEBUG - 2019-10-17 12:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:13:22 --> Total execution time: 0.0105
ERROR - 2019-10-17 12:13:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:13:24 --> Total execution time: 0.0202
ERROR - 2019-10-17 12:13:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:13:24 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-17 12:15:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:15:12 --> Total execution time: 0.0109
ERROR - 2019-10-17 12:15:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:15:12 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-17 12:15:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:15:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:15:25 --> Total execution time: 0.1725
ERROR - 2019-10-17 12:15:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:15:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:15:25 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-17 12:15:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:15:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:15:27 --> Total execution time: 0.0191
ERROR - 2019-10-17 12:16:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:16:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:16:24 --> Total execution time: 0.0101
ERROR - 2019-10-17 12:16:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:16:31 --> Total execution time: 0.0051
ERROR - 2019-10-17 12:17:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:17:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:17:07 --> Total execution time: 0.0048
ERROR - 2019-10-17 12:17:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:17:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:17:12 --> Total execution time: 0.1176
ERROR - 2019-10-17 12:18:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:18:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:18:18 --> Total execution time: 0.0208
ERROR - 2019-10-17 12:18:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:18:52 --> Total execution time: 0.0127
ERROR - 2019-10-17 12:19:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:19:03 --> Total execution time: 0.0443
ERROR - 2019-10-17 12:20:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:20:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:20:54 --> Total execution time: 0.0032
ERROR - 2019-10-17 12:21:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:21:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:21:12 --> Total execution time: 0.0628
ERROR - 2019-10-17 12:21:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:21:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:21:54 --> Total execution time: 0.0066
ERROR - 2019-10-17 12:21:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:21:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:21:57 --> Total execution time: 0.0848
ERROR - 2019-10-17 12:22:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:22:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:22:11 --> Total execution time: 0.0077
ERROR - 2019-10-17 12:22:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:22:13 --> Total execution time: 0.0040
ERROR - 2019-10-17 12:22:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:22:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:22:16 --> Total execution time: 0.1592
ERROR - 2019-10-17 12:22:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:22:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:22:53 --> Total execution time: 0.0065
ERROR - 2019-10-17 12:23:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:23:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:23:44 --> Total execution time: 0.0068
ERROR - 2019-10-17 12:23:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:23:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:23:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:23:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:23:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:23:46 --> Total execution time: 0.0031
DEBUG - 2019-10-17 12:23:46 --> Total execution time: 0.0029
ERROR - 2019-10-17 12:23:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:23:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:23:48 --> Total execution time: 0.2828
ERROR - 2019-10-17 12:23:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:23:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:23:52 --> Total execution time: 0.0255
ERROR - 2019-10-17 12:24:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:24:28 --> Total execution time: 0.0044
ERROR - 2019-10-17 12:24:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:24:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 12:24:48 --> Query error: Duplicate entry '2147483647' for key 'drivers_mobile' - Invalid query: INSERT INTO `drivers` (`users_id`, `drivers_name`, `drivers_address`, `drivers_mobile`, `join_date`, `created_date`, `created_by`) VALUES ('191', 'eeq', '', '9879798213', '', '2019-10-17', '34')
DEBUG - 2019-10-17 12:24:48 --> Total execution time: 0.2886
ERROR - 2019-10-17 12:25:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:25:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:25:09 --> Total execution time: 0.2004
ERROR - 2019-10-17 12:25:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:25:45 --> Total execution time: 0.0052
ERROR - 2019-10-17 12:26:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:26:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:26:01 --> Total execution time: 0.0536
ERROR - 2019-10-17 12:26:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:26:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:26:01 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-17 12:26:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:26:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:26:03 --> Total execution time: 0.0032
ERROR - 2019-10-17 12:26:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:26:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:26:03 --> Total execution time: 0.0027
ERROR - 2019-10-17 12:29:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:29:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:29:20 --> Total execution time: 0.0106
ERROR - 2019-10-17 12:29:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:29:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:29:21 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-17 12:29:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:29:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:29:38 --> Total execution time: 0.0958
ERROR - 2019-10-17 12:30:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:30:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:30:01 --> Total execution time: 0.0074
ERROR - 2019-10-17 12:30:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:30:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:30:12 --> Total execution time: 0.0790
ERROR - 2019-10-17 12:32:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:32:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:32:17 --> Total execution time: 0.0080
ERROR - 2019-10-17 12:33:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:33:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:33:22 --> Total execution time: 0.0091
ERROR - 2019-10-17 12:33:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:33:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:33:27 --> Total execution time: 0.0724
ERROR - 2019-10-17 12:34:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:34:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:34:14 --> Total execution time: 0.0039
ERROR - 2019-10-17 12:34:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:34:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:34:21 --> Total execution time: 0.0044
ERROR - 2019-10-17 12:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:34:28 --> Total execution time: 0.0023
ERROR - 2019-10-17 12:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:34:28 --> Total execution time: 0.0031
ERROR - 2019-10-17 12:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:34:28 --> Total execution time: 0.0026
ERROR - 2019-10-17 12:34:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:34:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:34:29 --> Total execution time: 0.0023
ERROR - 2019-10-17 12:35:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:35:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:35:15 --> Total execution time: 0.0090
ERROR - 2019-10-17 12:35:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:35:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:35:21 --> Total execution time: 0.0022
ERROR - 2019-10-17 12:36:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:36:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:36:00 --> Total execution time: 0.0083
ERROR - 2019-10-17 12:36:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:36:08 --> Total execution time: 0.0528
ERROR - 2019-10-17 12:46:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:46:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:46:46 --> Total execution time: 0.0600
ERROR - 2019-10-17 12:48:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:48:00 --> Total execution time: 0.1585
ERROR - 2019-10-17 12:48:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:48:05 --> Total execution time: 0.0025
ERROR - 2019-10-17 12:48:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:48:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:48:21 --> Total execution time: 0.0053
ERROR - 2019-10-17 12:49:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:49:17 --> Total execution time: 0.0271
ERROR - 2019-10-17 12:49:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:49:20 --> Total execution time: 0.0179
ERROR - 2019-10-17 12:49:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-17 12:49:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:49:20 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-17 12:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:49:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:49:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:49:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:49:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:49:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:49:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:49:21 --> Total execution time: 0.0064
ERROR - 2019-10-17 12:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:49:38 --> Total execution time: 0.0083
ERROR - 2019-10-17 12:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:49:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:49:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:49:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:49:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:49:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:49:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:49:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:49:49 --> Total execution time: 0.0032
ERROR - 2019-10-17 12:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:50:30 --> Total execution time: 0.0039
ERROR - 2019-10-17 12:50:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:50:47 --> Total execution time: 0.0074
ERROR - 2019-10-17 12:50:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:47 --> UTF-8 Support Enabled
ERROR - 2019-10-17 12:50:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:50:47 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-17 12:50:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:50:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:50:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:50:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:50:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:50:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:50:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:50:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:50:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:50:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:50:49 --> Total execution time: 0.0042
ERROR - 2019-10-17 12:50:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:50:51 --> Total execution time: 0.0045
ERROR - 2019-10-17 12:50:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:50:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:50:56 --> Total execution time: 0.0211
ERROR - 2019-10-17 12:51:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:51:02 --> Total execution time: 0.0033
ERROR - 2019-10-17 12:51:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:51:03 --> Total execution time: 0.0074
ERROR - 2019-10-17 12:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:51:04 --> Total execution time: 0.0271
ERROR - 2019-10-17 12:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:51:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:51:27 --> Total execution time: 0.0085
ERROR - 2019-10-17 12:51:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:51:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:51:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:51:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:51:30 --> Total execution time: 0.0650
ERROR - 2019-10-17 12:51:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:31 --> UTF-8 Support Enabled
ERROR - 2019-10-17 12:51:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:31 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-17 12:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:51:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:51:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:51:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:52:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:52:07 --> Total execution time: 0.0044
ERROR - 2019-10-17 12:52:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:07 --> UTF-8 Support Enabled
ERROR - 2019-10-17 12:52:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:52:07 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-17 12:52:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:52:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:52:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:52:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:52:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:52:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:52:14 --> Total execution time: 0.0799
ERROR - 2019-10-17 12:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-17 12:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:52:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-17 12:52:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-17 12:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:52:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-17 12:52:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:52:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-17 12:52:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:52:23 --> Total execution time: 0.0037
ERROR - 2019-10-17 12:52:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:25 --> No URI present. Default controller set.
DEBUG - 2019-10-17 12:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:52:25 --> Total execution time: 0.0140
ERROR - 2019-10-17 12:52:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:52:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:52:29 --> Total execution time: 0.0094
ERROR - 2019-10-17 12:53:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:53:03 --> Total execution time: 0.0025
ERROR - 2019-10-17 12:53:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:53:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:53:06 --> No URI present. Default controller set.
DEBUG - 2019-10-17 12:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:53:06 --> Total execution time: 0.0096
ERROR - 2019-10-17 12:53:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:53:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:53:08 --> Total execution time: 0.0046
ERROR - 2019-10-17 12:53:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:53:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:53:11 --> No URI present. Default controller set.
DEBUG - 2019-10-17 12:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:53:11 --> Total execution time: 0.0086
ERROR - 2019-10-17 12:53:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:53:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:53:14 --> Total execution time: 0.0096
ERROR - 2019-10-17 12:53:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:53:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:53:18 --> Total execution time: 0.0104
ERROR - 2019-10-17 12:55:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:55:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:55:22 --> Total execution time: 0.0088
ERROR - 2019-10-17 12:55:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:55:23 --> Total execution time: 0.0107
ERROR - 2019-10-17 12:55:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:55:51 --> Total execution time: 0.0021
ERROR - 2019-10-17 12:55:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:55:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:55:54 --> No URI present. Default controller set.
DEBUG - 2019-10-17 12:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:55:54 --> Total execution time: 0.0092
ERROR - 2019-10-17 12:55:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:55:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:55:56 --> Total execution time: 0.0076
ERROR - 2019-10-17 12:55:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:55:58 --> Total execution time: 0.0074
ERROR - 2019-10-17 12:56:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:56:00 --> Total execution time: 0.0084
ERROR - 2019-10-17 12:56:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:56:02 --> Total execution time: 0.0054
ERROR - 2019-10-17 12:56:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:02 --> UTF-8 Support Enabled
ERROR - 2019-10-17 12:56:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:56:02 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-17 12:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:56:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:56:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:56:02 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:56:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:56:02 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:56:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:56:03 --> Total execution time: 0.0173
ERROR - 2019-10-17 12:56:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:56:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:56:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:56:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:56:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:56:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 12:56:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 12:56:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 12:56:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:56:05 --> Total execution time: 0.0076
ERROR - 2019-10-17 12:56:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:56:31 --> You did not select a file to upload.
DEBUG - 2019-10-17 12:56:31 --> Total execution time: 0.0579
ERROR - 2019-10-17 12:56:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:56:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:56:59 --> Total execution time: 0.0093
ERROR - 2019-10-17 12:57:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:57:03 --> You did not select a file to upload.
DEBUG - 2019-10-17 12:57:03 --> Total execution time: 0.0031
ERROR - 2019-10-17 12:57:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:57:04 --> Total execution time: 0.0041
ERROR - 2019-10-17 12:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:57:05 --> Total execution time: 0.0023
ERROR - 2019-10-17 12:57:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:57:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:57:07 --> You did not select a file to upload.
DEBUG - 2019-10-17 12:57:07 --> Total execution time: 0.0817
ERROR - 2019-10-17 12:57:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:57:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:57:12 --> Total execution time: 0.0065
ERROR - 2019-10-17 12:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:57:45 --> Total execution time: 0.0123
ERROR - 2019-10-17 12:57:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:57:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:57:54 --> Total execution time: 0.0762
ERROR - 2019-10-17 12:58:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:58:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:58:21 --> Total execution time: 0.0076
ERROR - 2019-10-17 12:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:58:24 --> Total execution time: 0.0107
ERROR - 2019-10-17 12:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:58:26 --> Total execution time: 0.0052
ERROR - 2019-10-17 12:58:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:58:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:58:27 --> Total execution time: 0.0024
ERROR - 2019-10-17 12:58:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:58:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:58:31 --> Total execution time: 0.0029
ERROR - 2019-10-17 12:58:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:58:33 --> Total execution time: 0.0048
ERROR - 2019-10-17 12:58:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:58:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:58:37 --> Total execution time: 0.0589
ERROR - 2019-10-17 12:59:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:59:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:59:24 --> Total execution time: 0.0567
ERROR - 2019-10-17 12:59:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 12:59:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 12:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 12:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 12:59:25 --> Total execution time: 0.0062
ERROR - 2019-10-17 13:13:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 13:13:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 13:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 13:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 13:13:39 --> Total execution time: 0.0068
ERROR - 2019-10-17 13:13:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 13:13:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 13:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 13:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 13:13:49 --> Total execution time: 0.1236
ERROR - 2019-10-17 13:13:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 13:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 13:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 13:13:52 --> Total execution time: 0.0801
ERROR - 2019-10-17 13:13:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 13:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 13:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 13:13:52 --> Total execution time: 0.0033
ERROR - 2019-10-17 13:21:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 13:21:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 13:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 13:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 13:21:51 --> Total execution time: 0.0112
ERROR - 2019-10-17 16:12:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 16:12:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 16:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 16:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 16:12:55 --> Total execution time: 0.0028
ERROR - 2019-10-17 16:12:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 16:12:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 16:12:59 --> No URI present. Default controller set.
DEBUG - 2019-10-17 16:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 16:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 16:12:59 --> Total execution time: 0.0107
ERROR - 2019-10-17 16:13:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 16:13:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 16:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 16:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 16:13:04 --> Total execution time: 0.0074
ERROR - 2019-10-17 16:13:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 16:13:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 16:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 16:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 16:13:24 --> Total execution time: 0.0098
ERROR - 2019-10-17 17:29:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:29:36 --> Total execution time: 0.0055
ERROR - 2019-10-17 17:29:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:39 --> No URI present. Default controller set.
DEBUG - 2019-10-17 17:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:29:39 --> Total execution time: 0.0118
ERROR - 2019-10-17 17:29:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:29:42 --> Total execution time: 0.0085
ERROR - 2019-10-17 17:29:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:29:45 --> Total execution time: 0.0034
ERROR - 2019-10-17 17:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:29:46 --> Total execution time: 0.0089
ERROR - 2019-10-17 17:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:29:49 --> Total execution time: 0.0118
ERROR - 2019-10-17 17:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:49 --> UTF-8 Support Enabled
ERROR - 2019-10-17 17:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 17:29:49 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-17 17:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 17:29:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 17:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 17:29:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-17 17:29:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:29:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-17 17:29:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-17 17:34:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:34:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:34:07 --> Total execution time: 0.0086
ERROR - 2019-10-17 17:34:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:34:11 --> Total execution time: 0.0027
ERROR - 2019-10-17 17:34:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:34:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:34:15 --> Total execution time: 0.0466
ERROR - 2019-10-17 17:34:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:34:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:34:19 --> Total execution time: 0.0742
ERROR - 2019-10-17 17:51:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:51:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:51:10 --> Total execution time: 0.0154
ERROR - 2019-10-17 17:51:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:51:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:51:33 --> Total execution time: 0.0115
ERROR - 2019-10-17 17:51:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:51:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:51:38 --> Total execution time: 0.0073
ERROR - 2019-10-17 17:52:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:52:03 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: SELECT `s`.`student_name`, `s`.`id` as `stud_id`, `s`.`roll_number`, `a`.*
FROM `leaves` `a`
LEFT JOIN `students` `s` ON `a`.`student_id`=`s`.`id`
WHERE `a`.`student_id` = '13'
AND DATE_FORMAT(date,'%Y-%m') = '2019-09'
DEBUG - 2019-10-17 17:52:03 --> Total execution time: 0.0192
ERROR - 2019-10-17 17:52:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:52:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:52:21 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: SELECT `s`.`student_name`, `s`.`id` as `stud_id`, `s`.`roll_number`, `a`.*
FROM `leaves` `a`
LEFT JOIN `students` `s` ON `a`.`student_id`=`s`.`id`
WHERE `a`.`student_id` = '13'
AND DATE_FORMAT(date,'%Y-%m') = '2019-09'
ERROR - 2019-10-17 17:52:21 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 114
ERROR - 2019-10-17 17:52:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:52:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:53:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:55:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:55:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
DEBUG - 2019-10-17 17:55:31 --> Total execution time: 0.0365
ERROR - 2019-10-17 17:56:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:56:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
DEBUG - 2019-10-17 17:56:03 --> Total execution time: 0.0124
ERROR - 2019-10-17 17:56:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:56:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
DEBUG - 2019-10-17 17:56:37 --> Total execution time: 0.0129
ERROR - 2019-10-17 17:57:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:57:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
DEBUG - 2019-10-17 17:57:06 --> Total execution time: 0.0134
ERROR - 2019-10-17 17:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 146
DEBUG - 2019-10-17 17:57:10 --> Total execution time: 0.0123
ERROR - 2019-10-17 17:57:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:57:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:38 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
DEBUG - 2019-10-17 17:57:38 --> Total execution time: 0.0081
ERROR - 2019-10-17 17:57:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:57:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
ERROR - 2019-10-17 17:57:48 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 146
DEBUG - 2019-10-17 17:57:48 --> Total execution time: 0.0077
ERROR - 2019-10-17 17:58:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:58:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:58:03 --> Total execution time: 0.0062
ERROR - 2019-10-17 17:58:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:58:28 --> Total execution time: 0.0069
ERROR - 2019-10-17 17:58:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:58:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 17:59:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:59:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 17:59:10 --> Total execution time: 0.0092
ERROR - 2019-10-17 17:59:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 17:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 17:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 18:00:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:00:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:00:16 --> Total execution time: 0.0140
ERROR - 2019-10-17 18:00:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:00:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 18:00:56 --> Severity: Notice --> Undefined variable: leaves_student_show /var/www/html/School19/application/views/student_attendance.php 147
ERROR - 2019-10-17 18:01:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:01:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:01:49 --> Total execution time: 0.0061
ERROR - 2019-10-17 18:02:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:02:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-17 18:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:02:13 --> Total execution time: 0.0069
ERROR - 2019-10-17 18:02:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:02:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:02:25 --> Total execution time: 0.0079
ERROR - 2019-10-17 18:03:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:03:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:03:10 --> Total execution time: 0.0077
ERROR - 2019-10-17 18:04:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:04:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:04:25 --> Total execution time: 0.0083
ERROR - 2019-10-17 18:04:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:04:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:04:38 --> Total execution time: 0.0072
ERROR - 2019-10-17 18:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:05:04 --> Total execution time: 0.0076
ERROR - 2019-10-17 18:05:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:05:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:05:08 --> Total execution time: 0.0063
ERROR - 2019-10-17 18:05:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:05:24 --> Total execution time: 0.0082
ERROR - 2019-10-17 18:05:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:05:47 --> Total execution time: 0.0122
ERROR - 2019-10-17 18:06:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:06:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:06:33 --> Total execution time: 0.0073
ERROR - 2019-10-17 18:06:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:06:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:06:46 --> Total execution time: 0.0063
ERROR - 2019-10-17 18:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:12:44 --> Total execution time: 0.0062
ERROR - 2019-10-17 18:13:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:13:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:13:06 --> Total execution time: 0.0082
ERROR - 2019-10-17 18:15:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:15:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:15:20 --> Total execution time: 0.0050
ERROR - 2019-10-17 18:15:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:15:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:15:28 --> Total execution time: 0.0082
ERROR - 2019-10-17 18:15:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:15:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:15:49 --> Total execution time: 0.0049
ERROR - 2019-10-17 18:15:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:15:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:15:56 --> Total execution time: 0.0037
ERROR - 2019-10-17 18:28:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:28:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:28:29 --> Total execution time: 0.0049
ERROR - 2019-10-17 18:28:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:28:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:28:39 --> Total execution time: 0.0048
ERROR - 2019-10-17 18:29:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:24 --> Total execution time: 0.0063
ERROR - 2019-10-17 18:29:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:29 --> Total execution time: 0.0025
ERROR - 2019-10-17 18:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:33 --> No URI present. Default controller set.
DEBUG - 2019-10-17 18:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:33 --> Total execution time: 0.0104
ERROR - 2019-10-17 18:29:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:34 --> Total execution time: 0.0105
ERROR - 2019-10-17 18:29:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:38 --> Total execution time: 0.0037
ERROR - 2019-10-17 18:29:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:39 --> Total execution time: 0.0053
ERROR - 2019-10-17 18:29:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:40 --> Total execution time: 0.0047
ERROR - 2019-10-17 18:29:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:41 --> Total execution time: 0.0025
ERROR - 2019-10-17 18:29:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:29:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:29:43 --> Total execution time: 0.0051
ERROR - 2019-10-17 18:33:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:33:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:33:40 --> Total execution time: 0.0088
ERROR - 2019-10-17 18:35:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-17 18:35:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-17 18:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-17 18:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-17 18:35:34 --> Total execution time: 0.0235
