<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-02 10:31:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-02 10:31:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 10:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 10:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-02 10:31:11 --> Total execution time: 9.6744
ERROR - 2019-11-02 10:31:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-02 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 10:31:33 --> No URI present. Default controller set.
DEBUG - 2019-11-02 10:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 10:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-02 10:31:37 --> Total execution time: 4.3320
ERROR - 2019-11-02 10:31:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-02 10:31:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 10:31:58 --> No URI present. Default controller set.
DEBUG - 2019-11-02 10:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 10:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-02 10:32:01 --> Total execution time: 3.5204
ERROR - 2019-11-02 10:34:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-02 10:34:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 10:34:45 --> No URI present. Default controller set.
DEBUG - 2019-11-02 10:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 10:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-02 10:34:45 --> disha :: Disha@123
DEBUG - 2019-11-02 10:34:45 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-02 10:34:45 --> Total execution time: 0.0355
ERROR - 2019-11-02 10:34:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-02 10:34:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 10:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-02 10:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-02 10:34:52 --> Total execution time: 0.3582
ERROR - 2019-11-02 10:34:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-02 10:34:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-02 10:34:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-02 10:34:52 --> 404 Page Not Found: Profile/logo.png
