<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-09 10:08:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:08:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:08:09 --> Total execution time: 1.3748
ERROR - 2019-10-09 10:08:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:08:35 --> No URI present. Default controller set.
DEBUG - 2019-10-09 10:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:08:39 --> Total execution time: 3.6087
ERROR - 2019-10-09 10:36:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:36:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:36:15 --> Total execution time: 0.0033
ERROR - 2019-10-09 10:36:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:36:18 --> No URI present. Default controller set.
DEBUG - 2019-10-09 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:36:18 --> Total execution time: 0.0101
ERROR - 2019-10-09 10:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:36:21 --> Total execution time: 0.0642
ERROR - 2019-10-09 10:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:36:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:36:21 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:36:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:36:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:06 --> Total execution time: 0.0093
ERROR - 2019-10-09 10:49:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:06 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:07 --> Total execution time: 0.0081
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:07 --> Total execution time: 0.0055
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:07 --> Total execution time: 0.0057
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-09 10:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:07 --> Total execution time: 0.0050
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:07 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:07 --> Total execution time: 0.0055
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:08 --> Total execution time: 0.0076
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:08 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:08 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:59 --> Total execution time: 0.0077
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:59 --> Total execution time: 0.0053
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Img/logo.png
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:59 --> Total execution time: 0.0062
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:59 --> Total execution time: 0.0071
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:49:59 --> Total execution time: 0.0053
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 10:49:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 10:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:49:59 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:50:00 --> Total execution time: 0.0058
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:50:00 --> Total execution time: 0.0057
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:50:00 --> Total execution time: 0.0051
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:50:00 --> Total execution time: 0.0057
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:00 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:50:01 --> Total execution time: 0.0051
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:50:01 --> Total execution time: 0.0047
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:50:01 --> Total execution time: 0.0043
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:50:16 --> Total execution time: 0.0056
ERROR - 2019-10-09 10:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:16 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:50:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:50:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:50:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:50:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:25 --> Total execution time: 0.0079
ERROR - 2019-10-09 10:52:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 10:52:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:25 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-09 10:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:25 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:26 --> Total execution time: 0.0064
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:26 --> Total execution time: 0.0049
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:26 --> Total execution time: 0.0070
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:26 --> Total execution time: 0.0046
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:52:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:27 --> Total execution time: 0.0030
ERROR - 2019-10-09 10:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 10:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:27 --> 404 Page Not Found: Img/logo.png
DEBUG - 2019-10-09 10:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:27 --> Total execution time: 0.0049
ERROR - 2019-10-09 10:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:27 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:52:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:47 --> Total execution time: 0.0084
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:48 --> Total execution time: 0.0047
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:48 --> Total execution time: 0.0085
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:48 --> Total execution time: 0.0051
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 10:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 10:52:48 --> Total execution time: 0.0074
ERROR - 2019-10-09 10:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 10:52:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:49 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 10:52:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 10:52:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 10:52:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 10:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 10:52:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:45:17 --> Total execution time: 0.0050
ERROR - 2019-10-09 11:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:45:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:45:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:45:17 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:45:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:45:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:45:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:45:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:45:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:45:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:46:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:46:40 --> Total execution time: 0.0051
ERROR - 2019-10-09 11:46:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:46:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 11:46:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:46:40 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:46:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:46:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:46:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:46:44 --> Total execution time: 0.0044
ERROR - 2019-10-09 11:46:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:46:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 11:46:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:46:44 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:46:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:46:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:46:59 --> Total execution time: 0.0071
ERROR - 2019-10-09 11:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:59 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:46:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:47:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:47:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:47:53 --> Total execution time: 0.0082
ERROR - 2019-10-09 11:47:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:47:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:47:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:47:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:47:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:47:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:47:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:47:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:47:53 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:47:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:47:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:47:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:47:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:47:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:47:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:48:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:48:29 --> Total execution time: 0.0045
ERROR - 2019-10-09 11:48:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:48:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 11:48:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:29 --> 404 Page Not Found: Img/logo.png
DEBUG - 2019-10-09 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:48:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:48:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:48:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:48:30 --> Total execution time: 0.0048
ERROR - 2019-10-09 11:48:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:48:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:48:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:30 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:48:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:48:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:48:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:48:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:49:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:49:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:49:13 --> Total execution time: 0.0098
ERROR - 2019-10-09 11:49:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:49:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:49:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:49:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:49:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:49:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:49:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:49:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:49:13 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:49:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:49:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:49:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:49:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:50:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:50:45 --> Total execution time: 0.0074
ERROR - 2019-10-09 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:52:11 --> Total execution time: 0.0051
ERROR - 2019-10-09 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:52:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:11 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:52:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:52:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:52:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:52:13 --> Total execution time: 0.0042
ERROR - 2019-10-09 11:52:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:15 --> No URI present. Default controller set.
DEBUG - 2019-10-09 11:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:52:15 --> Total execution time: 0.0100
ERROR - 2019-10-09 11:52:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:52:21 --> Total execution time: 0.0030
ERROR - 2019-10-09 11:52:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:24 --> No URI present. Default controller set.
DEBUG - 2019-10-09 11:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:52:24 --> Total execution time: 0.0083
ERROR - 2019-10-09 11:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:52:27 --> Total execution time: 0.0065
ERROR - 2019-10-09 11:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:27 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:52:48 --> Total execution time: 0.0046
ERROR - 2019-10-09 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:48 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:52:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:52:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:59:44 --> Total execution time: 0.0075
ERROR - 2019-10-09 11:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:44 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:59:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:59:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:59:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 11:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 11:59:52 --> Total execution time: 0.0047
ERROR - 2019-10-09 11:59:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:59:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 11:59:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:52 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 11:59:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 11:59:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 11:59:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 11:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 11:59:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:00:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:00:07 --> Total execution time: 0.0065
ERROR - 2019-10-09 12:00:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:00:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 12:00:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:07 --> 404 Page Not Found: Img/logo.png
DEBUG - 2019-10-09 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:00:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:07 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:00:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:07 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:00:23 --> Total execution time: 0.0049
ERROR - 2019-10-09 12:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:23 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:23 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:23 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:23 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:00:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:23 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:00:27 --> Total execution time: 0.0052
ERROR - 2019-10-09 12:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 12:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:27 --> 404 Page Not Found: Img/logo.png
DEBUG - 2019-10-09 12:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:00:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:00:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:00:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:07:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:07:26 --> Total execution time: 0.0113
ERROR - 2019-10-09 12:07:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:07:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:07:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:27 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:07:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:07:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:07:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:07:39 --> Total execution time: 0.0097
ERROR - 2019-10-09 12:07:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:07:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:07:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:39 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:07:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:07:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:07:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:10:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:10:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:10:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:11:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:11:08 --> Total execution time: 0.0064
ERROR - 2019-10-09 12:11:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:11:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:11:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:11:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:11:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:11:08 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:11:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:11:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:11:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:11:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:11:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:11:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:11:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:11:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:11:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:12:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:12:20 --> Total execution time: 0.0088
ERROR - 2019-10-09 12:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:21 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:12:47 --> Total execution time: 0.0068
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:47 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:12:47 --> Total execution time: 0.0054
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 12:12:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:47 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 12:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:47 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:12:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:12:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:12:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:12:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:14:27 --> Total execution time: 0.0051
ERROR - 2019-10-09 12:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:14:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:14:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:14:27 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:14:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:14:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:14:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:15:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:15:43 --> Total execution time: 0.0056
ERROR - 2019-10-09 12:15:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:15:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:15:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:15:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:15:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:15:43 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:15:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:15:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:15:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:15:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:15:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:15:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:34:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:34:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:34:10 --> Total execution time: 0.0093
ERROR - 2019-10-09 12:34:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:34:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:34:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:34:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:34:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:34:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:34:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:34:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:34:10 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:34:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:34:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:34:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:34:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:34:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:34:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:36:43 --> Total execution time: 0.0092
ERROR - 2019-10-09 12:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:36:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 12:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:36:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:36:43 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:36:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:36:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:37:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:37:24 --> Total execution time: 0.0053
ERROR - 2019-10-09 12:37:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:24 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:37:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:24 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:37:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:24 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:37:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:24 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:37:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:24 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:37:25 --> Total execution time: 0.0052
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:37:25 --> Total execution time: 0.0048
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:37:25 --> Total execution time: 0.0060
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:37:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:37:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:39:38 --> Total execution time: 0.0101
ERROR - 2019-10-09 12:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:38 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:39:38 --> Total execution time: 0.0073
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:39:39 --> Total execution time: 0.0060
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:39:39 --> Total execution time: 0.0058
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:39:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:40:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:40:56 --> Total execution time: 0.0048
ERROR - 2019-10-09 12:40:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:40:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:40:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:56 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:40:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:40:57 --> Total execution time: 0.0042
ERROR - 2019-10-09 12:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 12:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:40:57 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:40:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:59:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:59:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 12:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 12:59:58 --> Total execution time: 0.0059
ERROR - 2019-10-09 12:59:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:59:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:59:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:59:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:59:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:59:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 12:59:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:59:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:59:58 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 12:59:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:59:59 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 12:59:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 12:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 12:59:59 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 13:03:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:03:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:03:40 --> Total execution time: 0.0090
ERROR - 2019-10-09 13:03:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:03:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:03:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:03:40 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:37:33 --> Total execution time: 0.0094
ERROR - 2019-10-09 13:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:37:33 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:37:33 --> Total execution time: 0.0069
ERROR - 2019-10-09 13:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:37:34 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:38:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:38:20 --> Total execution time: 0.0071
ERROR - 2019-10-09 13:38:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:38:20 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:38:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:38:21 --> Total execution time: 0.0058
ERROR - 2019-10-09 13:38:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:38:21 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:38:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:38:47 --> Total execution time: 0.0058
ERROR - 2019-10-09 13:38:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:38:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:38:47 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:38:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:38:48 --> Total execution time: 0.0049
ERROR - 2019-10-09 13:38:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:38:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:38:48 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:39:38 --> Total execution time: 0.0055
ERROR - 2019-10-09 13:39:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:39:38 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:39:39 --> Total execution time: 0.0083
ERROR - 2019-10-09 13:39:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:39:39 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:39:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:39:49 --> Total execution time: 0.0058
ERROR - 2019-10-09 13:39:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:39:49 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:39:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:39:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:39:50 --> Total execution time: 0.0073
ERROR - 2019-10-09 13:39:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:39:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:39:50 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:40:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:40:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:40:32 --> Total execution time: 0.0072
ERROR - 2019-10-09 13:40:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:40:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:40:32 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:40:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:40:33 --> Total execution time: 0.0052
ERROR - 2019-10-09 13:40:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:40:33 --> Total execution time: 0.0053
ERROR - 2019-10-09 13:40:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:40:33 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:40:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:40:33 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:41:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:41:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:41:18 --> Total execution time: 0.0075
ERROR - 2019-10-09 13:41:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:41:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:41:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:41:18 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:41:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:41:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:41:31 --> Total execution time: 0.0044
ERROR - 2019-10-09 13:41:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:41:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:41:31 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:43:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:43:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:43:24 --> Total execution time: 0.0057
ERROR - 2019-10-09 13:43:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:43:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:43:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:43:24 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:43:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:43:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:43:43 --> Total execution time: 0.0069
ERROR - 2019-10-09 13:43:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:43:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:43:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:43:43 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:43:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:43:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:43:44 --> Total execution time: 0.0045
ERROR - 2019-10-09 13:43:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:43:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:43:44 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:43:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:43:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:43:54 --> Total execution time: 0.0046
ERROR - 2019-10-09 13:43:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:43:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:43:54 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:47:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:47:18 --> Total execution time: 0.0067
ERROR - 2019-10-09 13:47:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:47:18 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:54:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:54:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:54:02 --> Total execution time: 0.0071
ERROR - 2019-10-09 13:54:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:54:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:54:03 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:55:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:55:00 --> Total execution time: 0.0070
ERROR - 2019-10-09 13:55:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:55:00 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:55:40 --> Total execution time: 0.0072
ERROR - 2019-10-09 13:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:55:40 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:55:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:55:41 --> Total execution time: 0.0032
ERROR - 2019-10-09 13:55:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:55:41 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:55:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:55:41 --> Total execution time: 0.0049
ERROR - 2019-10-09 13:55:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:55:42 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:55:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:55:42 --> Total execution time: 0.0052
ERROR - 2019-10-09 13:55:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:55:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:55:42 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 13:57:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 13:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 13:57:29 --> Total execution time: 0.0156
ERROR - 2019-10-09 13:57:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 13:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 13:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 13:57:29 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:00:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:00:52 --> Total execution time: 0.0093
ERROR - 2019-10-09 14:00:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:00:52 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:11:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:11:07 --> Total execution time: 0.0079
ERROR - 2019-10-09 14:11:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:11:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:11:07 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:12:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:12:30 --> Total execution time: 0.0089
ERROR - 2019-10-09 14:12:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:12:30 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:12:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:12:31 --> Total execution time: 0.0040
ERROR - 2019-10-09 14:12:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:12:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:12:31 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:12:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:12:32 --> Total execution time: 0.0053
ERROR - 2019-10-09 14:12:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:12:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:12:32 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:13:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:13:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:13:21 --> Total execution time: 0.0051
ERROR - 2019-10-09 14:13:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:13:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:13:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:13:21 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:13:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:13:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:13:22 --> Total execution time: 0.0061
ERROR - 2019-10-09 14:13:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:13:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:13:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:13:22 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:14:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:14:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:14:39 --> Total execution time: 0.0073
ERROR - 2019-10-09 14:14:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:14:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:14:39 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:14:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:14:40 --> Total execution time: 0.0079
ERROR - 2019-10-09 14:14:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:14:40 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:14:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:14:46 --> Total execution time: 0.0037
ERROR - 2019-10-09 14:14:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:14:46 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:14:47 --> Total execution time: 0.0057
ERROR - 2019-10-09 14:14:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:14:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:14:47 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:15:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:15:42 --> Total execution time: 0.0089
ERROR - 2019-10-09 14:15:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:15:42 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:15:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:15:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:15:49 --> Total execution time: 0.0063
ERROR - 2019-10-09 14:15:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:15:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:15:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:15:49 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:15:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:15:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:15:50 --> Total execution time: 0.0046
ERROR - 2019-10-09 14:15:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:15:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:15:50 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:16:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:51 --> Total execution time: 0.0068
ERROR - 2019-10-09 14:16:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:16:51 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:52 --> Total execution time: 0.0058
ERROR - 2019-10-09 14:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:52 --> Total execution time: 0.0050
ERROR - 2019-10-09 14:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:16:52 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:16:52 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:16:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:52 --> Total execution time: 0.0052
ERROR - 2019-10-09 14:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:16:53 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:53 --> Total execution time: 0.0057
ERROR - 2019-10-09 14:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:53 --> Total execution time: 0.0055
ERROR - 2019-10-09 14:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:16:53 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:53 --> Total execution time: 0.0044
ERROR - 2019-10-09 14:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:16:53 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:54 --> Total execution time: 0.0064
ERROR - 2019-10-09 14:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:16:54 --> Total execution time: 0.0049
ERROR - 2019-10-09 14:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:16:54 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:16:54 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:17:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:17:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:17:56 --> Total execution time: 0.0063
ERROR - 2019-10-09 14:17:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:17:57 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:17:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:17:57 --> Total execution time: 0.0099
ERROR - 2019-10-09 14:17:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:17:57 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:17:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:17:57 --> Total execution time: 0.0073
ERROR - 2019-10-09 14:17:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:17:58 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:18:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:18:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:18:23 --> Total execution time: 0.0052
ERROR - 2019-10-09 14:18:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:18:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:18:23 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:18:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:18:24 --> Total execution time: 0.0053
ERROR - 2019-10-09 14:18:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:18:24 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:26:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:26:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:26:18 --> Total execution time: 0.0060
ERROR - 2019-10-09 14:26:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:26:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:26:18 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:26:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:26:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:26:19 --> Total execution time: 0.0052
ERROR - 2019-10-09 14:26:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:26:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:26:19 --> Total execution time: 0.0052
ERROR - 2019-10-09 14:26:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:26:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:26:20 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:28:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:28:14 --> Total execution time: 0.0074
ERROR - 2019-10-09 14:28:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:28:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:28:14 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:28:15 --> Total execution time: 0.0046
ERROR - 2019-10-09 14:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:28:15 --> Total execution time: 0.0050
ERROR - 2019-10-09 14:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:28:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:28:15 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:28:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:28:15 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:29:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:29:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:29:40 --> Total execution time: 0.0073
ERROR - 2019-10-09 14:29:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:29:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:29:40 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:29:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:29:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:29:41 --> Total execution time: 0.0054
ERROR - 2019-10-09 14:29:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:29:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:29:41 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:32:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:32:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:32:48 --> Total execution time: 0.0117
ERROR - 2019-10-09 14:32:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:32:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:32:48 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:33:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:33:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:33:17 --> Total execution time: 0.0054
ERROR - 2019-10-09 14:33:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:33:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:33:17 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:33:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:33:18 --> Total execution time: 0.0051
ERROR - 2019-10-09 14:33:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:33:18 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:34:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:34:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:34:15 --> Total execution time: 0.0051
ERROR - 2019-10-09 14:34:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:34:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:34:15 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:34:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:34:26 --> Total execution time: 0.0204
ERROR - 2019-10-09 14:34:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 14:34:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:34:26 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:34:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 14:34:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:34:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 14:34:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:34:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 14:35:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:35:20 --> Total execution time: 0.0081
ERROR - 2019-10-09 14:35:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:35:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 14:35:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:35:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 14:35:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:35:20 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 14:35:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:35:20 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 14:35:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:35:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:35:46 --> Total execution time: 0.0059
ERROR - 2019-10-09 14:36:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:36:11 --> Total execution time: 0.0074
ERROR - 2019-10-09 14:36:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:36:11 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:36:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:36:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:36:59 --> Total execution time: 0.0039
ERROR - 2019-10-09 14:37:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:37:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:37:19 --> Total execution time: 0.0056
ERROR - 2019-10-09 14:37:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:37:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:37:20 --> Total execution time: 0.0055
ERROR - 2019-10-09 14:50:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:50:00 --> Total execution time: 0.0041
ERROR - 2019-10-09 14:51:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:51:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:51:57 --> Total execution time: 0.0061
ERROR - 2019-10-09 14:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:53:09 --> Total execution time: 0.0045
ERROR - 2019-10-09 14:53:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:53:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:53:09 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:54:45 --> Total execution time: 0.1152
ERROR - 2019-10-09 14:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 14:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 14:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:45 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 14:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 14:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 14:54:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:54:50 --> Total execution time: 0.1032
ERROR - 2019-10-09 14:54:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 14:54:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:50 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 14:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 14:54:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 14:54:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 14:54:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 14:56:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:56:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:56:40 --> Total execution time: 0.0079
ERROR - 2019-10-09 14:56:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:56:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:56:41 --> Total execution time: 0.0052
ERROR - 2019-10-09 14:57:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 14:57:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 14:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 14:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 14:57:14 --> Total execution time: 0.0085
ERROR - 2019-10-09 15:00:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:00:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:00:21 --> Total execution time: 0.0053
ERROR - 2019-10-09 15:00:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:00:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:00:21 --> Total execution time: 0.0039
ERROR - 2019-10-09 15:00:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:00:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:00:22 --> Total execution time: 0.0045
ERROR - 2019-10-09 15:00:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:00:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:00:45 --> Total execution time: 0.0047
ERROR - 2019-10-09 15:00:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:00:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:00:48 --> No URI present. Default controller set.
DEBUG - 2019-10-09 15:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:00:48 --> Total execution time: 0.0110
ERROR - 2019-10-09 15:01:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:01:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:01:06 --> Total execution time: 0.0035
ERROR - 2019-10-09 15:01:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:01:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:01:09 --> No URI present. Default controller set.
DEBUG - 2019-10-09 15:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:01:09 --> Total execution time: 0.0083
ERROR - 2019-10-09 15:01:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:01:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:01:22 --> Total execution time: 0.0043
ERROR - 2019-10-09 15:01:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:01:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:01:26 --> Total execution time: 0.0071
ERROR - 2019-10-09 15:01:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:01:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:01:26 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 15:03:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:03:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:03:04 --> Total execution time: 0.0131
ERROR - 2019-10-09 15:03:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:03:04 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 15:03:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:03:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:03:40 --> Total execution time: 0.0074
ERROR - 2019-10-09 15:03:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:03:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:03:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:03:40 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 15:04:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:04:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:04:33 --> Total execution time: 0.0052
ERROR - 2019-10-09 15:04:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:04:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:04:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:04:33 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 15:05:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:05:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:05:03 --> Query error: Duplicate entry '2147483647' for key 'school_mobile' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('rewrew', 'wer', '3423423443', '3244444444', 'logo19.png', 'r@r.com', '2019-10-09', '2019-10-09', '1')
DEBUG - 2019-10-09 15:05:03 --> Total execution time: 0.2999
ERROR - 2019-10-09 15:05:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:05:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:05:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:05:03 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:05:33 --> Query error: Duplicate entry '2147483647' for key 'school_mobile2' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('qqqq', 'qqqq', '2111111111', '3333333333', 'logo123.png', 'qqq123@gmail.com', '2019-10-09', '2019-10-09', '1')
DEBUG - 2019-10-09 15:05:33 --> Total execution time: 0.1026
ERROR - 2019-10-09 15:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:05:33 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:06:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:06:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:06:28 --> Query error: Duplicate entry '2147483647' for key 'school_mobile2' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('qqqq', 'qqqq', '2111111111', '3333333333', 'logo1231.png', 'qqq123@gmail.com', '2019-10-09', '2019-10-09', '1')
DEBUG - 2019-10-09 15:06:28 --> Total execution time: 0.0627
ERROR - 2019-10-09 15:06:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:06:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:06:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:06:28 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:07:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:07:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:07:11 --> Query error: Duplicate entry '2147483647' for key 'school_mobile2' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('qqqq', 'qqqq', '2111111111', '3333333333', 'logo1232.png', 'qqq123@gmail.com', '2019-10-09', '2019-10-09', '1')
DEBUG - 2019-10-09 15:07:11 --> Total execution time: 0.0677
ERROR - 2019-10-09 15:07:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:07:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:07:11 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:07:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:07:22 --> Total execution time: 0.0043
ERROR - 2019-10-09 15:07:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:07:22 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:07:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:07:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:07:54 --> Query error: Duplicate entry '2147483647' for key 'school_mobile' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('abcd', 'ssss', '2321312112', '3123312312', 'logo20.png', 'abcd@gmail.com', '2019-10-09', '2019-10-09', '1')
DEBUG - 2019-10-09 15:07:54 --> Total execution time: 0.0928
ERROR - 2019-10-09 15:07:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:07:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:07:54 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:08:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:08:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:08:16 --> Total execution time: 0.0069
ERROR - 2019-10-09 15:08:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:08:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:08:16 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:08:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:08:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:08:50 --> Total execution time: 0.0053
ERROR - 2019-10-09 15:08:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:08:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:08:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:08:50 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:09:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:09:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:09:14 --> Query error: Duplicate entry '2147483647' for key 'school_mobile' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('rrrrrrrrrrrrrrrrrr', 'rrrrrrrrrr', '2222222222', '3333333333', '170477-004-B774BDDF.jpg', 'rrrrr@rrrr.com', '2019-10-09', '2019-10-09', '1')
DEBUG - 2019-10-09 15:09:14 --> Total execution time: 0.1038
ERROR - 2019-10-09 15:09:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:09:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:09:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:09:14 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:09:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:09:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:12:18 --> Query error: Duplicate entry '2147483647' for key 'school_mobile' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('rrrrrrrrrrrrrrrrrr', 'rrrrrrrrrr', '2222222222', '3333333333', '170477-004-B774BDDF2.jpg', 'rrrrr@rrrr.com', '2019-10-09', '2019-10-09', '1')
ERROR - 2019-10-09 15:14:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:14:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:14:12 --> Query error: Duplicate entry '2147483647' for key 'school_mobile' - Invalid query: INSERT INTO `school` (`school_name`, `school_address`, `school_mobile`, `school_mobile2`, `school_logo`, `school_mail`, `date`, `created_date`, `created_by`) VALUES ('rrrrrrrrrrrrrrrrrr', 'rrrrrrrrrr', '2222222222', '3333333333', '170477-004-B774BDDF3.jpg', 'rrrrr@rrrr.com', '2019-10-09', '2019-10-09', '1')
ERROR - 2019-10-09 15:15:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:15:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:15:13 --> Total execution time: 0.0608
ERROR - 2019-10-09 15:15:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:15:13 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:15:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:15:27 --> Total execution time: 0.0649
ERROR - 2019-10-09 15:15:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:15:27 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:15:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:15:31 --> Total execution time: 0.0806
ERROR - 2019-10-09 15:15:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:15:31 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:15:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:15:34 --> Total execution time: 0.1008
ERROR - 2019-10-09 15:15:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:15:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:15:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:15:34 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:16:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:16:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:16:26 --> Total execution time: 0.1812
ERROR - 2019-10-09 15:16:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:16:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:16:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:16:26 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:16:54 --> Total execution time: 0.0052
ERROR - 2019-10-09 15:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:16:54 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:17:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:17:50 --> Total execution time: 0.0080
ERROR - 2019-10-09 15:17:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:17:50 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:18:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:18:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:18:12 --> Total execution time: 0.1644
ERROR - 2019-10-09 15:18:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:18:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:18:12 --> 404 Page Not Found: Welcome/img
ERROR - 2019-10-09 15:18:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:18:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:18:30 --> Total execution time: 0.0066
ERROR - 2019-10-09 15:18:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:18:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:18:43 --> Total execution time: 0.0025
ERROR - 2019-10-09 15:18:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:18:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:18:48 --> No URI present. Default controller set.
DEBUG - 2019-10-09 15:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:18:48 --> Total execution time: 0.0089
ERROR - 2019-10-09 15:19:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:19:13 --> Total execution time: 0.0777
ERROR - 2019-10-09 15:19:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:19:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:19:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:19:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:19:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:19:13 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:19:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:19:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:19:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:19:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:19:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:19:44 --> Total execution time: 0.0023
ERROR - 2019-10-09 15:19:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:19:44 --> Total execution time: 0.0019
ERROR - 2019-10-09 15:20:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:20:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:20:18 --> Total execution time: 0.0065
ERROR - 2019-10-09 15:36:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:36:50 --> Total execution time: 0.0148
ERROR - 2019-10-09 15:36:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:36:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:36:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:36:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:36:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:36:50 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:36:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:36:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:36:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:36:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:36:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:36:51 --> Total execution time: 0.0071
ERROR - 2019-10-09 15:36:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:36:51 --> Total execution time: 0.0036
ERROR - 2019-10-09 15:36:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:36:58 --> Total execution time: 0.0047
ERROR - 2019-10-09 15:37:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:37:09 --> Total execution time: 0.0028
ERROR - 2019-10-09 15:38:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:38:51 --> Total execution time: 0.0144
ERROR - 2019-10-09 15:38:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:38:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:38:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:38:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:38:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:38:51 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:38:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:38:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:38:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:38:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:38:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:38:53 --> Total execution time: 0.0026
ERROR - 2019-10-09 15:38:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:38:53 --> Total execution time: 0.0027
ERROR - 2019-10-09 15:38:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:38:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:38:56 --> Total execution time: 0.0037
ERROR - 2019-10-09 15:39:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:39:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:39:03 --> Total execution time: 0.0230
ERROR - 2019-10-09 15:39:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:39:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:39:13 --> Total execution time: 0.0034
ERROR - 2019-10-09 15:39:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:39:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:39:18 --> Total execution time: 0.0035
ERROR - 2019-10-09 15:39:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:39:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:39:45 --> Total execution time: 0.0034
ERROR - 2019-10-09 15:40:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:40:44 --> Total execution time: 0.0117
ERROR - 2019-10-09 15:40:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:40:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:40:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:40:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:40:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:40:44 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:40:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:40:45 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:40:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:40:45 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:40:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:40:45 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:40:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:40:45 --> Total execution time: 0.0028
ERROR - 2019-10-09 15:40:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:40:48 --> Total execution time: 0.0049
ERROR - 2019-10-09 15:40:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:40:53 --> Total execution time: 0.0029
ERROR - 2019-10-09 15:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:40:57 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:41:11 --> Total execution time: 0.0081
ERROR - 2019-10-09 15:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 15:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:41:11 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:41:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:41:11 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:41:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:41:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:41:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:41:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:41:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:41:12 --> Total execution time: 0.0030
ERROR - 2019-10-09 15:41:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:41:12 --> Total execution time: 0.0042
ERROR - 2019-10-09 15:41:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:41:14 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:41:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:41:17 --> Total execution time: 0.0030
ERROR - 2019-10-09 15:41:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:41:21 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:41:23 --> Total execution time: 0.0047
ERROR - 2019-10-09 15:41:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:41:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:41:28 --> Total execution time: 0.0054
ERROR - 2019-10-09 15:44:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:16 --> Total execution time: 0.0100
ERROR - 2019-10-09 15:44:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:44:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:44:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:16 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:44:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:44:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:44:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:17 --> Total execution time: 0.0035
ERROR - 2019-10-09 15:44:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:17 --> Total execution time: 0.0027
ERROR - 2019-10-09 15:44:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:19 --> Total execution time: 0.0025
ERROR - 2019-10-09 15:44:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:22 --> Total execution time: 0.0042
ERROR - 2019-10-09 15:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:25 --> Total execution time: 0.0036
ERROR - 2019-10-09 15:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:27 --> Total execution time: 0.0031
ERROR - 2019-10-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:52 --> Total execution time: 0.0079
ERROR - 2019-10-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:52 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:44:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:52 --> Total execution time: 0.0030
ERROR - 2019-10-09 15:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:52 --> Total execution time: 0.0028
ERROR - 2019-10-09 15:44:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:55 --> Total execution time: 0.0037
ERROR - 2019-10-09 15:44:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:44:58 --> Total execution time: 0.0051
ERROR - 2019-10-09 15:44:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:44:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:45:00 --> Total execution time: 0.0050
ERROR - 2019-10-09 15:45:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:45:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:45:04 --> Total execution time: 0.0028
ERROR - 2019-10-09 15:46:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:46:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:46:01 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:47:33 --> Total execution time: 0.0161
ERROR - 2019-10-09 15:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:47:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:47:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:47:33 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:47:33 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:47:33 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:47:33 --> Total execution time: 0.0030
ERROR - 2019-10-09 15:47:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:47:33 --> Total execution time: 0.0046
ERROR - 2019-10-09 15:47:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:47:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:47:48 --> Total execution time: 0.0034
ERROR - 2019-10-09 15:48:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:48:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:48:04 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:48:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:48:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:48:20 --> Total execution time: 0.0037
ERROR - 2019-10-09 15:48:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:48:23 --> Total execution time: 0.0028
ERROR - 2019-10-09 15:48:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:48:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:48:26 --> Total execution time: 0.0033
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:30 --> Total execution time: 0.0126
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:30 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:30 --> Total execution time: 0.0150
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:30 --> Total execution time: 0.0133
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:30 --> Total execution time: 0.0119
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:49:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:30 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:49:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:49:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:49:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:34 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:49:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:34 --> Total execution time: 0.0031
ERROR - 2019-10-09 15:49:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:42 --> Total execution time: 0.0031
ERROR - 2019-10-09 15:49:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:49 --> Total execution time: 0.0050
ERROR - 2019-10-09 15:49:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:49:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:49:52 --> Total execution time: 0.0038
ERROR - 2019-10-09 15:51:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:51:21 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:51:29 --> Total execution time: 0.0069
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:29 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:51:29 --> Total execution time: 0.0084
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:51:29 --> Total execution time: 0.0139
ERROR - 2019-10-09 15:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:51:30 --> Total execution time: 0.0084
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-09 15:51:30 --> Total execution time: 0.0079
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:51:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:51:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:52:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:52:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:52:21 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:52:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:52:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:52:21 --> Total execution time: 0.0031
ERROR - 2019-10-09 15:54:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:12 --> Total execution time: 0.0098
ERROR - 2019-10-09 15:54:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:54:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:54:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:12 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:13 --> Total execution time: 0.0083
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:13 --> Total execution time: 0.0056
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:54:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:54:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:54:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:54:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:16 --> Total execution time: 0.0031
ERROR - 2019-10-09 15:54:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:16 --> Total execution time: 0.0024
ERROR - 2019-10-09 15:54:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:41 --> Total execution time: 0.0023
ERROR - 2019-10-09 15:54:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:42 --> Total execution time: 0.0074
ERROR - 2019-10-09 15:54:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:44 --> Total execution time: 0.0028
ERROR - 2019-10-09 15:54:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:44 --> Total execution time: 0.0059
ERROR - 2019-10-09 15:54:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:44 --> Total execution time: 0.0042
ERROR - 2019-10-09 15:54:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:44 --> Total execution time: 0.0024
ERROR - 2019-10-09 15:54:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:44 --> Total execution time: 0.0026
ERROR - 2019-10-09 15:54:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:45 --> Total execution time: 0.0044
ERROR - 2019-10-09 15:54:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:47 --> Total execution time: 0.0047
ERROR - 2019-10-09 15:54:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:48 --> Total execution time: 0.0028
ERROR - 2019-10-09 15:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:49 --> Total execution time: 0.0027
ERROR - 2019-10-09 15:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:49 --> Total execution time: 0.0049
ERROR - 2019-10-09 15:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:49 --> Total execution time: 0.0038
ERROR - 2019-10-09 15:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:49 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:49 --> Total execution time: 0.0035
ERROR - 2019-10-09 15:54:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:54:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:54:51 --> Total execution time: 0.0045
ERROR - 2019-10-09 15:58:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:11 --> Total execution time: 0.0183
ERROR - 2019-10-09 15:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:58:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:58:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:58:12 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 15:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:58:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 15:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 15:58:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 15:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:12 --> Total execution time: 0.0043
ERROR - 2019-10-09 15:58:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:12 --> Total execution time: 0.0028
ERROR - 2019-10-09 15:58:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:19 --> Total execution time: 0.0041
ERROR - 2019-10-09 15:58:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:21 --> Total execution time: 0.0033
ERROR - 2019-10-09 15:58:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:22 --> Total execution time: 0.0070
ERROR - 2019-10-09 15:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:24 --> Total execution time: 0.0042
ERROR - 2019-10-09 15:58:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:38 --> Total execution time: 0.0034
ERROR - 2019-10-09 15:58:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:41 --> Total execution time: 0.0032
ERROR - 2019-10-09 15:58:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:58:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:58:44 --> Total execution time: 0.0038
ERROR - 2019-10-09 15:59:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:59:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:59:10 --> Total execution time: 0.0050
ERROR - 2019-10-09 15:59:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:59:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:59:10 --> Total execution time: 0.0046
ERROR - 2019-10-09 15:59:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:59:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:59:11 --> Total execution time: 0.0050
ERROR - 2019-10-09 15:59:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 15:59:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 15:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 15:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 15:59:12 --> Total execution time: 0.0028
ERROR - 2019-10-09 16:01:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:03 --> Total execution time: 0.0042
ERROR - 2019-10-09 16:01:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:03 --> Total execution time: 0.0056
ERROR - 2019-10-09 16:01:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:20 --> Total execution time: 0.0056
ERROR - 2019-10-09 16:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:21 --> Total execution time: 0.0054
ERROR - 2019-10-09 16:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:28 --> Total execution time: 0.0081
ERROR - 2019-10-09 16:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:28 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 16:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:01:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:28 --> Total execution time: 0.0091
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:29 --> Total execution time: 0.0021
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:29 --> Total execution time: 0.0023
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:29 --> Total execution time: 0.0091
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:29 --> Total execution time: 0.0096
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:01:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:01:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:31 --> Total execution time: 0.0027
ERROR - 2019-10-09 16:01:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:31 --> Total execution time: 0.0029
ERROR - 2019-10-09 16:01:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:35 --> Total execution time: 0.0045
ERROR - 2019-10-09 16:01:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:01:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:01:41 --> Total execution time: 0.0041
ERROR - 2019-10-09 16:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:03:49 --> Total execution time: 0.0081
ERROR - 2019-10-09 16:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:03:49 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:03:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:03:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:03:50 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 16:03:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:03:50 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:03:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:03:50 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:03:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:03:50 --> Total execution time: 0.0029
ERROR - 2019-10-09 16:03:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:03:50 --> Total execution time: 0.0025
ERROR - 2019-10-09 16:03:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 16:03:56 --> Query error: Unknown column 'st.school_id' in 'where clause' - Invalid query: SELECT *
FROM `students`
WHERE `id` != '13'
AND `roll_number` = '2'
AND `sections_id` = '40'
AND `st`.`school_id` = '3'
DEBUG - 2019-10-09 16:03:56 --> Total execution time: 0.0053
ERROR - 2019-10-09 16:03:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:03:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 16:03:58 --> Query error: Unknown column 'st.school_id' in 'where clause' - Invalid query: SELECT *
FROM `students`
WHERE `id` != '13'
AND `roll_number` = '1'
AND `sections_id` = '40'
AND `st`.`school_id` = '3'
DEBUG - 2019-10-09 16:03:58 --> Total execution time: 0.0057
ERROR - 2019-10-09 16:04:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:04:27 --> Total execution time: 0.0095
ERROR - 2019-10-09 16:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:28 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:28 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 16:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:28 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 16:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:28 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 16:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:04:28 --> Total execution time: 0.0036
ERROR - 2019-10-09 16:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:04:28 --> Total execution time: 0.0042
ERROR - 2019-10-09 16:04:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:04:33 --> Total execution time: 0.0034
ERROR - 2019-10-09 16:04:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:04:35 --> Total execution time: 0.0040
ERROR - 2019-10-09 16:04:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:04:49 --> Total execution time: 0.3158
ERROR - 2019-10-09 16:04:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:04:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:04:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:04:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:04:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:49 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:04:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:04:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:04:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:04:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:12:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:07 --> Total execution time: 0.0055
ERROR - 2019-10-09 16:12:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:07 --> Total execution time: 0.0026
ERROR - 2019-10-09 16:12:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:11 --> Total execution time: 0.0042
ERROR - 2019-10-09 16:12:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:22 --> Total execution time: 0.0035
ERROR - 2019-10-09 16:12:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:24 --> Total execution time: 0.0035
ERROR - 2019-10-09 16:12:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:28 --> Total execution time: 0.0041
ERROR - 2019-10-09 16:12:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:33 --> Total execution time: 0.0042
ERROR - 2019-10-09 16:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:35 --> Total execution time: 0.1255
ERROR - 2019-10-09 16:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:12:35 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:12:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:12:35 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:12:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:12:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:44 --> Total execution time: 0.0024
ERROR - 2019-10-09 16:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:12:44 --> Total execution time: 0.0036
ERROR - 2019-10-09 16:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:17:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:17:39 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2019-10-09 16:17:39 --> Total execution time: 0.0887
ERROR - 2019-10-09 16:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:17:39 --> UTF-8 Support Enabled
ERROR - 2019-10-09 16:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:17:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:17:39 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:17:39 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:17:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:17:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:17:39 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:17:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:17:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:17:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:17:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:17:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:17:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:18:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:18:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:18:01 --> Total execution time: 0.0039
ERROR - 2019-10-09 16:18:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:18:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:18:01 --> Total execution time: 0.0028
ERROR - 2019-10-09 16:18:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:18:06 --> Total execution time: 1.0553
ERROR - 2019-10-09 16:18:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:18:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:18:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:18:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:18:06 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-09 16:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:18:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:18:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:18:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:18:06 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:18:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:18:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:18:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:18:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:18:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:18:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:19:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:19:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:19:48 --> Total execution time: 0.0045
ERROR - 2019-10-09 16:19:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:19:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:19:48 --> Total execution time: 0.0022
ERROR - 2019-10-09 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:21:46 --> Total execution time: 0.0369
ERROR - 2019-10-09 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:21:46 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:21:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:21:46 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:21:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:21:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:21:48 --> Total execution time: 0.0024
ERROR - 2019-10-09 16:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:21:48 --> Total execution time: 0.0023
ERROR - 2019-10-09 16:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:23:34 --> Total execution time: 0.0364
ERROR - 2019-10-09 16:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:23:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:23:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:23:34 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:23:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:23:35 --> Total execution time: 0.0071
ERROR - 2019-10-09 16:23:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:23:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:23:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:23:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:23:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:23:35 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:23:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:23:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:23:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:24:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:24:26 --> Total execution time: 0.0030
ERROR - 2019-10-09 16:24:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:24:26 --> Total execution time: 0.0020
ERROR - 2019-10-09 16:24:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:24:26 --> Total execution time: 0.0088
ERROR - 2019-10-09 16:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:24:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:24:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:24:27 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:24:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:24:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:24:27 --> Total execution time: 0.0047
ERROR - 2019-10-09 16:25:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:12 --> Total execution time: 0.0073
ERROR - 2019-10-09 16:25:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:25:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:12 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:12 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:25:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:25:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:14 --> Total execution time: 0.0026
ERROR - 2019-10-09 16:25:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:14 --> Total execution time: 0.0022
ERROR - 2019-10-09 16:25:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:14 --> Total execution time: 0.0107
ERROR - 2019-10-09 16:25:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:25:14 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:25:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:14 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:25:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:25:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:37 --> Total execution time: 0.0031
ERROR - 2019-10-09 16:25:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:37 --> Total execution time: 0.0035
ERROR - 2019-10-09 16:25:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:37 --> Total execution time: 0.0081
ERROR - 2019-10-09 16:25:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:25:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:37 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:38 --> Total execution time: 0.0043
ERROR - 2019-10-09 16:25:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:38 --> Total execution time: 0.0029
ERROR - 2019-10-09 16:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:44 --> Total execution time: 0.0109
ERROR - 2019-10-09 16:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:44 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:44 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:44 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:44 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:25:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:44 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:58 --> Total execution time: 0.0035
ERROR - 2019-10-09 16:25:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:58 --> Total execution time: 0.0038
ERROR - 2019-10-09 16:25:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:59 --> Total execution time: 0.0113
ERROR - 2019-10-09 16:25:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:25:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:59 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-09 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:59 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:25:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:59 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:25:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:59 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:25:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:25:59 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:25:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:59 --> Total execution time: 0.0025
ERROR - 2019-10-09 16:25:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:25:59 --> Total execution time: 0.0026
ERROR - 2019-10-09 16:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:26:27 --> Total execution time: 0.0097
ERROR - 2019-10-09 16:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:27 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:26:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:26:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:26:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:26:37 --> Total execution time: 0.0101
ERROR - 2019-10-09 16:26:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:37 --> UTF-8 Support Enabled
ERROR - 2019-10-09 16:26:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:37 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:37 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:26:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:26:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:26:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:26:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:26:49 --> Total execution time: 0.0094
ERROR - 2019-10-09 16:26:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:26:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:26:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:49 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:26:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:26:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:26:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:27:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:27:19 --> Total execution time: 0.0093
ERROR - 2019-10-09 16:27:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:27:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:27:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:19 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:27:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:27:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:20 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:27:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:27:45 --> Total execution time: 0.0091
ERROR - 2019-10-09 16:27:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:27:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:27:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:45 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:27:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:27:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:27:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:27:53 --> Total execution time: 0.0104
ERROR - 2019-10-09 16:27:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:27:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:27:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:53 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:27:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:27:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:27:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:28:15 --> Total execution time: 0.0093
ERROR - 2019-10-09 16:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:28:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:28:15 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:28:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:28:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:28:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:28:15 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:28:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:28:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:28:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:28:16 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:29:16 --> Total execution time: 0.0093
ERROR - 2019-10-09 16:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:16 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-09 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:16 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:16 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:16 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:29:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:16 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:29:26 --> Total execution time: 0.0083
ERROR - 2019-10-09 16:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:26 --> UTF-8 Support Enabled
ERROR - 2019-10-09 16:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:29:26 --> UTF-8 Support Enabled
ERROR - 2019-10-09 16:29:26 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:26 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:26 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:29:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:29:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:29:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:30:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:30:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:30:10 --> Total execution time: 0.0129
ERROR - 2019-10-09 16:30:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:30:11 --> UTF-8 Support Enabled
ERROR - 2019-10-09 16:30:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:30:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:30:11 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 16:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:30:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:30:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:30:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:30:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:30:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:30:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:30:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:30:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:30:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:30:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:31:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:31:28 --> Total execution time: 0.0087
ERROR - 2019-10-09 16:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:29 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:31:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:31:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:31:54 --> Total execution time: 0.0099
ERROR - 2019-10-09 16:31:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:31:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:31:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:54 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:31:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:31:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:31:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:32:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:32:57 --> Total execution time: 0.0092
ERROR - 2019-10-09 16:32:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:32:57 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:32:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:32:57 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:32:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:32:57 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:32:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:32:57 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:32:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:32:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:32:57 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:32:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:32:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:32:59 --> Total execution time: 0.0023
ERROR - 2019-10-09 16:32:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:32:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:32:59 --> Total execution time: 0.0024
ERROR - 2019-10-09 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:33:12 --> Total execution time: 0.0098
ERROR - 2019-10-09 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:12 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:33:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:33:25 --> Total execution time: 0.0089
ERROR - 2019-10-09 16:33:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:33:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:33:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:25 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:33:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:33:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:33:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:33:37 --> Total execution time: 0.0082
ERROR - 2019-10-09 16:33:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:33:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:33:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:37 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:33:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:33:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:33:45 --> Total execution time: 0.0086
ERROR - 2019-10-09 16:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:45 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:33:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:34:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:34:01 --> Total execution time: 0.0126
ERROR - 2019-10-09 16:34:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:01 --> UTF-8 Support Enabled
ERROR - 2019-10-09 16:34:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:34:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:34:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:01 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:34:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:34:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:34:13 --> Total execution time: 0.0095
ERROR - 2019-10-09 16:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:13 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:34:18 --> Total execution time: 0.0081
ERROR - 2019-10-09 16:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:18 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:18 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:18 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:34:28 --> Total execution time: 0.0094
ERROR - 2019-10-09 16:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 16:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:28 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-09 16:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:28 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:34:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:35:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:35:12 --> Total execution time: 0.0143
ERROR - 2019-10-09 16:35:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:35:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:35:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:35:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:35:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:35:12 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:35:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:35:12 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:35:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:35:12 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:36:04 --> Total execution time: 0.0103
ERROR - 2019-10-09 16:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:04 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:36:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:36:10 --> Total execution time: 0.0087
ERROR - 2019-10-09 16:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:10 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:36:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:37:33 --> Total execution time: 0.0070
ERROR - 2019-10-09 16:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:33 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:33 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:37:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:33 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:37:34 --> Total execution time: 0.0096
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:37:34 --> Total execution time: 0.0084
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 16:37:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 16:37:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:37:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:37:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 16:37:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 16:38:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:38:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:38:10 --> Total execution time: 0.0031
ERROR - 2019-10-09 16:38:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 16:38:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 16:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 16:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 16:38:10 --> Total execution time: 0.0024
ERROR - 2019-10-09 17:44:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:44:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:44:38 --> Total execution time: 0.0084
ERROR - 2019-10-09 17:44:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:44:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:44:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:44:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:44:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:44:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:44:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:44:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:44:38 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:44:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:44:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:44:39 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:44:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:44:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:44:39 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:44:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:44:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:44:41 --> Total execution time: 0.0025
ERROR - 2019-10-09 17:44:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:44:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:44:41 --> Total execution time: 0.0022
ERROR - 2019-10-09 17:45:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:09 --> Total execution time: 0.0080
ERROR - 2019-10-09 17:45:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:45:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:45:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:09 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:45:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:45:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:45:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:10 --> Total execution time: 0.0026
ERROR - 2019-10-09 17:45:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:10 --> Total execution time: 0.0049
ERROR - 2019-10-09 17:45:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:10 --> You did not select a file to upload.
DEBUG - 2019-10-09 17:45:10 --> Total execution time: 0.0091
ERROR - 2019-10-09 17:45:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:45:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:45:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:10 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:45:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:11 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:45:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:45:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:16 --> Total execution time: 0.0027
ERROR - 2019-10-09 17:45:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:16 --> Total execution time: 0.0025
ERROR - 2019-10-09 17:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:17 --> Total execution time: 0.0097
ERROR - 2019-10-09 17:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:17 --> UTF-8 Support Enabled
ERROR - 2019-10-09 17:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:17 --> UTF-8 Support Enabled
ERROR - 2019-10-09 17:45:17 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 17:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:17 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:45:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:18 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:45:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:45:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:38 --> Total execution time: 0.0092
ERROR - 2019-10-09 17:45:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:45:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:45:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:38 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:45:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:45:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:45:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:45:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:40 --> Total execution time: 0.0035
ERROR - 2019-10-09 17:45:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:45:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:45:40 --> Total execution time: 0.0024
ERROR - 2019-10-09 17:48:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:48:45 --> Total execution time: 0.0085
ERROR - 2019-10-09 17:48:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:48:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:48:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:48:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:48:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:48:45 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:48:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:48:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:48:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:48:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:48:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:48:45 --> Total execution time: 0.0044
ERROR - 2019-10-09 17:48:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:48:54 --> Total execution time: 0.0103
ERROR - 2019-10-09 17:48:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 17:48:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:48:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:48:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:48:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:48:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:48:54 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:48:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:48:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:48:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:48:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:49:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:49:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:49:33 --> Total execution time: 0.0021
ERROR - 2019-10-09 17:49:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:49:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:49:33 --> Total execution time: 0.0022
ERROR - 2019-10-09 17:51:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:51:24 --> Total execution time: 0.0072
ERROR - 2019-10-09 17:51:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:51:24 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:51:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:51:24 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:51:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:51:24 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:51:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:51:24 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:51:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:51:24 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:51:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:51:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:51:41 --> Total execution time: 0.0022
ERROR - 2019-10-09 17:51:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:51:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:51:41 --> Total execution time: 0.0024
ERROR - 2019-10-09 17:53:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:16 --> Total execution time: 0.0143
ERROR - 2019-10-09 17:53:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:53:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:53:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:17 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:53:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:53:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:53:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:18 --> Total execution time: 0.0034
ERROR - 2019-10-09 17:53:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:18 --> Total execution time: 0.0023
ERROR - 2019-10-09 17:53:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:22 --> Total execution time: 0.0108
ERROR - 2019-10-09 17:53:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:22 --> UTF-8 Support Enabled
ERROR - 2019-10-09 17:53:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:22 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 17:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:53:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:22 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:53:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:53:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:53:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:28 --> Total execution time: 0.0050
ERROR - 2019-10-09 17:53:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:28 --> Total execution time: 0.0030
ERROR - 2019-10-09 17:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:30 --> Total execution time: 0.0110
ERROR - 2019-10-09 17:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 17:53:30 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-09 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 17:53:30 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-09 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:30 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:30 --> Total execution time: 0.0028
ERROR - 2019-10-09 17:53:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:30 --> Total execution time: 0.0027
ERROR - 2019-10-09 17:53:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:38 --> Total execution time: 0.0085
ERROR - 2019-10-09 17:53:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:53:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:53:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:38 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:53:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:53:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:53:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:39 --> Total execution time: 0.0071
ERROR - 2019-10-09 17:53:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:39 --> Total execution time: 0.0029
ERROR - 2019-10-09 17:53:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:47 --> Total execution time: 0.0087
ERROR - 2019-10-09 17:53:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:53:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:47 --> UTF-8 Support Enabled
ERROR - 2019-10-09 17:53:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:47 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-09 17:53:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:47 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:53:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:53:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:53:47 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:53:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:48 --> Total execution time: 0.0024
ERROR - 2019-10-09 17:53:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:53:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:53:48 --> Total execution time: 0.0025
ERROR - 2019-10-09 17:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:54:00 --> Total execution time: 0.0075
ERROR - 2019-10-09 17:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:54:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:54:00 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:54:00 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:54:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:54:00 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:54:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:54:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:54:01 --> Total execution time: 0.0022
ERROR - 2019-10-09 17:54:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:54:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:54:01 --> Total execution time: 0.0035
ERROR - 2019-10-09 17:58:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:58:28 --> Total execution time: 0.0257
ERROR - 2019-10-09 17:58:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:58:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:58:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:58:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:58:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:58:28 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 17:58:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:58:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 17:58:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 17:58:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 17:58:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:58:30 --> Total execution time: 0.0024
ERROR - 2019-10-09 17:58:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 17:58:30 --> Total execution time: 0.0025
ERROR - 2019-10-09 17:58:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 17:58:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 17:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 17:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-09 18:00:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:00:03 --> Total execution time: 0.1575
ERROR - 2019-10-09 18:00:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:03 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:00:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:03 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:00:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:03 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:00:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:03 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:00:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:03 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:00:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:00:39 --> Total execution time: 0.0044
ERROR - 2019-10-09 18:00:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:00:39 --> Total execution time: 0.0027
ERROR - 2019-10-09 18:00:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:00:48 --> Total execution time: 0.1574
ERROR - 2019-10-09 18:00:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:00:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 18:00:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:48 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-09 18:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:48 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:00:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:00:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:00:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:00:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:00:52 --> Total execution time: 0.0029
ERROR - 2019-10-09 18:00:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:00:52 --> Total execution time: 0.0024
ERROR - 2019-10-09 18:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:01 --> Total execution time: 0.0331
ERROR - 2019-10-09 18:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:01 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:03 --> Total execution time: 0.0029
ERROR - 2019-10-09 18:01:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:03 --> Total execution time: 0.0028
ERROR - 2019-10-09 18:01:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:05 --> Total execution time: 0.0164
ERROR - 2019-10-09 18:01:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:05 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:05 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:05 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:01:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:05 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:05 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:10 --> Total execution time: 0.0034
ERROR - 2019-10-09 18:01:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:10 --> Total execution time: 0.0021
ERROR - 2019-10-09 18:01:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:16 --> Total execution time: 0.0488
ERROR - 2019-10-09 18:01:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:16 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:16 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:16 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:01:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:18 --> Total execution time: 0.0025
ERROR - 2019-10-09 18:01:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:18 --> Total execution time: 0.0046
ERROR - 2019-10-09 18:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:21 --> Total execution time: 0.0347
ERROR - 2019-10-09 18:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:21 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:21 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:21 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:21 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:21 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:27 --> Total execution time: 0.0048
ERROR - 2019-10-09 18:01:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:27 --> Total execution time: 0.0025
ERROR - 2019-10-09 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:01:29 --> Total execution time: 0.0086
ERROR - 2019-10-09 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:29 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:01:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:02:16 --> Total execution time: 0.0034
ERROR - 2019-10-09 18:02:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:02:16 --> Total execution time: 0.0034
ERROR - 2019-10-09 18:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:02:19 --> Total execution time: 0.0126
ERROR - 2019-10-09 18:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:19 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:19 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:02:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:19 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:02:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:02:20 --> Total execution time: 0.0034
ERROR - 2019-10-09 18:02:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:02:20 --> Total execution time: 0.0028
ERROR - 2019-10-09 18:02:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:02:48 --> Total execution time: 0.0068
ERROR - 2019-10-09 18:02:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:48 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:02:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:48 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:02:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:49 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:02:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:02:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:02:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:02:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:02:51 --> Total execution time: 0.0032
ERROR - 2019-10-09 18:02:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:02:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:02:51 --> Total execution time: 0.0053
ERROR - 2019-10-09 18:03:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:14 --> Total execution time: 0.0113
ERROR - 2019-10-09 18:03:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:03:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:03:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:14 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:15 --> Total execution time: 0.0027
ERROR - 2019-10-09 18:03:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:15 --> Total execution time: 0.0030
ERROR - 2019-10-09 18:03:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:35 --> Total execution time: 0.0130
ERROR - 2019-10-09 18:03:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:03:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:03:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:36 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:03:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:03:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:03:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:36 --> Total execution time: 0.0058
ERROR - 2019-10-09 18:03:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:36 --> Total execution time: 0.0048
ERROR - 2019-10-09 18:03:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:42 --> Total execution time: 0.0072
ERROR - 2019-10-09 18:03:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:42 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:03:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:42 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:03:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:42 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:03:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:03:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:03:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:03:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:43 --> Total execution time: 0.0053
ERROR - 2019-10-09 18:03:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:03:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:03:43 --> Total execution time: 0.0023
ERROR - 2019-10-09 18:10:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:10:08 --> Total execution time: 0.0094
ERROR - 2019-10-09 18:10:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 18:10:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 18:10:08 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-09 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:08 --> 404 Page Not Found: Welcome/profile
DEBUG - 2019-10-09 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:08 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:10:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:10:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:10:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:10:09 --> Total execution time: 0.0034
ERROR - 2019-10-09 18:10:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:10:09 --> Total execution time: 0.0030
ERROR - 2019-10-09 18:10:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:10:45 --> Total execution time: 0.0083
ERROR - 2019-10-09 18:10:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:45 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:10:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:45 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:10:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:45 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:10:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:10:46 --> Total execution time: 0.0025
ERROR - 2019-10-09 18:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:10:46 --> Total execution time: 0.0027
ERROR - 2019-10-09 18:12:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:12:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:12:34 --> Total execution time: 0.0087
ERROR - 2019-10-09 18:12:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:12:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:12:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:12:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:12:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:12:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:12:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:12:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:12:34 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:12:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:12:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:12:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:12:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:12:35 --> Total execution time: 0.0038
ERROR - 2019-10-09 18:12:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:12:35 --> Total execution time: 0.0059
ERROR - 2019-10-09 18:13:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:13:40 --> Total execution time: 0.0107
ERROR - 2019-10-09 18:13:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:13:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:13:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 18:13:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:13:40 --> 404 Page Not Found: Welcome/profile
DEBUG - 2019-10-09 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:13:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:13:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:13:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:13:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:13:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:13:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:13:41 --> Total execution time: 0.0038
ERROR - 2019-10-09 18:13:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:13:41 --> Total execution time: 0.0051
ERROR - 2019-10-09 18:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:14:00 --> Total execution time: 0.0601
ERROR - 2019-10-09 18:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:14:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:14:00 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:14:00 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:14:00 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:14:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:14:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:14:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:14:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:14:05 --> Total execution time: 0.0027
ERROR - 2019-10-09 18:14:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:14:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:14:05 --> Total execution time: 0.0023
ERROR - 2019-10-09 18:16:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:16:30 --> Total execution time: 0.0067
ERROR - 2019-10-09 18:16:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:16:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:30 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:16:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:16:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:30 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:16:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:30 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:16:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:16:31 --> Total execution time: 0.0028
ERROR - 2019-10-09 18:16:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:16:31 --> Total execution time: 0.0035
ERROR - 2019-10-09 18:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:16:53 --> Total execution time: 0.0091
ERROR - 2019-10-09 18:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 18:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:16:53 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:16:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:16:53 --> Total execution time: 0.0075
ERROR - 2019-10-09 18:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:54 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:54 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:16:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:16:54 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:16:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:16:55 --> Total execution time: 0.0037
ERROR - 2019-10-09 18:16:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:16:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:16:55 --> Total execution time: 0.0029
ERROR - 2019-10-09 18:17:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:17:16 --> Total execution time: 0.0061
ERROR - 2019-10-09 18:17:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:17:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:17:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:17 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:17:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:17:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:17:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:17:17 --> Total execution time: 0.0030
ERROR - 2019-10-09 18:17:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:17:17 --> Total execution time: 0.0053
ERROR - 2019-10-09 18:17:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:17:55 --> Total execution time: 0.0122
ERROR - 2019-10-09 18:17:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:55 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:17:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:55 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:17:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:55 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:17:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:55 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:17:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:17:55 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:17:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:17:56 --> Total execution time: 0.0032
ERROR - 2019-10-09 18:17:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:17:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:17:56 --> Total execution time: 0.0031
ERROR - 2019-10-09 18:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:18:10 --> Total execution time: 0.0095
ERROR - 2019-10-09 18:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:18:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:18:10 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:18:10 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:18:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:18:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:18:10 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:18:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:18:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:18:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:18:11 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:18:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:18:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:18:11 --> Total execution time: 0.0033
ERROR - 2019-10-09 18:18:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:18:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:18:11 --> Total execution time: 0.0032
ERROR - 2019-10-09 18:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:20:15 --> Total execution time: 0.0092
ERROR - 2019-10-09 18:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:15 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:20:15 --> Total execution time: 0.0044
ERROR - 2019-10-09 18:20:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:20:15 --> Total execution time: 0.0047
ERROR - 2019-10-09 18:20:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:20:40 --> Total execution time: 0.0079
ERROR - 2019-10-09 18:20:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:20:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:20:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:40 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:20:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:40 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:20:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:20:41 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:20:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:20:41 --> Total execution time: 0.0028
ERROR - 2019-10-09 18:20:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:20:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:20:41 --> Total execution time: 0.0025
ERROR - 2019-10-09 18:21:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:23 --> Total execution time: 0.0069
ERROR - 2019-10-09 18:21:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:21:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:21:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:23 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:21:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:21:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:21:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:24 --> Total execution time: 0.0030
ERROR - 2019-10-09 18:21:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:24 --> Total execution time: 0.0052
ERROR - 2019-10-09 18:21:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:35 --> Total execution time: 0.0079
ERROR - 2019-10-09 18:21:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:21:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:21:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:36 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:21:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:21:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:21:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:36 --> Total execution time: 0.0030
ERROR - 2019-10-09 18:21:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:36 --> Total execution time: 0.0027
ERROR - 2019-10-09 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:49 --> Total execution time: 0.0077
ERROR - 2019-10-09 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:49 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:49 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:21:49 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:49 --> Total execution time: 0.0055
ERROR - 2019-10-09 18:21:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:21:49 --> Total execution time: 0.0028
ERROR - 2019-10-09 18:22:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:22:01 --> Total execution time: 0.0101
ERROR - 2019-10-09 18:22:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:01 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:22:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:01 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:22:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:01 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:22:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:22:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:22:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:22:02 --> Total execution time: 0.0031
ERROR - 2019-10-09 18:22:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:22:02 --> Total execution time: 0.0036
ERROR - 2019-10-09 18:22:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:22:35 --> Total execution time: 0.0142
ERROR - 2019-10-09 18:22:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:22:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:22:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:35 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-09 18:22:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-09 18:22:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:22:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-09 18:22:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:22:36 --> Total execution time: 0.0024
ERROR - 2019-10-09 18:22:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:22:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:22:36 --> Total execution time: 0.0024
ERROR - 2019-10-09 18:33:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:33:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:33:40 --> Total execution time: 0.0036
ERROR - 2019-10-09 18:33:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:33:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:33:42 --> No URI present. Default controller set.
DEBUG - 2019-10-09 18:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:33:42 --> Total execution time: 0.0084
ERROR - 2019-10-09 18:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:33:45 --> Total execution time: 0.0058
ERROR - 2019-10-09 18:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:33:45 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-09 18:38:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:38:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:38:47 --> Total execution time: 0.0020
ERROR - 2019-10-09 18:38:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:38:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:38:50 --> No URI present. Default controller set.
DEBUG - 2019-10-09 18:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:38:50 --> Total execution time: 0.0087
ERROR - 2019-10-09 18:38:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:38:53 --> Total execution time: 0.0090
ERROR - 2019-10-09 18:38:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:38:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:38:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:38:53 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:38:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:38:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:38:55 --> Total execution time: 0.0022
ERROR - 2019-10-09 18:38:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:38:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:38:55 --> Total execution time: 0.0035
ERROR - 2019-10-09 18:39:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:39:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:39:41 --> Total execution time: 0.0094
ERROR - 2019-10-09 18:39:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:39:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:39:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:39:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:40:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:01 --> Total execution time: 0.0035
ERROR - 2019-10-09 18:40:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:01 --> Total execution time: 0.0032
ERROR - 2019-10-09 18:40:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:20 --> Total execution time: 0.0085
ERROR - 2019-10-09 18:40:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:40:21 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:40:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:21 --> Total execution time: 0.0108
ERROR - 2019-10-09 18:40:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:22 --> Total execution time: 0.0052
ERROR - 2019-10-09 18:40:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:40:22 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:40:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:48 --> Total execution time: 0.0060
ERROR - 2019-10-09 18:40:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:48 --> Total execution time: 0.0031
ERROR - 2019-10-09 18:40:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:48 --> Total execution time: 0.0131
ERROR - 2019-10-09 18:40:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:40:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 18:40:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:40:48 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:40:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:40:49 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 18:40:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:49 --> Total execution time: 0.0023
ERROR - 2019-10-09 18:40:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:49 --> Total execution time: 0.0031
ERROR - 2019-10-09 18:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:40:57 --> Total execution time: 0.0096
ERROR - 2019-10-09 18:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:40:57 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:41:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:41:05 --> Total execution time: 0.0103
ERROR - 2019-10-09 18:41:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:41:05 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:41:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:41:22 --> Total execution time: 0.0062
ERROR - 2019-10-09 18:41:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:41:22 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 18:41:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:41:22 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:41:23 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 18:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:41:23 --> Total execution time: 0.0032
ERROR - 2019-10-09 18:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:41:23 --> Total execution time: 0.0028
ERROR - 2019-10-09 18:41:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:41:34 --> Total execution time: 0.0104
ERROR - 2019-10-09 18:41:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:41:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 18:41:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:41:34 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:41:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:41:34 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 18:41:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:41:35 --> Total execution time: 0.0030
ERROR - 2019-10-09 18:41:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:41:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:41:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:41:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 18:42:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:42:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:42:39 --> Total execution time: 0.0106
ERROR - 2019-10-09 18:42:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:42:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:42:39 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:42:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:42:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:42:39 --> Total execution time: 0.0107
ERROR - 2019-10-09 18:42:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:42:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:42:39 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:43:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:43:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:43:13 --> Total execution time: 0.0123
ERROR - 2019-10-09 18:43:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:43:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:43:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:43:14 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:43:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:43:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:43:36 --> Total execution time: 0.0123
ERROR - 2019-10-09 18:43:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:43:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:43:36 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:43:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:43:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:43:40 --> Total execution time: 0.0032
ERROR - 2019-10-09 18:43:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:43:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:43:40 --> Total execution time: 0.0023
ERROR - 2019-10-09 18:44:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:44:11 --> Total execution time: 0.0057
ERROR - 2019-10-09 18:44:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:44:11 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:44:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:44:23 --> Total execution time: 0.0071
ERROR - 2019-10-09 18:44:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:44:23 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:44:31 --> Total execution time: 0.0086
ERROR - 2019-10-09 18:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:44:31 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:44:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:44:35 --> Total execution time: 0.0079
ERROR - 2019-10-09 18:44:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:44:35 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:44:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:44:36 --> Total execution time: 0.0023
ERROR - 2019-10-09 18:44:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:44:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:44:36 --> Total execution time: 0.0035
ERROR - 2019-10-09 18:45:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:45:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:45:19 --> Total execution time: 0.0099
ERROR - 2019-10-09 18:45:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:45:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:45:19 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:45:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:45:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:45:43 --> Total execution time: 0.0076
ERROR - 2019-10-09 18:45:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:45:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:45:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:45:43 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:45:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:45:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:45:44 --> Total execution time: 0.0084
ERROR - 2019-10-09 18:45:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:45:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:45:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:45:44 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:46:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:46:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:46:33 --> Total execution time: 0.0068
ERROR - 2019-10-09 18:46:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:46:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:46:33 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:47:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:47:35 --> Total execution time: 0.0132
ERROR - 2019-10-09 18:47:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:47:35 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:47:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:47:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:47:54 --> Total execution time: 0.0096
ERROR - 2019-10-09 18:47:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:47:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:47:54 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:48:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:48:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:48:08 --> Total execution time: 0.0060
ERROR - 2019-10-09 18:48:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:48:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:48:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:48:08 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:48:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:48:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:48:14 --> Total execution time: 0.0041
ERROR - 2019-10-09 18:48:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:48:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:48:14 --> Total execution time: 0.0032
ERROR - 2019-10-09 18:48:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:48:30 --> Total execution time: 0.0091
ERROR - 2019-10-09 18:48:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:48:30 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:51:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:51:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:51:21 --> Total execution time: 0.0080
ERROR - 2019-10-09 18:51:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:51:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:51:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:51:21 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:51:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:51:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:51:22 --> Total execution time: 0.0112
ERROR - 2019-10-09 18:51:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:51:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:51:22 --> Total execution time: 0.0074
ERROR - 2019-10-09 18:51:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:51:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:51:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:51:22 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 18:51:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:51:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:51:34 --> Total execution time: 0.0033
ERROR - 2019-10-09 18:51:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:51:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:51:34 --> Total execution time: 0.0036
ERROR - 2019-10-09 18:53:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:53:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 18:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 18:53:17 --> Total execution time: 0.0082
ERROR - 2019-10-09 18:53:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 18:53:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 18:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 18:53:17 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 19:03:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:03:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:03:27 --> Total execution time: 0.0065
ERROR - 2019-10-09 19:03:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:03:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 19:03:27 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 19:03:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:03:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:03:28 --> Total execution time: 0.0110
ERROR - 2019-10-09 19:03:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:03:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:03:28 --> Total execution time: 0.0088
ERROR - 2019-10-09 19:03:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:03:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:03:29 --> Total execution time: 0.0026
ERROR - 2019-10-09 19:03:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:03:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:03:29 --> Total execution time: 0.0028
ERROR - 2019-10-09 19:03:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:03:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 19:03:29 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 19:05:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:05:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:05:11 --> Total execution time: 0.0094
ERROR - 2019-10-09 19:05:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:05:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 19:05:11 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-09 19:08:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:08:25 --> Total execution time: 0.0034
ERROR - 2019-10-09 19:08:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:08:25 --> Total execution time: 0.0032
ERROR - 2019-10-09 19:08:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:08:25 --> Total execution time: 0.0048
ERROR - 2019-10-09 19:08:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-09 19:08:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 19:08:25 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 19:08:25 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 19:08:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:08:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 19:08:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-09 19:08:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:08:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 19:08:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-09 19:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-09 19:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-09 19:08:27 --> Total execution time: 0.0060
ERROR - 2019-10-09 19:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-09 19:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-09 19:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-09 19:08:28 --> 404 Page Not Found: Profile/logo.png
