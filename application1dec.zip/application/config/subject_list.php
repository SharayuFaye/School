<?php 
$subject_list =  array(   
    array( "name" => "Marathi" ),
    array(  "name" => "Hindi" ),
    array( "name" => "Sanskrit" ),
    array(  "name" => "Maths" ),
    array(  "name" => "Science" ),
    array(  "name" => "History" ),
    array(  "name" => "Geography" ),
    array(  "name" => "Biology" ),
    array(  "name" => "Chemistry" ),
    array(  "name" => "Physics" ),
    array(  "name" => "English" ),
    array(  "name" => "IT" ),
    array( "name" => "SocialScience" ) 
    
);

//    json_encode($subject_list); 
?>