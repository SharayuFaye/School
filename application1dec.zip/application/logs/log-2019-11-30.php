<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-30 17:33:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:33:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-30 17:33:54 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_students.php 158
ERROR - 2019-11-30 17:33:54 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_class.php 60
ERROR - 2019-11-30 17:33:54 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_bus.php 138
ERROR - 2019-11-30 17:33:54 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_sel_route.php 55
ERROR - 2019-11-30 17:33:54 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_route.php 49
ERROR - 2019-11-30 17:33:54 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_sections.php 137
ERROR - 2019-11-30 17:33:54 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_teachers.php 135
DEBUG - 2019-11-30 17:33:54 --> Total execution time: 0.6651
ERROR - 2019-11-30 17:33:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:33:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:33:56 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-30 17:33:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:33:58 --> Total execution time: 0.0027
ERROR - 2019-11-30 17:34:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:02 --> No URI present. Default controller set.
DEBUG - 2019-11-30 17:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:02 --> admin :: admin
DEBUG - 2019-11-30 17:34:02 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-30 17:34:03 --> Total execution time: 0.4032
ERROR - 2019-11-30 17:34:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:07 --> Total execution time: 0.0061
ERROR - 2019-11-30 17:34:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-30 17:34:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:11 --> Total execution time: 0.2923
ERROR - 2019-11-30 17:34:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:20 --> Total execution time: 0.1326
ERROR - 2019-11-30 17:34:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:23 --> Total execution time: 0.0655
ERROR - 2019-11-30 17:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:29 --> Total execution time: 0.1322
ERROR - 2019-11-30 17:34:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:31 --> Total execution time: 0.0235
ERROR - 2019-11-30 17:34:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:34:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-30 17:34:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:34:32 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-30 17:34:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:34:32 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-30 17:34:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:34:32 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-30 17:34:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:33 --> Total execution time: 0.0660
ERROR - 2019-11-30 17:34:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:34:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:34:37 --> Total execution time: 0.1438
ERROR - 2019-11-30 17:35:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:35:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:35:43 --> Total execution time: 0.1175
ERROR - 2019-11-30 17:35:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:35:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:35:47 --> Total execution time: 0.1938
ERROR - 2019-11-30 17:36:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:36:16 --> Total execution time: 0.0618
ERROR - 2019-11-30 17:36:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:36:19 --> Total execution time: 0.0726
ERROR - 2019-11-30 17:36:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:36:26 --> Total execution time: 0.1918
ERROR - 2019-11-30 17:36:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:36:30 --> Total execution time: 0.0035
ERROR - 2019-11-30 17:36:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-11-30 17:36:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:30 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-11-30 17:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-30 17:36:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:30 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-30 17:36:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-30 17:36:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-30 17:36:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-30 17:36:35 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_school`.`backgrounds`, CONSTRAINT `backgrounds_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school` (`id`)) - Invalid query: UPDATE `backgrounds` SET `wallpaper` = 'index3.jpeg', `date` = '2019-09-24', `school_id` = NULL, `updated_date` = '2019-11-30', `updated_by` = '1'
WHERE `id` = '3'
DEBUG - 2019-11-30 17:36:35 --> Total execution time: 0.2926
ERROR - 2019-11-30 17:36:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:35 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-30 17:36:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:35 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-30 17:36:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:35 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-30 17:36:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-30 17:36:38 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_school`.`backgrounds`, CONSTRAINT `backgrounds_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school` (`id`)) - Invalid query: UPDATE `backgrounds` SET `wallpaper` = 'school.jpg', `date` = '2019-10-07', `school_id` = NULL, `updated_date` = '2019-11-30', `updated_by` = '1'
WHERE `id` = '4'
DEBUG - 2019-11-30 17:36:38 --> Total execution time: 0.1653
ERROR - 2019-11-30 17:36:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-30 17:36:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-30 17:36:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:38 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-30 17:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:39 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-30 17:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-30 17:36:39 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-30 17:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:36:42 --> Total execution time: 0.0031
ERROR - 2019-11-30 17:36:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-30 17:36:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-30 17:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-30 17:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-30 17:36:45 --> Total execution time: 0.1033
