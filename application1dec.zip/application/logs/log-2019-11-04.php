<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-04 10:30:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-04 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-04 10:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-04 10:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-04 10:30:35 --> Total execution time: 10.4408
