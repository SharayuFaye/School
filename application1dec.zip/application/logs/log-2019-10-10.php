<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-10 10:36:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:36:58 --> Total execution time: 2.8751
ERROR - 2019-10-10 10:37:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:37:09 --> No URI present. Default controller set.
DEBUG - 2019-10-10 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:37:11 --> Total execution time: 2.2574
ERROR - 2019-10-10 10:37:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:37:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:37:55 --> Total execution time: 0.0243
ERROR - 2019-10-10 10:37:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:37:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:37:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 10:37:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 10:37:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 10:37:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 10:37:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 10:37:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 10:37:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 10:37:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 10:41:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:41:41 --> Total execution time: 0.0978
ERROR - 2019-10-10 10:41:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 10:41:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 10:41:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:41:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:41:43 --> Total execution time: 0.0054
ERROR - 2019-10-10 10:41:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:41:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:41:43 --> Total execution time: 0.0041
ERROR - 2019-10-10 10:42:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:42:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:42:40 --> Total execution time: 0.0106
ERROR - 2019-10-10 10:42:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:42:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 10:42:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 10:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:55:40 --> Total execution time: 0.0116
ERROR - 2019-10-10 10:55:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 10:55:40 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 10:59:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 10:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 10:59:32 --> Total execution time: 0.0109
ERROR - 2019-10-10 10:59:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 10:59:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 10:59:32 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:00:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:00:00 --> Total execution time: 0.0100
ERROR - 2019-10-10 11:00:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:00:01 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:00:04 --> Total execution time: 0.0035
ERROR - 2019-10-10 11:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:00:04 --> Total execution time: 0.0027
ERROR - 2019-10-10 11:01:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:01:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:01:50 --> Total execution time: 0.0098
ERROR - 2019-10-10 11:01:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:01:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:01:50 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:04:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:04:36 --> Total execution time: 0.0069
ERROR - 2019-10-10 11:04:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:04:36 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:06:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:06:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:06:43 --> Total execution time: 0.0099
ERROR - 2019-10-10 11:06:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:06:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:06:43 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:06:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:06:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:06:47 --> Total execution time: 0.0035
ERROR - 2019-10-10 11:06:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:06:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:06:47 --> Total execution time: 0.0024
ERROR - 2019-10-10 11:07:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:07:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:07:47 --> Total execution time: 0.0086
ERROR - 2019-10-10 11:07:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:07:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:07:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:07:47 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:08:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:08:03 --> Total execution time: 0.0088
ERROR - 2019-10-10 11:08:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:08:03 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:08:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:08:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:08:12 --> Total execution time: 0.0091
ERROR - 2019-10-10 11:08:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:08:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:08:12 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:08:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:08:18 --> Total execution time: 0.0050
ERROR - 2019-10-10 11:08:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:08:18 --> Total execution time: 0.0033
ERROR - 2019-10-10 11:15:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:15:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:15:38 --> Total execution time: 0.0105
ERROR - 2019-10-10 11:15:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:15:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:15:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:15:38 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:17:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:17:40 --> Total execution time: 0.0095
ERROR - 2019-10-10 11:17:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:17:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:17:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:19:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:19:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:19:48 --> Total execution time: 0.0030
ERROR - 2019-10-10 11:19:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:19:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:19:48 --> Total execution time: 0.0035
ERROR - 2019-10-10 11:19:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:19:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:19:48 --> Total execution time: 0.0061
ERROR - 2019-10-10 11:19:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:19:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:19:48 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:20:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:20:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:20:23 --> Total execution time: 0.0111
ERROR - 2019-10-10 11:20:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:20:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:20:23 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:23:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:23:56 --> Total execution time: 0.0133
ERROR - 2019-10-10 11:23:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:23:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:23:56 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:24:06 --> Total execution time: 0.0086
ERROR - 2019-10-10 11:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:24:06 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:24:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:24:07 --> Total execution time: 0.0086
ERROR - 2019-10-10 11:24:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:24:07 --> Total execution time: 0.0074
ERROR - 2019-10-10 11:24:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:24:07 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:24:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:24:11 --> Total execution time: 0.0033
ERROR - 2019-10-10 11:24:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:24:11 --> Total execution time: 0.0030
ERROR - 2019-10-10 11:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:45:17 --> Total execution time: 0.0086
ERROR - 2019-10-10 11:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:45:17 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:48:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:48:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:48:01 --> Total execution time: 0.0084
ERROR - 2019-10-10 11:48:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:48:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:48:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:48:01 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:49:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:49:16 --> Total execution time: 0.0050
ERROR - 2019-10-10 11:49:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:49:16 --> Total execution time: 0.0024
ERROR - 2019-10-10 11:49:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:49:16 --> Total execution time: 0.0058
ERROR - 2019-10-10 11:49:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:49:16 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:49:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:49:16 --> Total execution time: 0.0084
ERROR - 2019-10-10 11:49:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:49:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:49:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:49:17 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 11:49:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:49:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 11:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 11:49:17 --> Total execution time: 0.0077
ERROR - 2019-10-10 11:49:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 11:49:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 11:49:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 11:49:17 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 12:34:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:34:47 --> Total execution time: 0.0066
ERROR - 2019-10-10 12:34:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:34:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:34:47 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 12:35:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:35:33 --> Total execution time: 0.0049
ERROR - 2019-10-10 12:35:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:35:33 --> Total execution time: 0.0031
ERROR - 2019-10-10 12:35:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:35:33 --> Total execution time: 0.0075
ERROR - 2019-10-10 12:35:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:35:33 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 12:35:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:35:33 --> Total execution time: 0.0083
ERROR - 2019-10-10 12:35:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:35:33 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 12:35:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:35:34 --> Total execution time: 0.0108
ERROR - 2019-10-10 12:35:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:35:34 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 12:35:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:35:58 --> Total execution time: 0.0034
ERROR - 2019-10-10 12:35:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:35:58 --> Total execution time: 0.0032
ERROR - 2019-10-10 12:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:35:59 --> Total execution time: 0.0111
ERROR - 2019-10-10 12:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:35:59 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 12:36:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:36:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:36:00 --> Total execution time: 0.0024
ERROR - 2019-10-10 12:36:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:36:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:36:00 --> Total execution time: 0.0036
ERROR - 2019-10-10 12:36:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:36:15 --> Total execution time: 0.0037
ERROR - 2019-10-10 12:36:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:36:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:36:17 --> Total execution time: 0.0043
ERROR - 2019-10-10 12:36:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:36:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:36:20 --> Total execution time: 0.0029
ERROR - 2019-10-10 12:36:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:36:22 --> Total execution time: 0.0033
ERROR - 2019-10-10 12:53:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 12:53:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:53:36 --> Total execution time: 0.0496
DEBUG - 2019-10-10 12:53:36 --> Total execution time: 0.0090
ERROR - 2019-10-10 12:53:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 12:53:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:36 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-10 12:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 12:53:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:37 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 12:53:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:37 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 12:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:53:43 --> Total execution time: 0.1554
ERROR - 2019-10-10 12:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:43 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 12:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:43 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 12:53:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:44 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 12:53:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:44 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 12:53:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:53:52 --> Total execution time: 0.1080
ERROR - 2019-10-10 12:53:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 12:53:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 12:53:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 12:53:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 12:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 12:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 12:53:57 --> Total execution time: 0.1224
ERROR - 2019-10-10 12:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:57 --> UTF-8 Support Enabled
ERROR - 2019-10-10 12:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:57 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-10 12:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:57 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 12:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:57 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 12:53:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 12:53:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 12:53:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 12:53:58 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:02:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:02:38 --> Total execution time: 0.0062
ERROR - 2019-10-10 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:02:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:02:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:02:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:02:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:02:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:02:43 --> Total execution time: 0.0019
ERROR - 2019-10-10 13:02:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:49 --> No URI present. Default controller set.
DEBUG - 2019-10-10 13:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:02:49 --> Total execution time: 0.0107
ERROR - 2019-10-10 13:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:02:55 --> Total execution time: 0.0081
ERROR - 2019-10-10 13:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:02:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 13:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:02:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 13:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:02:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 13:02:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:02:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 13:03:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:03:02 --> Total execution time: 0.0064
ERROR - 2019-10-10 13:03:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 13:03:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:03:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:03:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:03:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:03:02 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:03:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:03:02 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:04:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:04:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 13:04:26 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Marathi', '2019-10-10', '148')
ERROR - 2019-10-10 13:04:26 --> Query error: Duplicate entry 'Hindi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Hindi', '2019-10-10', '148')
ERROR - 2019-10-10 13:04:26 --> Query error: Duplicate entry 'Maths' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Maths', '2019-10-10', '148')
ERROR - 2019-10-10 13:04:26 --> Query error: Duplicate entry 'Science' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Science', '2019-10-10', '148')
DEBUG - 2019-10-10 13:04:26 --> Total execution time: 0.2876
ERROR - 2019-10-10 13:04:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:04:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:04:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:04:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:04:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:04:26 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:04:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:04:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:04:26 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:04:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:04:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:04:26 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:08:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:08:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:08:51 --> Total execution time: 0.0055
ERROR - 2019-10-10 13:08:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 13:08:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:08:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:08:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:08:51 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-10 13:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:08:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:08:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:08:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:08:51 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:08:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:08:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:08:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:08:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:09:37 --> Total execution time: 0.0095
ERROR - 2019-10-10 13:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:09:37 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:09:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:09:37 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:09:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:09:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:09:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:09:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:09:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:09:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:09:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:10:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:10:04 --> Total execution time: 0.0084
ERROR - 2019-10-10 13:10:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:10:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:10:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:10:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:10:15 --> Total execution time: 0.0080
ERROR - 2019-10-10 13:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:15 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:15 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:10:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 13:10:27 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Marathi', '2019-10-10', '148')
ERROR - 2019-10-10 13:10:27 --> Query error: Duplicate entry 'Maths' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Maths', '2019-10-10', '148')
DEBUG - 2019-10-10 13:10:27 --> Total execution time: 0.2144
ERROR - 2019-10-10 13:10:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:10:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:10:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:10:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:10:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 13:10:38 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Marathi', '2019-10-10', '148')
ERROR - 2019-10-10 13:10:38 --> Query error: Duplicate entry 'Maths' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Maths', '2019-10-10', '148')
DEBUG - 2019-10-10 13:10:38 --> Total execution time: 0.2245
ERROR - 2019-10-10 13:10:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:10:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:10:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 13:10:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:10:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:10:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 13:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:12:44 --> Total execution time: 0.0104
ERROR - 2019-10-10 13:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:12:44 --> UTF-8 Support Enabled
ERROR - 2019-10-10 13:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:12:44 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-10 13:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:12:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 13:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:12:44 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 13:12:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:12:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:12:44 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 13:59:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 13:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 13:59:16 --> Total execution time: 0.0111
ERROR - 2019-10-10 13:59:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:59:16 --> UTF-8 Support Enabled
ERROR - 2019-10-10 13:59:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:59:16 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-10 13:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:59:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 13:59:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:59:16 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 13:59:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 13:59:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 13:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 13:59:16 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:00:04 --> Total execution time: 0.0107
ERROR - 2019-10-10 14:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 14:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:00:04 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-10 14:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:00:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:00:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:00:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:00:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:02:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:02:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:02:40 --> Total execution time: 0.0107
ERROR - 2019-10-10 14:02:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 14:02:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:02:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:02:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:02:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:02:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:02:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:02:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:02:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:02:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:02:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:02:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:03:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:03:01 --> Total execution time: 0.0069
ERROR - 2019-10-10 14:03:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 14:03:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:03:01 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-10 14:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:03:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:03:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:03:01 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:03:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:03:01 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:03:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:03:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:03:38 --> Total execution time: 0.0057
ERROR - 2019-10-10 14:05:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:05:32 --> Total execution time: 0.0068
ERROR - 2019-10-10 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:07:00 --> Total execution time: 0.0085
ERROR - 2019-10-10 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:00 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-10 14:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:07:04 --> Total execution time: 0.0408
ERROR - 2019-10-10 14:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:04 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:04 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:07:08 --> Total execution time: 0.0234
ERROR - 2019-10-10 14:07:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:07:09 --> Total execution time: 0.0544
ERROR - 2019-10-10 14:07:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:09 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:09 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:07:12 --> Total execution time: 0.0045
ERROR - 2019-10-10 14:07:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:07:14 --> Total execution time: 0.0025
ERROR - 2019-10-10 14:07:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:07:18 --> Total execution time: 0.0110
ERROR - 2019-10-10 14:07:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:07:43 --> Total execution time: 0.0626
ERROR - 2019-10-10 14:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:07:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:08:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:08:18 --> Total execution time: 0.0050
ERROR - 2019-10-10 14:08:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:08:31 --> Total execution time: 0.0102
ERROR - 2019-10-10 14:08:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:08:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:08:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:08:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:08:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:08:31 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:08:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:08:31 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:08:36 --> Total execution time: 0.0057
ERROR - 2019-10-10 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:08:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:08:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:08:36 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:08:36 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:09:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:09:30 --> Total execution time: 0.0063
ERROR - 2019-10-10 14:09:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 14:09:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:09:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:09:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:09:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:09:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:09:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:09:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:10:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:10:46 --> Total execution time: 0.0084
ERROR - 2019-10-10 14:11:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:11:09 --> Total execution time: 0.0083
ERROR - 2019-10-10 14:11:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:11:24 --> Total execution time: 0.0175
ERROR - 2019-10-10 14:11:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 14:11:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:11:24 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-10 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:11:24 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:11:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:11:24 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:11:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:11:24 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:12:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:12:18 --> Total execution time: 0.0040
ERROR - 2019-10-10 14:13:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:13:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:13:01 --> Total execution time: 0.0021
ERROR - 2019-10-10 14:13:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:13:45 --> Total execution time: 0.0055
ERROR - 2019-10-10 14:13:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:13:45 --> Total execution time: 0.0037
ERROR - 2019-10-10 14:13:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:13:45 --> Total execution time: 0.0045
ERROR - 2019-10-10 14:13:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:13:46 --> Total execution time: 0.0035
ERROR - 2019-10-10 14:14:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:14:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:14:04 --> Total execution time: 0.0027
ERROR - 2019-10-10 14:14:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:14:41 --> Total execution time: 0.0039
ERROR - 2019-10-10 14:15:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:15:11 --> Total execution time: 0.0077
ERROR - 2019-10-10 14:15:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:15:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:15:26 --> Total execution time: 0.0037
ERROR - 2019-10-10 14:15:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:15:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:15:29 --> Total execution time: 0.0036
ERROR - 2019-10-10 14:15:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:15:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:15:46 --> Total execution time: 0.0051
ERROR - 2019-10-10 14:15:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:15:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:15:52 --> Total execution time: 0.0045
ERROR - 2019-10-10 14:16:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:16:20 --> Total execution time: 0.0029
ERROR - 2019-10-10 14:16:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:16:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:16:31 --> Total execution time: 0.0071
ERROR - 2019-10-10 14:16:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:16:34 --> Total execution time: 0.0041
ERROR - 2019-10-10 14:16:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:16:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:16:36 --> Total execution time: 0.0042
ERROR - 2019-10-10 14:17:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:17:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:17:16 --> Total execution time: 0.0067
ERROR - 2019-10-10 14:17:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:17:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:17:35 --> Total execution time: 0.0056
ERROR - 2019-10-10 14:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:17:46 --> Total execution time: 0.0283
ERROR - 2019-10-10 14:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:17:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:17:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:17:46 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:17:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:17:46 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:18:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:18:54 --> Total execution time: 0.0050
ERROR - 2019-10-10 14:19:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:19:10 --> Total execution time: 0.0252
ERROR - 2019-10-10 14:19:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 14:19:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:19:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:19:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:19:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:19:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:19:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:19:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:19:11 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:20:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:20:00 --> Total execution time: 0.0054
ERROR - 2019-10-10 14:20:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:20:12 --> Total execution time: 0.0128
ERROR - 2019-10-10 14:20:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:20:12 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 14:20:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:20:14 --> Total execution time: 0.0028
ERROR - 2019-10-10 14:20:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:20:14 --> Total execution time: 0.0047
ERROR - 2019-10-10 14:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:20:17 --> Total execution time: 0.0028
ERROR - 2019-10-10 14:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:17 --> UTF-8 Support Enabled
ERROR - 2019-10-10 14:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:20:17 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-10 14:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:20:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:20:17 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:20:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:20:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:20:17 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:21:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:21:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:21:02 --> Total execution time: 0.0038
ERROR - 2019-10-10 14:21:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:21:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:21:18 --> Total execution time: 0.0058
ERROR - 2019-10-10 14:21:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:21:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:21:41 --> Total execution time: 0.0038
ERROR - 2019-10-10 14:21:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:21:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:21:47 --> Total execution time: 0.0369
ERROR - 2019-10-10 14:21:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:21:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:21:47 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:21:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:21:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:21:47 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:21:48 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:21:48 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:23:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:23:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:23:47 --> Total execution time: 0.0122
ERROR - 2019-10-10 14:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:24:06 --> Total execution time: 0.0105
ERROR - 2019-10-10 14:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:24:06 --> UTF-8 Support Enabled
ERROR - 2019-10-10 14:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:24:06 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-10 14:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:24:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:24:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:24:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:29:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:29:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:29:28 --> Total execution time: 0.0098
ERROR - 2019-10-10 14:29:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:29:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:29:56 --> Total execution time: 0.0094
ERROR - 2019-10-10 14:30:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:30:03 --> Total execution time: 0.0073
ERROR - 2019-10-10 14:30:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 14:30:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:30:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:30:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:30:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:30:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 14:30:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 14:30:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 14:30:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:30:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:30:36 --> Total execution time: 0.0056
ERROR - 2019-10-10 14:31:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:31:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:31:04 --> Total execution time: 0.0096
ERROR - 2019-10-10 14:47:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:47:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:47:58 --> Total execution time: 0.0091
ERROR - 2019-10-10 14:48:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:48:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:48:04 --> Total execution time: 0.0049
ERROR - 2019-10-10 14:48:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 14:48:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 14:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 14:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 14:48:06 --> Total execution time: 0.0049
ERROR - 2019-10-10 16:01:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:01:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:01:17 --> Total execution time: 0.0141
ERROR - 2019-10-10 16:01:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:01:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 16:01:17 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-10 16:01:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:01:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:01:37 --> Total execution time: 0.2199
ERROR - 2019-10-10 16:01:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:01:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 16:01:37 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-10 16:02:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:02:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:02:58 --> Total execution time: 0.1099
ERROR - 2019-10-10 16:02:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:02:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:02:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 16:02:58 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-10-10 16:06:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:06:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:06:58 --> Severity: Notice --> Undefined variable: class_show /var/www/html/School19/application/views/marks.php 376
ERROR - 2019-10-10 16:06:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/marks.php 376
DEBUG - 2019-10-10 16:06:58 --> Total execution time: 0.0512
ERROR - 2019-10-10 16:08:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:08:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:08:12 --> Severity: Notice --> Undefined property: Welcome::$m_class /var/www/html/School19/application/controllers/Welcome.php 1827
ERROR - 2019-10-10 16:08:12 --> Severity: error --> Exception: Call to a member function class_show_id() on null /var/www/html/School19/application/controllers/Welcome.php 1827
ERROR - 2019-10-10 16:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:08:27 --> Severity: Notice --> Undefined property: Welcome::$m_class /var/www/html/School19/application/controllers/Welcome.php 1829
ERROR - 2019-10-10 16:08:27 --> Severity: error --> Exception: Call to a member function class_show_id() on null /var/www/html/School19/application/controllers/Welcome.php 1829
ERROR - 2019-10-10 16:08:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:08:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:08:47 --> Total execution time: 0.0186
ERROR - 2019-10-10 16:21:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:21:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:21:15 --> Total execution time: 0.0086
ERROR - 2019-10-10 16:28:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:28:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:28:12 --> Total execution time: 0.0103
ERROR - 2019-10-10 16:30:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:30:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:30:13 --> Total execution time: 0.0080
ERROR - 2019-10-10 16:30:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:30:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:30:22 --> Total execution time: 0.0102
ERROR - 2019-10-10 16:30:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:30:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:30:48 --> Total execution time: 0.0065
ERROR - 2019-10-10 16:30:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:30:52 --> Total execution time: 0.0046
ERROR - 2019-10-10 16:30:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:30:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:30:53 --> Total execution time: 0.0050
ERROR - 2019-10-10 16:33:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:33:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:33:36 --> Total execution time: 0.0180
ERROR - 2019-10-10 16:33:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:33:40 --> Total execution time: 0.0024
ERROR - 2019-10-10 16:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 16:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:33:41 --> Total execution time: 0.0043
DEBUG - 2019-10-10 16:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:33:41 --> Total execution time: 0.0037
ERROR - 2019-10-10 16:34:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:34:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:34:54 --> Total execution time: 0.0054
ERROR - 2019-10-10 16:34:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:34:57 --> Total execution time: 0.0044
ERROR - 2019-10-10 16:35:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:35:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:35:08 --> Total execution time: 0.0057
ERROR - 2019-10-10 16:49:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:49:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:49:02 --> Total execution time: 0.0174
ERROR - 2019-10-10 16:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:49:07 --> Total execution time: 0.0032
ERROR - 2019-10-10 16:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 16:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:49:08 --> Total execution time: 0.0033
DEBUG - 2019-10-10 16:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:49:08 --> Total execution time: 0.0029
ERROR - 2019-10-10 16:49:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:49:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:49:24 --> Total execution time: 0.0041
ERROR - 2019-10-10 16:49:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:49:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:49:32 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '8', '', '4', 'A', '', 'Maths', '', 'NaN', '11', '2019-10-10', '148', '1', '52', '55', 'Grade', 'Present')
DEBUG - 2019-10-10 16:49:32 --> Total execution time: 0.0107
ERROR - 2019-10-10 16:51:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:51:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:51:41 --> Total execution time: 0.0094
ERROR - 2019-10-10 16:51:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:51:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:51:44 --> Total execution time: 0.0032
ERROR - 2019-10-10 16:51:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:51:45 --> UTF-8 Support Enabled
ERROR - 2019-10-10 16:51:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:51:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:51:45 --> Total execution time: 0.0019
DEBUG - 2019-10-10 16:51:45 --> Total execution time: 0.0037
ERROR - 2019-10-10 16:51:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:51:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 16:51:55 --> Total execution time: 0.0033
ERROR - 2019-10-10 16:51:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:51:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:51:58 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', '', 'NaN', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
DEBUG - 2019-10-10 16:51:58 --> Total execution time: 0.0094
ERROR - 2019-10-10 16:53:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:53:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 16:53:04 --> Severity: error --> Exception: syntax error, unexpected '==' (T_IS_EQUAL) /var/www/html/School19/application/controllers/Welcome.php 1778
ERROR - 2019-10-10 16:53:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:53:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:53:22 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', 'A', 'NaN', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
DEBUG - 2019-10-10 16:53:22 --> Total execution time: 0.0163
ERROR - 2019-10-10 16:53:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:53:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:54:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:54:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:54:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:54:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:54:41 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', '', 'A', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
DEBUG - 2019-10-10 16:54:41 --> Total execution time: 0.0082
ERROR - 2019-10-10 16:54:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:55:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:55:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:55:54 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', '', 'A', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
ERROR - 2019-10-10 16:56:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 16:56:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 16:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 16:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 16:56:16 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', '', 'A', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
ERROR - 2019-10-10 17:01:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:01:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:01:31 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', '', 'A', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
ERROR - 2019-10-10 17:02:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:02:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:02:05 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', '', 'A', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
ERROR - 2019-10-10 17:02:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:02:53 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', '', 'A', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
ERROR - 2019-10-10 17:04:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:04:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:04:26 --> Query error: Column 'students_id' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES (NULL, '9', '', '4', 'A', '', 'Hindi', '', 'A', '11', '2019-10-10', '148', '1', '42', '52', 'Grade', 'Present')
ERROR - 2019-10-10 17:06:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:06:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:06:45 --> Query error: Unknown column 'students_id' in 'where clause' - Invalid query: SELECT *
FROM `marks`
WHERE `students_id` = 'Amit Kumar'
AND `subject` = 'Hindi'
AND `marks` = 'A'
AND `out_of` = ''
AND `date` = ''
ERROR - 2019-10-10 17:06:45 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /var/www/html/School19/application/models/M_marks.php 12
ERROR - 2019-10-10 17:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:07:04 --> Query error: Unknown column 'students_id' in 'where clause' - Invalid query: SELECT *
FROM `marks`
WHERE `students_id` = 'Amit Kumar'
AND `subject` = 'Hindi'
AND `marks` = 'A'
AND `out_of` = ''
AND `date` = ''
ERROR - 2019-10-10 17:07:04 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /var/www/html/School19/application/models/M_marks.php 12
ERROR - 2019-10-10 17:07:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:07:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:07:12 --> Query error: Unknown column 'f.students_id' in 'on clause' - Invalid query: SELECT `s`.`student_name`, `s`.`roll_number`, `f`.*, `t`.`teacher_name`, `ex`.`type`
FROM `marks` `f`
LEFT JOIN `students` `s` ON `f`.`students_id`=`s`.`id`
LEFT JOIN `teachers` `t` ON `f`.`teacher_id`=`t`.`id`
LEFT JOIN `exam_type` `ex` ON `f`.`exam_type_id`=`ex`.`id`
WHERE `f`.`school_id` = '11'
AND `s`.`active` = 1
ERROR - 2019-10-10 17:07:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/marks.php 69
DEBUG - 2019-10-10 17:07:12 --> Total execution time: 0.0078
ERROR - 2019-10-10 17:08:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:08:23 --> Query error: Unknown column 'f.students_id' in 'on clause' - Invalid query: SELECT `s`.`student_name`, `s`.`roll_number`, `f`.*, `t`.`teacher_name`, `ex`.`type`
FROM `marks` `f`
LEFT JOIN `students` `s` ON `f`.`students_id`=`s`.`id`
LEFT JOIN `teachers` `t` ON `f`.`teacher_id`=`t`.`id`
LEFT JOIN `exam_type` `ex` ON `f`.`exam_type_id`=`ex`.`id`
WHERE `f`.`school_id` = '11'
AND `s`.`active` = 1
ERROR - 2019-10-10 17:08:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/marks.php 69
DEBUG - 2019-10-10 17:08:23 --> Total execution time: 0.0136
ERROR - 2019-10-10 17:08:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:08:27 --> Total execution time: 0.0029
ERROR - 2019-10-10 17:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 17:08:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:08:28 --> Total execution time: 0.0038
DEBUG - 2019-10-10 17:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:08:28 --> Total execution time: 0.0035
ERROR - 2019-10-10 17:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:08:36 --> Total execution time: 0.0030
ERROR - 2019-10-10 17:08:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:08:42 --> Query error: Unknown column 'students_id' in 'where clause' - Invalid query: SELECT *
FROM `marks`
WHERE `students_id` = '52'
AND `subject` = 'Hindi'
AND `marks` = 'A'
AND `out_of` = ''
AND `date` = ''
ERROR - 2019-10-10 17:08:42 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /var/www/html/School19/application/models/M_marks.php 12
ERROR - 2019-10-10 17:08:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:08:48 --> Query error: Unknown column 'f.students_id' in 'on clause' - Invalid query: SELECT `s`.`student_name`, `s`.`roll_number`, `f`.*, `t`.`teacher_name`, `ex`.`type`
FROM `marks` `f`
LEFT JOIN `students` `s` ON `f`.`students_id`=`s`.`id`
LEFT JOIN `teachers` `t` ON `f`.`teacher_id`=`t`.`id`
LEFT JOIN `exam_type` `ex` ON `f`.`exam_type_id`=`ex`.`id`
WHERE `f`.`school_id` = '11'
AND `s`.`active` = 1
ERROR - 2019-10-10 17:08:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/marks.php 69
DEBUG - 2019-10-10 17:08:48 --> Total execution time: 0.0102
ERROR - 2019-10-10 17:08:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:08:53 --> Total execution time: 0.0025
ERROR - 2019-10-10 17:08:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 17:08:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:08:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:08:54 --> Total execution time: 0.0050
DEBUG - 2019-10-10 17:08:54 --> Total execution time: 0.0057
ERROR - 2019-10-10 17:09:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:09:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:09:05 --> Total execution time: 0.0046
ERROR - 2019-10-10 17:09:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:09:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:09:16 --> Query error: Unknown column 'students_id' in 'where clause' - Invalid query: SELECT *
FROM `marks`
WHERE `students_id` = '53'
AND `subject` = 'Hindi'
AND `marks` = '89'
AND `out_of` = '120'
AND `date` = ''
ERROR - 2019-10-10 17:09:16 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /var/www/html/School19/application/models/M_marks.php 12
ERROR - 2019-10-10 17:10:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:10:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:10:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:10:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:10:25 --> Total execution time: 0.2557
ERROR - 2019-10-10 17:10:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:10:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:10:40 --> Total execution time: 0.0112
ERROR - 2019-10-10 17:11:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:11:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:11:33 --> Total execution time: 0.0100
ERROR - 2019-10-10 17:11:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:11:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:11:36 --> Total execution time: 0.0601
ERROR - 2019-10-10 17:11:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:11:45 --> Total execution time: 0.0033
ERROR - 2019-10-10 17:11:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:11:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:11:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 17:11:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:11:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:11:46 --> Total execution time: 0.0053
DEBUG - 2019-10-10 17:11:46 --> Total execution time: 0.0047
ERROR - 2019-10-10 17:11:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:11:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:11:53 --> Total execution time: 0.0031
ERROR - 2019-10-10 17:11:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:11:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:11:57 --> Total execution time: 0.1143
ERROR - 2019-10-10 17:12:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:12:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:12:15 --> Total execution time: 0.0099
ERROR - 2019-10-10 17:17:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:17:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:17:35 --> Severity: Notice --> Undefined property: stdClass::$Sections /var/www/html/School19/application/views/marks.php 76
ERROR - 2019-10-10 17:17:35 --> Severity: Notice --> Undefined property: stdClass::$sections /var/www/html/School19/application/views/marks.php 92
ERROR - 2019-10-10 17:17:35 --> Severity: Notice --> Undefined property: stdClass::$Sections /var/www/html/School19/application/views/marks.php 76
ERROR - 2019-10-10 17:17:35 --> Severity: Notice --> Undefined property: stdClass::$sections /var/www/html/School19/application/views/marks.php 92
DEBUG - 2019-10-10 17:17:35 --> Total execution time: 0.0108
ERROR - 2019-10-10 17:17:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:17:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:17:43 --> Severity: Notice --> Undefined property: stdClass::$sections /var/www/html/School19/application/views/marks.php 76
ERROR - 2019-10-10 17:17:43 --> Severity: Notice --> Undefined property: stdClass::$sections /var/www/html/School19/application/views/marks.php 92
ERROR - 2019-10-10 17:17:43 --> Severity: Notice --> Undefined property: stdClass::$sections /var/www/html/School19/application/views/marks.php 76
ERROR - 2019-10-10 17:17:43 --> Severity: Notice --> Undefined property: stdClass::$sections /var/www/html/School19/application/views/marks.php 92
DEBUG - 2019-10-10 17:17:43 --> Total execution time: 0.0082
ERROR - 2019-10-10 17:18:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:18:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:18:52 --> Total execution time: 0.0072
ERROR - 2019-10-10 17:20:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:20:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:20:35 --> Total execution time: 0.0107
ERROR - 2019-10-10 17:21:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:21:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:21:24 --> Total execution time: 0.0074
ERROR - 2019-10-10 17:24:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:24:48 --> Total execution time: 0.0129
ERROR - 2019-10-10 17:25:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:25:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:25:04 --> Total execution time: 0.0081
ERROR - 2019-10-10 17:25:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:25:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:25:39 --> Total execution time: 0.0066
ERROR - 2019-10-10 17:26:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:26:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:26:22 --> Total execution time: 0.0088
ERROR - 2019-10-10 17:33:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:33:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:33:43 --> Total execution time: 0.0111
ERROR - 2019-10-10 17:34:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:34:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:34:02 --> Total execution time: 0.0093
ERROR - 2019-10-10 17:35:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:35:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:35:05 --> Total execution time: 0.0140
ERROR - 2019-10-10 17:35:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:35:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:35:06 --> Total execution time: 0.0140
ERROR - 2019-10-10 17:35:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:35:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:35:06 --> Total execution time: 0.0100
ERROR - 2019-10-10 17:35:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:35:32 --> Total execution time: 0.0098
ERROR - 2019-10-10 17:35:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:35:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:35:51 --> Total execution time: 0.0095
ERROR - 2019-10-10 17:36:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:36:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:36:05 --> Total execution time: 0.0105
ERROR - 2019-10-10 17:38:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:38:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:38:03 --> Total execution time: 0.0081
ERROR - 2019-10-10 17:39:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:39:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:39:43 --> Total execution time: 0.0086
ERROR - 2019-10-10 17:40:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:40:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:40:45 --> Total execution time: 0.0127
ERROR - 2019-10-10 17:41:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:41:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:41:29 --> Total execution time: 0.0070
ERROR - 2019-10-10 17:41:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:41:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:41:40 --> Total execution time: 0.1235
ERROR - 2019-10-10 17:42:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:42:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:42:20 --> Total execution time: 0.0667
ERROR - 2019-10-10 17:42:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:42:28 --> Total execution time: 0.0021
ERROR - 2019-10-10 17:42:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:42:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:42:30 --> Total execution time: 0.0044
ERROR - 2019-10-10 17:42:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:42:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:42:31 --> Total execution time: 0.0033
ERROR - 2019-10-10 17:42:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:42:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:42:48 --> Total execution time: 0.0609
ERROR - 2019-10-10 17:42:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:42:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:42:54 --> Total execution time: 0.0021
ERROR - 2019-10-10 17:42:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:42:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:42:55 --> Total execution time: 0.0024
ERROR - 2019-10-10 17:42:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:42:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:42:56 --> Total execution time: 0.0037
ERROR - 2019-10-10 17:44:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:44:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:44:21 --> Total execution time: 0.0577
ERROR - 2019-10-10 17:44:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:44:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:44:26 --> Total execution time: 0.0023
ERROR - 2019-10-10 17:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:44:27 --> Total execution time: 0.0042
ERROR - 2019-10-10 17:44:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:44:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:44:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 17:44:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:44:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:44:28 --> Total execution time: 0.0039
DEBUG - 2019-10-10 17:44:28 --> Total execution time: 0.0028
ERROR - 2019-10-10 17:47:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:47:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:47:17 --> Total execution time: 0.0884
ERROR - 2019-10-10 17:47:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:47:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:47:22 --> Total execution time: 0.0040
ERROR - 2019-10-10 17:47:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:47:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:47:23 --> Total execution time: 0.0061
ERROR - 2019-10-10 17:47:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:47:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 17:47:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:47:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:47:25 --> Total execution time: 0.0050
DEBUG - 2019-10-10 17:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:47:25 --> Total execution time: 0.0051
ERROR - 2019-10-10 17:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:47:28 --> Total execution time: 0.0036
ERROR - 2019-10-10 17:47:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:47:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:47:30 --> Total execution time: 0.0036
ERROR - 2019-10-10 17:47:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:47:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:47:32 --> Total execution time: 0.1408
ERROR - 2019-10-10 17:50:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:50:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:50:16 --> Total execution time: 0.0649
ERROR - 2019-10-10 17:50:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:50:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:50:19 --> Total execution time: 0.1031
ERROR - 2019-10-10 17:50:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:50:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:50:27 --> Total execution time: 0.1068
ERROR - 2019-10-10 17:51:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:51:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:51:40 --> Total execution time: 0.0761
ERROR - 2019-10-10 17:53:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:53:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:53:11 --> Total execution time: 0.0783
ERROR - 2019-10-10 17:53:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:53:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:53:58 --> Total execution time: 0.0627
ERROR - 2019-10-10 17:55:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:55:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:55:05 --> Total execution time: 0.0065
ERROR - 2019-10-10 17:55:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:55:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:55:08 --> Total execution time: 0.0045
ERROR - 2019-10-10 17:55:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:55:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 17:55:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:55:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:55:09 --> Total execution time: 0.0028
DEBUG - 2019-10-10 17:55:09 --> Total execution time: 0.0056
ERROR - 2019-10-10 17:55:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:55:18 --> Total execution time: 0.0051
ERROR - 2019-10-10 17:55:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:55:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:55:22 --> Total execution time: 0.1134
ERROR - 2019-10-10 17:55:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:55:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:55:59 --> Total execution time: 0.0111
ERROR - 2019-10-10 17:56:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:56:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:56:20 --> Total execution time: 0.1227
ERROR - 2019-10-10 17:56:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:56:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:56:34 --> Total execution time: 0.1296
ERROR - 2019-10-10 17:57:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:57:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:57:33 --> Total execution time: 0.0797
ERROR - 2019-10-10 17:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:57:42 --> Total execution time: 0.1007
ERROR - 2019-10-10 17:57:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:57:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:57:50 --> Total execution time: 0.1447
ERROR - 2019-10-10 17:58:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:58:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:58:40 --> Total execution time: 0.0672
ERROR - 2019-10-10 17:59:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:59:19 --> Total execution time: 0.1090
ERROR - 2019-10-10 17:59:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 17:59:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 17:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 17:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 17:59:39 --> Total execution time: 0.0638
ERROR - 2019-10-10 18:00:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:00:52 --> Total execution time: 0.0119
ERROR - 2019-10-10 18:01:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:01:00 --> Total execution time: 0.0038
ERROR - 2019-10-10 18:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:01:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:01:01 --> Total execution time: 0.0039
DEBUG - 2019-10-10 18:01:01 --> Total execution time: 0.0035
ERROR - 2019-10-10 18:07:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:07:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:07:06 --> Total execution time: 0.0162
ERROR - 2019-10-10 18:09:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:09:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:09:39 --> Total execution time: 0.0144
ERROR - 2019-10-10 18:09:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:09:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:09:43 --> Total execution time: 0.0023
ERROR - 2019-10-10 18:09:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:09:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:09:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:09:44 --> Total execution time: 0.0041
DEBUG - 2019-10-10 18:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:09:44 --> Total execution time: 0.0041
ERROR - 2019-10-10 18:09:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:09:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:09:53 --> Total execution time: 0.0028
ERROR - 2019-10-10 18:10:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:10:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:10:51 --> Total execution time: 0.0071
ERROR - 2019-10-10 18:10:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:10:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:10:52 --> Total execution time: 0.0120
ERROR - 2019-10-10 18:10:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:10:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:10:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:10:56 --> 404 Page Not Found: Marks_add/index
ERROR - 2019-10-10 18:11:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:11:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:11:21 --> Total execution time: 0.0100
ERROR - 2019-10-10 18:11:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:11:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 18:11:26 --> Query error: Column 'subject' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES ('', '', '', '', '', '', NULL, '', '', '11', '2019-10-10', '148', '', NULL, '', 'Grade', 'Present')
DEBUG - 2019-10-10 18:11:26 --> Total execution time: 0.0044
ERROR - 2019-10-10 18:12:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:12:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:12:11 --> Total execution time: 0.0104
ERROR - 2019-10-10 18:12:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:12:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 18:12:15 --> Query error: Column 'subject' cannot be null - Invalid query: INSERT INTO `marks` (`students_id`, `teacher_id`, `date`, `exam_type_id`, `marks`, `out_of`, `subject`, `competence`, `percentage`, `school_id`, `created_date`, `created_by`, `class_id`, `sections_id`, `roll_no`, `evaluation_type`, `pa`) VALUES ('', '', '', '', '', '', NULL, '', '', '11', '2019-10-10', '148', '', NULL, '', 'Grade', 'Present')
DEBUG - 2019-10-10 18:12:15 --> Total execution time: 0.0036
ERROR - 2019-10-10 18:12:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:12:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:12:19 --> Total execution time: 0.0029
ERROR - 2019-10-10 18:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-10 18:12:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:12:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:12:21 --> Total execution time: 0.0029
DEBUG - 2019-10-10 18:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:12:21 --> Total execution time: 0.0035
ERROR - 2019-10-10 18:12:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:12:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:12:29 --> Total execution time: 0.0028
ERROR - 2019-10-10 18:12:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:12:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:12:33 --> Total execution time: 0.0550
ERROR - 2019-10-10 18:13:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:13:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:13:08 --> Total execution time: 0.0093
ERROR - 2019-10-10 18:16:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:16:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:16:07 --> Total execution time: 0.0031
ERROR - 2019-10-10 18:16:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:16:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:16:14 --> No URI present. Default controller set.
DEBUG - 2019-10-10 18:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:16:14 --> Total execution time: 0.0118
ERROR - 2019-10-10 18:16:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:16:16 --> Total execution time: 0.0104
ERROR - 2019-10-10 18:17:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:17:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:17:52 --> Total execution time: 0.0088
ERROR - 2019-10-10 18:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:18:00 --> Total execution time: 0.0097
ERROR - 2019-10-10 18:22:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:22:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:22:53 --> Total execution time: 0.0199
ERROR - 2019-10-10 18:23:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:23:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:23:02 --> Total execution time: 0.0104
ERROR - 2019-10-10 18:23:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:23:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:23:20 --> Total execution time: 0.0069
ERROR - 2019-10-10 18:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:23:29 --> Total execution time: 0.0028
ERROR - 2019-10-10 18:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-10 18:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:23:29 --> Total execution time: 0.0033
DEBUG - 2019-10-10 18:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:23:29 --> Total execution time: 0.0027
ERROR - 2019-10-10 18:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:23:36 --> Total execution time: 0.0026
ERROR - 2019-10-10 18:23:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:23:41 --> Total execution time: 0.0518
ERROR - 2019-10-10 18:23:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:23:44 --> Total execution time: 0.0091
ERROR - 2019-10-10 18:24:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:24:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:24:54 --> Total execution time: 0.0107
ERROR - 2019-10-10 18:28:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:28:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:28:06 --> Total execution time: 0.0157
ERROR - 2019-10-10 18:37:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:37:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:37:58 --> Total execution time: 0.0565
ERROR - 2019-10-10 18:37:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:37:58 --> UTF-8 Support Enabled
ERROR - 2019-10-10 18:37:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:37:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:37:58 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-10 18:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:37:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 18:37:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:37:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:37:58 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-10 18:37:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:37:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:37:58 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-10 18:38:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-10 18:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-10 18:38:04 --> Total execution time: 0.1132
ERROR - 2019-10-10 18:38:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:38:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 18:38:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:38:04 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-10 18:38:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:38:04 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-10 18:38:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-10 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-10 18:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-10 18:38:04 --> 404 Page Not Found: Welcome/js
