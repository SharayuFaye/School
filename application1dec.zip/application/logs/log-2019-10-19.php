<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-19 10:33:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 10:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 10:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 10:33:44 --> Total execution time: 4.3517
ERROR - 2019-10-19 10:34:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 10:34:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 10:34:13 --> No URI present. Default controller set.
DEBUG - 2019-10-19 10:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 10:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 10:34:16 --> Total execution time: 2.8163
ERROR - 2019-10-19 10:35:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 10:35:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 10:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 10:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 10:35:06 --> Total execution time: 0.1148
ERROR - 2019-10-19 11:04:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 11:04:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 11:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 11:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 11:04:35 --> Total execution time: 6.3072
ERROR - 2019-10-19 13:31:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 13:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 13:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 13:31:26 --> Total execution time: 0.0486
ERROR - 2019-10-19 13:31:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 13:31:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 13:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 13:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 13:31:28 --> Total execution time: 0.0025
ERROR - 2019-10-19 13:35:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 13:35:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 13:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 13:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 13:35:45 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_teachers.php 103
ERROR - 2019-10-19 13:35:45 --> Severity: Notice --> Undefined index: school /var/www/html/School19/application/models/M_sections.php 99
DEBUG - 2019-10-19 13:35:45 --> Total execution time: 0.2074
ERROR - 2019-10-19 15:06:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 15:06:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 15:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 15:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 15:06:54 --> Total execution time: 0.0040
ERROR - 2019-10-19 15:06:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 15:06:57 --> No URI present. Default controller set.
DEBUG - 2019-10-19 15:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 15:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 15:06:57 --> Total execution time: 0.1890
ERROR - 2019-10-19 15:07:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 15:07:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 15:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 15:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 15:07:01 --> Total execution time: 0.0054
ERROR - 2019-10-19 15:57:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 15:57:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 15:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 15:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 15:57:04 --> Total execution time: 0.0102
ERROR - 2019-10-19 15:57:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 15:57:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 15:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 15:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 15:57:07 --> Total execution time: 0.0018
ERROR - 2019-10-19 15:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 15:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 15:57:10 --> No URI present. Default controller set.
DEBUG - 2019-10-19 15:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 15:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 15:57:10 --> Total execution time: 0.0088
ERROR - 2019-10-19 16:19:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:19:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:19:54 --> No URI present. Default controller set.
DEBUG - 2019-10-19 16:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 16:19:54 --> Total execution time: 0.0230
ERROR - 2019-10-19 16:19:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:19:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:19:59 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01'
AND `a`.`date` <= '2019-10-31'
ERROR - 2019-10-19 16:21:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:21:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:21:42 --> Severity: error --> Exception: Call to undefined method m_attendances::attendances_percent_today() /var/www/html/School19/application/controllers/Welcome.php 80
ERROR - 2019-10-19 16:21:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:21:51 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19'
ERROR - 2019-10-19 16:21:51 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01'
AND `a`.`date` <= '2019-10-31'
ERROR - 2019-10-19 16:22:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:22:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:22:01 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19'
ERROR - 2019-10-19 16:22:01 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01'
AND `a`.`date` <= '2019-10-31'
ERROR - 2019-10-19 16:22:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:22:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:22:12 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19'
ERROR - 2019-10-19 16:22:12 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01'
AND `a`.`date` <= '2019-10-31'
ERROR - 2019-10-19 16:22:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:22:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:22:52 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19  00:00:00'
ERROR - 2019-10-19 16:22:52 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:22:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:22:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:22:54 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19  00:00:00'
ERROR - 2019-10-19 16:22:54 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:22:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:22:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:22:54 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19  00:00:00'
ERROR - 2019-10-19 16:22:54 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:23:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:23:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:23:32 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:23:32 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:23:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:23:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:23:33 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:23:33 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:23:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:23:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:23:33 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:23:33 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:23:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:23:39 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:23:39 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:24:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:24:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:24:15 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:24:15 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:24:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:24:53 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:24:53 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:24:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:24:53 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:24:53 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:24:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:24:53 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:24:53 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:24:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:24:53 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:24:53 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:24:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:24:54 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:24:54 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:25:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:25:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:25:20 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:25:20 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 132
ERROR - 2019-10-19 16:25:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:25:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:25:49 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:25:49 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 132
ERROR - 2019-10-19 16:25:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:25:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:25:50 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:25:50 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 132
ERROR - 2019-10-19 16:25:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:25:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:25:50 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:25:50 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 132
ERROR - 2019-10-19 16:26:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:26:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:26:43 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date=` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:26:43 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 132
ERROR - 2019-10-19 16:27:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:27:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:27:34 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:27:34 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 134
ERROR - 2019-10-19 16:27:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:27:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:27:34 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:27:34 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 134
ERROR - 2019-10-19 16:27:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:27:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:27:34 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:27:34 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 134
ERROR - 2019-10-19 16:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:28:16 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:28:16 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 134
ERROR - 2019-10-19 16:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:28:16 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:28:16 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 134
ERROR - 2019-10-19 16:28:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:28:16 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` = '2019-10-19 00:00:00'
ERROR - 2019-10-19 16:28:16 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 134
ERROR - 2019-10-19 16:29:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:29:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:29:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:29:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:29:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:29:12 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
ERROR - 2019-10-19 16:29:12 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/School19/application/models/M_attendances.php 134
ERROR - 2019-10-19 16:29:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:29:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:29:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:29:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:29:48 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:29:54 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/models/M_attendances.php 129
ERROR - 2019-10-19 16:29:54 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:30:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:30:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:30:10 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:30:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:30:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:30:21 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:30:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:30:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:30:50 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:30:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:30:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:30:50 --> Query error: Unknown column 'a.attedance' in 'where clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
WHERE `a`.`school_id` = '3'
AND `a`.`attedance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
ERROR - 2019-10-19 16:31:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:31:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:31:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:31:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:31:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:31:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:34:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:34:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 16:34:15 --> Severity: Notice --> Undefined variable: attendances_count /var/www/html/School19/application/controllers/Welcome.php 86
DEBUG - 2019-10-19 16:34:15 --> Total execution time: 0.0181
ERROR - 2019-10-19 16:35:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:35:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 16:35:11 --> Total execution time: 0.0250
ERROR - 2019-10-19 16:35:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:35:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 16:35:54 --> Total execution time: 0.0136
ERROR - 2019-10-19 16:36:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:36:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 16:36:25 --> Total execution time: 0.0104
ERROR - 2019-10-19 16:36:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 16:36:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 16:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 16:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 16:36:38 --> Total execution time: 0.0077
ERROR - 2019-10-19 17:18:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:18:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:22:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:22:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:22:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:22:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:22:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:22:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:22:40 --> Total execution time: 0.0151
ERROR - 2019-10-19 17:26:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:26:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:08 --> Severity: Warning --> Division by zero /var/www/html/School19/application/controllers/Welcome.php 84
ERROR - 2019-10-19 17:26:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:26:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:26:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:26:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:26:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:26:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:27:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:27:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:27:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:27:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:27:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:27:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:27:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:27:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:27:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:28:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:28:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:29:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:29:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:29:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:29:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:29:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:29:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:29:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:29:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:29:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:29:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:29:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:29:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:29:48 --> Total execution time: 0.0326
ERROR - 2019-10-19 17:32:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:32:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:32:10 --> Severity: Notice --> Undefined offset: 11 /var/www/html/School19/application/views/dashboard.php 72
ERROR - 2019-10-19 17:32:10 --> Severity: Notice --> Undefined offset: 12 /var/www/html/School19/application/views/dashboard.php 73
DEBUG - 2019-10-19 17:32:10 --> Total execution time: 0.0349
ERROR - 2019-10-19 17:32:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:32:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:32:56 --> Severity: Notice --> Undefined offset: 11 /var/www/html/School19/application/views/dashboard.php 72
ERROR - 2019-10-19 17:32:56 --> Severity: Notice --> Undefined offset: 12 /var/www/html/School19/application/views/dashboard.php 73
DEBUG - 2019-10-19 17:32:56 --> Total execution time: 0.0337
ERROR - 2019-10-19 17:33:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:33:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:33:15 --> Severity: Notice --> Undefined offset: 11 /var/www/html/School19/application/views/dashboard.php 72
ERROR - 2019-10-19 17:33:15 --> Severity: Notice --> Undefined offset: 12 /var/www/html/School19/application/views/dashboard.php 73
DEBUG - 2019-10-19 17:33:15 --> Total execution time: 0.0357
ERROR - 2019-10-19 17:33:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:33:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:33:40 --> Total execution time: 0.0391
ERROR - 2019-10-19 17:34:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:34:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:34:01 --> Total execution time: 0.0454
ERROR - 2019-10-19 17:34:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:34:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:34:12 --> Total execution time: 0.0446
ERROR - 2019-10-19 17:34:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:34:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:34:25 --> Total execution time: 0.0414
ERROR - 2019-10-19 17:34:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:34:28 --> Total execution time: 0.0646
ERROR - 2019-10-19 17:34:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:34:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:34:43 --> Total execution time: 0.0362
ERROR - 2019-10-19 17:35:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:35:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:35:16 --> Total execution time: 0.0468
ERROR - 2019-10-19 17:36:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:36:43 --> Total execution time: 0.0452
ERROR - 2019-10-19 17:36:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:36:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:36:51 --> No URI present. Default controller set.
DEBUG - 2019-10-19 17:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:36:51 --> Total execution time: 0.0324
ERROR - 2019-10-19 17:37:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:37:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:37:31 --> No URI present. Default controller set.
DEBUG - 2019-10-19 17:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:37:31 --> Total execution time: 0.0523
ERROR - 2019-10-19 17:37:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:37:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:37:59 --> No URI present. Default controller set.
DEBUG - 2019-10-19 17:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:37:59 --> Total execution time: 0.0479
ERROR - 2019-10-19 17:38:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:38:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:38:10 --> No URI present. Default controller set.
DEBUG - 2019-10-19 17:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:38:10 --> Total execution time: 0.0432
ERROR - 2019-10-19 17:38:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:38:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 1 /var/www/html/School19/application/views/dashboard.php 62
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 2 /var/www/html/School19/application/views/dashboard.php 63
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 3 /var/www/html/School19/application/views/dashboard.php 64
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 4 /var/www/html/School19/application/views/dashboard.php 65
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 5 /var/www/html/School19/application/views/dashboard.php 66
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 6 /var/www/html/School19/application/views/dashboard.php 67
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 7 /var/www/html/School19/application/views/dashboard.php 68
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 8 /var/www/html/School19/application/views/dashboard.php 69
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 11 /var/www/html/School19/application/views/dashboard.php 72
ERROR - 2019-10-19 17:38:14 --> Severity: Notice --> Undefined offset: 12 /var/www/html/School19/application/views/dashboard.php 73
DEBUG - 2019-10-19 17:38:14 --> Total execution time: 0.0331
ERROR - 2019-10-19 17:38:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:38:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 17:38:22 --> Severity: Notice --> Undefined offset: 11 /var/www/html/School19/application/views/dashboard.php 72
ERROR - 2019-10-19 17:38:22 --> Severity: Notice --> Undefined offset: 12 /var/www/html/School19/application/views/dashboard.php 73
DEBUG - 2019-10-19 17:38:22 --> Total execution time: 0.0452
ERROR - 2019-10-19 17:40:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:40:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:40:30 --> Total execution time: 0.0452
ERROR - 2019-10-19 17:41:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 17:41:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 17:41:04 --> No URI present. Default controller set.
DEBUG - 2019-10-19 17:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 17:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 17:41:04 --> Total execution time: 0.0321
ERROR - 2019-10-19 18:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:01:21 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-1-01 00:00:00'
AND `a`.`date` <= '2019-1-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-2-01 00:00:00'
AND `a`.`date` <= '2019-2-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-3-01 00:00:00'
AND `a`.`date` <= '2019-3-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-4-01 00:00:00'
AND `a`.`date` <= '2019-4-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-5-01 00:00:00'
AND `a`.`date` <= '2019-5-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-6-01 00:00:00'
AND `a`.`date` <= '2019-6-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-7-01 00:00:00'
AND `a`.`date` <= '2019-7-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-8-01 00:00:00'
AND `a`.`date` <= '2019-8-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-9-01 00:00:00'
AND `a`.`date` <= '2019-9-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:01:21 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:02:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:02:01 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-1-01 00:00:00'
AND `a`.`date` <= '2019-1-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-2-01 00:00:00'
AND `a`.`date` <= '2019-2-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-3-01 00:00:00'
AND `a`.`date` <= '2019-3-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-4-01 00:00:00'
AND `a`.`date` <= '2019-4-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-5-01 00:00:00'
AND `a`.`date` <= '2019-5-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-6-01 00:00:00'
AND `a`.`date` <= '2019-6-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-7-01 00:00:00'
AND `a`.`date` <= '2019-7-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-8-01 00:00:00'
AND `a`.`date` <= '2019-8-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-9-01 00:00:00'
AND `a`.`date` <= '2019-9-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:01 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
AND `s`.`active` = 1
DEBUG - 2019-10-19 18:02:01 --> Total execution time: 0.0434
ERROR - 2019-10-19 18:02:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:02:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:02:17 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-1-01 00:00:00'
AND `a`.`date` <= '2019-1-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-2-01 00:00:00'
AND `a`.`date` <= '2019-2-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-3-01 00:00:00'
AND `a`.`date` <= '2019-3-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-4-01 00:00:00'
AND `a`.`date` <= '2019-4-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-5-01 00:00:00'
AND `a`.`date` <= '2019-5-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-6-01 00:00:00'
AND `a`.`date` <= '2019-6-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-7-01 00:00:00'
AND `a`.`date` <= '2019-7-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-8-01 00:00:00'
AND `a`.`date` <= '2019-8-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-9-01 00:00:00'
AND `a`.`date` <= '2019-9-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:17 --> Query error: Unknown column 'a.srudents_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `attendance` `a`
LEFT JOIN `students` `s` ON `a`.`srudents_id`=`s`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`attendance` = 'present'
AND `a`.`date` >= '2019-10-01 00:00:00'
AND `a`.`date` <= '2019-10-31 00:00:00'
AND `s`.`active` = 1
ERROR - 2019-10-19 18:02:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:02:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:02:30 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:02:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:02:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:02:51 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:03:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:03:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:03:03 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:03:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:03:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:03:57 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:04:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:04:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:04:16 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:05:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:05:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:05:29 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:05:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:05:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:05:36 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:06:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:06:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:06:10 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:08:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:08:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:08:15 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:08:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:08:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:08:32 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:08:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:08:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:08:55 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:10:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:10:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:10:50 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:11:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:11:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:11:08 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-19 18:19:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-19 18:19:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-19 18:19:11 --> No URI present. Default controller set.
DEBUG - 2019-10-19 18:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-19 18:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-19 18:19:11 --> Total execution time: 0.0340
