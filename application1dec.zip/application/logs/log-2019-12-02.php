<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-02 10:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-12-02 10:33:47 --> UTF-8 Support Enabled
DEBUG - 2019-12-02 10:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-12-02 10:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-12-02 10:33:58 --> Total execution time: 14.2638
ERROR - 2019-12-02 10:33:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
