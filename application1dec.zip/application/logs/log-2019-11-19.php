<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-19 18:22:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:22:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:22:40 --> Total execution time: 1.0413
ERROR - 2019-11-19 18:22:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:22:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:22:56 --> No URI present. Default controller set.
DEBUG - 2019-11-19 18:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:22:56 --> mmd :: Mmd@123
DEBUG - 2019-11-19 18:22:56 --> mmd :: 451e5aab7012b98a36d7847beb40ddc3
DEBUG - 2019-11-19 18:22:57 --> Total execution time: 0.4861
ERROR - 2019-11-19 18:23:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:23:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:23:11 --> No URI present. Default controller set.
DEBUG - 2019-11-19 18:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:23:11 --> mmd :: Mmd@12234
DEBUG - 2019-11-19 18:23:11 --> mmd :: 2ef958b1242e86a63d7c7fc47c2e9046
DEBUG - 2019-11-19 18:23:11 --> Total execution time: 0.0042
ERROR - 2019-11-19 18:23:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:23:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:23:21 --> No URI present. Default controller set.
DEBUG - 2019-11-19 18:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:23:21 --> mmd :: Mmd@1234
DEBUG - 2019-11-19 18:23:21 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-19 18:23:21 --> Total execution time: 0.2712
ERROR - 2019-11-19 18:23:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:23:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:23:26 --> Total execution time: 0.1384
ERROR - 2019-11-19 18:23:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:23:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:23:27 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-19 18:23:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:23:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:23:30 --> Total execution time: 0.0037
ERROR - 2019-11-19 18:23:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:23:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:23:30 --> Total execution time: 0.0076
ERROR - 2019-11-19 18:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:23:53 --> Total execution time: 0.0115
ERROR - 2019-11-19 18:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:23:53 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:24:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:24:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:24:54 --> Total execution time: 0.0033
ERROR - 2019-11-19 18:24:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:24:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:24:54 --> Total execution time: 0.0029
ERROR - 2019-11-19 18:24:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:24:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:24:56 --> Total execution time: 0.0130
ERROR - 2019-11-19 18:24:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:24:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:24:56 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:24:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-19 18:25:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:18 --> Total execution time: 0.0035
ERROR - 2019-11-19 18:25:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:18 --> Total execution time: 0.0051
ERROR - 2019-11-19 18:25:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:19 --> Total execution time: 0.0127
ERROR - 2019-11-19 18:25:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:25:19 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:25:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-19 18:25:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:34 --> Total execution time: 0.0042
ERROR - 2019-11-19 18:25:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:34 --> Total execution time: 0.0036
ERROR - 2019-11-19 18:25:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:35 --> Total execution time: 0.0124
ERROR - 2019-11-19 18:25:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:25:35 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:25:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:51 --> Total execution time: 0.0062
ERROR - 2019-11-19 18:25:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:51 --> Total execution time: 0.0048
ERROR - 2019-11-19 18:25:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:25:52 --> Total execution time: 0.0134
ERROR - 2019-11-19 18:25:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:25:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:25:52 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:25:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-19 18:26:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:26:02 --> Total execution time: 0.0059
ERROR - 2019-11-19 18:26:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:26:02 --> Total execution time: 0.0110
ERROR - 2019-11-19 18:26:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:26:04 --> Total execution time: 0.0117
ERROR - 2019-11-19 18:26:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:26:04 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:26:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:26:25 --> Total execution time: 0.0035
ERROR - 2019-11-19 18:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:26:25 --> Total execution time: 0.0051
ERROR - 2019-11-19 18:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:26:25 --> Total execution time: 0.0109
ERROR - 2019-11-19 18:26:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:26:25 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:26:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:26:59 --> Total execution time: 0.0053
ERROR - 2019-11-19 18:26:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:26:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:26:59 --> Total execution time: 0.0044
ERROR - 2019-11-19 18:27:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:27:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:27:00 --> Total execution time: 0.0100
ERROR - 2019-11-19 18:27:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:27:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:27:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:27:00 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:28:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:28:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:28:49 --> Total execution time: 0.0045
ERROR - 2019-11-19 18:28:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:28:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:28:49 --> Total execution time: 0.0046
ERROR - 2019-11-19 18:28:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-19 18:28:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:28:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:28:50 --> Total execution time: 0.0113
ERROR - 2019-11-19 18:28:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:28:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:28:50 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:29:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:29:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:29:12 --> Total execution time: 0.0036
ERROR - 2019-11-19 18:29:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:29:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:29:12 --> Total execution time: 0.0035
ERROR - 2019-11-19 18:29:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:29:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:29:14 --> Total execution time: 0.0133
ERROR - 2019-11-19 18:29:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:29:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:29:14 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-19 18:29:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:29:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:29:21 --> Total execution time: 0.0045
ERROR - 2019-11-19 18:29:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:29:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:29:21 --> Total execution time: 0.0041
ERROR - 2019-11-19 18:29:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:29:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-19 18:29:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:29:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-19 18:30:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:30:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-19 18:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-19 18:30:12 --> Total execution time: 0.1731
ERROR - 2019-11-19 18:30:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-19 18:30:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-19 18:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-19 18:30:13 --> 404 Page Not Found: Welcome/profile
