<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-27 10:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 10:28:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 10:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 10:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 10:29:18 --> Total execution time: 21.3305
ERROR - 2019-11-27 10:29:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-27 10:29:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 10:29:57 --> No URI present. Default controller set.
DEBUG - 2019-11-27 10:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 10:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 10:29:58 --> mmd :: Mmd@1234
DEBUG - 2019-11-27 10:29:58 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-27 10:30:02 --> Total execution time: 4.3180
ERROR - 2019-11-27 10:30:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-27 10:32:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 10:32:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 10:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 10:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 10:32:23 --> Total execution time: 0.1744
ERROR - 2019-11-27 14:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:28:57 --> Total execution time: 0.0032
ERROR - 2019-11-27 14:29:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:29:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:29:06 --> No URI present. Default controller set.
DEBUG - 2019-11-27 14:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:29:06 --> admin :: admin
DEBUG - 2019-11-27 14:29:06 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-27 14:29:06 --> Total execution time: 0.0277
ERROR - 2019-11-27 14:29:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:29:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:29:10 --> Total execution time: 0.0849
ERROR - 2019-11-27 14:29:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:29:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:29:10 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 14:29:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:29:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-27 14:29:14 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_school`.`attendance`, CONSTRAINT `attendance_ibfk_5` FOREIGN KEY (`school_id`) REFERENCES `school` (`id`)) - Invalid query: DELETE FROM `school`
WHERE `id` = '11'
DEBUG - 2019-11-27 14:29:14 --> Total execution time: 0.1824
ERROR - 2019-11-27 14:29:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-27 14:29:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:29:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:29:14 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 14:29:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:29:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:29:18 --> Total execution time: 0.2062
ERROR - 2019-11-27 14:29:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:29:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:29:18 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 14:29:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:29:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:29:21 --> Total execution time: 0.0263
ERROR - 2019-11-27 14:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:57:10 --> Total execution time: 0.0093
ERROR - 2019-11-27 14:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:57:10 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 14:57:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:57:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-27 14:57:14 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_school`.`backgrounds`, CONSTRAINT `backgrounds_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `school` (`id`)) - Invalid query: DELETE FROM `school`
WHERE `id` = '27'
DEBUG - 2019-11-27 14:57:14 --> Total execution time: 0.2753
ERROR - 2019-11-27 14:57:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:57:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:57:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:57:14 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 14:57:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:57:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:57:33 --> Total execution time: 0.2990
ERROR - 2019-11-27 14:57:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:57:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:57:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:57:33 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 14:57:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:57:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:57:37 --> Total execution time: 0.0048
ERROR - 2019-11-27 14:58:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:58:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:58:08 --> Total execution time: 0.1196
ERROR - 2019-11-27 14:58:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:58:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:58:10 --> Total execution time: 0.0055
ERROR - 2019-11-27 14:58:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:58:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:58:10 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 14:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:58:20 --> Total execution time: 0.0759
ERROR - 2019-11-27 14:58:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:58:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:58:20 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 14:58:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:58:23 --> Total execution time: 0.0070
ERROR - 2019-11-27 14:59:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 14:59:54 --> Total execution time: 0.0064
ERROR - 2019-11-27 14:59:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 14:59:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 14:59:54 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 15:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 15:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 15:00:08 --> Total execution time: 0.3020
ERROR - 2019-11-27 15:00:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:00:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:00:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 15:00:08 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 15:00:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:00:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 15:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 15:00:11 --> Total execution time: 0.0066
ERROR - 2019-11-27 15:00:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:00:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 15:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 15:00:19 --> Total execution time: 0.1589
ERROR - 2019-11-27 15:00:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:00:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 15:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 15:00:20 --> Total execution time: 0.0071
ERROR - 2019-11-27 15:00:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:00:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 15:00:21 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 15:00:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:00:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 15:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 15:00:24 --> Total execution time: 0.0732
ERROR - 2019-11-27 15:00:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:00:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:00:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 15:00:24 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 15:10:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:10:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 15:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 15:10:52 --> Total execution time: 0.0043
ERROR - 2019-11-27 15:10:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:10:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 15:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 15:10:56 --> Total execution time: 0.0044
ERROR - 2019-11-27 15:11:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 15:11:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 15:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 15:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 15:11:03 --> Total execution time: 0.1010
ERROR - 2019-11-27 16:47:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:47:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:47:28 --> Total execution time: 0.0996
ERROR - 2019-11-27 16:47:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:47:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:47:36 --> Total execution time: 0.1738
ERROR - 2019-11-27 16:47:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:47:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:47:41 --> Total execution time: 0.1234
ERROR - 2019-11-27 16:47:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:47:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:47:51 --> Total execution time: 0.2023
ERROR - 2019-11-27 16:47:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:47:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:47:56 --> Total execution time: 0.2189
ERROR - 2019-11-27 16:48:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:48:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:48:01 --> Total execution time: 0.1162
ERROR - 2019-11-27 16:54:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:54:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:54:59 --> Total execution time: 0.0064
ERROR - 2019-11-27 16:54:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:54:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 16:54:59 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 16:56:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:56:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:56:16 --> Total execution time: 0.0075
ERROR - 2019-11-27 16:56:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:56:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:56:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 16:56:16 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 16:56:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:56:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:56:26 --> Total execution time: 0.0071
ERROR - 2019-11-27 16:56:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 16:56:27 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 16:56:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 16:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 16:56:27 --> Total execution time: 0.0069
ERROR - 2019-11-27 16:56:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 16:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 16:56:27 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 17:41:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:41:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:41:48 --> Total execution time: 0.0067
ERROR - 2019-11-27 17:41:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:41:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:41:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:41:48 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 17:41:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:41:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:41:49 --> Total execution time: 0.0048
ERROR - 2019-11-27 17:41:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:41:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:41:49 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 17:42:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:42:28 --> Total execution time: 0.0074
ERROR - 2019-11-27 17:42:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:42:28 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 17:43:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:43:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:43:02 --> Total execution time: 0.0038
ERROR - 2019-11-27 17:43:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:43:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:43:23 --> Total execution time: 0.0058
ERROR - 2019-11-27 17:55:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:55:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:55:02 --> Total execution time: 0.1506
ERROR - 2019-11-27 17:55:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-27 17:55:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:55:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:55:03 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-27 17:55:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:55:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:55:06 --> Total execution time: 0.0037
ERROR - 2019-11-27 17:55:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:55:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:55:10 --> Total execution time: 0.0076
ERROR - 2019-11-27 17:55:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:55:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:55:10 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 17:55:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:55:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:55:27 --> Total execution time: 0.4483
ERROR - 2019-11-27 17:55:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:55:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:55:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:55:27 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 17:55:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:55:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:55:29 --> Total execution time: 0.0045
ERROR - 2019-11-27 17:56:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:56:38 --> Total execution time: 0.1014
ERROR - 2019-11-27 17:56:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:56:40 --> Total execution time: 0.0070
ERROR - 2019-11-27 17:56:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:56:40 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 17:56:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:56:44 --> Total execution time: 0.0064
ERROR - 2019-11-27 17:56:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:56:50 --> Total execution time: 0.0076
ERROR - 2019-11-27 17:56:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:56:50 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 17:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-27 17:56:54 --> Query error: Table 'db_school.user' doesn't exist - Invalid query: DELETE FROM `user`
WHERE `school_id` = '31'
DEBUG - 2019-11-27 17:56:54 --> Total execution time: 0.0641
ERROR - 2019-11-27 17:56:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 17:56:54 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 17:56:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:56:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:56:55 --> Total execution time: 0.0041
ERROR - 2019-11-27 17:58:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:58:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:58:53 --> Total execution time: 0.0051
ERROR - 2019-11-27 17:58:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:58:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:58:55 --> Total execution time: 0.0308
ERROR - 2019-11-27 17:59:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 17:59:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 17:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 17:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 17:59:17 --> Total execution time: 0.1139
ERROR - 2019-11-27 18:00:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:00:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:00:06 --> Total execution time: 0.0063
ERROR - 2019-11-27 18:01:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:01:08 --> Total execution time: 0.0274
ERROR - 2019-11-27 18:01:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-27 18:01:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-27 18:01:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:08 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 18:01:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:08 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-27 18:01:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:08 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-27 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:01:29 --> Total execution time: 0.0083
ERROR - 2019-11-27 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-11-27 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:29 --> 404 Page Not Found: Js/examples
DEBUG - 2019-11-27 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-27 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:29 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:29 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-27 18:01:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:01:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:01:29 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-27 18:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:02:00 --> Total execution time: 0.0048
ERROR - 2019-11-27 18:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-27 18:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-27 18:02:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-27 18:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:00 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 18:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-27 18:02:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-27 18:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:02:13 --> Total execution time: 0.0307
ERROR - 2019-11-27 18:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-27 18:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-27 18:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:13 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-27 18:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-27 18:02:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:02:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-27 18:03:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:03:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:03:51 --> Total execution time: 0.0028
ERROR - 2019-11-27 18:03:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:03:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:03:57 --> No URI present. Default controller set.
DEBUG - 2019-11-27 18:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:03:57 --> mmd :: Mmd@1234
DEBUG - 2019-11-27 18:03:57 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-27 18:03:57 --> Total execution time: 0.0251
ERROR - 2019-11-27 18:04:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:04:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:04:00 --> Total execution time: 0.0054
ERROR - 2019-11-27 18:04:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:04:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:04:00 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:04:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:04:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:04:45 --> Total execution time: 0.0092
ERROR - 2019-11-27 18:04:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:04:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:04:45 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-27 18:05:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:05:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:05:27 --> You did not select a file to upload.
DEBUG - 2019-11-27 18:05:27 --> Total execution time: 0.2390
ERROR - 2019-11-27 18:05:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:05:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:05:27 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-27 18:16:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:16:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:16:34 --> Total execution time: 0.0054
ERROR - 2019-11-27 18:16:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:16:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:16:34 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-27 18:17:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:17:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:17:03 --> Total execution time: 0.0066
ERROR - 2019-11-27 18:17:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:17:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:17:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:17:03 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-27 18:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:18:19 --> Total execution time: 0.0026
ERROR - 2019-11-27 18:18:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:18:29 --> No URI present. Default controller set.
DEBUG - 2019-11-27 18:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:18:29 --> admin :: admin
DEBUG - 2019-11-27 18:18:29 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-27 18:18:29 --> Total execution time: 0.0247
ERROR - 2019-11-27 18:18:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:18:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:18:31 --> Total execution time: 0.0049
ERROR - 2019-11-27 18:19:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:19:29 --> Total execution time: 0.0095
ERROR - 2019-11-27 18:19:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:19:29 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-27 18:19:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:19:36 --> Total execution time: 0.0028
ERROR - 2019-11-27 18:19:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:42 --> No URI present. Default controller set.
DEBUG - 2019-11-27 18:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:19:42 --> mmd :: Mmd@1234
DEBUG - 2019-11-27 18:19:42 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-27 18:19:42 --> Total execution time: 0.0248
ERROR - 2019-11-27 18:19:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:19:45 --> Total execution time: 0.0076
ERROR - 2019-11-27 18:19:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:19:45 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:19:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:19:47 --> Total execution time: 0.0813
ERROR - 2019-11-27 18:19:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:19:54 --> Total execution time: 0.0405
ERROR - 2019-11-27 18:19:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:19:57 --> Total execution time: 0.0031
ERROR - 2019-11-27 18:19:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:19:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:19:59 --> Total execution time: 0.0143
ERROR - 2019-11-27 18:20:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:20:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:20:03 --> Total execution time: 0.0056
ERROR - 2019-11-27 18:21:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:21:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:21:18 --> Total execution time: 0.0054
ERROR - 2019-11-27 18:21:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:21:40 --> Total execution time: 0.0457
ERROR - 2019-11-27 18:21:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:21:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:21:58 --> Total execution time: 0.0063
ERROR - 2019-11-27 18:21:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:21:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:21:58 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:23:34 --> Total execution time: 0.0092
ERROR - 2019-11-27 18:23:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:23:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:23:34 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:23:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:23:41 --> Total execution time: 0.0029
ERROR - 2019-11-27 18:26:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:26:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:26:29 --> Total execution time: 0.7557
ERROR - 2019-11-27 18:26:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:26:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:26:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:26:29 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:27:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:27:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:27:57 --> Total execution time: 0.0084
ERROR - 2019-11-27 18:27:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:27:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:27:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:27:57 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:28:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:12 --> Total execution time: 0.0062
ERROR - 2019-11-27 18:28:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:28:12 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:28:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:14 --> Total execution time: 0.0052
ERROR - 2019-11-27 18:28:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:25 --> Total execution time: 0.0035
ERROR - 2019-11-27 18:28:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:26 --> Total execution time: 0.0087
ERROR - 2019-11-27 18:28:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:27 --> Total execution time: 0.0072
ERROR - 2019-11-27 18:28:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:28 --> Total execution time: 0.0279
ERROR - 2019-11-27 18:28:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:31 --> Total execution time: 0.0923
ERROR - 2019-11-27 18:28:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:33 --> Total execution time: 0.0045
ERROR - 2019-11-27 18:28:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:28:33 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:28:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:36 --> Total execution time: 0.0044
ERROR - 2019-11-27 18:28:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:42 --> No URI present. Default controller set.
DEBUG - 2019-11-27 18:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:42 --> admin :: admin
DEBUG - 2019-11-27 18:28:42 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-27 18:28:42 --> Total execution time: 0.0281
ERROR - 2019-11-27 18:28:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:44 --> Total execution time: 0.0039
ERROR - 2019-11-27 18:28:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:49 --> Total execution time: 0.0048
ERROR - 2019-11-27 18:28:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:28:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:28:55 --> No URI present. Default controller set.
DEBUG - 2019-11-27 18:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:28:55 --> mmd :: Mmd@1234
DEBUG - 2019-11-27 18:28:55 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-27 18:28:55 --> Total execution time: 0.0747
ERROR - 2019-11-27 18:29:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:29:00 --> Total execution time: 0.0059
ERROR - 2019-11-27 18:29:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:29:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:29:00 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:29:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:29:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:29:07 --> Total execution time: 0.0117
ERROR - 2019-11-27 18:29:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:29:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:29:07 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:29:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:29:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:29:22 --> Total execution time: 0.0034
ERROR - 2019-11-27 18:29:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:29:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:29:34 --> Total execution time: 0.0071
ERROR - 2019-11-27 18:29:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:29:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:29:51 --> Total execution time: 0.0132
ERROR - 2019-11-27 18:29:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-27 18:29:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:29:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:29:51 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-27 18:48:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:48:37 --> Total execution time: 0.0388
ERROR - 2019-11-27 18:48:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:48:39 --> Total execution time: 0.0455
ERROR - 2019-11-27 18:48:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:48:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-27 18:48:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:48:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-27 18:48:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:48:39 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-27 18:48:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:48:39 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-27 18:48:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:48:40 --> Total execution time: 0.0389
ERROR - 2019-11-27 18:48:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:48:41 --> Total execution time: 0.0334
ERROR - 2019-11-27 18:48:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:48:42 --> Total execution time: 0.0564
ERROR - 2019-11-27 18:48:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:48:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:48:43 --> Total execution time: 0.0096
ERROR - 2019-11-27 18:50:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:50:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:50:13 --> Total execution time: 0.0277
ERROR - 2019-11-27 18:50:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-27 18:51:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:51:11 --> Total execution time: 0.0150
ERROR - 2019-11-27 18:51:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:51:11 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:51:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:51:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:51:51 --> Total execution time: 0.0060
ERROR - 2019-11-27 18:52:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:52:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:52:15 --> Total execution time: 0.0111
ERROR - 2019-11-27 18:53:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:53:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:53:07 --> Total execution time: 0.0088
ERROR - 2019-11-27 18:53:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:53:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:53:16 --> Total execution time: 0.0775
ERROR - 2019-11-27 18:53:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:53:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-27 18:53:25 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Marathi', '2019-11-27', '148')
ERROR - 2019-11-27 18:53:25 --> Query error: Duplicate entry 'Geography' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Geography', '2019-11-27', '148')
ERROR - 2019-11-27 18:53:25 --> Query error: Duplicate entry 'Physics' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Physics', '2019-11-27', '148')
DEBUG - 2019-11-27 18:53:25 --> Total execution time: 0.2727
ERROR - 2019-11-27 18:54:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:54:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:54:09 --> Total execution time: 0.0065
ERROR - 2019-11-27 18:54:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:54:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:54:49 --> Total execution time: 0.0084
ERROR - 2019-11-27 18:55:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:55:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:55:07 --> Total execution time: 0.0057
ERROR - 2019-11-27 18:56:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:56:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:56:12 --> Total execution time: 0.0050
ERROR - 2019-11-27 18:56:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:56:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:56:57 --> Total execution time: 0.0029
ERROR - 2019-11-27 18:56:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:56:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:56:59 --> Total execution time: 0.0034
ERROR - 2019-11-27 18:57:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:57:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:57:01 --> Total execution time: 0.0037
ERROR - 2019-11-27 18:57:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:57:03 --> Total execution time: 0.0036
ERROR - 2019-11-27 18:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:57:05 --> Total execution time: 0.0046
ERROR - 2019-11-27 18:58:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:58:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:58:10 --> Total execution time: 0.0067
ERROR - 2019-11-27 18:58:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:58:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:58:18 --> Total execution time: 0.0056
ERROR - 2019-11-27 18:58:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:58:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:58:31 --> Total execution time: 0.0052
ERROR - 2019-11-27 18:58:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:58:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:58:57 --> Total execution time: 0.0046
ERROR - 2019-11-27 18:58:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:58:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:58:59 --> Total execution time: 0.0025
ERROR - 2019-11-27 18:59:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:59:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:59:03 --> Total execution time: 0.0538
ERROR - 2019-11-27 18:59:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:59:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:59:26 --> Total execution time: 0.0107
ERROR - 2019-11-27 18:59:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:59:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:59:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-27 18:59:27 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-27 18:59:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 18:59:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 18:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 18:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 18:59:37 --> Total execution time: 0.0052
ERROR - 2019-11-27 19:00:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 19:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 19:00:03 --> Total execution time: 0.0095
ERROR - 2019-11-27 19:00:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-27 19:00:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-27 19:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-27 19:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-27 19:00:54 --> Total execution time: 0.0106
ERROR - 2019-11-27 19:00:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
