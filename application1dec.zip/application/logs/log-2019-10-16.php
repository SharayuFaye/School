<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-16 10:50:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 10:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 10:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 10:50:47 --> Total execution time: 9.5877
ERROR - 2019-10-16 10:53:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 10:53:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 10:53:04 --> No URI present. Default controller set.
DEBUG - 2019-10-16 10:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 10:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 10:53:06 --> Total execution time: 2.4378
ERROR - 2019-10-16 10:53:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 10:53:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 10:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 10:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 10:53:27 --> Total execution time: 1.0417
ERROR - 2019-10-16 10:53:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 10:53:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 10:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 10:53:29 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-16 10:53:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 10:53:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 10:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 10:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 10:53:54 --> Total execution time: 0.8585
ERROR - 2019-10-16 10:59:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 10:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 10:59:21 --> Total execution time: 0.0422
ERROR - 2019-10-16 10:59:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 10:59:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 10:59:24 --> No URI present. Default controller set.
DEBUG - 2019-10-16 10:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 10:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 10:59:24 --> Total execution time: 0.0118
ERROR - 2019-10-16 10:59:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 10:59:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 10:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 10:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 10:59:26 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:26 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 10:59:26 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:26 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 10:59:26 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:26 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 10:59:26 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 10:59:27 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-16 10:59:27 --> Total execution time: 0.0842
ERROR - 2019-10-16 11:00:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:00:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:00:33 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-16 11:00:33 --> Total execution time: 0.0136
ERROR - 2019-10-16 11:02:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:02:52 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
DEBUG - 2019-10-16 11:02:52 --> Total execution time: 0.0147
ERROR - 2019-10-16 11:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:11 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
DEBUG - 2019-10-16 11:03:11 --> Total execution time: 0.0101
ERROR - 2019-10-16 11:03:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:03:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:03:58 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
DEBUG - 2019-10-16 11:03:58 --> Total execution time: 0.0136
ERROR - 2019-10-16 11:04:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:04:00 --> Total execution time: 0.0585
ERROR - 2019-10-16 11:04:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:04:03 --> Total execution time: 0.0046
ERROR - 2019-10-16 11:04:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:04:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:04:05 --> Total execution time: 0.0039
ERROR - 2019-10-16 11:04:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:04:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:04:08 --> Total execution time: 0.0033
ERROR - 2019-10-16 11:04:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:04:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:04:09 --> Severity: error --> Exception: Call to undefined method m_attendances::attendances_class_sel() /var/www/html/School19/application/controllers/Welcome.php 2313
ERROR - 2019-10-16 11:22:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:22:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:22:28 --> Query error: Unknown column 's.student_name' in 'field list' - Invalid query: SELECT `s`.`student_name`, `s`.`roll_number`, `a`.*, `c`.`class`, `sec`.`sections`, `t`.`teacher_name`
FROM `attendance` `a`
LEFT JOIN `class` `c` ON `a`.`class_id`=`c`.`id`
LEFT JOIN `sections` `sec` ON `a`.`sections_id`=`sec`.`id`
WHERE `a`.`school_id` = '3'
AND `a`.`class_id` = '1'
AND `a`.`sections_id` = '40'
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:22:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/attendances.php 90
DEBUG - 2019-10-16 11:22:28 --> Total execution time: 0.0143
ERROR - 2019-10-16 11:39:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:39:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:39:28 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-16 11:39:28 --> Total execution time: 0.0145
ERROR - 2019-10-16 11:40:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:40:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:40:36 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-16 11:40:36 --> Total execution time: 0.0115
ERROR - 2019-10-16 11:42:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:42:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:42:16 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-16 11:42:16 --> Total execution time: 0.0111
ERROR - 2019-10-16 11:43:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:43:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
ERROR - 2019-10-16 11:43:20 --> Severity: Notice --> Undefined property: stdClass::$stud_id /var/www/html/School19/application/views/attendances.php 98
DEBUG - 2019-10-16 11:43:20 --> Total execution time: 0.0247
ERROR - 2019-10-16 11:43:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:43:43 --> Severity: Notice --> Undefined variable: attendances_show /var/www/html/School19/application/views/attendances.php 95
ERROR - 2019-10-16 11:43:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/attendances.php 95
DEBUG - 2019-10-16 11:43:43 --> Total execution time: 0.0154
ERROR - 2019-10-16 11:44:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:01 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/attendances.php 95
DEBUG - 2019-10-16 11:44:01 --> Total execution time: 0.0160
ERROR - 2019-10-16 11:44:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:32 --> Severity: Notice --> Undefined variable: attendances_show /var/www/html/School19/application/views/attendances.php 95
DEBUG - 2019-10-16 11:44:32 --> Total execution time: 0.0172
ERROR - 2019-10-16 11:44:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:44:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:44:54 --> Severity: Notice --> Undefined variable: section1 /var/www/html/School19/application/views/attendances.php 60
DEBUG - 2019-10-16 11:44:54 --> Total execution time: 0.0093
ERROR - 2019-10-16 11:44:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:44:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:44:56 --> Total execution time: 0.0035
ERROR - 2019-10-16 11:45:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:45:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:01 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-16 11:45:01 --> Total execution time: 0.0093
ERROR - 2019-10-16 11:45:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:45:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:45:09 --> Total execution time: 0.0026
ERROR - 2019-10-16 11:45:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:45:10 --> Total execution time: 0.0032
ERROR - 2019-10-16 11:45:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
ERROR - 2019-10-16 11:45:15 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 59
DEBUG - 2019-10-16 11:45:15 --> Total execution time: 0.0094
ERROR - 2019-10-16 11:45:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:45:46 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
DEBUG - 2019-10-16 11:45:46 --> Total execution time: 0.0104
ERROR - 2019-10-16 11:46:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:46:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
ERROR - 2019-10-16 11:46:06 --> Severity: Notice --> Undefined property: stdClass::$class_id /var/www/html/School19/application/views/attendances.php 58
DEBUG - 2019-10-16 11:46:06 --> Total execution time: 0.0113
ERROR - 2019-10-16 11:47:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:47:36 --> Total execution time: 0.0107
ERROR - 2019-10-16 11:48:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:48:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:48:39 --> Total execution time: 0.0097
ERROR - 2019-10-16 11:50:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:50:09 --> Total execution time: 0.0092
ERROR - 2019-10-16 11:50:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:50:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:50:21 --> Total execution time: 0.0076
ERROR - 2019-10-16 11:50:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:50:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:50:42 --> Severity: error --> Exception: Call to undefined method stdClass::date() /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:51:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:51:05 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:05 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:05 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:05 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:05 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /var/www/html/School19/application/views/attendances.php 100
DEBUG - 2019-10-16 11:51:05 --> Total execution time: 0.0102
ERROR - 2019-10-16 11:51:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:51:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:51:19 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:19 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:19 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:19 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:51:19 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/School19/application/views/attendances.php 100
DEBUG - 2019-10-16 11:51:19 --> Total execution time: 0.0076
ERROR - 2019-10-16 11:51:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:51:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:51:57 --> Total execution time: 0.0093
ERROR - 2019-10-16 11:53:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:53:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 11:53:16 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:53:16 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:53:16 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:53:16 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/attendances.php 100
ERROR - 2019-10-16 11:53:16 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/attendances.php 100
DEBUG - 2019-10-16 11:53:16 --> Total execution time: 0.0094
ERROR - 2019-10-16 11:55:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:55:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:55:22 --> Total execution time: 0.0096
ERROR - 2019-10-16 11:56:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:56:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:56:50 --> Total execution time: 0.0090
ERROR - 2019-10-16 11:56:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:56:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 11:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 11:56:52 --> Total execution time: 0.4949
ERROR - 2019-10-16 11:56:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 11:56:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:56:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:56:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 11:56:52 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-16 11:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 11:56:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 11:56:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:56:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 11:56:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 11:56:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 11:56:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 11:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 11:56:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:01:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:01:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:01:21 --> Total execution time: 0.0156
ERROR - 2019-10-16 12:01:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:01:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:01:23 --> Severity: error --> Exception: Call to undefined method m_attendances::attendances_student_show() /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 12:02:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:02:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:02:56 --> Severity: Notice --> Undefined variable: class_id /var/www/html/School19/application/models/M_attendances.php 94
ERROR - 2019-10-16 12:02:56 --> Severity: Notice --> Undefined variable: section_id /var/www/html/School19/application/models/M_attendances.php 95
DEBUG - 2019-10-16 12:02:56 --> Total execution time: 0.0075
ERROR - 2019-10-16 12:02:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:02:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:02:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 12:02:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:02:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:02:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 12:02:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:02:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:02:57 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 12:02:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:02:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:02:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 12:03:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:03:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:03:35 --> Severity: Notice --> Undefined variable: class_id /var/www/html/School19/application/models/M_attendances.php 94
ERROR - 2019-10-16 12:03:35 --> Severity: Notice --> Undefined variable: section_id /var/www/html/School19/application/models/M_attendances.php 95
ERROR - 2019-10-16 12:03:35 --> Severity: Notice --> Use of undefined constant attendances_student_show - assumed 'attendances_student_show' /var/www/html/School19/application/views/student_attendance.php 53
ERROR - 2019-10-16 12:04:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:04:01 --> Severity: Notice --> Undefined variable: class_id /var/www/html/School19/application/models/M_attendances.php 94
ERROR - 2019-10-16 12:04:01 --> Severity: Notice --> Undefined variable: section_id /var/www/html/School19/application/models/M_attendances.php 95
ERROR - 2019-10-16 12:04:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:04:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:05:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:05:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:11:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:11:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:12:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:12:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:16:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:16:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:17:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:21:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:21:29 --> Severity: Notice --> Undefined property: Welcome::$m_notifications /var/www/html/School19/application/controllers/Welcome.php 2361
ERROR - 2019-10-16 12:21:29 --> Severity: error --> Exception: Call to a member function notifications_show() on null /var/www/html/School19/application/controllers/Welcome.php 2361
ERROR - 2019-10-16 12:21:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:21:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:23:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:23:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:23:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:23:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:23:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:23:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:23:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:23:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:23:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:23:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:23:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:23:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:29:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:29:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:29:17 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/views/student_attendance.php 29
ERROR - 2019-10-16 12:29:17 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/student_attendance.php 29
ERROR - 2019-10-16 12:29:17 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/views/student_attendance.php 36
ERROR - 2019-10-16 12:29:17 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/student_attendance.php 36
ERROR - 2019-10-16 12:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:29:46 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/views/student_attendance.php 29
ERROR - 2019-10-16 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/student_attendance.php 29
ERROR - 2019-10-16 12:29:46 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/views/student_attendance.php 36
ERROR - 2019-10-16 12:29:46 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/student_attendance.php 36
DEBUG - 2019-10-16 12:29:46 --> Total execution time: 0.0120
ERROR - 2019-10-16 12:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:29:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:29:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:29:46 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:29:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:29:46 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:29:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:29:57 --> Total execution time: 0.0062
ERROR - 2019-10-16 12:29:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:29:57 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 12:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:30:00 --> Total execution time: 0.0057
ERROR - 2019-10-16 12:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 12:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:30:00 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-16 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:30:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 12:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:30:00 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 12:30:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:30:00 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 12:31:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:31:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:31:13 --> Total execution time: 0.0099
ERROR - 2019-10-16 12:31:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:31:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:31:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:31:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:31:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:31:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:31:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:31:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:31:13 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:31:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:31:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:31:13 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:32:06 --> Severity: Notice --> Undefined variable: student_id /var/www/html/School19/application/views/student_attendance.php 36
ERROR - 2019-10-16 12:32:06 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 40
DEBUG - 2019-10-16 12:32:06 --> Total execution time: 0.0076
ERROR - 2019-10-16 12:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:32:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:32:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:32:06 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:32:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:32:06 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:33:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:33:28 --> Total execution time: 0.0121
ERROR - 2019-10-16 12:33:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:33:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:33:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:33:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:33:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:33:28 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:33:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:33:28 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:33:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/views/student_attendance.php 29
ERROR - 2019-10-16 12:33:34 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/views/student_attendance.php 29
DEBUG - 2019-10-16 12:33:34 --> Total execution time: 0.0083
ERROR - 2019-10-16 12:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:33:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:33:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:33:34 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:33:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:34:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:34:59 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2357
ERROR - 2019-10-16 12:34:59 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2357
DEBUG - 2019-10-16 12:34:59 --> Total execution time: 0.0139
ERROR - 2019-10-16 12:34:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:34:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:34:59 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:34:59 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:34:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:34:59 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:34:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:34:59 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:35:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:35:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:35:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:35:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2357
ERROR - 2019-10-16 12:35:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2357
DEBUG - 2019-10-16 12:35:25 --> Total execution time: 0.0118
ERROR - 2019-10-16 12:35:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:35:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:35:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:25 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:35:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:25 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:35:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:35:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:35:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:35:52 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2357
DEBUG - 2019-10-16 12:35:52 --> Total execution time: 0.0134
ERROR - 2019-10-16 12:35:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 12:35:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:35:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:35:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:35:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:53 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:35:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:53 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:35:59 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:35:59 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2351
DEBUG - 2019-10-16 12:35:59 --> Total execution time: 0.0117
ERROR - 2019-10-16 12:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:59 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:59 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:59 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:35:59 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:36:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:36:09 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:36:09 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:36:09 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2358
ERROR - 2019-10-16 12:36:09 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2358
DEBUG - 2019-10-16 12:36:09 --> Total execution time: 0.0095
ERROR - 2019-10-16 12:36:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:36:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:36:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:36:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:36:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:36:09 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:36:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:36:09 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:36:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:36:14 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:36:14 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:36:14 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2358
ERROR - 2019-10-16 12:36:14 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2358
DEBUG - 2019-10-16 12:36:14 --> Total execution time: 0.0158
ERROR - 2019-10-16 12:36:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:36:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:36:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:36:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:36:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:36:14 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:36:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:36:14 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:39:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:39:57 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:39:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2351
ERROR - 2019-10-16 12:41:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:41:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:41:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:41:40 --> Total execution time: 0.0166
ERROR - 2019-10-16 12:41:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:41:40 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 12:41:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:41:40 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 12:41:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:41:41 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 12:41:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:41:41 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 12:41:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:41:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2361
ERROR - 2019-10-16 12:41:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2361
DEBUG - 2019-10-16 12:41:47 --> Total execution time: 0.0071
ERROR - 2019-10-16 12:41:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:47 --> UTF-8 Support Enabled
ERROR - 2019-10-16 12:41:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:41:47 --> 404 Page Not Found: Welcome/js
DEBUG - 2019-10-16 12:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:41:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:41:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:41:47 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:41:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:41:47 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:44:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:44:17 --> Total execution time: 0.0133
ERROR - 2019-10-16 12:44:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 12:44:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:17 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:44:17 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:44:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:18 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:44:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:18 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:44:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:44:19 --> Total execution time: 0.0054
ERROR - 2019-10-16 12:44:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:44:23 --> Total execution time: 0.0074
ERROR - 2019-10-16 12:44:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:23 --> UTF-8 Support Enabled
ERROR - 2019-10-16 12:44:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:23 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:23 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 12:44:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:23 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 12:44:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:23 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 12:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:44:27 --> Total execution time: 0.0033
ERROR - 2019-10-16 12:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 12:44:27 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-16 12:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:27 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:44:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:27 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:44:31 --> Total execution time: 0.0049
ERROR - 2019-10-16 12:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:31 --> UTF-8 Support Enabled
ERROR - 2019-10-16 12:44:31 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-16 12:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:44:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:44:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:44:36 --> Total execution time: 0.0030
ERROR - 2019-10-16 12:44:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:44:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:44:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:36 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:44:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:44:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:44:36 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:45:22 --> Severity: Notice --> Use of undefined constant attendances_student_show - assumed 'attendances_student_show' /var/www/html/School19/application/views/student_attendance.php 51
DEBUG - 2019-10-16 12:45:22 --> Total execution time: 0.0086
ERROR - 2019-10-16 12:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:22 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:45:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:22 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 12:45:31 --> Severity: Notice --> Use of undefined constant attendances_student_show - assumed 'attendances_student_show' /var/www/html/School19/application/views/student_attendance.php 51
DEBUG - 2019-10-16 12:45:31 --> Total execution time: 0.0048
ERROR - 2019-10-16 12:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:31 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:45:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:31 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:45:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 12:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 12:45:40 --> Total execution time: 0.0071
ERROR - 2019-10-16 12:45:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:40 --> UTF-8 Support Enabled
ERROR - 2019-10-16 12:45:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:40 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-16 12:45:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:40 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 12:45:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:41 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 12:45:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 12:45:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 12:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 12:45:41 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 14:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:18:21 --> Total execution time: 0.0147
ERROR - 2019-10-16 14:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:21 --> UTF-8 Support Enabled
ERROR - 2019-10-16 14:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 14:18:21 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-10-16 14:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 14:18:21 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 14:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 14:18:21 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 14:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 14:18:21 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 14:18:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:18:29 --> Total execution time: 0.0053
ERROR - 2019-10-16 14:18:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 14:18:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 14:18:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 14:18:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 14:18:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 14:18:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-10-16 14:18:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 14:18:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-10-16 14:18:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:18:54 --> Total execution time: 0.0066
ERROR - 2019-10-16 14:19:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:19:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:19:22 --> Total execution time: 0.0062
ERROR - 2019-10-16 14:19:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:19:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:19:35 --> Total execution time: 0.0123
ERROR - 2019-10-16 14:20:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:20:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:20:36 --> Total execution time: 0.0075
ERROR - 2019-10-16 14:21:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:21:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:21:12 --> Total execution time: 0.0091
ERROR - 2019-10-16 14:26:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:26:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:56:00 --> Total execution time: 0.0118
ERROR - 2019-10-16 14:29:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:29:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 14:29:36 --> Severity: Notice --> Undefined variable: dateArray /var/www/html/School19/application/views/student_attendance.php 159
DEBUG - 2019-10-16 14:29:36 --> Total execution time: 0.0052
ERROR - 2019-10-16 14:39:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:39:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:39:36 --> Total execution time: 0.0074
ERROR - 2019-10-16 14:39:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:39:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 14:39:59 --> Severity: Notice --> Undefined variable: events /var/www/html/School19/application/views/student_attendance.php 158
DEBUG - 2019-10-16 14:39:59 --> Total execution time: 0.0052
ERROR - 2019-10-16 14:40:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:40:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:40:18 --> Total execution time: 0.0049
ERROR - 2019-10-16 14:40:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:40:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:40:50 --> Total execution time: 0.0099
ERROR - 2019-10-16 14:42:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:42:12 --> Total execution time: 0.0089
ERROR - 2019-10-16 14:42:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:42:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:42:48 --> Total execution time: 0.0083
ERROR - 2019-10-16 14:42:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:42:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:42:50 --> Total execution time: 0.0056
ERROR - 2019-10-16 14:42:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:42:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:42:50 --> Total execution time: 0.0054
ERROR - 2019-10-16 14:42:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:42:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:42:51 --> Total execution time: 0.0045
ERROR - 2019-10-16 14:43:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:43:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:43:08 --> Total execution time: 0.0063
ERROR - 2019-10-16 14:43:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:43:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:43:30 --> Total execution time: 0.0054
ERROR - 2019-10-16 14:45:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:45:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:45:48 --> Total execution time: 0.0091
ERROR - 2019-10-16 14:46:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:46:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:46:18 --> Total execution time: 0.0106
ERROR - 2019-10-16 14:46:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:46:24 --> Total execution time: 0.0047
ERROR - 2019-10-16 14:47:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:47:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 14:47:07 --> Severity: Notice --> Undefined index: href /var/www/html/School19/application/views/student_attendance.php 123
ERROR - 2019-10-16 14:47:07 --> Severity: Notice --> Undefined index: href /var/www/html/School19/application/views/student_attendance.php 123
DEBUG - 2019-10-16 14:47:07 --> Total execution time: 0.0082
ERROR - 2019-10-16 14:47:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:47:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:47:15 --> Total execution time: 0.0057
ERROR - 2019-10-16 14:47:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:47:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:47:22 --> Total execution time: 0.0090
ERROR - 2019-10-16 14:48:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:48:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:48:07 --> Total execution time: 0.0087
ERROR - 2019-10-16 14:50:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:50:30 --> Total execution time: 0.0062
ERROR - 2019-10-16 14:50:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:50:31 --> Total execution time: 0.0042
ERROR - 2019-10-16 14:50:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:50:31 --> Total execution time: 0.0050
ERROR - 2019-10-16 14:50:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:50:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:50:32 --> Total execution time: 0.0073
ERROR - 2019-10-16 14:51:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:51:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:51:21 --> Total execution time: 0.0059
ERROR - 2019-10-16 14:51:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:51:29 --> Total execution time: 0.0053
ERROR - 2019-10-16 14:52:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:52:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:52:46 --> Total execution time: 0.0064
ERROR - 2019-10-16 14:54:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:54:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:54:10 --> Total execution time: 0.0074
ERROR - 2019-10-16 14:56:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:56:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:56:00 --> Total execution time: 0.0044
ERROR - 2019-10-16 14:56:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:56:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:56:30 --> Total execution time: 0.0091
ERROR - 2019-10-16 14:58:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:58:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 14:58:38 --> Severity: error --> Exception: syntax error, unexpected '$month' (T_VARIABLE) /var/www/html/School19/application/views/student_attendance.php 117
ERROR - 2019-10-16 14:59:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 14:59:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 14:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 14:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 14:59:19 --> Total execution time: 0.0049
ERROR - 2019-10-16 15:00:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:00:02 --> Total execution time: 0.0065
ERROR - 2019-10-16 15:11:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: calender /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
DEBUG - 2019-10-16 15:11:25 --> Total execution time: 0.0165
ERROR - 2019-10-16 15:12:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:12:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: calender /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
DEBUG - 2019-10-16 15:12:00 --> Total execution time: 0.0130
ERROR - 2019-10-16 15:15:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:15:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: calender /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
DEBUG - 2019-10-16 15:15:27 --> Total execution time: 0.0147
ERROR - 2019-10-16 15:16:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:16:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
DEBUG - 2019-10-16 15:16:07 --> Total execution time: 0.0148
ERROR - 2019-10-16 15:17:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:17:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
DEBUG - 2019-10-16 15:17:19 --> Total execution time: 0.0110
ERROR - 2019-10-16 15:18:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:18:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 66
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
DEBUG - 2019-10-16 15:18:50 --> Total execution time: 0.0121
ERROR - 2019-10-16 15:19:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:19:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 66
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Notice --> Undefined variable: attendances_student_show /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/student_attendance.php 118
DEBUG - 2019-10-16 15:19:28 --> Total execution time: 0.0138
ERROR - 2019-10-16 15:19:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:19:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:19:49 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:20:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:20:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:20:30 --> Total execution time: 0.0064
ERROR - 2019-10-16 15:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:21:48 --> Total execution time: 0.0040
ERROR - 2019-10-16 15:25:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:25:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:25:18 --> Severity: error --> Exception: syntax error, unexpected '$day' (T_VARIABLE) /var/www/html/School19/application/views/student_attendance.php 118
ERROR - 2019-10-16 15:25:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:25:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
ERROR - 2019-10-16 15:25:48 --> Severity: Notice --> Array to string conversion /var/www/html/School19/application/views/student_attendance.php 121
DEBUG - 2019-10-16 15:25:48 --> Total execution time: 0.0140
ERROR - 2019-10-16 15:26:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:26:18 --> Total execution time: 0.0052
ERROR - 2019-10-16 15:27:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:27:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:27:27 --> Total execution time: 0.0052
ERROR - 2019-10-16 15:28:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:28:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:28:43 --> Total execution time: 0.0042
ERROR - 2019-10-16 15:29:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:29:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:29:37 --> Total execution time: 0.0044
ERROR - 2019-10-16 15:30:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:30:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:30:50 --> Total execution time: 0.0091
ERROR - 2019-10-16 15:32:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:32:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
ERROR - 2019-10-16 15:32:20 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/views/student_attendance.php 119
DEBUG - 2019-10-16 15:32:20 --> Total execution time: 0.0091
ERROR - 2019-10-16 15:32:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:32:39 --> Total execution time: 0.0041
ERROR - 2019-10-16 15:32:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:32:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:32:58 --> Total execution time: 0.0058
ERROR - 2019-10-16 15:35:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:35:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:35:06 --> Total execution time: 0.0045
ERROR - 2019-10-16 15:36:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:36:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:36:17 --> Total execution time: 0.0046
ERROR - 2019-10-16 15:36:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:36:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:36:26 --> Total execution time: 0.0050
ERROR - 2019-10-16 15:36:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:36:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:36:41 --> Total execution time: 0.0087
ERROR - 2019-10-16 15:37:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:37:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:37:57 --> Total execution time: 0.0081
ERROR - 2019-10-16 15:38:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:38:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:38:20 --> Total execution time: 0.0049
ERROR - 2019-10-16 15:40:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:40:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:40:10 --> Total execution time: 0.0074
ERROR - 2019-10-16 15:40:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:40:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:40:45 --> Total execution time: 0.0081
ERROR - 2019-10-16 15:41:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:41:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:41:55 --> Total execution time: 0.0083
ERROR - 2019-10-16 15:42:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:42:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:42:45 --> Total execution time: 0.0048
ERROR - 2019-10-16 15:45:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:45:21 --> Severity: error --> Exception: Call to undefined function 2019-10() /var/www/html/School19/application/views/student_attendance.php 186
ERROR - 2019-10-16 15:46:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:46:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:46:50 --> Severity: error --> Exception: Call to undefined function 2019-10() /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 15:49:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:49:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:49:05 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 15:49:05 --> Severity: Notice --> Use of undefined constant date - assumed 'date' /var/www/html/School19/application/views/student_attendance.php 188
ERROR - 2019-10-16 15:49:05 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/student_attendance.php 188
DEBUG - 2019-10-16 15:49:05 --> Total execution time: 0.0081
ERROR - 2019-10-16 15:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:49:07 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 15:49:07 --> Severity: Notice --> Use of undefined constant date - assumed 'date' /var/www/html/School19/application/views/student_attendance.php 188
ERROR - 2019-10-16 15:49:07 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/student_attendance.php 188
DEBUG - 2019-10-16 15:49:07 --> Total execution time: 0.0050
ERROR - 2019-10-16 15:49:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 15:49:15 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 15:49:15 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given /var/www/html/School19/application/views/student_attendance.php 188
DEBUG - 2019-10-16 15:49:15 --> Total execution time: 0.0069
ERROR - 2019-10-16 15:50:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:50:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:50:46 --> Total execution time: 0.0046
ERROR - 2019-10-16 15:50:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:50:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:50:56 --> Total execution time: 0.0061
ERROR - 2019-10-16 15:51:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:51:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:51:35 --> Total execution time: 0.0044
ERROR - 2019-10-16 15:51:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:51:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:51:41 --> Total execution time: 0.0055
ERROR - 2019-10-16 15:51:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:51:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:51:50 --> Total execution time: 0.0078
ERROR - 2019-10-16 15:52:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:52:02 --> Total execution time: 0.0074
ERROR - 2019-10-16 15:52:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:52:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:52:22 --> Total execution time: 0.0069
ERROR - 2019-10-16 15:52:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:52:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:52:41 --> Total execution time: 0.0074
ERROR - 2019-10-16 15:52:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:52:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:52:58 --> Total execution time: 0.0072
ERROR - 2019-10-16 15:53:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:53:08 --> Total execution time: 0.0047
ERROR - 2019-10-16 15:53:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:53:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:53:40 --> Total execution time: 0.0050
ERROR - 2019-10-16 15:53:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:53:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:53:43 --> Total execution time: 0.0058
ERROR - 2019-10-16 15:53:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:53:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:53:48 --> Total execution time: 0.0030
ERROR - 2019-10-16 15:53:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:53:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:53:52 --> Total execution time: 0.0098
ERROR - 2019-10-16 15:53:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:53:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:53:54 --> Total execution time: 0.0073
ERROR - 2019-10-16 15:53:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:53:57 --> Total execution time: 0.0077
ERROR - 2019-10-16 15:54:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:00 --> Total execution time: 0.0077
ERROR - 2019-10-16 15:54:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:05 --> Total execution time: 0.0061
ERROR - 2019-10-16 15:54:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:08 --> Total execution time: 0.0037
ERROR - 2019-10-16 15:54:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:24 --> Total execution time: 0.0090
ERROR - 2019-10-16 15:54:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:26 --> Total execution time: 0.0099
ERROR - 2019-10-16 15:54:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:28 --> Total execution time: 0.0074
ERROR - 2019-10-16 15:54:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:30 --> Total execution time: 0.0107
ERROR - 2019-10-16 15:54:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:31 --> Total execution time: 0.0080
ERROR - 2019-10-16 15:54:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:54:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:54:57 --> Total execution time: 0.0112
ERROR - 2019-10-16 15:55:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:55:04 --> Total execution time: 0.0085
ERROR - 2019-10-16 15:55:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:55:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:55:18 --> Total execution time: 0.0058
ERROR - 2019-10-16 15:55:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:55:30 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:55:30 --> Total execution time: 0.0090
ERROR - 2019-10-16 15:56:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:56:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:56:00 --> Total execution time: 0.0087
ERROR - 2019-10-16 15:56:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:56:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:56:14 --> Total execution time: 0.0086
ERROR - 2019-10-16 15:56:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:56:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:56:24 --> Total execution time: 0.0075
ERROR - 2019-10-16 15:56:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:56:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:56:28 --> Total execution time: 0.0097
ERROR - 2019-10-16 15:56:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:56:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:56:41 --> Total execution time: 0.0087
ERROR - 2019-10-16 15:56:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 15:56:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 15:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 15:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 15:56:44 --> Total execution time: 0.0065
ERROR - 2019-10-16 16:01:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:01:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:01:32 --> Total execution time: 0.0180
ERROR - 2019-10-16 16:01:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:01:34 --> Total execution time: 0.0049
ERROR - 2019-10-16 16:01:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:01:39 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:01:39 --> Total execution time: 0.0071
ERROR - 2019-10-16 16:01:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:01:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:01:42 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:02:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:02:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:02:10 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 2354
ERROR - 2019-10-16 16:02:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 2354
ERROR - 2019-10-16 16:02:10 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 16:03:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:03:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:03:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:03:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:03:38 --> Severity: error --> Exception: Call to a member function format() on null /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:03:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:03:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:03:51 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:04:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:04:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:04:00 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:04:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:04:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:04:15 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:04:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:04:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:04:16 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:04:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:04:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:04:16 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:04:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:04:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:04:16 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:04:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:04:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:04:45 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:05:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:05:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:05:02 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:05:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:05:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:05:03 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:05:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:05:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:05:07 --> Total execution time: 0.0102
ERROR - 2019-10-16 16:05:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:05:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:05:09 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:05:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:05:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:05:26 --> Total execution time: 0.0112
ERROR - 2019-10-16 16:05:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:05:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:05:27 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:06:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:06:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:06:07 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:06:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:06:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:06:11 --> Total execution time: 0.0077
ERROR - 2019-10-16 16:06:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:06:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:06:13 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:07:23 --> Total execution time: 0.0109
ERROR - 2019-10-16 16:07:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:07:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:07:25 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:07:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:07:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:07:43 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/controllers/Welcome.php 2350
ERROR - 2019-10-16 16:08:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:08:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:08:00 --> Total execution time: 0.0076
ERROR - 2019-10-16 16:08:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:08:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:08:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:08:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:08:19 --> Total execution time: 0.0217
ERROR - 2019-10-16 16:08:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:08:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:08:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:08:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:08:34 --> Total execution time: 0.0169
ERROR - 2019-10-16 16:08:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:08:36 --> Severity: 4096 --> Object of class DateTime could not be converted to string /var/www/html/School19/application/views/student_attendance.php 41
ERROR - 2019-10-16 16:08:36 --> Severity: Warning --> DateTime::createFromFormat() expects parameter 2 to be string, object given /var/www/html/School19/application/views/student_attendance.php 185
ERROR - 2019-10-16 16:08:36 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 16:08:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:08:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:08:37 --> Severity: 4096 --> Object of class DateTime could not be converted to string /var/www/html/School19/application/views/student_attendance.php 41
ERROR - 2019-10-16 16:08:37 --> Severity: Warning --> DateTime::createFromFormat() expects parameter 2 to be string, object given /var/www/html/School19/application/views/student_attendance.php 185
ERROR - 2019-10-16 16:08:37 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 16:08:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:08:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:08:46 --> Total execution time: 0.0073
ERROR - 2019-10-16 16:10:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:10:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:10:04 --> Total execution time: 0.0157
ERROR - 2019-10-16 16:10:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:10:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:10:10 --> Total execution time: 0.0073
ERROR - 2019-10-16 16:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:10:15 --> Severity: Notice --> Undefined variable: student_id /var/www/html/School19/application/controllers/Welcome.php 2368
ERROR - 2019-10-16 16:10:15 --> Severity: Notice --> Undefined variable: date /var/www/html/School19/application/controllers/Welcome.php 2369
ERROR - 2019-10-16 16:10:15 --> Severity: Notice --> Undefined variable: student_name /var/www/html/School19/application/views/student_attendance.php 29
ERROR - 2019-10-16 16:10:15 --> Severity: Notice --> Undefined variable: student_name /var/www/html/School19/application/views/student_attendance.php 37
ERROR - 2019-10-16 16:10:15 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 16:10:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:10:26 --> Total execution time: 0.0050
ERROR - 2019-10-16 16:10:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:10:31 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:10:32 --> Total execution time: 0.0048
ERROR - 2019-10-16 16:11:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:11:02 --> Severity: Warning --> date() expects at least 1 parameter, 0 given /var/www/html/School19/application/views/student_attendance.php 41
DEBUG - 2019-10-16 16:11:02 --> Total execution time: 0.0071
ERROR - 2019-10-16 16:11:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:18 --> Total execution time: 0.0076
ERROR - 2019-10-16 16:11:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:24 --> Total execution time: 0.0057
ERROR - 2019-10-16 16:11:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:32 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:32 --> Total execution time: 0.0056
ERROR - 2019-10-16 16:11:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:35 --> Total execution time: 0.0023
ERROR - 2019-10-16 16:11:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:38 --> Total execution time: 0.0093
ERROR - 2019-10-16 16:11:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:40 --> Total execution time: 0.0062
ERROR - 2019-10-16 16:11:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:42 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:42 --> Total execution time: 0.0081
ERROR - 2019-10-16 16:11:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:54 --> Total execution time: 0.0066
ERROR - 2019-10-16 16:11:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:11:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:11:58 --> Total execution time: 0.0165
ERROR - 2019-10-16 16:12:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:12:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:12:02 --> Total execution time: 0.0073
ERROR - 2019-10-16 16:13:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:13:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:13:06 --> Total execution time: 0.0069
ERROR - 2019-10-16 16:13:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:13:25 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:13:25 --> Total execution time: 0.0095
ERROR - 2019-10-16 16:13:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:13:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:13:41 --> Total execution time: 0.0062
ERROR - 2019-10-16 16:13:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:13:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:13:45 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/views/student_attendance.php 186
ERROR - 2019-10-16 16:14:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:14:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:14:38 --> Severity: error --> Exception: Call to a member function format() on boolean /var/www/html/School19/application/views/student_attendance.php 187
ERROR - 2019-10-16 16:14:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:14:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:14:56 --> Total execution time: 0.0066
ERROR - 2019-10-16 16:15:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:15:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:15:00 --> Total execution time: 0.0076
ERROR - 2019-10-16 16:15:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:15:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:15:07 --> Total execution time: 0.0081
ERROR - 2019-10-16 16:24:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:24:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:24:41 --> Total execution time: 0.0100
ERROR - 2019-10-16 16:27:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:27:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:27:57 --> Total execution time: 0.0057
ERROR - 2019-10-16 16:28:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:28:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:28:08 --> Total execution time: 0.0082
ERROR - 2019-10-16 16:28:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:28:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:28:35 --> Total execution time: 0.0103
ERROR - 2019-10-16 16:28:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:28:47 --> Total execution time: 0.0107
ERROR - 2019-10-16 16:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:28:57 --> Total execution time: 0.0100
ERROR - 2019-10-16 16:29:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:29:04 --> Total execution time: 0.0066
ERROR - 2019-10-16 16:29:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:29:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:29:44 --> Total execution time: 0.0111
ERROR - 2019-10-16 16:29:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:29:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:29:56 --> Total execution time: 0.0102
ERROR - 2019-10-16 16:30:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:30:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:30:24 --> Total execution time: 0.0119
ERROR - 2019-10-16 16:30:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:30:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:30:41 --> Total execution time: 0.0086
ERROR - 2019-10-16 16:31:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:31:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:31:40 --> Total execution time: 0.0070
ERROR - 2019-10-16 16:31:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:31:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:31:48 --> Total execution time: 0.0107
ERROR - 2019-10-16 16:33:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:33:11 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:33:11 --> Total execution time: 0.0098
ERROR - 2019-10-16 16:33:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:33:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:33:27 --> Total execution time: 0.0080
ERROR - 2019-10-16 16:33:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:33:38 --> Total execution time: 0.0068
ERROR - 2019-10-16 16:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:33:45 --> Total execution time: 0.0063
ERROR - 2019-10-16 16:33:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:33:50 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:33:50 --> Total execution time: 0.0107
ERROR - 2019-10-16 16:34:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:34:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:34:00 --> Total execution time: 0.0097
ERROR - 2019-10-16 16:34:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:34:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:34:23 --> Total execution time: 0.0094
ERROR - 2019-10-16 16:34:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:34:34 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:34:34 --> Total execution time: 0.0099
ERROR - 2019-10-16 16:35:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:35:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:35:04 --> Total execution time: 0.0075
ERROR - 2019-10-16 16:35:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:35:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:35:15 --> Total execution time: 0.0062
ERROR - 2019-10-16 16:36:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:36:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:36:56 --> Total execution time: 0.0874
ERROR - 2019-10-16 16:37:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:37:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:37:00 --> Total execution time: 0.0028
ERROR - 2019-10-16 16:37:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 16:37:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:37:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:37:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:37:01 --> Total execution time: 0.0033
DEBUG - 2019-10-16 16:37:01 --> Total execution time: 0.0039
ERROR - 2019-10-16 16:57:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:57:00 --> Total execution time: 0.0027
ERROR - 2019-10-16 16:57:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:03 --> No URI present. Default controller set.
DEBUG - 2019-10-16 16:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:57:03 --> Total execution time: 0.0127
ERROR - 2019-10-16 16:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 16:57:05 --> Severity: Notice --> Undefined variable: school_id /var/www/html/School19/application/models/M_faq.php 50
DEBUG - 2019-10-16 16:57:05 --> Total execution time: 0.0206
ERROR - 2019-10-16 16:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 16:57:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 16:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 16:57:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 16:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 16:57:05 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 16:57:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 16:57:05 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 16:57:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 16:57:27 --> Total execution time: 0.0068
ERROR - 2019-10-16 16:57:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 16:57:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 16:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 16:57:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 16:57:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 16:57:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 16:57:27 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 16:57:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 16:57:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 16:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 16:57:27 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 17:51:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:51:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:51:14 --> Total execution time: 0.0084
ERROR - 2019-10-16 17:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:57:44 --> Total execution time: 0.0029
ERROR - 2019-10-16 17:57:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:47 --> No URI present. Default controller set.
DEBUG - 2019-10-16 17:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:57:47 --> Total execution time: 0.0070
ERROR - 2019-10-16 17:57:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:57:49 --> Total execution time: 0.0278
ERROR - 2019-10-16 17:57:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:49 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-16 17:57:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:57:52 --> Total execution time: 0.0242
ERROR - 2019-10-16 17:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:57:53 --> Total execution time: 0.0516
ERROR - 2019-10-16 17:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:53 --> UTF-8 Support Enabled
ERROR - 2019-10-16 17:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:53 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-16 17:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 17:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:53 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-16 17:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:53 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 17:57:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:53 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 17:57:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:57:54 --> Total execution time: 0.0432
ERROR - 2019-10-16 17:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:57:55 --> Total execution time: 0.0046
ERROR - 2019-10-16 17:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 17:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 17:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:55 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-10-16 17:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:55 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 17:57:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:57:55 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 17:57:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:57:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:57:59 --> Total execution time: 0.0024
ERROR - 2019-10-16 17:58:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:58:03 --> No URI present. Default controller set.
DEBUG - 2019-10-16 17:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:58:03 --> Total execution time: 0.0107
ERROR - 2019-10-16 17:58:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:58:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:58:05 --> Total execution time: 0.0283
ERROR - 2019-10-16 17:58:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:58:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:58:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:58:05 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-16 17:58:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:58:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:58:15 --> Total execution time: 0.0071
ERROR - 2019-10-16 17:58:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:58:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:58:17 --> Total execution time: 0.0252
ERROR - 2019-10-16 17:58:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:58:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:58:56 --> Total execution time: 0.0069
ERROR - 2019-10-16 17:59:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:00 --> Total execution time: 0.0039
ERROR - 2019-10-16 17:59:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:02 --> Total execution time: 0.0023
ERROR - 2019-10-16 17:59:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:03 --> Total execution time: 0.0043
ERROR - 2019-10-16 17:59:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:06 --> Total execution time: 0.0595
ERROR - 2019-10-16 17:59:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:19 --> Total execution time: 0.0056
ERROR - 2019-10-16 17:59:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:19 --> Total execution time: 0.0054
ERROR - 2019-10-16 17:59:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:20 --> Total execution time: 0.0048
ERROR - 2019-10-16 17:59:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:22 --> Total execution time: 0.0041
ERROR - 2019-10-16 17:59:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:24 --> Total execution time: 0.0690
ERROR - 2019-10-16 17:59:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:28 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:28 --> Total execution time: 0.0235
ERROR - 2019-10-16 17:59:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:35 --> Total execution time: 0.0078
ERROR - 2019-10-16 17:59:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:38 --> Total execution time: 0.0023
ERROR - 2019-10-16 17:59:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:40 --> Total execution time: 0.0628
ERROR - 2019-10-16 17:59:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:43 --> Total execution time: 0.0298
ERROR - 2019-10-16 17:59:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:47 --> Total execution time: 0.0197
ERROR - 2019-10-16 17:59:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 17:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 17:59:55 --> Total execution time: 0.0073
ERROR - 2019-10-16 17:59:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 17:59:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 17:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 17:59:55 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-10-16 18:00:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:00:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:00:57 --> Total execution time: 0.0044
ERROR - 2019-10-16 18:00:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:00:57 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:00:57 --> Total execution time: 0.0025
ERROR - 2019-10-16 18:00:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:00:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:00:59 --> Total execution time: 0.0112
ERROR - 2019-10-16 18:01:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:01:06 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:01:06 --> Total execution time: 0.0024
ERROR - 2019-10-16 18:01:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:01:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:01:07 --> Total execution time: 0.0089
ERROR - 2019-10-16 18:02:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:02:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:02:46 --> Total execution time: 0.0025
ERROR - 2019-10-16 18:02:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:02:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:02:48 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:02:48 --> Total execution time: 0.0059
ERROR - 2019-10-16 18:02:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:02:51 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:02:51 --> Total execution time: 0.0132
ERROR - 2019-10-16 18:02:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 18:02:52 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-16 18:02:52 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-16 18:02:52 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-16 18:02:52 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-16 18:02:52 --> Total execution time: 0.0197
ERROR - 2019-10-16 18:02:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 18:02:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:02:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:02:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:02:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:02:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:02:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:02:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:03:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:03:05 --> Total execution time: 0.0021
ERROR - 2019-10-16 18:03:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:08 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:08 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:03:08 --> Total execution time: 0.0099
ERROR - 2019-10-16 18:03:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:03:10 --> Total execution time: 0.0099
ERROR - 2019-10-16 18:03:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:03:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:03:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:03:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:03:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:03:10 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:03:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:10 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:03:10 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:03:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:03:14 --> Total execution time: 0.0026
ERROR - 2019-10-16 18:03:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:17 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:03:17 --> Total execution time: 0.0083
ERROR - 2019-10-16 18:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 18:03:19 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-16 18:03:19 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-16 18:03:19 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
ERROR - 2019-10-16 18:03:19 --> Severity: Warning --> max(): When only one parameter is given, it must be an array /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-16 18:03:19 --> Total execution time: 0.0066
ERROR - 2019-10-16 18:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:03:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:03:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:03:19 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:03:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:03:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 18:04:21 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-16 18:04:21 --> Total execution time: 0.0095
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 18:04:21 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-16 18:04:21 --> Total execution time: 0.0049
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:21 --> 404 Page Not Found: Vendor/datatables
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:21 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:21 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 18:04:21 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-16 18:04:22 --> Total execution time: 0.0035
ERROR - 2019-10-16 18:04:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:22 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:22 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:22 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:22 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 18:04:35 --> Severity: Notice --> Undefined variable: timetable /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-16 18:04:35 --> Total execution time: 0.0102
ERROR - 2019-10-16 18:04:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-10-16 18:04:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:35 --> 404 Page Not Found: Js/examples
DEBUG - 2019-10-16 18:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:35 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:35 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:35 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-16 18:04:43 --> Severity: Notice --> Undefined variable: timetables /var/www/html/School19/application/views/my_class.php 63
DEBUG - 2019-10-16 18:04:43 --> Total execution time: 0.0071
ERROR - 2019-10-16 18:04:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:43 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:43 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:43 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:04:56 --> Total execution time: 0.0064
ERROR - 2019-10-16 18:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:56 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:04:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:04:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:04:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:04:56 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:05:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:05:04 --> Total execution time: 0.0034
ERROR - 2019-10-16 18:05:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:07 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:07 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:05:07 --> Total execution time: 0.0107
ERROR - 2019-10-16 18:05:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:05:13 --> Total execution time: 0.0100
ERROR - 2019-10-16 18:05:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:05:16 --> Total execution time: 0.0020
ERROR - 2019-10-16 18:05:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:20 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:05:20 --> Total execution time: 0.0133
ERROR - 2019-10-16 18:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:05:22 --> Total execution time: 0.0094
ERROR - 2019-10-16 18:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:05:22 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:05:22 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:05:22 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:05:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:05:22 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:05:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:05:26 --> Total execution time: 0.0028
ERROR - 2019-10-16 18:05:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:05:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:05:29 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:05:29 --> Total execution time: 0.0074
ERROR - 2019-10-16 18:06:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:06:03 --> Total execution time: 0.0048
ERROR - 2019-10-16 18:06:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:06:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:06:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:06:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:06:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:06:03 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:06:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:06:03 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:06:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:06:04 --> Total execution time: 0.0070
ERROR - 2019-10-16 18:06:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:06:12 --> Total execution time: 0.0066
ERROR - 2019-10-16 18:06:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:06:14 --> Total execution time: 0.0078
ERROR - 2019-10-16 18:06:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:06:17 --> Total execution time: 0.0025
ERROR - 2019-10-16 18:06:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:06:20 --> Total execution time: 0.0071
ERROR - 2019-10-16 18:06:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:06:26 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:06:26 --> Total execution time: 0.0056
ERROR - 2019-10-16 18:07:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:07:15 --> Total execution time: 0.0034
ERROR - 2019-10-16 18:07:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:07:18 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:07:18 --> Total execution time: 0.0090
ERROR - 2019-10-16 18:07:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:07:22 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:07:22 --> Total execution time: 0.0061
ERROR - 2019-10-16 18:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:07:23 --> Total execution time: 0.0048
ERROR - 2019-10-16 18:07:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:07:27 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:07:27 --> Total execution time: 0.0116
ERROR - 2019-10-16 18:08:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:08:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:08:40 --> Total execution time: 0.0027
ERROR - 2019-10-16 18:08:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:08:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:08:48 --> Total execution time: 0.0041
ERROR - 2019-10-16 18:08:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:08:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:08:53 --> Total execution time: 0.0033
ERROR - 2019-10-16 18:08:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:08:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:08:56 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:08:56 --> Total execution time: 0.0070
ERROR - 2019-10-16 18:09:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:00 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:00 --> Total execution time: 0.0086
ERROR - 2019-10-16 18:09:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:02 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:02 --> Total execution time: 0.0025
ERROR - 2019-10-16 18:09:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:05 --> Total execution time: 0.0105
ERROR - 2019-10-16 18:09:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:09 --> Total execution time: 0.0090
ERROR - 2019-10-16 18:09:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:12 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:12 --> Total execution time: 0.0069
ERROR - 2019-10-16 18:09:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:16 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:16 --> Total execution time: 0.0074
ERROR - 2019-10-16 18:09:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:18 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:18 --> Total execution time: 0.0040
ERROR - 2019-10-16 18:09:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:21 --> Total execution time: 0.0077
ERROR - 2019-10-16 18:09:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:29 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:29 --> Total execution time: 0.0039
ERROR - 2019-10-16 18:09:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:33 --> No URI present. Default controller set.
DEBUG - 2019-10-16 18:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:33 --> Total execution time: 0.0103
ERROR - 2019-10-16 18:09:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:36 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:36 --> Total execution time: 0.0072
ERROR - 2019-10-16 18:09:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:38 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:38 --> Total execution time: 0.0026
ERROR - 2019-10-16 18:09:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:41 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:41 --> Total execution time: 0.0098
ERROR - 2019-10-16 18:09:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:46 --> Total execution time: 0.0096
ERROR - 2019-10-16 18:09:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:49 --> Total execution time: 0.0070
ERROR - 2019-10-16 18:09:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:09:53 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:09:53 --> Total execution time: 0.0084
ERROR - 2019-10-16 18:10:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:03 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:10:03 --> Total execution time: 0.0074
ERROR - 2019-10-16 18:10:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:10:05 --> Total execution time: 0.0063
ERROR - 2019-10-16 18:10:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:09 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:10:09 --> Total execution time: 0.0080
ERROR - 2019-10-16 18:10:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:10:13 --> Total execution time: 0.0069
ERROR - 2019-10-16 18:10:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:10:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:10:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:10:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:10:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:10:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-10-16 18:10:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-10-16 18:10:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-10-16 18:10:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:10:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:10:15 --> Total execution time: 0.0077
ERROR - 2019-10-16 18:12:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:12:52 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:12:52 --> Total execution time: 0.0788
ERROR - 2019-10-16 18:12:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:12:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:12:56 --> Total execution time: 0.0160
ERROR - 2019-10-16 18:13:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:13:15 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:13:16 --> Total execution time: 0.0068
ERROR - 2019-10-16 18:14:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:14:59 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:14:59 --> Total execution time: 0.0103
ERROR - 2019-10-16 18:16:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:16:19 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:16:19 --> Total execution time: 0.0120
ERROR - 2019-10-16 18:16:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:16:44 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:16:44 --> Total execution time: 0.0066
ERROR - 2019-10-16 18:17:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:17:37 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:17:37 --> Total execution time: 0.0074
ERROR - 2019-10-16 18:18:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:18:17 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:18:17 --> Total execution time: 0.0113
ERROR - 2019-10-16 18:19:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-16 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2019-10-16 18:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-16 18:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-16 18:19:04 --> Total execution time: 0.0075
