<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-11 17:44:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-11 17:44:33 --> UTF-8 Support Enabled
DEBUG - 2019-10-11 17:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-11 17:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-11 17:44:33 --> Total execution time: 0.6080
ERROR - 2019-10-11 17:44:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-11 17:44:40 --> UTF-8 Support Enabled
DEBUG - 2019-10-11 17:44:40 --> No URI present. Default controller set.
DEBUG - 2019-10-11 17:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-11 17:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-11 17:44:40 --> Total execution time: 0.4251
ERROR - 2019-10-11 17:44:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-11 17:44:47 --> UTF-8 Support Enabled
DEBUG - 2019-10-11 17:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-11 17:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-10-11 17:44:47 --> Severity: error --> Exception: Call to undefined method m_sections::subject_show() /var/www/html/School19/application/controllers/Welcome.php 985
ERROR - 2019-10-11 17:45:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-11 17:45:48 --> UTF-8 Support Enabled
DEBUG - 2019-10-11 17:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-11 17:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-11 17:45:48 --> Total execution time: 0.0138
ERROR - 2019-10-11 17:45:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-11 17:45:55 --> UTF-8 Support Enabled
DEBUG - 2019-10-11 17:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-11 17:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-11 17:45:55 --> Total execution time: 0.0273
ERROR - 2019-10-11 17:45:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-11 17:45:58 --> UTF-8 Support Enabled
DEBUG - 2019-10-11 17:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-11 17:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-11 17:45:58 --> Total execution time: 0.0046
ERROR - 2019-10-11 17:46:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-11 17:46:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-11 17:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-11 17:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-11 17:46:05 --> Total execution time: 0.0615
