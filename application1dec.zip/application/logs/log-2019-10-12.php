<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-12 13:15:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-12 13:15:46 --> UTF-8 Support Enabled
DEBUG - 2019-10-12 13:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-12 13:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-12 13:15:47 --> Total execution time: 1.0085
ERROR - 2019-10-12 13:16:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-10-12 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2019-10-12 13:16:05 --> No URI present. Default controller set.
DEBUG - 2019-10-12 13:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-12 13:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-10-12 13:16:07 --> Total execution time: 2.1361
