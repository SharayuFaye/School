<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-08 11:33:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-08 11:33:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-08 11:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-08 11:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-08 11:33:47 --> Total execution time: 5.2079
ERROR - 2019-11-08 11:34:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-08 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-08 11:34:05 --> No URI present. Default controller set.
DEBUG - 2019-11-08 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-08 11:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-08 11:34:06 --> admin :: admin
DEBUG - 2019-11-08 11:34:06 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-08 11:34:10 --> Total execution time: 4.7966
ERROR - 2019-11-08 11:34:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-08 11:34:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-08 11:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-08 11:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-08 11:34:25 --> Total execution time: 0.0398
ERROR - 2019-11-08 11:34:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-08 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-08 11:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-08 11:34:26 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-08 11:34:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-08 11:34:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-08 11:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-08 11:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-08 11:34:52 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `school`
WHERE `school_name` = 'Disha'
AND `school_mail` = 'aa@a.com'
AND `school_mobile` = '2147483611'
AND `school_mobile2` = '2147483621'
AND `school_id` = '0'
AND `id` != '3'
ERROR - 2019-11-08 11:34:52 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /var/www/html/School19/application/models/M_school.php 39
ERROR - 2019-11-08 11:34:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-08 11:36:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-08 11:36:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-08 11:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-08 11:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-08 11:36:33 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `school`
WHERE `school_name` = 'Disha'
AND `school_mail` = 'aa@a.com'
AND `school_id` = '0'
AND `id` != '3'
ERROR - 2019-11-08 11:36:33 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /var/www/html/School19/application/models/M_school.php 37
ERROR - 2019-11-08 11:36:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-08 11:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-08 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-08 11:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-08 11:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-08 11:37:13 --> Total execution time: 0.1040
ERROR - 2019-11-08 11:37:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-08 11:37:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-08 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-08 11:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-08 11:37:13 --> 404 Page Not Found: Welcome/img
