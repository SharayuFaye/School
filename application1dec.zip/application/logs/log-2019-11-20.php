<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-20 10:30:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 10:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 10:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 10:30:53 --> Total execution time: 7.6742
ERROR - 2019-11-20 10:30:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 10:31:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 10:31:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 10:31:17 --> No URI present. Default controller set.
DEBUG - 2019-11-20 10:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 10:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 10:31:19 --> disha :: Disha@123
DEBUG - 2019-11-20 10:31:19 --> disha :: bbd19846253a953693bb9ece0d18a9c9
DEBUG - 2019-11-20 10:31:20 --> Total execution time: 2.6987
ERROR - 2019-11-20 10:31:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 10:31:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 10:31:33 --> No URI present. Default controller set.
DEBUG - 2019-11-20 10:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 10:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 10:31:33 --> mmd :: Mmd@1234
DEBUG - 2019-11-20 10:31:33 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-20 10:31:34 --> Total execution time: 0.7104
ERROR - 2019-11-20 10:35:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 10:35:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 10:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 10:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 10:35:41 --> Total execution time: 0.0202
ERROR - 2019-11-20 10:35:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 10:35:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 10:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 10:35:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 10:42:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 10:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 10:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 10:42:20 --> Total execution time: 0.0081
ERROR - 2019-11-20 10:42:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 11:25:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:25:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:25:40 --> Total execution time: 0.2186
ERROR - 2019-11-20 11:25:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:25:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:25:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 11:25:41 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 11:25:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 11:27:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:27:11 --> Total execution time: 0.0138
ERROR - 2019-11-20 11:27:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:27:11 --> Total execution time: 0.0041
ERROR - 2019-11-20 11:27:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:27:59 --> Total execution time: 0.0176
ERROR - 2019-11-20 11:27:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 11:27:59 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 11:28:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:28:02 --> Total execution time: 0.0033
ERROR - 2019-11-20 11:28:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:28:02 --> Total execution time: 0.0046
ERROR - 2019-11-20 11:28:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:28:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:28:18 --> Total execution time: 0.2344
ERROR - 2019-11-20 11:28:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 11:28:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:28:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:28:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 11:28:18 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 11:30:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:30:35 --> Total execution time: 0.0163
ERROR - 2019-11-20 11:30:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 11:30:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 11:30:35 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 11:30:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:30:47 --> Total execution time: 0.0054
ERROR - 2019-11-20 11:30:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 11:30:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:30:47 --> Total execution time: 0.0023
ERROR - 2019-11-20 11:30:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:30:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:30:53 --> Total execution time: 0.0110
ERROR - 2019-11-20 11:30:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:30:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 11:30:53 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 11:30:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:30:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:30:59 --> Total execution time: 0.0096
ERROR - 2019-11-20 11:30:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:30:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:30:59 --> Total execution time: 0.0028
ERROR - 2019-11-20 11:31:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:31:32 --> Total execution time: 0.2316
ERROR - 2019-11-20 11:31:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:31:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 11:31:32 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 11:31:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:31:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:31:57 --> Total execution time: 0.0056
ERROR - 2019-11-20 11:31:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:31:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:31:57 --> Total execution time: 0.0031
ERROR - 2019-11-20 11:31:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:31:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:31:59 --> Total execution time: 0.0250
ERROR - 2019-11-20 11:32:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:32:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:32:03 --> Total execution time: 0.0031
ERROR - 2019-11-20 11:37:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:37:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:37:41 --> Total execution time: 0.0147
ERROR - 2019-11-20 11:37:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 11:37:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:37:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 11:37:41 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 11:37:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:37:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:37:45 --> Total execution time: 0.0047
ERROR - 2019-11-20 11:37:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 11:37:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 11:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 11:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 11:37:45 --> Total execution time: 0.0030
ERROR - 2019-11-20 16:56:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:56:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:56:34 --> Total execution time: 0.0024
ERROR - 2019-11-20 16:56:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:56:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:56:38 --> No URI present. Default controller set.
DEBUG - 2019-11-20 16:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:56:38 --> mmd :: Mmd@1234
DEBUG - 2019-11-20 16:56:38 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-20 16:56:38 --> Total execution time: 0.0656
ERROR - 2019-11-20 16:56:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:56:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:56:43 --> Total execution time: 0.0082
ERROR - 2019-11-20 16:56:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:56:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 16:56:43 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 16:56:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:56:44 --> Total execution time: 0.0042
ERROR - 2019-11-20 16:56:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:56:44 --> Total execution time: 0.0028
ERROR - 2019-11-20 16:57:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:57:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:57:14 --> Total execution time: 1.6664
ERROR - 2019-11-20 16:57:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:57:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:57:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 16:57:14 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 16:57:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 16:57:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:57:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:57:19 --> Total execution time: 0.0049
ERROR - 2019-11-20 16:57:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:57:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:57:19 --> Total execution time: 0.0028
ERROR - 2019-11-20 16:57:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:57:51 --> Total execution time: 0.0256
ERROR - 2019-11-20 16:57:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:57:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:57:59 --> Total execution time: 0.0137
ERROR - 2019-11-20 16:58:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:58:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:58:39 --> Total execution time: 0.0068
ERROR - 2019-11-20 16:58:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 16:58:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:58:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:58:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 16:58:39 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 16:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 16:58:48 --> Total execution time: 0.0128
ERROR - 2019-11-20 16:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 16:58:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 16:58:48 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 17:05:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:21 --> Total execution time: 0.0394
ERROR - 2019-11-20 17:05:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:23 --> Total execution time: 0.0074
ERROR - 2019-11-20 17:05:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 17:05:23 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 17:05:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:25 --> Total execution time: 0.0036
ERROR - 2019-11-20 17:05:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:25 --> Total execution time: 0.0027
ERROR - 2019-11-20 17:05:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:25 --> Total execution time: 0.0062
ERROR - 2019-11-20 17:05:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 17:05:25 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 17:05:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:38 --> Total execution time: 0.2282
ERROR - 2019-11-20 17:05:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 17:05:38 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 17:05:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:48 --> Total execution time: 0.0097
ERROR - 2019-11-20 17:05:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 17:05:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 17:05:49 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 17:05:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:55 --> Total execution time: 0.0052
ERROR - 2019-11-20 17:05:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:05:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:05:55 --> Total execution time: 0.0028
ERROR - 2019-11-20 17:07:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:07:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:07:14 --> Total execution time: 0.0060
ERROR - 2019-11-20 17:07:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:07:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:07:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 17:07:14 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 17:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:07:23 --> Total execution time: 0.0047
ERROR - 2019-11-20 17:07:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 17:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:07:23 --> Total execution time: 0.0021
ERROR - 2019-11-20 17:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:07:23 --> Total execution time: 0.0175
ERROR - 2019-11-20 17:07:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:07:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:07:25 --> Total execution time: 0.0051
ERROR - 2019-11-20 17:07:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:07:35 --> Total execution time: 0.2261
ERROR - 2019-11-20 17:46:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:46:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:46:02 --> Total execution time: 0.0926
ERROR - 2019-11-20 17:46:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:46:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:46:09 --> Total execution time: 0.0075
ERROR - 2019-11-20 17:46:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:46:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 17:46:09 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 17:46:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:46:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:46:10 --> Total execution time: 0.0024
ERROR - 2019-11-20 17:46:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:46:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:46:10 --> Total execution time: 0.0030
ERROR - 2019-11-20 17:56:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 17:56:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 17:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 17:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 17:56:50 --> Total execution time: 0.0040
ERROR - 2019-11-20 18:00:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:00:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:00:13 --> Total execution time: 0.0185
ERROR - 2019-11-20 18:01:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:01:44 --> Total execution time: 0.0022
ERROR - 2019-11-20 18:20:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:20:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:20:13 --> No URI present. Default controller set.
DEBUG - 2019-11-20 18:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:20:13 --> mmd :: Mmd@1234
DEBUG - 2019-11-20 18:20:13 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-20 18:20:13 --> Total execution time: 0.0728
ERROR - 2019-11-20 18:20:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:20:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:20:27 --> Total execution time: 0.0124
ERROR - 2019-11-20 18:20:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:20:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:20:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:20:27 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:20:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:20:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:20:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:20:31 --> Total execution time: 0.0022
ERROR - 2019-11-20 18:20:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:20:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:20:31 --> Total execution time: 0.0033
ERROR - 2019-11-20 18:20:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:20:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:20:40 --> Total execution time: 0.0073
ERROR - 2019-11-20 18:20:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:20:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:20:51 --> Total execution time: 0.0052
ERROR - 2019-11-20 18:21:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:21:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:21:11 --> Total execution time: 0.0081
ERROR - 2019-11-20 18:21:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:21:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:21:11 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:21:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:21:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:21:13 --> Total execution time: 0.0032
ERROR - 2019-11-20 18:21:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:21:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:21:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:21:13 --> Total execution time: 0.0035
ERROR - 2019-11-20 18:21:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:21:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:21:16 --> Total execution time: 0.0034
ERROR - 2019-11-20 18:21:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:21:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:21:44 --> Total execution time: 0.0056
ERROR - 2019-11-20 18:22:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:22:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:22:25 --> Total execution time: 0.0063
ERROR - 2019-11-20 18:22:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:22:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:22:28 --> Total execution time: 0.0029
ERROR - 2019-11-20 18:27:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:27:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:27:55 --> Total execution time: 0.0218
ERROR - 2019-11-20 18:27:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:27:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:27:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:27:55 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:28:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:28:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:28:05 --> Total execution time: 0.0092
ERROR - 2019-11-20 18:28:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:28:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:28:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:28:05 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:28:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:28:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:28:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:28:06 --> Total execution time: 0.0115
ERROR - 2019-11-20 18:28:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:28:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:28:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:28:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:28:06 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:28:40 --> Total execution time: 0.0105
ERROR - 2019-11-20 18:28:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:28:40 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:28:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:29:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:29:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:29:22 --> Total execution time: 0.0107
ERROR - 2019-11-20 18:29:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:29:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:29:23 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:30:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:30:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:30:17 --> Total execution time: 0.0132
ERROR - 2019-11-20 18:30:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:30:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:30:17 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:30:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:30:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:30:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:30:28 --> Total execution time: 0.0039
ERROR - 2019-11-20 18:32:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:32:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:32:43 --> Total execution time: 0.0090
ERROR - 2019-11-20 18:32:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:32:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:32:43 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:32:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:32:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:32:48 --> Total execution time: 0.0030
ERROR - 2019-11-20 18:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:33:44 --> Total execution time: 0.0098
ERROR - 2019-11-20 18:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:33:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:33:44 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:33:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:33:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:33:48 --> Total execution time: 0.0056
ERROR - 2019-11-20 18:33:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:34:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:34:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:34:30 --> Total execution time: 0.0108
ERROR - 2019-11-20 18:34:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:34:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:34:31 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:34:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:34:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:34:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:34:34 --> Total execution time: 0.0034
ERROR - 2019-11-20 18:34:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:34:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:34:41 --> Total execution time: 0.0071
ERROR - 2019-11-20 18:34:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:34:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:34:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:34:56 --> Total execution time: 0.0118
ERROR - 2019-11-20 18:34:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:34:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:34:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:34:56 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:34:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:34:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:34:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:34:59 --> Total execution time: 0.0035
ERROR - 2019-11-20 18:35:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:35:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:35:02 --> Total execution time: 0.0030
ERROR - 2019-11-20 18:35:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:35:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:35:14 --> Total execution time: 0.0078
ERROR - 2019-11-20 18:35:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:35:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:35:16 --> Total execution time: 0.0030
ERROR - 2019-11-20 18:40:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:40:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:40:03 --> Total execution time: 0.0092
ERROR - 2019-11-20 18:40:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:40:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:40:04 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:40:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:40:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:40:08 --> Total execution time: 0.0101
ERROR - 2019-11-20 18:40:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:41:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:41:08 --> Total execution time: 0.0124
ERROR - 2019-11-20 18:41:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:41:08 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:41:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:41:08 --> Total execution time: 0.0122
ERROR - 2019-11-20 18:41:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:41:09 --> Total execution time: 0.0112
ERROR - 2019-11-20 18:41:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:41:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:41:09 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:41:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:41:09 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:41:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:41:20 --> Total execution time: 0.0048
ERROR - 2019-11-20 18:41:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:41:33 --> Total execution time: 0.0024
ERROR - 2019-11-20 18:41:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:41:45 --> Total execution time: 0.0051
ERROR - 2019-11-20 18:41:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:41:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:41:50 --> Total execution time: 0.1330
ERROR - 2019-11-20 18:41:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:41:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:41:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:41:51 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 18:41:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:42:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:42:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:42:44 --> Total execution time: 0.0202
ERROR - 2019-11-20 18:42:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:42:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:42:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:42:44 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 18:42:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:42:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:42:51 --> Total execution time: 0.0069
ERROR - 2019-11-20 18:42:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:42:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:42:53 --> Total execution time: 0.0056
ERROR - 2019-11-20 18:43:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:43:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:43:04 --> Total execution time: 0.0049
ERROR - 2019-11-20 18:43:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:43:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:43:06 --> Total execution time: 0.0030
ERROR - 2019-11-20 18:43:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:43:10 --> Total execution time: 0.1407
ERROR - 2019-11-20 18:43:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:43:10 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 18:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:46:59 --> Total execution time: 0.0088
ERROR - 2019-11-20 18:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:46:59 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 18:47:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:47:06 --> Total execution time: 0.0386
ERROR - 2019-11-20 18:47:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:47:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:47:06 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 18:50:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:50:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Query error: Duplicate entry 's1@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s1@gmail.com', '0102812fbd5f73aa18aa0bae2cd8f79f', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Query error: Duplicate entry 's2@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s2@gmail.com', '0bd0fe6372c64e09c4ae81e056a9dbda', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Query error: Duplicate entry 's1@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s1@gmail.com', 'c868bff94e54b8eddbdbce22159c0299', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Query error: Duplicate entry 's2@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s2@gmail.com', 'd1f38b569c772ebb8fa464e1a90c5a00', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Query error: Duplicate entry 's1@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s1@gmail.com', 'b279786ec5a7ed00dbe4d3fe1516c121', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Query error: Duplicate entry 's2@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s2@gmail.com', '66c99bf933f5e6bf3bf2052d66577ca8', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:47 --> Query error: Duplicate entry 's1@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s1@gmail.com', '6c2a5c9ead1d7d6ba86c8764d5cad395', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:47 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:48 --> Query error: Duplicate entry 's2@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s2@gmail.com', '64152ab7368fc7ca6b3ef6b71e330b86', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:48 --> Query error: Duplicate entry 's1@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s1@gmail.com', '1f61b744f2c9e8f49ae4c4965f39963f', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 303
ERROR - 2019-11-20 18:50:48 --> Query error: Duplicate entry 's2@gmail.com' for key 'username' - Invalid query: INSERT INTO `users` (`username`, `password`, `school_id`, `role`, `created_date`, `created_by`) VALUES ('s2@gmail.com', '90bfa11df19a9b9d429ccfa6997104df', '11', 'student', '2019-11-20', '148')
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/models/M_students.php 337
ERROR - 2019-11-20 18:50:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/models/M_students.php 337
DEBUG - 2019-11-20 18:50:48 --> Total execution time: 1.5700
ERROR - 2019-11-20 18:50:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:50:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:50:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:50:48 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 18:52:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:52:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:52:00 --> Total execution time: 0.0599
ERROR - 2019-11-20 18:52:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:52:01 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 18:52:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:55:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:55:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:55:27 --> Total execution time: 0.0057
ERROR - 2019-11-20 18:55:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:55:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:55:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:55:27 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-20 18:55:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:55:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 18:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 18:55:34 --> Total execution time: 0.0198
ERROR - 2019-11-20 18:55:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 18:55:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 18:55:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 18:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 18:55:34 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 18:55:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-20 19:01:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 19:01:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 19:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 19:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 19:01:37 --> Total execution time: 0.1557
ERROR - 2019-11-20 19:01:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 19:01:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 19:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 19:01:37 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-20 19:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 19:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 19:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 19:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-20 19:07:23 --> Total execution time: 0.0128
ERROR - 2019-11-20 19:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-20 19:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-20 19:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-20 19:07:23 --> 404 Page Not Found: Welcome/profile
