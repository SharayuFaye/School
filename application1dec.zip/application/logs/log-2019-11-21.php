<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-21 10:31:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 10:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 10:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 10:32:06 --> Total execution time: 7.2302
ERROR - 2019-11-21 10:32:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 11:16:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:16:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 11:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 11:16:15 --> Total execution time: 0.0374
ERROR - 2019-11-21 11:16:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 11:16:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:16:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:16:23 --> No URI present. Default controller set.
DEBUG - 2019-11-21 11:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 11:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 11:16:23 --> mmd :: Mmd@1234
DEBUG - 2019-11-21 11:16:23 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-21 11:16:23 --> Total execution time: 0.2322
ERROR - 2019-11-21 11:16:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 11:16:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:16:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 11:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 11:16:28 --> Total execution time: 0.0097
ERROR - 2019-11-21 11:16:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:16:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:16:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 11:16:29 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-21 11:19:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:19:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 11:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 11:19:02 --> Total execution time: 0.0741
ERROR - 2019-11-21 11:19:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 11:19:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:19:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 11:19:02 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 11:19:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:19:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 11:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 11:19:07 --> Total execution time: 0.0145
ERROR - 2019-11-21 11:19:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:19:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 11:19:07 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 11:21:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:21:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 11:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 11:21:47 --> Total execution time: 0.0143
ERROR - 2019-11-21 11:21:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 11:21:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 11:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 11:21:47 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 11:21:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 14:41:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:41:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:41:49 --> Total execution time: 0.0034
ERROR - 2019-11-21 14:41:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:41:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:41:59 --> No URI present. Default controller set.
DEBUG - 2019-11-21 14:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:41:59 --> mmd :: Mmd@1234
DEBUG - 2019-11-21 14:41:59 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-21 14:42:00 --> Total execution time: 0.0655
ERROR - 2019-11-21 14:42:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:42:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:42:03 --> Total execution time: 0.0078
ERROR - 2019-11-21 14:42:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:42:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:42:32 --> Total execution time: 0.0109
ERROR - 2019-11-21 14:42:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:42:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:42:53 --> Total execution time: 0.0125
ERROR - 2019-11-21 14:43:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:43:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:43:09 --> Total execution time: 0.0090
ERROR - 2019-11-21 14:43:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:43:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 14:43:14 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Marathi', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:14 --> Query error: Duplicate entry 'Hindi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Hindi', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:14 --> Query error: Duplicate entry 'Sanskrit' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Sanskrit', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:14 --> Query error: Duplicate entry 'Science' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Science', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:14 --> Query error: Duplicate entry 'History' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'History', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:15 --> Query error: Duplicate entry 'Biology' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Biology', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:15 --> Query error: Duplicate entry 'Chemistry' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Chemistry', '2019-11-21', '148')
DEBUG - 2019-11-21 14:43:15 --> Total execution time: 0.9030
ERROR - 2019-11-21 14:43:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:43:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 14:43:41 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Marathi', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:41 --> Query error: Duplicate entry 'Hindi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Hindi', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:41 --> Query error: Duplicate entry 'Sanskrit' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Sanskrit', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:41 --> Query error: Duplicate entry 'Science' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Science', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:41 --> Query error: Duplicate entry 'History' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'History', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:41 --> Query error: Duplicate entry 'Biology' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Biology', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:41 --> Query error: Duplicate entry 'Chemistry' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Chemistry', '2019-11-21', '148')
DEBUG - 2019-11-21 14:43:41 --> Total execution time: 0.4504
ERROR - 2019-11-21 14:43:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 14:43:48 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Marathi', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:48 --> Query error: Duplicate entry 'Hindi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Hindi', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:48 --> Query error: Duplicate entry 'Sanskrit' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Sanskrit', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:48 --> Query error: Duplicate entry 'Science' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Science', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:48 --> Query error: Duplicate entry 'History' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'History', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:48 --> Query error: Duplicate entry 'Biology' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Biology', '2019-11-21', '148')
ERROR - 2019-11-21 14:43:48 --> Query error: Duplicate entry 'Chemistry' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Chemistry', '2019-11-21', '148')
DEBUG - 2019-11-21 14:43:49 --> Total execution time: 0.5526
ERROR - 2019-11-21 14:44:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 14:44:53 --> Query error: Duplicate entry 'Physics' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Physics', '2019-11-21', '148')
DEBUG - 2019-11-21 14:44:53 --> Total execution time: 0.1677
ERROR - 2019-11-21 14:45:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:45:38 --> Total execution time: 0.0132
ERROR - 2019-11-21 14:45:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:45:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:45:53 --> Total execution time: 0.0122
ERROR - 2019-11-21 14:45:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:45:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:45:59 --> Total execution time: 0.0137
ERROR - 2019-11-21 14:46:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:46:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:46:01 --> Total execution time: 0.0054
ERROR - 2019-11-21 14:46:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:46:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:46:02 --> Total execution time: 0.0045
ERROR - 2019-11-21 14:46:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:46:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:46:04 --> Total execution time: 0.0597
ERROR - 2019-11-21 14:48:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:48:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:48:51 --> Total execution time: 0.0044
ERROR - 2019-11-21 14:48:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:48:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:48:54 --> Total execution time: 0.0110
ERROR - 2019-11-21 14:48:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:48:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:48:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 14:48:54 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-21 14:49:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:02 --> Total execution time: 0.0032
ERROR - 2019-11-21 14:49:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:08 --> Total execution time: 0.2042
ERROR - 2019-11-21 14:49:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 14:49:08 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 14:49:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 14:49:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:11 --> Total execution time: 0.0066
ERROR - 2019-11-21 14:49:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:17 --> Total execution time: 0.0145
ERROR - 2019-11-21 14:49:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:22 --> Total execution time: 0.0024
ERROR - 2019-11-21 14:49:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:23 --> Total execution time: 0.0036
ERROR - 2019-11-21 14:49:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:24 --> Total execution time: 0.0068
ERROR - 2019-11-21 14:49:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:37 --> Total execution time: 0.1190
ERROR - 2019-11-21 14:49:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:37 --> Total execution time: 0.0133
ERROR - 2019-11-21 14:49:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:49:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:49:58 --> Total execution time: 0.0119
ERROR - 2019-11-21 14:50:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:50:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:50:03 --> Total execution time: 0.0037
ERROR - 2019-11-21 14:50:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:50:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:50:05 --> Total execution time: 0.0029
ERROR - 2019-11-21 14:50:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:50:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:50:13 --> Total execution time: 0.0586
ERROR - 2019-11-21 14:50:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:50:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:50:13 --> Total execution time: 0.0071
ERROR - 2019-11-21 14:50:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:50:22 --> Total execution time: 0.0115
ERROR - 2019-11-21 14:50:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:50:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:50:43 --> Total execution time: 0.0029
ERROR - 2019-11-21 14:50:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:50:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:50:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 14:50:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:50:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:50:46 --> Total execution time: 0.0071
DEBUG - 2019-11-21 14:50:46 --> Total execution time: 0.0064
ERROR - 2019-11-21 14:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:51:04 --> Total execution time: 0.0048
ERROR - 2019-11-21 14:51:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:51:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:51:09 --> Total execution time: 0.0884
ERROR - 2019-11-21 14:51:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:51:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:51:10 --> Total execution time: 0.0125
ERROR - 2019-11-21 14:57:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:57:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:57:21 --> Total execution time: 0.0112
ERROR - 2019-11-21 14:57:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:57:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:57:27 --> Total execution time: 0.0031
ERROR - 2019-11-21 14:57:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:57:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:57:28 --> Total execution time: 0.0048
ERROR - 2019-11-21 14:57:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:57:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:57:32 --> Total execution time: 0.0595
ERROR - 2019-11-21 14:57:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:57:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:57:34 --> Total execution time: 0.0095
ERROR - 2019-11-21 14:57:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:57:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:57:39 --> Total execution time: 0.0066
ERROR - 2019-11-21 14:57:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:57:41 --> Total execution time: 0.0076
ERROR - 2019-11-21 14:57:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 14:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 14:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 14:57:43 --> Total execution time: 0.0068
ERROR - 2019-11-21 16:33:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:07 --> Total execution time: 0.0094
ERROR - 2019-11-21 16:33:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:10 --> Total execution time: 0.0024
ERROR - 2019-11-21 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:12 --> Total execution time: 0.0086
ERROR - 2019-11-21 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:33:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-21 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:33:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-21 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:33:12 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-21 16:33:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:33:12 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-21 16:33:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:14 --> Total execution time: 0.0026
ERROR - 2019-11-21 16:33:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:16 --> Total execution time: 0.0021
ERROR - 2019-11-21 16:33:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:30 --> Total execution time: 0.0599
ERROR - 2019-11-21 16:33:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:32 --> Total execution time: 0.0022
ERROR - 2019-11-21 16:33:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:35 --> Total execution time: 0.0115
ERROR - 2019-11-21 16:33:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:38 --> Total execution time: 0.0108
ERROR - 2019-11-21 16:33:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:33:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-21 16:33:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:33:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-21 16:33:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:33:38 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-21 16:33:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:33:38 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-21 16:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:44 --> Total execution time: 0.0072
ERROR - 2019-11-21 16:33:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:47 --> Total execution time: 0.0030
ERROR - 2019-11-21 16:33:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:48 --> Total execution time: 0.0083
ERROR - 2019-11-21 16:33:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:33:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:33:55 --> Total execution time: 0.0106
ERROR - 2019-11-21 16:34:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:34:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:34:00 --> Total execution time: 0.0115
ERROR - 2019-11-21 16:34:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:34:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:34:04 --> Total execution time: 0.0057
ERROR - 2019-11-21 16:34:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:34:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:34:04 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-21 16:34:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:34:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:34:24 --> Total execution time: 0.0042
ERROR - 2019-11-21 16:34:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:34:31 --> No URI present. Default controller set.
DEBUG - 2019-11-21 16:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:34:31 --> kk1 :: kk1
DEBUG - 2019-11-21 16:34:31 --> kk1 :: 2d695b9d8fe3bb961924330a0ec67921
DEBUG - 2019-11-21 16:34:31 --> Total execution time: 0.0027
ERROR - 2019-11-21 16:34:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:34:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:34:42 --> No URI present. Default controller set.
DEBUG - 2019-11-21 16:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:34:42 --> mmd :: Mmd@1234
DEBUG - 2019-11-21 16:34:42 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-21 16:34:42 --> Total execution time: 0.0926
ERROR - 2019-11-21 16:34:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:34:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:34:47 --> Total execution time: 0.0042
ERROR - 2019-11-21 16:34:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:34:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:34:47 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-21 16:35:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:35:08 --> Total execution time: 0.1745
ERROR - 2019-11-21 16:35:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:35:08 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:35:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:35:10 --> Total execution time: 0.0030
ERROR - 2019-11-21 16:35:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:18 --> No URI present. Default controller set.
DEBUG - 2019-11-21 16:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:35:18 --> neha@mmd :: Neha1234
DEBUG - 2019-11-21 16:35:18 --> neha@mmd :: 099784d0db9c01e7407dbc5349644208
DEBUG - 2019-11-21 16:35:18 --> Total execution time: 0.0715
ERROR - 2019-11-21 16:35:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:35:24 --> Total execution time: 0.0083
ERROR - 2019-11-21 16:35:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 16:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:35:40 --> Total execution time: 0.0115
ERROR - 2019-11-21 16:35:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:35:42 --> Total execution time: 0.0198
ERROR - 2019-11-21 16:35:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:35:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-21 16:35:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:35:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-21 16:35:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:35:42 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-21 16:35:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:35:42 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-21 16:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:35:59 --> Total execution time: 0.0088
ERROR - 2019-11-21 16:36:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:02 --> Total execution time: 0.0032
ERROR - 2019-11-21 16:36:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:03 --> Total execution time: 0.0086
ERROR - 2019-11-21 16:36:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:08 --> Total execution time: 0.0091
ERROR - 2019-11-21 16:36:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:10 --> Total execution time: 0.0090
ERROR - 2019-11-21 16:36:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:13 --> Total execution time: 0.0071
ERROR - 2019-11-21 16:36:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:20 --> Total execution time: 0.0027
ERROR - 2019-11-21 16:36:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:31 --> Total execution time: 0.0042
ERROR - 2019-11-21 16:36:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:32 --> Total execution time: 0.0044
ERROR - 2019-11-21 16:36:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:33 --> Total execution time: 0.0027
ERROR - 2019-11-21 16:36:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:36 --> Total execution time: 0.0051
ERROR - 2019-11-21 16:36:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:36:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:36:37 --> Total execution time: 0.0035
ERROR - 2019-11-21 16:45:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:45:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:45:00 --> Total execution time: 0.0031
ERROR - 2019-11-21 16:45:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:45:10 --> No URI present. Default controller set.
DEBUG - 2019-11-21 16:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:45:10 --> mmd :: Mmd@1234
DEBUG - 2019-11-21 16:45:10 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-21 16:45:11 --> Total execution time: 0.0824
ERROR - 2019-11-21 16:45:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:45:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:45:17 --> Total execution time: 0.0063
ERROR - 2019-11-21 16:45:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:45:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:45:22 --> Total execution time: 0.1304
ERROR - 2019-11-21 16:46:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:46:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:46:20 --> Total execution time: 0.0112
ERROR - 2019-11-21 16:48:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:48:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:48:50 --> Total execution time: 0.0064
ERROR - 2019-11-21 16:48:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:48:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:48:51 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-21 16:48:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:48:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:48:56 --> Total execution time: 0.0155
ERROR - 2019-11-21 16:48:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:48:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:48:56 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:50:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:50:57 --> Total execution time: 0.0127
ERROR - 2019-11-21 16:50:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:50:57 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:51:04 --> Total execution time: 0.0178
ERROR - 2019-11-21 16:51:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:51:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:51:04 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:52:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:52:31 --> Total execution time: 0.0176
ERROR - 2019-11-21 16:52:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:52:31 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:52:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:52:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:52:45 --> Total execution time: 0.0180
ERROR - 2019-11-21 16:52:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:52:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:52:45 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:53:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:53:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:53:14 --> Total execution time: 0.0047
ERROR - 2019-11-21 16:53:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:53:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:53:14 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:53:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:53:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:53:18 --> Total execution time: 0.0146
ERROR - 2019-11-21 16:53:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:53:19 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:53:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:53:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:53:31 --> Total execution time: 0.0227
ERROR - 2019-11-21 16:53:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:53:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:53:31 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:55:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:55:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:55:46 --> Total execution time: 0.0213
ERROR - 2019-11-21 16:55:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:55:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:55:47 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:55:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:55:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:55:51 --> Total execution time: 0.0065
ERROR - 2019-11-21 16:55:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:55:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:55:51 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:55:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:55:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:55:59 --> Total execution time: 0.0130
ERROR - 2019-11-21 16:55:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:55:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:55:59 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:57:10 --> Total execution time: 0.0135
ERROR - 2019-11-21 16:57:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:57:10 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:57:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:57:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:57:18 --> Total execution time: 0.0173
ERROR - 2019-11-21 16:57:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 16:57:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:57:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:57:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:57:18 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 16:57:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:57:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 16:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 16:57:24 --> Total execution time: 0.0130
ERROR - 2019-11-21 16:57:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 16:57:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 16:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 16:57:24 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:00:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:00:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:00:41 --> Total execution time: 0.0139
ERROR - 2019-11-21 17:00:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:00:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:00:41 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:02:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:02:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:02:05 --> Total execution time: 0.1325
ERROR - 2019-11-21 17:02:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:02:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:02:05 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:02:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:02:28 --> Total execution time: 0.0156
ERROR - 2019-11-21 17:02:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:02:28 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:06:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:06:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:06:41 --> Total execution time: 0.0223
ERROR - 2019-11-21 17:06:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:06:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:06:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:06:41 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:07:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:07:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:07:57 --> Total execution time: 0.0144
ERROR - 2019-11-21 17:07:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:07:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:07:57 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:08:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:08:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:08:11 --> Total execution time: 0.0134
ERROR - 2019-11-21 17:08:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:08:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:08:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:08:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:08:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:08:35 --> Total execution time: 0.0114
ERROR - 2019-11-21 17:08:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:08:35 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:11:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:11:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:14:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:14:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:14:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:14:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:14:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:14:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:15:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:15:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:15:11 --> Total execution time: 0.0076
ERROR - 2019-11-21 17:15:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:15:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:15:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:15:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:15:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:15:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:15:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:15:25 --> Total execution time: 0.0167
ERROR - 2019-11-21 17:15:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:15:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:15:25 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:15:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:15:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:15:41 --> Total execution time: 0.0103
ERROR - 2019-11-21 17:15:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:15:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:15:41 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:30:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:30:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:30:44 --> Total execution time: 0.0125
ERROR - 2019-11-21 17:30:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:30:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:30:45 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-21 17:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:30:51 --> Total execution time: 0.0233
ERROR - 2019-11-21 17:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:30:51 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:31:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:31:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:31:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:31:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:32:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:32:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:33:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:33:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:34:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:34:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:34:17 --> Total execution time: 0.0186
ERROR - 2019-11-21 17:34:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:34:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:34:17 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:36:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:36:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:36:16 --> Total execution time: 0.0235
ERROR - 2019-11-21 17:36:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 17:36:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:36:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:36:16 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:37:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:37:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:37:11 --> Total execution time: 0.0061
ERROR - 2019-11-21 17:37:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:37:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:38:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:38:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 17:38:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 17:39:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:39:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:39:04 --> Total execution time: 0.1094
ERROR - 2019-11-21 17:39:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:39:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:39:04 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:39:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:39:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:39:30 --> Total execution time: 0.0260
ERROR - 2019-11-21 17:39:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 17:39:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:39:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:39:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:39:30 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 17:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 17:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 17:41:11 --> Total execution time: 0.0215
ERROR - 2019-11-21 17:41:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 17:41:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 17:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 17:41:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-21 18:35:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:35:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:35:38 --> Severity: Warning --> Illegal string offset 'name' /var/www/html/School19/application/views/sections.php 265
DEBUG - 2019-11-21 18:35:38 --> Total execution time: 0.0091
ERROR - 2019-11-21 18:35:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 18:36:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:36:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:36:03 --> Severity: Warning --> Illegal string offset 'name' /var/www/html/School19/application/views/sections.php 265
DEBUG - 2019-11-21 18:36:03 --> Total execution time: 0.0095
ERROR - 2019-11-21 18:36:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:36:18 --> Total execution time: 0.0077
ERROR - 2019-11-21 18:37:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:37:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:37:18 --> Severity: Warning --> Illegal string offset 'name' /var/www/html/School19/application/views/sections.php 265
DEBUG - 2019-11-21 18:37:18 --> Total execution time: 0.0064
ERROR - 2019-11-21 18:40:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:40:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:40:54 --> Total execution time: 0.0059
ERROR - 2019-11-21 18:41:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:41:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:41:18 --> Total execution time: 0.0121
ERROR - 2019-11-21 18:42:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:42:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:42:56 --> Severity: Warning --> include(../config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:42:56 --> Severity: Warning --> include(): Failed opening '../config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:42:56 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:42:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:42:56 --> Total execution time: 0.0051
ERROR - 2019-11-21 18:43:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:43:10 --> Severity: Warning --> include(config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:43:10 --> Severity: Warning --> include(): Failed opening 'config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:43:10 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:43:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:43:10 --> Total execution time: 0.0059
ERROR - 2019-11-21 18:43:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:43:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:43:18 --> Severity: Warning --> include(../../config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:43:18 --> Severity: Warning --> include(): Failed opening '../../config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:43:18 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:43:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:43:18 --> Total execution time: 0.0073
ERROR - 2019-11-21 18:43:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:43:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:43:51 --> Severity: Warning --> include(../../../config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:43:51 --> Severity: Warning --> include(): Failed opening '../../../config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:43:51 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:43:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:43:51 --> Total execution time: 0.0069
ERROR - 2019-11-21 18:44:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:44:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:44:15 --> Severity: Warning --> include(../config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:44:15 --> Severity: Warning --> include(): Failed opening '../config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:44:15 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:44:15 --> Total execution time: 0.0093
ERROR - 2019-11-21 18:44:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:44:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:44:15 --> Severity: Warning --> include(../config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:44:15 --> Severity: Warning --> include(): Failed opening '../config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:44:15 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:44:15 --> Total execution time: 0.0067
ERROR - 2019-11-21 18:44:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:44:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:44:35 --> Severity: Warning --> include(../config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:44:35 --> Severity: Warning --> include(): Failed opening '../config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:44:35 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:44:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:44:35 --> Total execution time: 0.0071
ERROR - 2019-11-21 18:44:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-21 18:45:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:45:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:45:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 18:45:23 --> Severity: Warning --> include(../config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/controllers/Welcome.php 5
ERROR - 2019-11-21 18:45:23 --> Severity: Warning --> include(): Failed opening '../config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/controllers/Welcome.php 5
DEBUG - 2019-11-21 18:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:45:23 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 261
ERROR - 2019-11-21 18:45:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 261
DEBUG - 2019-11-21 18:45:23 --> Total execution time: 0.0167
ERROR - 2019-11-21 18:45:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:45:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:45:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 18:45:24 --> Severity: Warning --> include(../config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/controllers/Welcome.php 5
ERROR - 2019-11-21 18:45:24 --> Severity: Warning --> include(): Failed opening '../config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/controllers/Welcome.php 5
DEBUG - 2019-11-21 18:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:45:24 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 261
ERROR - 2019-11-21 18:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 261
DEBUG - 2019-11-21 18:45:24 --> Total execution time: 0.0060
ERROR - 2019-11-21 18:45:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:45:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:45:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 18:45:30 --> Severity: Warning --> include(config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/controllers/Welcome.php 5
ERROR - 2019-11-21 18:45:30 --> Severity: Warning --> include(): Failed opening 'config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/controllers/Welcome.php 5
DEBUG - 2019-11-21 18:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:45:30 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 261
ERROR - 2019-11-21 18:45:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 261
DEBUG - 2019-11-21 18:45:30 --> Total execution time: 0.0123
ERROR - 2019-11-21 18:45:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:45:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 18:45:35 --> Severity: Warning --> include(/config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/controllers/Welcome.php 5
ERROR - 2019-11-21 18:45:35 --> Severity: Warning --> include(): Failed opening '/config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/controllers/Welcome.php 5
DEBUG - 2019-11-21 18:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:45:35 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 261
ERROR - 2019-11-21 18:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 261
DEBUG - 2019-11-21 18:45:35 --> Total execution time: 0.0102
ERROR - 2019-11-21 18:46:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:46:59 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:47:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:47:12 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:47:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:47:25 --> Severity: Warning --> include(config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:25 --> Severity: Warning --> include(): Failed opening 'config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:25 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:47:25 --> Total execution time: 0.0092
ERROR - 2019-11-21 18:47:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:47:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> include(config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> include(): Failed opening 'config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:26 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:47:26 --> Total execution time: 0.0043
ERROR - 2019-11-21 18:47:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:47:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> include(config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> include(): Failed opening 'config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:26 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:47:26 --> Total execution time: 0.0079
ERROR - 2019-11-21 18:47:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:47:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> include(config/subject_list.php): failed to open stream: No such file or directory /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> include(): Failed opening 'config/subject_list.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:47:26 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:47:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:47:26 --> Total execution time: 0.0055
ERROR - 2019-11-21 18:48:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:48:00 --> Severity: error --> Exception: syntax error, unexpected ';' /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:48:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:48:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:48:06 --> Severity: error --> Exception: syntax error, unexpected ''config/subject_list.php'' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/School19/application/views/sections.php 2
ERROR - 2019-11-21 18:48:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:48:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:48:16 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:48:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:48:16 --> Total execution time: 0.0085
ERROR - 2019-11-21 18:48:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:48:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:48:17 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:48:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:48:17 --> Total execution time: 0.0055
ERROR - 2019-11-21 18:48:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:48:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:48:37 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:48:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:48:37 --> Total execution time: 0.0078
ERROR - 2019-11-21 18:49:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:49:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:49:00 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:49:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:49:00 --> Total execution time: 0.0052
ERROR - 2019-11-21 18:49:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:49:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:49:36 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:49:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:49:36 --> Total execution time: 0.0062
ERROR - 2019-11-21 18:50:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:50:41 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:50:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:50:41 --> Total execution time: 0.0047
ERROR - 2019-11-21 18:50:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:50:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:50:42 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:50:42 --> Total execution time: 0.0068
ERROR - 2019-11-21 18:50:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:50:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:50:42 --> Severity: Notice --> Undefined variable: subject_list /var/www/html/School19/application/views/sections.php 262
ERROR - 2019-11-21 18:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/School19/application/views/sections.php 262
DEBUG - 2019-11-21 18:50:42 --> Total execution time: 0.0074
ERROR - 2019-11-21 18:50:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:50:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:50:53 --> Total execution time: 0.0054
ERROR - 2019-11-21 18:51:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:51:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:51:00 --> Total execution time: 0.0087
ERROR - 2019-11-21 18:51:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:51:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:51:13 --> Total execution time: 0.0057
ERROR - 2019-11-21 18:51:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:51:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:51:25 --> Query error: Duplicate entry 'History' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'History', '2019-11-21', '148')
ERROR - 2019-11-21 18:51:25 --> Query error: Duplicate entry 'Chemistry' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Chemistry', '2019-11-21', '148')
ERROR - 2019-11-21 18:51:25 --> Query error: Duplicate entry 'Physics' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `created_date`, `created_by`) VALUES ('11', 'Physics', '2019-11-21', '148')
DEBUG - 2019-11-21 18:51:25 --> Total execution time: 0.2722
ERROR - 2019-11-21 18:51:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:51:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:51:55 --> Total execution time: 0.0074
ERROR - 2019-11-21 18:52:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:52:03 --> Total execution time: 0.0066
ERROR - 2019-11-21 18:52:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:52:50 --> Total execution time: 0.0057
ERROR - 2019-11-21 18:53:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:53:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:53:12 --> Total execution time: 0.0080
ERROR - 2019-11-21 18:53:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:53:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 18:53:45 --> Total execution time: 0.0104
ERROR - 2019-11-21 18:53:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:53:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:53:53 --> Query error: Duplicate entry 'Hindi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Hindi', '2019-11-21', '148')
ERROR - 2019-11-21 18:53:53 --> Query error: Duplicate entry 'Sanskrit' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Sanskrit', '2019-11-21', '148')
ERROR - 2019-11-21 18:53:53 --> Query error: Duplicate entry 'History' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'History', '2019-11-21', '148')
ERROR - 2019-11-21 18:53:53 --> Query error: Duplicate entry 'Chemistry' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Chemistry', '2019-11-21', '148')
ERROR - 2019-11-21 18:53:53 --> Query error: Duplicate entry 'Physics' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Physics', '2019-11-21', '148')
DEBUG - 2019-11-21 18:53:53 --> Total execution time: 0.3955
ERROR - 2019-11-21 18:54:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 18:54:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 18:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 18:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 18:54:05 --> Query error: Duplicate entry 'Hindi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Hindi', '2019-11-21', '148')
ERROR - 2019-11-21 18:54:05 --> Query error: Duplicate entry 'Sanskrit' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Sanskrit', '2019-11-21', '148')
ERROR - 2019-11-21 18:54:05 --> Query error: Duplicate entry 'Maths' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Maths', '2019-11-21', '148')
ERROR - 2019-11-21 18:54:05 --> Query error: Duplicate entry 'History' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'History', '2019-11-21', '148')
ERROR - 2019-11-21 18:54:05 --> Query error: Duplicate entry 'Biology' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Biology', '2019-11-21', '148')
ERROR - 2019-11-21 18:54:05 --> Query error: Duplicate entry 'Chemistry' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Chemistry', '2019-11-21', '148')
ERROR - 2019-11-21 18:54:05 --> Query error: Duplicate entry 'Physics' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Physics', '2019-11-21', '148')
ERROR - 2019-11-21 18:54:05 --> Query error: Duplicate entry 'IT' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'IT', '2019-11-21', '148')
DEBUG - 2019-11-21 18:54:05 --> Total execution time: 0.5777
ERROR - 2019-11-21 19:02:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:02:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:02:48 --> Total execution time: 0.0096
ERROR - 2019-11-21 19:03:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:03:30 --> Total execution time: 0.0070
ERROR - 2019-11-21 19:03:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:03:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:03:46 --> Total execution time: 0.0085
ERROR - 2019-11-21 19:03:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:03:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:03:55 --> Total execution time: 0.0069
ERROR - 2019-11-21 19:07:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:18 --> Total execution time: 0.0122
ERROR - 2019-11-21 19:07:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:28 --> Total execution time: 0.0085
ERROR - 2019-11-21 19:07:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:31 --> Total execution time: 0.0046
ERROR - 2019-11-21 19:07:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:35 --> Total execution time: 0.0089
ERROR - 2019-11-21 19:07:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:38 --> Total execution time: 0.0046
ERROR - 2019-11-21 19:07:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:42 --> Total execution time: 0.0122
ERROR - 2019-11-21 19:07:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:45 --> Total execution time: 0.0100
ERROR - 2019-11-21 19:07:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:48 --> Total execution time: 0.0094
ERROR - 2019-11-21 19:07:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:50 --> Total execution time: 0.0112
ERROR - 2019-11-21 19:07:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:51 --> Total execution time: 0.0063
ERROR - 2019-11-21 19:07:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 19:07:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-21 19:07:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 19:07:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-21 19:07:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 19:07:51 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-21 19:07:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-21 19:07:51 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-21 19:07:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:53 --> Total execution time: 0.0072
ERROR - 2019-11-21 19:07:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:07:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:07:56 --> Total execution time: 0.0098
ERROR - 2019-11-21 19:09:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:09:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:09:49 --> Total execution time: 0.0060
ERROR - 2019-11-21 19:11:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:11:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:11:46 --> Total execution time: 0.0092
ERROR - 2019-11-21 19:11:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:11:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:11:47 --> Total execution time: 0.0044
ERROR - 2019-11-21 19:12:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:12:05 --> Total execution time: 0.0121
ERROR - 2019-11-21 19:12:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:12:05 --> Total execution time: 0.0088
ERROR - 2019-11-21 19:12:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:12:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:12:50 --> Total execution time: 0.0096
ERROR - 2019-11-21 19:12:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:12:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:12:50 --> Total execution time: 0.0074
ERROR - 2019-11-21 19:12:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:12:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:12:51 --> Total execution time: 0.0061
ERROR - 2019-11-21 19:13:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:13:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:13:13 --> Total execution time: 0.0061
ERROR - 2019-11-21 19:13:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:13:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:13:40 --> Total execution time: 0.0095
ERROR - 2019-11-21 19:13:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:13:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:13:40 --> Total execution time: 0.0085
ERROR - 2019-11-21 19:13:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:13:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:13:41 --> Total execution time: 0.0097
ERROR - 2019-11-21 19:13:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:13:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:13:51 --> Total execution time: 0.0077
ERROR - 2019-11-21 19:13:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:13:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:13:52 --> Total execution time: 0.0089
ERROR - 2019-11-21 19:14:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:14:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:14:15 --> Total execution time: 0.0070
ERROR - 2019-11-21 19:14:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:14:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:14:16 --> Total execution time: 0.0082
ERROR - 2019-11-21 19:14:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:14:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:14:29 --> Total execution time: 0.0121
ERROR - 2019-11-21 19:14:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:14:42 --> Total execution time: 0.0072
ERROR - 2019-11-21 19:15:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:15:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:15:40 --> Total execution time: 0.0102
ERROR - 2019-11-21 19:15:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:15:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:15:40 --> Total execution time: 0.0081
ERROR - 2019-11-21 19:16:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:16:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-21 19:16:33 --> Total execution time: 0.0101
ERROR - 2019-11-21 19:16:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:16:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 19:16:50 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Marathi', '2019-11-21', '148')
ERROR - 2019-11-21 19:16:50 --> Query error: Duplicate entry 'Maths' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Maths', '2019-11-21', '148')
ERROR - 2019-11-21 19:16:50 --> Query error: Duplicate entry 'Chemistry' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Chemistry', '2019-11-21', '148')
ERROR - 2019-11-21 19:16:50 --> Query error: Duplicate entry 'IT' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'IT', '2019-11-21', '148')
DEBUG - 2019-11-21 19:16:50 --> Total execution time: 0.3331
ERROR - 2019-11-21 19:17:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-21 19:17:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-21 19:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-21 19:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-21 19:17:03 --> Query error: Duplicate entry 'Marathi' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Marathi', '2019-11-21', '148')
ERROR - 2019-11-21 19:17:03 --> Query error: Duplicate entry 'Sanskrit' for key 'subject' - Invalid query: INSERT INTO `subject` (`school_id`, `subject`, `updated_date`, `updated_by`) VALUES ('11', 'Sanskrit', '2019-11-21', '148')
DEBUG - 2019-11-21 19:17:03 --> Total execution time: 0.3310
