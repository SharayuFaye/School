<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-25 10:17:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:17:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:17:55 --> Total execution time: 6.6461
ERROR - 2019-11-25 10:17:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:19:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:19:53 --> No URI present. Default controller set.
DEBUG - 2019-11-25 10:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:19:56 --> mmd :: Mmd@1234
DEBUG - 2019-11-25 10:19:56 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-25 10:19:58 --> Total execution time: 5.5383
ERROR - 2019-11-25 10:19:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:20:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:20:18 --> Total execution time: 0.5973
ERROR - 2019-11-25 10:20:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:20:33 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 10:22:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:22:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:22:38 --> Total execution time: 0.0098
ERROR - 2019-11-25 10:22:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:22:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:22:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:22:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:22:38 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 10:22:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:22:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:22:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:22:50 --> Total execution time: 0.0065
ERROR - 2019-11-25 10:22:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:23:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:23:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:23:06 --> Total execution time: 0.0527
ERROR - 2019-11-25 10:23:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:23:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:23:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:23:06 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 10:23:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:23:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:23:14 --> Total execution time: 0.0062
ERROR - 2019-11-25 10:23:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:24:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:24:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:24:00 --> Total execution time: 0.0074
ERROR - 2019-11-25 10:24:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:24:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:24:00 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 10:24:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:24:06 --> Total execution time: 0.0059
ERROR - 2019-11-25 10:24:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:24:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:24:27 --> Total execution time: 0.0041
ERROR - 2019-11-25 10:24:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:24:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:24:35 --> Total execution time: 0.0030
ERROR - 2019-11-25 10:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:26:06 --> Total execution time: 0.0102
ERROR - 2019-11-25 10:26:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:26:06 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 10:26:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:26:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:26:18 --> Total execution time: 0.0072
ERROR - 2019-11-25 10:26:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:26:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:26:18 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 10:26:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:26:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:26:22 --> Total execution time: 0.0050
ERROR - 2019-11-25 10:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:26:28 --> Total execution time: 0.0401
ERROR - 2019-11-25 10:26:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:26:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:26:33 --> Total execution time: 0.0039
ERROR - 2019-11-25 10:26:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:26:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:26:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:26:48 --> Total execution time: 0.0038
ERROR - 2019-11-25 10:27:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:27:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:27:06 --> Total execution time: 0.0034
ERROR - 2019-11-25 10:27:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:27:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:27:11 --> You did not select a file to upload.
DEBUG - 2019-11-25 10:27:11 --> Total execution time: 0.2848
ERROR - 2019-11-25 10:27:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:27:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:27:11 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 10:27:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:27:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:27:54 --> You did not select a file to upload.
DEBUG - 2019-11-25 10:27:54 --> Total execution time: 0.0136
ERROR - 2019-11-25 10:27:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:27:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:27:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:27:54 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 10:29:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:29:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:29:31 --> You did not select a file to upload.
DEBUG - 2019-11-25 10:29:31 --> Total execution time: 0.0374
ERROR - 2019-11-25 10:29:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:29:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:29:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:29:32 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 10:29:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:29:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:29:32 --> You did not select a file to upload.
DEBUG - 2019-11-25 10:29:32 --> Total execution time: 0.0140
ERROR - 2019-11-25 10:29:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:29:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:29:32 --> You did not select a file to upload.
DEBUG - 2019-11-25 10:29:32 --> Total execution time: 0.0128
ERROR - 2019-11-25 10:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:29:33 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 10:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:29:33 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 10:29:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:29:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:29:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:29:54 --> Total execution time: 0.2393
ERROR - 2019-11-25 10:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:29:54 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 10:29:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:30:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:30:27 --> Total execution time: 0.3226
ERROR - 2019-11-25 10:30:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 10:30:27 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 10:36:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:36:36 --> Total execution time: 0.0642
ERROR - 2019-11-25 10:36:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:36:39 --> Total execution time: 0.0021
ERROR - 2019-11-25 10:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:36:42 --> Total execution time: 0.1636
ERROR - 2019-11-25 10:36:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:36:44 --> Total execution time: 0.0021
ERROR - 2019-11-25 10:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:36:52 --> Total execution time: 0.0824
ERROR - 2019-11-25 10:36:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:36:54 --> Total execution time: 0.0034
ERROR - 2019-11-25 10:38:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:38:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:38:08 --> Total execution time: 0.0633
ERROR - 2019-11-25 10:38:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:38:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:38:11 --> Total execution time: 0.0046
ERROR - 2019-11-25 10:38:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:38:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:38:14 --> Total execution time: 0.0553
ERROR - 2019-11-25 10:40:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:40:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:40:56 --> Total execution time: 0.0635
ERROR - 2019-11-25 10:40:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 10:41:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:41:41 --> Total execution time: 0.0075
ERROR - 2019-11-25 10:42:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 10:42:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 10:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 10:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 10:42:10 --> Total execution time: 0.0077
ERROR - 2019-11-25 18:14:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:14:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:14:57 --> Total execution time: 0.0020
ERROR - 2019-11-25 18:15:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:15:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:15:23 --> No URI present. Default controller set.
DEBUG - 2019-11-25 18:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:15:23 --> xyz11 :: Xyz@1111
DEBUG - 2019-11-25 18:15:23 --> xyz11 :: 06ebfd2a1c28335ea0063d1a084e370f
DEBUG - 2019-11-25 18:15:23 --> Total execution time: 0.0029
ERROR - 2019-11-25 18:15:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:15:45 --> No URI present. Default controller set.
DEBUG - 2019-11-25 18:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:15:45 --> mmd :: Mmd@1234
DEBUG - 2019-11-25 18:15:45 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-25 18:15:45 --> Total execution time: 0.0718
ERROR - 2019-11-25 18:15:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:15:47 --> Total execution time: 0.0078
ERROR - 2019-11-25 18:15:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:15:47 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 18:16:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:16:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:16:05 --> Total execution time: 0.1974
ERROR - 2019-11-25 18:16:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:16:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:16:05 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 18:16:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:16:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:16:07 --> Total execution time: 0.0042
ERROR - 2019-11-25 18:16:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:16:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:16:15 --> No URI present. Default controller set.
DEBUG - 2019-11-25 18:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:16:15 --> neha@mmd :: Neha@123
DEBUG - 2019-11-25 18:16:15 --> neha@mmd :: f3de5e16d00fe7056839f6018f1f52ca
DEBUG - 2019-11-25 18:16:15 --> Total execution time: 0.1658
ERROR - 2019-11-25 18:16:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:16:21 --> Total execution time: 0.0478
ERROR - 2019-11-25 18:16:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:16:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:16:50 --> Total execution time: 0.0063
ERROR - 2019-11-25 18:16:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 18:16:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:16:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:16:51 --> Total execution time: 0.0060
ERROR - 2019-11-25 18:16:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:16:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:16:58 --> Total execution time: 0.1123
ERROR - 2019-11-25 18:17:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:17:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:17:14 --> Total execution time: 0.0058
ERROR - 2019-11-25 18:17:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:17:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:17:21 --> Total execution time: 0.1567
ERROR - 2019-11-25 18:28:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:28:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:28:55 --> Total execution time: 0.0067
ERROR - 2019-11-25 18:29:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:29:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:29:33 --> Total execution time: 0.0337
ERROR - 2019-11-25 18:29:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:29:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:29:42 --> Total execution time: 0.0993
ERROR - 2019-11-25 18:29:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:29:54 --> Total execution time: 0.0783
ERROR - 2019-11-25 18:30:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:02 --> Total execution time: 0.1253
ERROR - 2019-11-25 18:30:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 18:30:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:07 --> Total execution time: 0.0580
ERROR - 2019-11-25 18:30:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:09 --> Total execution time: 0.0110
ERROR - 2019-11-25 18:30:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:12 --> Total execution time: 0.0123
ERROR - 2019-11-25 18:30:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:14 --> Total execution time: 0.0280
ERROR - 2019-11-25 18:30:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:30:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-25 18:30:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:30:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-25 18:30:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:30:14 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-25 18:30:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:30:14 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-25 18:30:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:15 --> Total execution time: 0.0077
ERROR - 2019-11-25 18:30:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:18 --> Total execution time: 0.0043
ERROR - 2019-11-25 18:30:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:24 --> No URI present. Default controller set.
DEBUG - 2019-11-25 18:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:24 --> mmd :: Mmd@1234
DEBUG - 2019-11-25 18:30:24 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-25 18:30:24 --> Total execution time: 0.0635
ERROR - 2019-11-25 18:30:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:30:27 --> Total execution time: 0.0053
ERROR - 2019-11-25 18:30:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:30:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:30:27 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 18:31:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:31:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:31:07 --> Total execution time: 0.2132
ERROR - 2019-11-25 18:31:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:31:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:31:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:31:07 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 18:31:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:31:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:31:13 --> Total execution time: 0.0090
ERROR - 2019-11-25 18:31:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:31:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:31:15 --> Total execution time: 0.0098
ERROR - 2019-11-25 18:31:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:31:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:31:17 --> Total execution time: 0.0046
ERROR - 2019-11-25 18:31:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:31:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:31:35 --> Total execution time: 0.1318
ERROR - 2019-11-25 18:32:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:04 --> Total execution time: 0.1059
ERROR - 2019-11-25 18:32:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:14 --> Total execution time: 0.0054
ERROR - 2019-11-25 18:32:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:16 --> Total execution time: 0.0019
ERROR - 2019-11-25 18:32:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:20 --> Total execution time: 0.1316
ERROR - 2019-11-25 18:32:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:22 --> Total execution time: 0.0026
ERROR - 2019-11-25 18:32:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:24 --> Total execution time: 0.0060
ERROR - 2019-11-25 18:32:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:32:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:26 --> Total execution time: 0.0026
DEBUG - 2019-11-25 18:32:26 --> Total execution time: 0.0048
ERROR - 2019-11-25 18:32:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:30 --> Total execution time: 0.5877
ERROR - 2019-11-25 18:32:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:32 --> Total execution time: 0.0023
ERROR - 2019-11-25 18:32:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:32 --> Total execution time: 0.0049
ERROR - 2019-11-25 18:32:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:35 --> Total execution time: 0.0071
ERROR - 2019-11-25 18:32:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:48 --> Total execution time: 0.1953
ERROR - 2019-11-25 18:32:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:51 --> Total execution time: 0.1748
ERROR - 2019-11-25 18:32:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:32:53 --> Total execution time: 0.0090
ERROR - 2019-11-25 18:32:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:32:53 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-25 18:33:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:33:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:33:03 --> Total execution time: 0.0034
ERROR - 2019-11-25 18:33:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:33:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:33:09 --> Total execution time: 0.0033
ERROR - 2019-11-25 18:33:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:33:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:33:29 --> Total execution time: 0.2001
ERROR - 2019-11-25 18:33:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:33:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-25 18:33:29 --> 404 Page Not Found: Welcome/profile
ERROR - 2019-11-25 18:33:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:33:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:33:41 --> Total execution time: 0.0245
ERROR - 2019-11-25 18:33:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:33:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:33:48 --> Total execution time: 0.1160
ERROR - 2019-11-25 18:33:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:33:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:33:59 --> Total execution time: 0.1005
ERROR - 2019-11-25 18:33:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-25 18:35:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-25 18:35:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-25 18:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-25 18:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-25 18:35:27 --> Total execution time: 0.0547
