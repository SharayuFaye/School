<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-26 10:21:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 10:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 10:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 10:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 10:21:22 --> Total execution time: 1.6080
ERROR - 2019-11-26 10:21:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 14:14:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:14:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:14:19 --> No URI present. Default controller set.
DEBUG - 2019-11-26 14:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:14:19 --> mmd :: Mmd@1234
DEBUG - 2019-11-26 14:14:19 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-26 14:14:20 --> Total execution time: 1.1733
ERROR - 2019-11-26 14:14:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 14:14:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:14:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:14:30 --> Total execution time: 0.0804
ERROR - 2019-11-26 14:14:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 14:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:14:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:14:51 --> Total execution time: 0.0745
ERROR - 2019-11-26 14:15:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:15:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:15:05 --> Total execution time: 0.0074
ERROR - 2019-11-26 14:15:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:15:12 --> Total execution time: 0.0107
ERROR - 2019-11-26 14:15:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:15:18 --> Total execution time: 0.0070
ERROR - 2019-11-26 14:15:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:15:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:15:29 --> Total execution time: 0.0577
ERROR - 2019-11-26 14:15:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:15:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:15:36 --> Total execution time: 0.0258
ERROR - 2019-11-26 14:15:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 14:15:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:15:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:15:40 --> Total execution time: 0.0058
ERROR - 2019-11-26 14:16:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:16:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:16:24 --> Total execution time: 0.0092
ERROR - 2019-11-26 14:17:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:17:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:17:24 --> Total execution time: 0.0191
ERROR - 2019-11-26 14:17:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:17:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:17:24 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-26 14:17:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:17:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:17:56 --> Total execution time: 0.1536
ERROR - 2019-11-26 14:18:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:18:00 --> Total execution time: 0.0438
ERROR - 2019-11-26 14:18:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:18:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:18:38 --> Total execution time: 0.0137
ERROR - 2019-11-26 14:18:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 14:18:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:18:51 --> Total execution time: 0.0130
ERROR - 2019-11-26 14:18:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:18:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:18:57 --> Total execution time: 0.0097
ERROR - 2019-11-26 14:32:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:32:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:32:44 --> Total execution time: 0.0821
ERROR - 2019-11-26 14:34:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:34:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:34:04 --> Total execution time: 0.0116
ERROR - 2019-11-26 14:34:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:34:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:34:08 --> Total execution time: 0.1636
ERROR - 2019-11-26 14:34:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:34:11 --> Total execution time: 0.0268
ERROR - 2019-11-26 14:34:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:34:11 --> Total execution time: 0.0031
ERROR - 2019-11-26 14:34:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:34:17 --> Total execution time: 0.1105
ERROR - 2019-11-26 14:34:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:34:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:34:18 --> Total execution time: 0.0581
ERROR - 2019-11-26 14:34:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:34:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:34:49 --> Total execution time: 0.1093
ERROR - 2019-11-26 14:35:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:35:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:35:35 --> Total execution time: 0.0907
ERROR - 2019-11-26 14:35:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:35:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:35:40 --> Total execution time: 0.0088
ERROR - 2019-11-26 14:35:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 14:35:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:35:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:35:43 --> Total execution time: 0.0042
ERROR - 2019-11-26 14:35:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:35:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:35:44 --> Total execution time: 0.0036
ERROR - 2019-11-26 14:35:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:35:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:35:46 --> You did not select a file to upload.
DEBUG - 2019-11-26 14:35:46 --> Total execution time: 0.0240
ERROR - 2019-11-26 14:35:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:35:49 --> Total execution time: 0.0825
ERROR - 2019-11-26 14:36:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:36:02 --> Total execution time: 0.0628
ERROR - 2019-11-26 14:36:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:36:19 --> Total execution time: 0.0786
ERROR - 2019-11-26 14:36:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:36:42 --> Total execution time: 0.0282
ERROR - 2019-11-26 14:36:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:36:45 --> Total execution time: 0.0141
ERROR - 2019-11-26 14:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:36:52 --> Total execution time: 0.0669
ERROR - 2019-11-26 14:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:36:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 14:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:36:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 14:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:36:52 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 14:36:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:36:52 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 14:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:38:30 --> Total execution time: 0.0079
ERROR - 2019-11-26 14:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 14:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 14:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:30 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 14:38:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:30 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 14:38:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:38:34 --> Total execution time: 0.1181
ERROR - 2019-11-26 14:38:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-11-26 14:38:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:34 --> 404 Page Not Found: Welcome/vendor
DEBUG - 2019-11-26 14:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:34 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:38:38 --> Total execution time: 0.1020
ERROR - 2019-11-26 14:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-26 14:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:38 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-26 14:38:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:38 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:38:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:38:51 --> Total execution time: 0.0658
ERROR - 2019-11-26 14:38:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-26 14:38:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:38:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:52 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-26 14:38:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:38:52 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:41:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:41:05 --> Total execution time: 0.0026
ERROR - 2019-11-26 14:41:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:10 --> No URI present. Default controller set.
DEBUG - 2019-11-26 14:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:41:10 --> admin :: admin
DEBUG - 2019-11-26 14:41:10 --> admin :: 21232f297a57a5a743894a0e4a801fc3
DEBUG - 2019-11-26 14:41:10 --> Total execution time: 0.0189
ERROR - 2019-11-26 14:41:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:41:13 --> Total execution time: 0.0766
ERROR - 2019-11-26 14:41:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 14:41:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 14:41:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:13 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-26 14:41:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:13 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 14:41:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:13 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 14:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:41:23 --> Total execution time: 0.1011
ERROR - 2019-11-26 14:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-26 14:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:23 --> 404 Page Not Found: Welcome/img
ERROR - 2019-11-26 14:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:23 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-26 14:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:23 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:41:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:41:49 --> Total execution time: 0.0234
ERROR - 2019-11-26 14:41:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:41:53 --> Total execution time: 0.1065
ERROR - 2019-11-26 14:41:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:41:55 --> Total execution time: 0.0084
ERROR - 2019-11-26 14:41:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:41:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:41:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:41:55 --> 404 Page Not Found: Img/logo.png
ERROR - 2019-11-26 14:42:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:02 --> Total execution time: 0.0044
ERROR - 2019-11-26 14:42:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:09 --> No URI present. Default controller set.
DEBUG - 2019-11-26 14:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:09 --> mmd :: Mmd@1234
DEBUG - 2019-11-26 14:42:09 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-26 14:42:09 --> Total execution time: 0.0584
ERROR - 2019-11-26 14:42:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:19 --> Total execution time: 0.0109
ERROR - 2019-11-26 14:42:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:26 --> Total execution time: 0.0248
ERROR - 2019-11-26 14:42:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 14:42:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:27 --> Total execution time: 0.0070
ERROR - 2019-11-26 14:42:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:28 --> Total execution time: 0.0080
ERROR - 2019-11-26 14:42:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:31 --> Total execution time: 0.0017
ERROR - 2019-11-26 14:42:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:44 --> No URI present. Default controller set.
DEBUG - 2019-11-26 14:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:44 --> mmd :: Mmd@1234
DEBUG - 2019-11-26 14:42:44 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-26 14:42:44 --> Total execution time: 0.0730
ERROR - 2019-11-26 14:42:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:46 --> Total execution time: 0.0217
ERROR - 2019-11-26 14:42:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:42:46 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-26 14:42:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:42:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:42:50 --> Total execution time: 0.0026
ERROR - 2019-11-26 14:43:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:43:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:43:02 --> No URI present. Default controller set.
DEBUG - 2019-11-26 14:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:43:02 --> neha@mmd :: Neha@123
DEBUG - 2019-11-26 14:43:02 --> neha@mmd :: f3de5e16d00fe7056839f6018f1f52ca
DEBUG - 2019-11-26 14:43:02 --> Total execution time: 0.1362
ERROR - 2019-11-26 14:43:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:43:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:43:04 --> Total execution time: 0.0720
ERROR - 2019-11-26 14:43:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:43:12 --> Total execution time: 0.1157
ERROR - 2019-11-26 14:43:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:43:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:43:19 --> Total execution time: 0.0097
ERROR - 2019-11-26 14:43:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:43:37 --> Total execution time: 0.0069
ERROR - 2019-11-26 14:45:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:45:08 --> Total execution time: 0.0032
ERROR - 2019-11-26 14:45:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:15 --> No URI present. Default controller set.
DEBUG - 2019-11-26 14:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:45:15 --> mmd :: Mmd@1234
DEBUG - 2019-11-26 14:45:15 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-26 14:45:15 --> Total execution time: 0.0631
ERROR - 2019-11-26 14:45:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:45:18 --> Total execution time: 0.0083
ERROR - 2019-11-26 14:45:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:45:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 14:45:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:45:18 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 14:45:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:45:18 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 14:45:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:45:19 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 14:45:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:45:29 --> Total execution time: 0.0049
ERROR - 2019-11-26 14:45:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:45:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-26 14:45:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:45:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:45:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:45:29 --> 404 Page Not Found: Welcome/vendor
ERROR - 2019-11-26 14:45:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:45:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:45:29 --> 404 Page Not Found: Welcome/js
ERROR - 2019-11-26 14:54:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:54:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:54:56 --> Total execution time: 0.0110
ERROR - 2019-11-26 14:54:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:54:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:54:56 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-26 14:55:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:55:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:55:03 --> Total execution time: 0.0043
ERROR - 2019-11-26 14:56:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:56:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:56:48 --> Total execution time: 0.0106
ERROR - 2019-11-26 14:56:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:56:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:56:50 --> Total execution time: 0.0138
ERROR - 2019-11-26 14:58:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:58:48 --> Total execution time: 0.0025
ERROR - 2019-11-26 14:58:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:58:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 14:58:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 14:58:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 14:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 14:58:49 --> Total execution time: 0.0042
DEBUG - 2019-11-26 14:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 14:58:49 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:16:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:16:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:16:30 --> Total execution time: 0.0274
ERROR - 2019-11-26 15:16:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 15:16:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:16:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:16:32 --> Total execution time: 0.0069
ERROR - 2019-11-26 15:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:16:37 --> Total execution time: 0.0024
ERROR - 2019-11-26 15:16:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:16:38 --> UTF-8 Support Enabled
ERROR - 2019-11-26 15:16:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:16:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:16:38 --> Total execution time: 0.0043
DEBUG - 2019-11-26 15:16:38 --> Total execution time: 0.0043
ERROR - 2019-11-26 15:16:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:16:57 --> Total execution time: 0.0108
ERROR - 2019-11-26 15:17:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:17:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:17:01 --> Total execution time: 0.0095
ERROR - 2019-11-26 15:17:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:17:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:17:03 --> Total execution time: 0.0108
ERROR - 2019-11-26 15:17:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:17:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:17:10 --> Total execution time: 0.0688
ERROR - 2019-11-26 15:17:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:17:14 --> Total execution time: 0.0030
ERROR - 2019-11-26 15:17:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:17:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:17:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:17:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:17:16 --> Total execution time: 0.0040
DEBUG - 2019-11-26 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:17:16 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:17:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:17:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:17:18 --> Severity: Warning --> Missing argument 1 for Welcome::exams_fetch_id(), called in /var/www/html/School19/system/core/CodeIgniter.php on line 532 and defined /var/www/html/School19/application/controllers/Welcome.php 1336
ERROR - 2019-11-26 15:17:18 --> Severity: Warning --> Missing argument 2 for Welcome::exams_fetch_id(), called in /var/www/html/School19/system/core/CodeIgniter.php on line 532 and defined /var/www/html/School19/application/controllers/Welcome.php 1336
ERROR - 2019-11-26 15:17:18 --> Severity: Warning --> Missing argument 3 for Welcome::exams_fetch_id(), called in /var/www/html/School19/system/core/CodeIgniter.php on line 532 and defined /var/www/html/School19/application/controllers/Welcome.php 1336
ERROR - 2019-11-26 15:17:18 --> Severity: Notice --> Undefined variable: class_sel /var/www/html/School19/application/controllers/Welcome.php 1342
ERROR - 2019-11-26 15:17:18 --> Severity: Warning --> Missing argument 2 for m_exams::exams_fetch_id(), called in /var/www/html/School19/application/controllers/Welcome.php on line 1342 and defined /var/www/html/School19/application/models/M_exams.php 77
ERROR - 2019-11-26 15:17:18 --> Severity: Warning --> Missing argument 3 for m_exams::exams_fetch_id(), called in /var/www/html/School19/application/controllers/Welcome.php on line 1342 and defined /var/www/html/School19/application/models/M_exams.php 77
ERROR - 2019-11-26 15:17:18 --> Severity: Notice --> Undefined variable: exam_type_id /var/www/html/School19/application/models/M_exams.php 82
ERROR - 2019-11-26 15:17:18 --> Severity: Notice --> Undefined variable: subject /var/www/html/School19/application/models/M_exams.php 83
DEBUG - 2019-11-26 15:17:18 --> Total execution time: 0.0043
ERROR - 2019-11-26 15:17:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:17:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:17:26 --> Severity: Warning --> Missing argument 1 for Welcome::exams_fetch_id(), called in /var/www/html/School19/system/core/CodeIgniter.php on line 532 and defined /var/www/html/School19/application/controllers/Welcome.php 1336
ERROR - 2019-11-26 15:17:26 --> Severity: Warning --> Missing argument 2 for Welcome::exams_fetch_id(), called in /var/www/html/School19/system/core/CodeIgniter.php on line 532 and defined /var/www/html/School19/application/controllers/Welcome.php 1336
ERROR - 2019-11-26 15:17:26 --> Severity: Warning --> Missing argument 3 for Welcome::exams_fetch_id(), called in /var/www/html/School19/system/core/CodeIgniter.php on line 532 and defined /var/www/html/School19/application/controllers/Welcome.php 1336
ERROR - 2019-11-26 15:17:26 --> Severity: Notice --> Undefined variable: class_sel /var/www/html/School19/application/controllers/Welcome.php 1342
ERROR - 2019-11-26 15:17:26 --> Severity: Warning --> Missing argument 2 for m_exams::exams_fetch_id(), called in /var/www/html/School19/application/controllers/Welcome.php on line 1342 and defined /var/www/html/School19/application/models/M_exams.php 77
ERROR - 2019-11-26 15:17:26 --> Severity: Warning --> Missing argument 3 for m_exams::exams_fetch_id(), called in /var/www/html/School19/application/controllers/Welcome.php on line 1342 and defined /var/www/html/School19/application/models/M_exams.php 77
ERROR - 2019-11-26 15:17:26 --> Severity: Notice --> Undefined variable: exam_type_id /var/www/html/School19/application/models/M_exams.php 82
ERROR - 2019-11-26 15:17:26 --> Severity: Notice --> Undefined variable: subject /var/www/html/School19/application/models/M_exams.php 83
DEBUG - 2019-11-26 15:17:26 --> Total execution time: 0.0052
ERROR - 2019-11-26 15:18:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:18:16 --> Total execution time: 0.0145
ERROR - 2019-11-26 15:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:18:19 --> Total execution time: 0.0099
ERROR - 2019-11-26 15:18:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:18:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:18:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:18:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:18:20 --> Total execution time: 0.0041
DEBUG - 2019-11-26 15:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:18:20 --> Total execution time: 0.0040
ERROR - 2019-11-26 15:18:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:18:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:18:23 --> Total execution time: 0.0033
ERROR - 2019-11-26 15:21:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:21:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:21:45 --> Total execution time: 0.0186
ERROR - 2019-11-26 15:21:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:21:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:21:59 --> Total execution time: 0.0046
ERROR - 2019-11-26 15:22:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:22:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:22:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:22:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:22:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:22:00 --> Total execution time: 0.0042
DEBUG - 2019-11-26 15:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:22:00 --> Total execution time: 0.0034
ERROR - 2019-11-26 15:22:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:22:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:22:03 --> Severity: error --> Exception: Call to undefined function daye() /var/www/html/School19/application/controllers/Welcome.php 1344
ERROR - 2019-11-26 15:22:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:22:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:22:08 --> Severity: error --> Exception: Call to undefined function daye() /var/www/html/School19/application/controllers/Welcome.php 1344
ERROR - 2019-11-26 15:22:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:22:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:22:18 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/School19/application/controllers/Welcome.php 1344
ERROR - 2019-11-26 15:23:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:23:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:23:46 --> Total execution time: 0.0229
ERROR - 2019-11-26 15:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:23:53 --> Total execution time: 0.0099
ERROR - 2019-11-26 15:23:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:23:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:23:57 --> Total execution time: 0.0022
ERROR - 2019-11-26 15:23:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:23:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:23:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:23:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:23:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:23:58 --> Total execution time: 0.0050
DEBUG - 2019-11-26 15:23:58 --> Total execution time: 0.0035
ERROR - 2019-11-26 15:24:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:00 --> Total execution time: 0.0060
ERROR - 2019-11-26 15:24:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:30 --> Total execution time: 0.0209
ERROR - 2019-11-26 15:24:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:33 --> Total execution time: 0.0038
ERROR - 2019-11-26 15:24:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:24:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:34 --> Total execution time: 0.0061
DEBUG - 2019-11-26 15:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:34 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:24:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:36 --> Total execution time: 0.0044
ERROR - 2019-11-26 15:24:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:39 --> Total execution time: 0.0025
ERROR - 2019-11-26 15:24:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:55 --> Total execution time: 0.0104
ERROR - 2019-11-26 15:24:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:58 --> Total execution time: 0.0030
ERROR - 2019-11-26 15:24:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:24:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:24:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:24:59 --> Total execution time: 0.0038
DEBUG - 2019-11-26 15:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:24:59 --> Total execution time: 0.0029
ERROR - 2019-11-26 15:25:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:01 --> Total execution time: 0.0048
ERROR - 2019-11-26 15:25:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:02 --> Total execution time: 0.0038
ERROR - 2019-11-26 15:25:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:07 --> Total execution time: 0.0026
ERROR - 2019-11-26 15:25:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:15 --> Total execution time: 0.0239
ERROR - 2019-11-26 15:25:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:17 --> Total execution time: 0.0035
ERROR - 2019-11-26 15:25:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:25:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:19 --> Total execution time: 0.0041
DEBUG - 2019-11-26 15:25:19 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:25:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:22 --> Total execution time: 0.0041
ERROR - 2019-11-26 15:25:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:25:25 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:25:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:25:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/School19/application/controllers/Welcome.php 1344
ERROR - 2019-11-26 15:25:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/School19/application/controllers/Welcome.php 1344
DEBUG - 2019-11-26 15:25:26 --> Total execution time: 0.0030
ERROR - 2019-11-26 15:27:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:27:31 --> Total execution time: 0.0199
ERROR - 2019-11-26 15:27:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:27:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:27:34 --> Total execution time: 0.0029
ERROR - 2019-11-26 15:27:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:27:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:27:35 --> Total execution time: 0.0045
DEBUG - 2019-11-26 15:27:35 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:27:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:27:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:27:38 --> Total execution time: 0.0040
ERROR - 2019-11-26 15:27:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:27:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:27:41 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:30:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:37 --> Total execution time: 0.0272
ERROR - 2019-11-26 15:30:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:40 --> Total execution time: 0.0037
ERROR - 2019-11-26 15:30:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:30:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:41 --> Total execution time: 0.0047
DEBUG - 2019-11-26 15:30:41 --> Total execution time: 0.0037
ERROR - 2019-11-26 15:30:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:44 --> Total execution time: 0.0039
ERROR - 2019-11-26 15:30:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:45 --> Total execution time: 0.0041
ERROR - 2019-11-26 15:30:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:49 --> Total execution time: 0.0069
ERROR - 2019-11-26 15:30:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:51 --> Total execution time: 0.0058
ERROR - 2019-11-26 15:30:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:56 --> Total execution time: 0.0044
ERROR - 2019-11-26 15:30:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:30:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:30:57 --> Total execution time: 0.0021
ERROR - 2019-11-26 15:32:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:28 --> Total execution time: 0.0136
ERROR - 2019-11-26 15:32:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:32 --> Total execution time: 0.0024
ERROR - 2019-11-26 15:32:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:32:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:33 --> Total execution time: 0.0068
DEBUG - 2019-11-26 15:32:33 --> Total execution time: 0.0057
ERROR - 2019-11-26 15:32:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:34 --> Total execution time: 0.0054
ERROR - 2019-11-26 15:32:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:36 --> Total execution time: 0.0039
ERROR - 2019-11-26 15:32:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:37 --> Total execution time: 0.0030
ERROR - 2019-11-26 15:32:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:45 --> Total execution time: 0.0050
ERROR - 2019-11-26 15:32:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:46 --> Total execution time: 0.0032
ERROR - 2019-11-26 15:32:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-11-26 15:32:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:47 --> Total execution time: 0.0023
DEBUG - 2019-11-26 15:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:47 --> Total execution time: 0.0037
ERROR - 2019-11-26 15:32:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:50 --> Total execution time: 0.0039
ERROR - 2019-11-26 15:32:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:51 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:32:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:53 --> Total execution time: 0.0069
ERROR - 2019-11-26 15:32:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:32:54 --> Total execution time: 0.0062
ERROR - 2019-11-26 15:33:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:01 --> Total execution time: 0.0028
ERROR - 2019-11-26 15:33:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:37 --> Total execution time: 0.0118
ERROR - 2019-11-26 15:33:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:43 --> Total execution time: 0.0041
ERROR - 2019-11-26 15:33:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:44 --> Total execution time: 0.0051
ERROR - 2019-11-26 15:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:33:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:45 --> Total execution time: 0.0042
DEBUG - 2019-11-26 15:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:45 --> Total execution time: 0.0029
ERROR - 2019-11-26 15:33:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 15:33:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:46 --> Total execution time: 0.0048
DEBUG - 2019-11-26 15:33:46 --> Total execution time: 0.0040
ERROR - 2019-11-26 15:33:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:49 --> Total execution time: 0.0036
ERROR - 2019-11-26 15:33:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:50 --> Total execution time: 0.0026
ERROR - 2019-11-26 15:33:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:52 --> Total execution time: 0.0028
ERROR - 2019-11-26 15:33:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:54 --> Total execution time: 0.0063
ERROR - 2019-11-26 15:33:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:33:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:33:57 --> Total execution time: 0.0054
ERROR - 2019-11-26 15:34:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:34:01 --> Total execution time: 0.0046
ERROR - 2019-11-26 15:34:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:34:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:34:02 --> Total execution time: 0.1066
ERROR - 2019-11-26 15:34:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:34:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:34:12 --> Total execution time: 0.0048
ERROR - 2019-11-26 15:34:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:34:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 15:34:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:34:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:34:14 --> Total execution time: 0.0034
DEBUG - 2019-11-26 15:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:34:14 --> Total execution time: 0.0025
ERROR - 2019-11-26 15:34:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:34:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:34:17 --> Total execution time: 0.0044
ERROR - 2019-11-26 15:34:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:34:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:34:20 --> Total execution time: 0.0046
ERROR - 2019-11-26 15:34:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 15:34:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 15:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 15:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 15:34:22 --> Total execution time: 0.1230
ERROR - 2019-11-26 16:16:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:16:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:16:01 --> Total execution time: 0.0048
ERROR - 2019-11-26 16:16:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:16:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:16:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 16:16:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:16:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:16:02 --> Total execution time: 0.0056
DEBUG - 2019-11-26 16:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:16:02 --> Total execution time: 0.0028
ERROR - 2019-11-26 16:16:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:16:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:16:04 --> Total execution time: 0.0030
ERROR - 2019-11-26 16:16:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:16:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:16:12 --> Total execution time: 0.0022
ERROR - 2019-11-26 16:16:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:16:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:16:13 --> Total execution time: 0.0038
ERROR - 2019-11-26 16:18:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:18:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:18:26 --> Total execution time: 0.0080
ERROR - 2019-11-26 16:18:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:18:29 --> Total execution time: 0.0110
ERROR - 2019-11-26 16:18:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:18:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:18:32 --> Total execution time: 0.0073
ERROR - 2019-11-26 16:25:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:25:48 --> Total execution time: 0.0265
ERROR - 2019-11-26 16:25:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:25:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:25:51 --> Total execution time: 0.0120
ERROR - 2019-11-26 16:25:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:25:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 16:25:51 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-26 16:25:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:25:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:25:53 --> Total execution time: 0.0032
ERROR - 2019-11-26 16:25:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:25:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:25:55 --> Total execution time: 0.0176
ERROR - 2019-11-26 16:25:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:25:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:25:56 --> Total execution time: 0.0035
ERROR - 2019-11-26 16:25:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:25:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:25:58 --> Total execution time: 0.0070
ERROR - 2019-11-26 16:26:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 16:26:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:26:02 --> Total execution time: 0.0044
DEBUG - 2019-11-26 16:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:26:02 --> Total execution time: 0.0031
ERROR - 2019-11-26 16:27:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:27:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:27:29 --> Total execution time: 0.0076
ERROR - 2019-11-26 16:27:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:27:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:27:30 --> Total execution time: 0.0063
ERROR - 2019-11-26 16:28:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 16:28:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:28:26 --> Total execution time: 0.0053
DEBUG - 2019-11-26 16:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:28:26 --> Total execution time: 0.0038
ERROR - 2019-11-26 16:28:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:28:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:28:44 --> Total execution time: 0.0076
ERROR - 2019-11-26 16:30:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:30:23 --> Total execution time: 0.0115
ERROR - 2019-11-26 16:30:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:30:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:30:24 --> Total execution time: 0.0089
ERROR - 2019-11-26 16:31:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:31:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:31:16 --> Total execution time: 0.0071
ERROR - 2019-11-26 16:31:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:31:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:31:17 --> Total execution time: 0.0083
ERROR - 2019-11-26 16:31:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:31:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:31:18 --> Total execution time: 0.0054
ERROR - 2019-11-26 16:31:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:31:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:31:57 --> Total execution time: 0.0588
ERROR - 2019-11-26 16:32:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:32:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:32:09 --> Total execution time: 0.0100
ERROR - 2019-11-26 16:32:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:32:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:32:09 --> Total execution time: 0.0078
ERROR - 2019-11-26 16:32:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:32:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:32:10 --> Total execution time: 0.0073
ERROR - 2019-11-26 16:32:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:32:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:32:10 --> Total execution time: 0.0121
ERROR - 2019-11-26 16:34:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:34:59 --> Total execution time: 0.0104
ERROR - 2019-11-26 16:34:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:34:59 --> Total execution time: 0.0064
ERROR - 2019-11-26 16:36:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:17 --> Total execution time: 0.0098
ERROR - 2019-11-26 16:36:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:18 --> Total execution time: 0.0083
ERROR - 2019-11-26 16:36:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:18 --> Total execution time: 0.0063
ERROR - 2019-11-26 16:36:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:18 --> Total execution time: 0.0075
ERROR - 2019-11-26 16:36:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:19 --> Total execution time: 0.0062
ERROR - 2019-11-26 16:36:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:19 --> Total execution time: 0.0074
ERROR - 2019-11-26 16:36:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:19 --> Total execution time: 0.0063
ERROR - 2019-11-26 16:36:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:19 --> Total execution time: 0.0065
ERROR - 2019-11-26 16:36:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:20 --> Total execution time: 0.0057
ERROR - 2019-11-26 16:36:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:20 --> Total execution time: 0.0063
ERROR - 2019-11-26 16:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:21 --> Total execution time: 0.0059
ERROR - 2019-11-26 16:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:21 --> Total execution time: 0.0070
ERROR - 2019-11-26 16:36:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:21 --> Total execution time: 0.0066
ERROR - 2019-11-26 16:36:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:22 --> Total execution time: 0.0069
ERROR - 2019-11-26 16:36:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:22 --> Total execution time: 0.0063
ERROR - 2019-11-26 16:36:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 16:36:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:22 --> Total execution time: 0.0068
ERROR - 2019-11-26 16:36:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:22 --> Total execution time: 0.0050
ERROR - 2019-11-26 16:36:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:23 --> Total execution time: 0.0055
ERROR - 2019-11-26 16:36:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:23 --> Total execution time: 0.0070
ERROR - 2019-11-26 16:36:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:23 --> Total execution time: 0.0070
ERROR - 2019-11-26 16:36:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:23 --> Total execution time: 0.0085
ERROR - 2019-11-26 16:36:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 16:36:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:23 --> Total execution time: 0.0066
ERROR - 2019-11-26 16:36:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:24 --> Total execution time: 0.0057
ERROR - 2019-11-26 16:36:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:24 --> Total execution time: 0.0048
ERROR - 2019-11-26 16:36:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:24 --> Total execution time: 0.0068
ERROR - 2019-11-26 16:36:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:36:24 --> Total execution time: 0.0055
ERROR - 2019-11-26 16:37:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:37:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:37:37 --> Total execution time: 0.0100
ERROR - 2019-11-26 16:39:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:39:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:39:59 --> Total execution time: 0.0058
ERROR - 2019-11-26 16:40:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:01 --> Total execution time: 0.0036
ERROR - 2019-11-26 16:40:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:02 --> Total execution time: 0.0046
ERROR - 2019-11-26 16:40:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:04 --> Total execution time: 0.0067
ERROR - 2019-11-26 16:40:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:06 --> Total execution time: 0.0092
ERROR - 2019-11-26 16:40:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 16:40:06 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-26 16:40:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:17 --> Total execution time: 0.0086
ERROR - 2019-11-26 16:40:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:18 --> Total execution time: 0.0054
ERROR - 2019-11-26 16:40:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:29 --> Total execution time: 0.0193
ERROR - 2019-11-26 16:40:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:33 --> Total execution time: 0.0084
ERROR - 2019-11-26 16:40:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:40:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:40:58 --> Total execution time: 0.0083
ERROR - 2019-11-26 16:41:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:41:41 --> Total execution time: 0.0106
ERROR - 2019-11-26 16:41:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:41:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:41:46 --> Total execution time: 0.0071
ERROR - 2019-11-26 16:42:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:42:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:42:43 --> Total execution time: 0.0099
ERROR - 2019-11-26 16:43:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:43:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:43:50 --> Total execution time: 0.0103
ERROR - 2019-11-26 16:52:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:52:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:52:25 --> Total execution time: 0.0035
ERROR - 2019-11-26 16:52:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:52:27 --> Total execution time: 0.0037
ERROR - 2019-11-26 16:52:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:52:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:52:36 --> Total execution time: 0.0020
ERROR - 2019-11-26 16:52:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:52:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:52:43 --> Total execution time: 0.0068
ERROR - 2019-11-26 16:52:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:52:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:52:57 --> Total execution time: 0.1171
ERROR - 2019-11-26 16:52:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:52:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:52:59 --> Total execution time: 0.0037
ERROR - 2019-11-26 16:53:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:53:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:53:03 --> Total execution time: 0.0048
ERROR - 2019-11-26 16:57:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:57:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:57:35 --> Total execution time: 0.0099
ERROR - 2019-11-26 16:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:58:24 --> Total execution time: 0.0046
ERROR - 2019-11-26 16:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 16:58:24 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-26 16:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:58:26 --> Total execution time: 0.0066
ERROR - 2019-11-26 16:58:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:58:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:58:29 --> Total execution time: 0.0107
ERROR - 2019-11-26 16:59:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 16:59:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 16:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 16:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 16:59:39 --> Total execution time: 0.0095
ERROR - 2019-11-26 17:04:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:04:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:04:12 --> Total execution time: 0.0475
ERROR - 2019-11-26 17:04:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:04:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:04:14 --> Total execution time: 0.0048
ERROR - 2019-11-26 17:04:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:04:18 --> Total execution time: 0.0064
ERROR - 2019-11-26 17:04:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:04:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:04:21 --> Total execution time: 0.0038
ERROR - 2019-11-26 17:07:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:07:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:07:23 --> Total execution time: 0.0134
ERROR - 2019-11-26 17:14:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:14:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:14:00 --> Total execution time: 0.0144
ERROR - 2019-11-26 17:14:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:14:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:14:04 --> Total execution time: 0.0091
ERROR - 2019-11-26 17:14:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:14:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:14:05 --> Total execution time: 0.0617
ERROR - 2019-11-26 17:17:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:17:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:17:53 --> Total execution time: 0.0135
ERROR - 2019-11-26 17:18:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:08 --> Total execution time: 0.1547
ERROR - 2019-11-26 17:18:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:19 --> Total execution time: 0.0030
ERROR - 2019-11-26 17:18:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:21 --> Total execution time: 0.0050
ERROR - 2019-11-26 17:18:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:18:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:22 --> Total execution time: 0.0055
DEBUG - 2019-11-26 17:18:22 --> Total execution time: 0.0044
ERROR - 2019-11-26 17:18:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:24 --> Total execution time: 0.0033
ERROR - 2019-11-26 17:18:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:28 --> Total execution time: 0.0039
ERROR - 2019-11-26 17:18:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:29 --> Total execution time: 0.1307
ERROR - 2019-11-26 17:18:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:36 --> Total execution time: 0.0079
ERROR - 2019-11-26 17:18:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:55 --> Total execution time: 0.0029
ERROR - 2019-11-26 17:18:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:57 --> Total execution time: 0.0043
ERROR - 2019-11-26 17:18:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:18:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:18:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:58 --> Total execution time: 0.0019
DEBUG - 2019-11-26 17:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:18:58 --> Total execution time: 0.0040
ERROR - 2019-11-26 17:19:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:19:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:19:00 --> Total execution time: 0.0028
ERROR - 2019-11-26 17:19:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:19:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:19:04 --> Total execution time: 0.0021
ERROR - 2019-11-26 17:19:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:19:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:19:05 --> Total execution time: 0.0040
ERROR - 2019-11-26 17:19:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:19:08 --> Total execution time: 0.0042
ERROR - 2019-11-26 17:19:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:19:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:19:10 --> Total execution time: 0.0053
ERROR - 2019-11-26 17:19:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:19:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:19:48 --> Total execution time: 0.0909
ERROR - 2019-11-26 17:20:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:01 --> Total execution time: 0.0023
ERROR - 2019-11-26 17:20:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:03 --> Total execution time: 0.0032
ERROR - 2019-11-26 17:20:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:20:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:04 --> Total execution time: 0.0033
DEBUG - 2019-11-26 17:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:04 --> Total execution time: 0.0031
ERROR - 2019-11-26 17:20:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:07 --> Total execution time: 0.0055
ERROR - 2019-11-26 17:20:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:10 --> Total execution time: 0.0027
ERROR - 2019-11-26 17:20:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:11 --> Total execution time: 0.0025
ERROR - 2019-11-26 17:20:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:32 --> Total execution time: 0.0025
ERROR - 2019-11-26 17:20:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:20:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:20:33 --> Total execution time: 0.0057
ERROR - 2019-11-26 17:21:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:01 --> Total execution time: 0.0738
ERROR - 2019-11-26 17:21:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:16 --> Total execution time: 0.0657
ERROR - 2019-11-26 17:21:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:33 --> Total execution time: 0.0021
ERROR - 2019-11-26 17:21:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:34 --> UTF-8 Support Enabled
ERROR - 2019-11-26 17:21:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:34 --> Total execution time: 0.0037
DEBUG - 2019-11-26 17:21:34 --> Total execution time: 0.0068
ERROR - 2019-11-26 17:21:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:37 --> Total execution time: 0.0033
ERROR - 2019-11-26 17:21:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:39 --> Total execution time: 0.0035
ERROR - 2019-11-26 17:21:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:40 --> Total execution time: 0.0055
ERROR - 2019-11-26 17:21:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:41 --> Total execution time: 0.0021
ERROR - 2019-11-26 17:21:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:44 --> Total execution time: 0.0045
ERROR - 2019-11-26 17:21:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:45 --> Total execution time: 0.0056
ERROR - 2019-11-26 17:21:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:46 --> Total execution time: 0.0044
ERROR - 2019-11-26 17:21:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:48 --> Total execution time: 0.0045
ERROR - 2019-11-26 17:21:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:50 --> Total execution time: 0.0045
ERROR - 2019-11-26 17:21:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:21:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:21:52 --> Total execution time: 0.0045
ERROR - 2019-11-26 17:23:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:01 --> Total execution time: 0.0112
ERROR - 2019-11-26 17:23:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:04 --> Total execution time: 0.0044
ERROR - 2019-11-26 17:23:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:06 --> Total execution time: 0.0026
ERROR - 2019-11-26 17:23:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:13 --> Total execution time: 0.0566
ERROR - 2019-11-26 17:23:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:15 --> Total execution time: 0.0037
ERROR - 2019-11-26 17:23:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:16 --> Total execution time: 0.0042
ERROR - 2019-11-26 17:23:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:28 --> Total execution time: 0.0613
ERROR - 2019-11-26 17:23:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:29 --> Total execution time: 0.0092
ERROR - 2019-11-26 17:23:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:31 --> Total execution time: 0.0113
ERROR - 2019-11-26 17:23:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:35 --> Total execution time: 0.0032
ERROR - 2019-11-26 17:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 17:23:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:36 --> Total execution time: 0.0046
DEBUG - 2019-11-26 17:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:36 --> Total execution time: 0.0024
ERROR - 2019-11-26 17:23:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:23:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:37 --> Total execution time: 0.0049
DEBUG - 2019-11-26 17:23:37 --> Total execution time: 0.0037
ERROR - 2019-11-26 17:23:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:38 --> Total execution time: 0.0028
ERROR - 2019-11-26 17:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-11-26 17:23:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:53 --> Total execution time: 0.0028
DEBUG - 2019-11-26 17:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:53 --> Total execution time: 0.0048
ERROR - 2019-11-26 17:23:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:58 --> Total execution time: 0.0052
ERROR - 2019-11-26 17:23:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:23:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:23:59 --> Total execution time: 0.0031
ERROR - 2019-11-26 17:24:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:24:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:24:00 --> Total execution time: 0.0026
ERROR - 2019-11-26 17:24:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:24:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:24:02 --> Total execution time: 0.0057
ERROR - 2019-11-26 17:24:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:24:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:24:05 --> Total execution time: 0.0045
ERROR - 2019-11-26 17:25:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:25:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:25:58 --> Total execution time: 0.0095
ERROR - 2019-11-26 17:26:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:26:24 --> Total execution time: 0.0118
ERROR - 2019-11-26 17:26:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:26:27 --> Total execution time: 0.0047
ERROR - 2019-11-26 17:26:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 17:26:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:30 --> Total execution time: 0.0057
DEBUG - 2019-11-26 17:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:26:30 --> Total execution time: 0.0026
ERROR - 2019-11-26 17:26:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:26:33 --> Total execution time: 0.0043
ERROR - 2019-11-26 17:26:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:26:41 --> Total execution time: 0.0071
ERROR - 2019-11-26 17:26:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:26:44 --> Total execution time: 0.0606
ERROR - 2019-11-26 17:26:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:26:46 --> Total execution time: 0.0099
ERROR - 2019-11-26 17:26:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:26:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:26:52 --> Total execution time: 0.1534
ERROR - 2019-11-26 17:28:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:28:15 --> Total execution time: 0.0705
ERROR - 2019-11-26 17:28:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:28:21 --> Total execution time: 0.0023
ERROR - 2019-11-26 17:28:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 17:28:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:22 --> Total execution time: 0.0037
DEBUG - 2019-11-26 17:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:28:22 --> Total execution time: 0.0028
ERROR - 2019-11-26 17:28:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:28:24 --> Total execution time: 0.0028
ERROR - 2019-11-26 17:28:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:28:26 --> Total execution time: 0.0049
ERROR - 2019-11-26 17:28:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:28:29 --> Total execution time: 0.0033
ERROR - 2019-11-26 17:28:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:28:31 --> Total execution time: 0.0064
ERROR - 2019-11-26 17:28:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:28:58 --> Total execution time: 0.0095
ERROR - 2019-11-26 17:29:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:29:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:29:02 --> Total execution time: 0.0023
ERROR - 2019-11-26 17:29:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:29:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:29:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:29:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:29:03 --> Total execution time: 0.0034
DEBUG - 2019-11-26 17:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:29:03 --> Total execution time: 0.0027
ERROR - 2019-11-26 17:29:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:29:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:29:07 --> Total execution time: 0.0027
ERROR - 2019-11-26 17:30:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:30:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:30:31 --> Total execution time: 0.0129
ERROR - 2019-11-26 17:30:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:30:35 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:30:35 --> Total execution time: 0.0028
ERROR - 2019-11-26 17:30:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:30:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:30:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:30:36 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:30:36 --> Total execution time: 0.0043
DEBUG - 2019-11-26 17:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:30:36 --> Total execution time: 0.0041
ERROR - 2019-11-26 17:30:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:30:40 --> Total execution time: 0.0023
ERROR - 2019-11-26 17:32:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:32:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:32:10 --> Total execution time: 0.0047
ERROR - 2019-11-26 17:32:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:32:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:32:11 --> Total execution time: 0.0024
ERROR - 2019-11-26 17:32:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:32:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:32:20 --> Total execution time: 0.0057
ERROR - 2019-11-26 17:32:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:32:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:32:30 --> Total execution time: 0.0084
ERROR - 2019-11-26 17:32:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:32:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:32:33 --> Total execution time: 0.0026
ERROR - 2019-11-26 17:32:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:32:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:32:34 --> Total execution time: 0.0051
ERROR - 2019-11-26 17:32:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:32:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:32:45 --> Total execution time: 0.0571
ERROR - 2019-11-26 17:32:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:32:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:32:45 --> Total execution time: 0.0110
ERROR - 2019-11-26 17:33:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:33:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:33:33 --> Total execution time: 0.0035
ERROR - 2019-11-26 17:33:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:33:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:33:34 --> Total execution time: 0.0028
ERROR - 2019-11-26 17:33:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:33:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:33:42 --> Total execution time: 0.0595
ERROR - 2019-11-26 17:33:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:33:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:33:48 --> Total execution time: 0.0045
ERROR - 2019-11-26 17:33:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:33:49 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:33:49 --> Total execution time: 0.0028
ERROR - 2019-11-26 17:33:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:33:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:33:57 --> Total execution time: 0.1269
ERROR - 2019-11-26 17:33:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:33:58 --> Total execution time: 0.0058
ERROR - 2019-11-26 17:34:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:34:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:34:58 --> Total execution time: 0.0025
ERROR - 2019-11-26 17:34:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:34:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:34:59 --> Total execution time: 0.0048
ERROR - 2019-11-26 17:35:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:00 --> Total execution time: 0.0048
ERROR - 2019-11-26 17:35:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:03 --> Total execution time: 0.0721
ERROR - 2019-11-26 17:35:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:11 --> Total execution time: 0.0090
ERROR - 2019-11-26 17:35:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:26 --> Total execution time: 0.0023
ERROR - 2019-11-26 17:35:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:28 --> Total execution time: 0.0031
ERROR - 2019-11-26 17:35:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 17:35:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:29 --> Total execution time: 0.0042
DEBUG - 2019-11-26 17:35:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:29 --> Total execution time: 0.0034
ERROR - 2019-11-26 17:35:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:31 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:31 --> Total execution time: 0.0040
ERROR - 2019-11-26 17:35:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:33 --> Total execution time: 0.0027
ERROR - 2019-11-26 17:35:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:45 --> Total execution time: 0.0055
ERROR - 2019-11-26 17:35:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:47 --> Total execution time: 0.0032
ERROR - 2019-11-26 17:35:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
ERROR - 2019-11-26 17:35:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:52 --> Total execution time: 0.0035
DEBUG - 2019-11-26 17:35:52 --> Total execution time: 0.0044
ERROR - 2019-11-26 17:35:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:54 --> Total execution time: 0.0027
ERROR - 2019-11-26 17:35:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:56 --> Total execution time: 0.0030
ERROR - 2019-11-26 17:35:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:57 --> Total execution time: 0.0040
ERROR - 2019-11-26 17:35:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:35:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:35:59 --> Total execution time: 0.0043
ERROR - 2019-11-26 17:36:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:36:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:36:22 --> Total execution time: 0.0111
ERROR - 2019-11-26 17:36:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:36:24 --> Total execution time: 0.0130
ERROR - 2019-11-26 17:40:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:09 --> Total execution time: 0.0023
ERROR - 2019-11-26 17:40:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:40:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:11 --> Total execution time: 0.0030
DEBUG - 2019-11-26 17:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:11 --> Total execution time: 0.0027
ERROR - 2019-11-26 17:40:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:40:13 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:13 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:13 --> Total execution time: 0.0045
DEBUG - 2019-11-26 17:40:13 --> Total execution time: 0.0036
ERROR - 2019-11-26 17:40:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:18 --> Total execution time: 0.0027
ERROR - 2019-11-26 17:40:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:19 --> Total execution time: 0.0062
ERROR - 2019-11-26 17:40:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:22 --> Total execution time: 0.0038
ERROR - 2019-11-26 17:40:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:24 --> Total execution time: 0.0032
ERROR - 2019-11-26 17:40:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:28 --> Total execution time: 0.0023
ERROR - 2019-11-26 17:40:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 17:40:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:38 --> Total execution time: 0.0029
DEBUG - 2019-11-26 17:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:38 --> Total execution time: 0.0026
ERROR - 2019-11-26 17:40:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:40 --> Total execution time: 0.0031
ERROR - 2019-11-26 17:40:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:41 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:41 --> Total execution time: 0.0033
ERROR - 2019-11-26 17:40:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:42 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:42 --> Total execution time: 0.0045
ERROR - 2019-11-26 17:40:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:44 --> Total execution time: 0.0038
ERROR - 2019-11-26 17:40:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:45 --> Total execution time: 0.0037
ERROR - 2019-11-26 17:40:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:47 --> Total execution time: 0.0031
ERROR - 2019-11-26 17:40:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:51 --> Total execution time: 0.0028
ERROR - 2019-11-26 17:40:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:52 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:52 --> Total execution time: 0.0055
ERROR - 2019-11-26 17:40:54 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:54 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:54 --> Total execution time: 0.0035
ERROR - 2019-11-26 17:40:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:55 --> Total execution time: 0.0049
ERROR - 2019-11-26 17:40:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:57 --> Total execution time: 0.0033
ERROR - 2019-11-26 17:40:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:40:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:40:58 --> Total execution time: 0.0043
ERROR - 2019-11-26 17:41:16 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:41:16 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:41:16 --> Total execution time: 0.0041
ERROR - 2019-11-26 17:41:20 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:41:20 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:41:20 --> Total execution time: 0.0023
ERROR - 2019-11-26 17:41:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:41:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:41:21 --> Total execution time: 0.0058
ERROR - 2019-11-26 17:41:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:41:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:41:22 --> Total execution time: 0.0035
ERROR - 2019-11-26 17:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 17:41:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:41:23 --> Total execution time: 0.0035
DEBUG - 2019-11-26 17:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:41:23 --> Total execution time: 0.0032
ERROR - 2019-11-26 17:41:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:41:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:41:27 --> Total execution time: 0.0044
ERROR - 2019-11-26 17:42:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:42:12 --> Total execution time: 0.0032
ERROR - 2019-11-26 17:42:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:42:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:42:15 --> Total execution time: 0.0033
ERROR - 2019-11-26 17:44:18 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:44:18 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:44:18 --> Total execution time: 0.0117
ERROR - 2019-11-26 17:44:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:44:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:44:24 --> Total execution time: 0.0035
ERROR - 2019-11-26 17:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:44:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:44:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:44:25 --> Total execution time: 0.0045
DEBUG - 2019-11-26 17:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:44:25 --> Total execution time: 0.0029
ERROR - 2019-11-26 17:44:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:44:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:44:28 --> Total execution time: 0.0035
ERROR - 2019-11-26 17:44:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:44:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:44:46 --> Total execution time: 0.0031
ERROR - 2019-11-26 17:53:55 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:53:55 --> Total execution time: 0.0105
ERROR - 2019-11-26 17:55:28 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:55:28 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:55:28 --> Total execution time: 0.0148
ERROR - 2019-11-26 17:56:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:56:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:56:46 --> Total execution time: 0.0126
ERROR - 2019-11-26 17:57:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:27 --> Total execution time: 0.0103
ERROR - 2019-11-26 17:57:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:40 --> Total execution time: 0.0049
ERROR - 2019-11-26 17:57:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:57:40 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-26 17:57:43 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:43 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:43 --> Total execution time: 0.0092
ERROR - 2019-11-26 17:57:44 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:44 --> Total execution time: 0.0043
ERROR - 2019-11-26 17:57:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:45 --> Total execution time: 0.0041
ERROR - 2019-11-26 17:57:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:47 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:47 --> Total execution time: 0.0041
ERROR - 2019-11-26 17:57:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:50 --> Total execution time: 0.0084
ERROR - 2019-11-26 17:57:50 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:50 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:57:50 --> 404 Page Not Found: Profile/logo.png
ERROR - 2019-11-26 17:57:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:56 --> Total execution time: 0.0042
ERROR - 2019-11-26 17:57:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20151012/php_curl.dll' - /usr/lib/php/20151012/php_curl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-11-26 17:57:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:58 --> Total execution time: 0.0105
ERROR - 2019-11-26 17:57:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:57:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:57:59 --> Total execution time: 0.0105
ERROR - 2019-11-26 17:58:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:00 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:00 --> Total execution time: 0.0100
ERROR - 2019-11-26 17:58:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:01 --> Total execution time: 0.0091
ERROR - 2019-11-26 17:58:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:03 --> Total execution time: 0.0095
ERROR - 2019-11-26 17:58:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:04 --> Total execution time: 0.0084
ERROR - 2019-11-26 17:58:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:05 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:05 --> Total execution time: 0.0085
ERROR - 2019-11-26 17:58:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:06 --> Total execution time: 0.0052
ERROR - 2019-11-26 17:58:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:58:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 17:58:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:58:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 17:58:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:58:06 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 17:58:06 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:58:06 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 17:58:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:08 --> Total execution time: 0.0042
ERROR - 2019-11-26 17:58:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:19 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:19 --> No URI present. Default controller set.
DEBUG - 2019-11-26 17:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:19 --> neha@mmd :: Neha@123
DEBUG - 2019-11-26 17:58:19 --> neha@mmd :: f3de5e16d00fe7056839f6018f1f52ca
DEBUG - 2019-11-26 17:58:19 --> Total execution time: 0.0626
ERROR - 2019-11-26 17:58:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:21 --> Total execution time: 0.0123
ERROR - 2019-11-26 17:58:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:22 --> Total execution time: 0.0073
ERROR - 2019-11-26 17:58:24 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:24 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:24 --> Total execution time: 0.0080
ERROR - 2019-11-26 17:58:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:25 --> Total execution time: 0.0115
ERROR - 2019-11-26 17:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:26 --> Total execution time: 0.0293
ERROR - 2019-11-26 17:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:58:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 17:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:58:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 17:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:58:26 --> 404 Page Not Found: Vendor/datatables
ERROR - 2019-11-26 17:58:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2019-11-26 17:58:26 --> 404 Page Not Found: Js/examples
ERROR - 2019-11-26 17:58:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:58:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:58:27 --> Total execution time: 0.0091
ERROR - 2019-11-26 17:59:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:59:03 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:59:03 --> Total execution time: 0.0093
ERROR - 2019-11-26 17:59:15 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:59:15 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:59:15 --> Total execution time: 0.0896
ERROR - 2019-11-26 17:59:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:59:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:59:27 --> Total execution time: 0.3394
ERROR - 2019-11-26 17:59:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 17:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 17:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 17:59:48 --> Total execution time: 0.1325
ERROR - 2019-11-26 18:00:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:00:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:00:07 --> Total execution time: 0.0664
ERROR - 2019-11-26 18:01:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:01:08 --> Total execution time: 0.0673
ERROR - 2019-11-26 18:01:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:01:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:01:25 --> Total execution time: 0.0140
ERROR - 2019-11-26 18:01:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:01:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:01:32 --> Total execution time: 0.1067
ERROR - 2019-11-26 18:01:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:01:59 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:02:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:02:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:02:22 --> Total execution time: 0.0082
ERROR - 2019-11-26 18:02:27 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:02:27 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:02:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:02:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:02:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:02:53 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:03:21 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:03:21 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:03:21 --> Total execution time: 0.0148
ERROR - 2019-11-26 18:03:30 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:03:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:03:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:03:32 --> Total execution time: 0.0068
ERROR - 2019-11-26 18:03:39 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:03:39 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:04:02 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:04:02 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:04:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:04:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:04:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:04:46 --> Total execution time: 0.0149
ERROR - 2019-11-26 18:04:58 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:04:58 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2019-11-26 18:05:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:05:10 --> Total execution time: 0.0659
ERROR - 2019-11-26 18:05:33 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:05:33 --> Total execution time: 0.0034
ERROR - 2019-11-26 18:05:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:05:34 --> Total execution time: 0.0029
ERROR - 2019-11-26 18:05:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:05:45 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:05:45 --> Total execution time: 0.0531
ERROR - 2019-11-26 18:05:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:05:46 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:05:46 --> Total execution time: 0.0759
ERROR - 2019-11-26 18:05:56 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:05:56 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:05:56 --> Total execution time: 0.0069
ERROR - 2019-11-26 18:06:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:06:01 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:06:01 --> Total execution time: 0.0589
ERROR - 2019-11-26 18:06:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:06:37 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:06:37 --> Total execution time: 0.0074
ERROR - 2019-11-26 18:06:40 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:06:40 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:06:40 --> Total execution time: 0.0054
ERROR - 2019-11-26 18:06:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:06:48 --> Total execution time: 0.0077
ERROR - 2019-11-26 18:06:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:06:51 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:06:51 --> Total execution time: 0.0031
ERROR - 2019-11-26 18:06:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:06:57 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:06:57 --> No URI present. Default controller set.
DEBUG - 2019-11-26 18:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:06:57 --> mmd :: Mmd@123
DEBUG - 2019-11-26 18:06:57 --> mmd :: 451e5aab7012b98a36d7847beb40ddc3
DEBUG - 2019-11-26 18:06:57 --> Total execution time: 0.0040
ERROR - 2019-11-26 18:07:04 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:07:04 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:07:04 --> No URI present. Default controller set.
DEBUG - 2019-11-26 18:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:07:04 --> mmd :: Mmd@1234
DEBUG - 2019-11-26 18:07:04 --> mmd :: 03db8e6e9a192f8a180c630bc79b3794
DEBUG - 2019-11-26 18:07:04 --> Total execution time: 0.0666
ERROR - 2019-11-26 18:07:07 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:07:07 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:07:07 --> Total execution time: 0.0100
ERROR - 2019-11-26 18:07:09 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:07:09 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:07:09 --> Total execution time: 0.0093
ERROR - 2019-11-26 18:07:11 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:07:11 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:07:11 --> Total execution time: 0.0108
ERROR - 2019-11-26 18:07:12 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:07:12 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:07:12 --> Total execution time: 0.0072
ERROR - 2019-11-26 18:07:22 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:07:22 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:07:23 --> Total execution time: 0.0659
ERROR - 2019-11-26 18:35:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:35:10 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:35:10 --> Total execution time: 0.0084
ERROR - 2019-11-26 18:35:17 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:35:17 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:35:17 --> Total execution time: 0.0026
ERROR - 2019-11-26 18:35:32 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:35:32 --> Total execution time: 0.0122
ERROR - 2019-11-26 18:35:34 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:35:34 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:35:34 --> Total execution time: 0.0091
ERROR - 2019-11-26 18:35:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:35:38 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:35:38 --> Total execution time: 0.0091
ERROR - 2019-11-26 18:36:25 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:36:25 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:36:25 --> Total execution time: 0.0124
ERROR - 2019-11-26 18:36:29 --> $config['composer_autoload'] is set to TRUE but /var/www/html/School19/application/vendor/autoload.php was not found.
DEBUG - 2019-11-26 18:36:29 --> UTF-8 Support Enabled
DEBUG - 2019-11-26 18:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-26 18:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-11-26 18:36:29 --> Total execution time: 0.0080
