<?php
$name='DejaVuSerifCondensed-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 939.0,
  'Descent' => -236.0,
  'CapHeight' => 939.0,
  'Flags' => 262148,
  'FontBBox' => '[-752 -389 1617 1235]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='/var/www/html/school/application/third_party/mpdf/ttfonts/DejaVuSerifCondensed-Bold.ttf';
$TTCfontID='0';
$originalsize=283140;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserifcondensedB';
$panose=' 0 0 2 6 8 6 5 6 5 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>