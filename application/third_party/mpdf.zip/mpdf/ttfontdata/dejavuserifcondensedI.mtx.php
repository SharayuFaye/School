<?php
$name='DejaVuSerifCondensed-Italic';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 68,
  'FontBBox' => '[-755 -347 1480 1227]',
  'ItalicAngle' => -11.0,
  'StemV' => 87.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='/var/www/html/school/application/third_party/mpdf/ttfonts/DejaVuSerifCondensed-Italic.ttf';
$TTCfontID='0';
$originalsize=302444;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserifcondensedI';
$panose=' 0 0 2 6 6 6 5 3 5 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>